package gregtechmod.api;

/**
 * You are allowed to include this File in your Download, as i will not change it.
 * This Interface is just needed to prevent the opening of GUIs when right clicking with an implementing Item
 */
public interface IIgnoreRightclickOnMachine {

}
