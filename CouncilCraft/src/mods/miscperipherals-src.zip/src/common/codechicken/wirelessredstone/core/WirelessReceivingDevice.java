package codechicken.wirelessredstone.core;

public interface WirelessReceivingDevice
{
	void updateDevice(int freq, boolean on);
}
