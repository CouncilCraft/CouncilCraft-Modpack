package codechicken.core;

public class Vector3 {
	public Vector3(double xCoord, double yCoord, double zCoord) {
		
	}
}
