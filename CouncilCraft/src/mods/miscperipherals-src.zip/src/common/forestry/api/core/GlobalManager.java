package forestry.api.core;

import java.util.ArrayList;

public class GlobalManager {

	public static ArrayList<Integer> dirtBlockIds = new ArrayList<Integer>();
	public static ArrayList<Integer> sandBlockIds = new ArrayList<Integer>();
	public static ArrayList<Integer> leafBlockIds = new ArrayList<Integer>();
	public static ArrayList<Integer> snowBlockIds = new ArrayList<Integer>();

}
