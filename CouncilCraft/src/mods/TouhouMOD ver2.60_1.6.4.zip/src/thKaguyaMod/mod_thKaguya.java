package thKaguyaMod;

import thKaguyaMod.client.ClientProxy;

import java.util.logging.Level;
import java.io.File;

import net.minecraft.src.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.*;
import net.minecraftforge.client.*;
import net.minecraftforge.common.EnumHelper;

//import net.minecraft.thKaguyaMod.block.*;

// Forge式コンフィグファイルを利用するためのAPI
import net.minecraftforge.common.Configuration;

import thKaguyaMod.block.*;
import thKaguyaMod.entity.*;
import thKaguyaMod.item.*;
import thKaguyaMod.tileentity.*;
import net.minecraft.util.ResourceLocation;

// FMLのログに出力するAPI
import cpw.mods.fml.common.FMLLog;

// プロキシシステムのためのアノテーション
import cpw.mods.fml.common.SidedProxy;

// FMLにロードさせるためのアノテーション
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.network.NetworkMod;

// 前初期化, 初期化のイベント
import cpw.mods.fml.common.event.*;
// Entityに関するレジストリ
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.VillagerRegistry;//村人に関するレジストリ

// 言語に関するレジストリ
import cpw.mods.fml.common.registry.LanguageRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.BiomeGenBase;

//レンダーに関するレジストリ
import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

// ModID   : mod固有の文字列, 
// name    : modの名前
// version : バージョン
@Mod(modid = "mod_thKaguya", name = "Itutu no Nandai MOD+", version = "2.60_1.6.4")
@NetworkMod(clientSideRequired = true, serverSideRequired = false)
public class mod_thKaguya
{
	
	
	// クライアント側とサーバー側で異なるインスタンスを生成
	@SidedProxy(clientSide = "thKaguyaMod.client.ClientProxy", serverSide = "thKaguyaMod.CommonProxy")
	public static CommonProxy proxy;
	
	// 自身のインスタンス
	@Mod.Instance("mod_thKaguya")//数行上の@Mod(modid = "......"で指定したmodid
	public static mod_thKaguya instance;
	
	private int itemIdBase;//五つの難題MOD+で追加されるアイテムIDの根底値
	
	//アイテム
	public static Item houraiedaItem;//蓬莱の玉の枝
	public static Item houraiPearlItem;//色真珠
	public static Item hotokehachiItem;//仏の御石の鉢
	public static Item hinezumiItem;//火鼠の皮衣
	public static Item koyasugaiItem;//燕の子安貝
	public static Item ryuutamaItem;//龍の頸の玉
	public static Item kinkakuziItem;//金閣寺の一枚天井
	public static Item roukankenItem;//楼観剣
	public static Item bentlarItem;//
	public static Item sakuyawatchItem;//咲夜の懐中時計
	public static Item sukimaItem;//スキマ
	public static Item thirdeyeItem;//第三の眼
	public static Item mazinkyoukanItem;//魔人経巻
	public static Item silverKnifeItem;//銀のナイフ
	public static Item heavenlyPeachItem;//天界の桃
	public static Item hisouItem;//緋想の剣
	public static Item houtouItem;//毘沙門天の宝塔
	public static Item pendulumItem;//ナズーリンペンデュラム
	public static Item treasureItem;//たから
	public static Item deathScytheItem;//死神の大鎌
	public static Item kaigoItem;//悔悟の棒
	public static Item hisyakuItem;//舟幽霊の柄杓（空）
	public static Item hisyaku2Item;//舟幽霊の柄杓（水入り）
	public static Item yuyukoOugiItem;//幽々子の扇
	public static Item hakkeroItem;//ミニ八卦炉
	public static Item oharaibouSItem;//風祝のお祓い帽
	public static Item onbashiraItem;//御柱
	public static Item kabenukenomiItem;//壁抜けの鑿
	public static Item mikoSwordItem;//豊聡耳の宝剣
	public static Item closedThirdEyeItem;//閉じた第三の眼
	public static Item homingAmuletItem;//ホーミングアミュレット
	public static Item yuukaParasolItem;//幽香の傘
	public static Item ajaRedStoneItem;//エイジャの赤石
	public static Item kappaCapItem;//河童の帽子
	public static Item spellCardItem;//スペルカード
	public static Item shotMaterialItem;//弾幕の素
	public static Item thShotItem;//単発ショット
	public static Item danmakuMemoItem;//弾幕記憶アイテム
	public static Item oharaibouRItem;//博麗のお祓い棒
	public static Item ibukihyouItem;//伊吹瓢
	public static Item tenguFanItem;//天狗の団扇
	public static Item marisaBroomItem;//魔理沙の箒
	public static Item pointItem;//点符アイテム
	public static Item powerItem;//パワーアイテム
	public static Item thLaserItem;//単発レーザーアイテム
	public static Item frandreRodItem;//フランの持っている棒
	public static Item kappaWaterPistolItem;//河童の水鉄砲
	public static Item hakuroukenItem;//白楼剣
	public static Item nuclearControlRodItem;//制御棒
	public static Item onmyoudamaItem;//陰陽玉
	public static Item uchideItem;//打ち出の小槌
	public static Item marisaHatItem;//魔理沙の帽子
	public static Item icicleSwordItem;//アイシクルソード
	public static Item kerobouItem;//諏訪子の帽子
	public static Item spearTheGungnirItem;//スピア・ザ・グングニル
	public static Item laevateinnItem;//レーヴァテイン
	//アイテムID
	private int houraiedaItemId;//蓬莱の玉の枝
	private int houraiPearlItemId;//色真珠
	private int hotokehachiItemId;//仏の御石の鉢
	private int hinezumiItemId;//火鼠の皮衣
	private int koyasugaiItemId;//燕の子安貝
	private int ryuutamaItemId;//龍の頸の玉
	private int kinkakuziItemId;//金閣寺の一枚天井
	private int roukankenItemId;//楼観剣
	private int bentlarItemId;//
	private int sakuyawatchItemId;//咲夜の懐中時計
	private int sukimaItemId;//スキマ
	private int thirdeyeItemId;//第三の眼
	private int mazinkyoukanItemId;//魔人経巻
	private int silverKnifeItemId;//銀のナイフ
	private int heavenlyPeachItemId;//天界の桃
	private int hisouItemId;//緋想の剣
	private int houtouItemId;//毘沙門天の宝塔
	private int pendulumItemId;//ナズーリンペンデュラム
	private int treasureItemId;//たから
	private int deathScytheItemId;//死神の大鎌
	private int kaigoItemId;//悔悟の棒
	private int hisyakuItemId;//舟幽霊の柄杓（空）
	private int hisyaku2ItemId;//舟幽霊の柄杓（水入り）
	private int yuyukoOugiItemId;//幽々子の扇
	private int hakkeroItemId;//ミニ八卦炉
	private int oharaibouSItemId;//風祝のお祓い帽
	private int onbashiraItemId;//御柱
	private int kabenukenomiItemId;//壁抜けの鑿
	private int mikoSwordItemId;//豊聡耳の宝剣
	private int closedThirdEyeItemId;//閉じた第三の眼
	private int homingAmuletItemId;//ホーミングアミュレット
	private int yuukaParasolItemId;//幽香の傘
	private int ajaRedStoneItemId;//エイジャの赤石
	private int kappaCapItemId;//河童の帽子
	private int spellCardItemId;//スペルカード
	private int shotMaterialItemId;//弾幕の素
	private int thShotItemId;//単発ショット
	private int danmakuMemoItemId;//弾幕記憶アイテム
	private int oharaibouRItemId;//博麗のお祓い棒
	private int ibukihyouItemId;//伊吹瓢
	private int tenguFanItemId;//天狗の団扇
	private int marisaBroomItemId;//魔理沙の箒
	private int pointItemId;//点符アイテム
	private int powerItemId;//パワーアイテム
	private int thLaserItemId;//単発レーザーアイテム
	private int frandreRodItemId;//フランの持ってる棒
	private int kappaWaterPistolItemId;//河童の水鉄砲
	private int hakuroukenItemId;//白楼剣
	private int nuclearControlRodItemId;//制御棒
	private int onmyoudamaItemId;//陰陽玉
	private int uchideItemId;//打ち出の小槌
	private int marisaHatItemId;//魔理沙の帽子
	private int icicleSwordItemId;//アイシクルソード
	private int kerobouItemId;//諏訪子の帽子
	private int spearTheGungnirItemId;//スピア・ザ・グングニル
	private int laevateinnItemId;//レーヴァテイン
	
	//ブロック
	public static Block danmakuCraftingTable;//弾幕作業台
	public static Block divineSpirit;//小神霊
	//ブロックID
	public static int danmakuCraftingTableBlockId;//弾幕作業台
	public static int divineSpiritBlockId;//小神霊
	
	//ブロックレンダーID
	public static int blockRenderId;
	
	//EntityID
	//private int entityIdEntityHouraiTama;
	private int entityIdEntityRyuuLightningBolt;
	private int entityIdEntityColorLightningBolt;
	private int entityIdEntityKinkakuzi;
	private int entityIdEntityPrivateSquare;
	private int entityIdEntitySilverKnife;
	private int entityIdEntitySukima;
	private int entityIdEntityMazinkyoukan;
	private int entityIdEntityHisou;
	//private int entityIdEntityKishitudan;
	private int entityIdEntityPendulum;
	//private int entityIdEntityButterflyShot;
	private int entityIdEntityMiniHakkero;
	private int entityIdEntityMiracleCircle;
	private int entityIdEntitySanaeWind;
	private int entityIdEntityUmiware;
	private int entityIdEntityYouryokuSpoiler;
	private int entityIdEntityMasterSpark;
	private int entityIdEntityHomingAmulet;
	//private int entityIdEntityUrokoShot;
	private int entityIdEntityYuukaParasol;
	private int entityIdEntityAjaRedStoneEffect;
	private int entityIdEntityAjaRedStoneLaser;
	private int entityIdEntityTHShot;
	private int entityIdEntityTHLaser;
	private int entityIdEntitySpellCard;
	private int entityIdEntityMusouFuuin;
	private int entityIdEntityHakureiShield;
	private int entityIdEntityMarisaBroom;
	private int entityIdEntityNuclearShot;
	private int entityIdEntityHakurouReflecter;
	
	private int entityIdEntityTHFairy;
	private int entityIdEntityDanmakuCreeper;//ハナビーパー
	private int entityIdEntityObjectEye;//
	
	private int entityIdEntityTHHenyoriLaser;//へにょりレーザー
	
	private int entityIdEntityOnmyoudama;//陰陽玉
	
	private int entityIdEntityTHFairyCirno;//チルノ
	
	private int entityIdEntityTHSetLaser;//固定レーザー
	
	private int entityIdEntityDivineSpirit;//小神霊
	
	//
	private ItemStack redPearl;
	private ItemStack bluePearl;
	private ItemStack greenPearl;
	private ItemStack yellowPearl;
	private ItemStack purplePearl;
	private ItemStack aquaPearl;
	private ItemStack orangePearl;
	private ItemStack silverKnifeBlue;
	private ItemStack silverKnifeRed;
	private ItemStack silverKnifeGreen;
	private ItemStack silverKnifeWhite;
	private ItemStack smallShot;
	private ItemStack tinyShot;
	private ItemStack mediumShot;
	private ItemStack bigShot;
	private ItemStack starShot;
	private ItemStack smallStarShot;
	private ItemStack circleShot;
	private ItemStack scaleShot;
	private ItemStack butterflyShot;
	private ItemStack lightShot;
	private ItemStack knifeShot;
	private ItemStack heartShot;
	private ItemStack kunaiShot;
	private ItemStack talismanShot;
	private ItemStack bigLightShot;
	private ItemStack riceShot;
	private ItemStack ovalShot;
	private ItemStack laser1;
	private ItemStack laser2;
	private ItemStack laser3;
	private ItemStack smallPowerUpItem;
	private ItemStack bigPowerUpItem;
	private ItemStack homingAmulet;
	private ItemStack diffusionAmulet;
	
	private ItemStack danmakuCraftingTable_shot;
	private ItemStack danmakuCraftingTable_laser;
	
	private ItemStack divineSpirit_red;
	private ItemStack divineSpirit_blue;
	private ItemStack divineSpirit_green;
	private ItemStack divineSpirit_yellow;
	private ItemStack divineSpirit_purple;
	private ItemStack divineSpirit_aqua;
	private ItemStack divineSpirit_orange;
	private ItemStack divineSpirit_white;
	
	//GUI
	public static int guiDanmakuCraftingID = 0;
	public static int guiDanmakuCraftingLaserID = 1;
	
	//スペルカードの英語名
	public static final String scEnName[] = {
		"Spirit Sign \"Fantasy Seal\"",
		"Love Sign \"Master Spark\"" ,
		"Deadly Butterfly \"Everlasting Nap\"",
		"Star Sign \"Meteonic Shower\"",
		"Boundary Sign \"Boundary between Wave and Particle\"",
		"Sinister Spirits \"Double Black Death Butterfly\"", 
		"Scarlet Sign \"Scarlet Shoot\"",
		"\"Sky of Scarlet Perception of All Humankind\"",
		"Maid Secret Skill \"Killing Doll\"",
		"Freeze Sign \"Perfect Freeze\"",
		"Fantasy Nest \"Flying-glowworm Nest\"" ,
		"Water Sign \"Kappa's Pororoca\"",
		"Magic Sign \"Stardust Reverie\"",
		"Native God \"Kero-chan Braves the Wind and Rain\"",
		"Miracle \"Miracle Fruit\"", 
		"Miracle \"Miracle of Fafrotskies\"",
		"Youkai Extermination \"Bewitching Power Spoiler\"",
		"Sea Opening \"Moses's Miracle\"",
		"Great Miracle \"Yasaka's Divine Wind\"",
		"Ice Sign \"Icicle Fall\"",
		"Forbidden Barrage \"Starbow Break\"",
		"Forbidden Barrage \"Catadioptric\"",
		"Scourge Sign \"Mishaguji-sama\"",
		"\"Red Magic\"",
		"Conjuring \"Eternal Meek\"" ,
		"Love Sign \"Non-Directional Laser\"",
		"Fantasy \"The Beauty of Nature\"",
		"Divine Spear \"Spear the Gungnir\"" 
	};
	
	//スペルカードの日本語名
	public static final String scJpName[] = {
		"霊符「夢想封印」",
		"恋符「マスタースパーク」",
		"死蝶「華胥の永眠」",
		"星符「メテオニックシャワー」",
		"境符「波と粒の境界」",
		"魍魎「二重黒死蝶」",
		"紅符「スカーレットシュート」",
		"「全人類の緋想天」",
		"メイド秘技「殺人ドール」",
		"凍符「パーフェクトフリーズ」",
		"幻巣「飛光虫ネスト」",
		"水符「河童のポロロッカ」",
		"魔符「スターダストレヴァリエ」",
		"土着神「ケロちゃん風雨に負けず」",
		"奇跡「ミラクルフルーツ」",
		"奇跡「ファフロッキーズの奇跡」",
		"妖怪退治「妖力スポイラー」",
		"開海「モーゼの奇跡」",
		"大奇跡「八坂の神風」",
		"氷符「アイシクルフォール」",
		"禁弾「スターボウブレイク」",
		"禁弾「カタディオプトリック」",
		"祟符「ミシャグジさま」",
		"「レッドマジック」",
		"奇術「エターナルミーク」",
		"恋符「ノンディレクショナルレーザー」",
		"幻想「花鳥風月、嘯風弄月」",
		"神槍「スピア・ザ・グングニル」"
	};
	
	//スペルカードの中国語（簡体字）名
	public static final String scCnName[] = {
		"灵符「梦想封印」",
		"恋符「Master Spark」",
		"死蝶「华胥的永眠」",
		"星符「Meteonic Shower」",
		"境符「波与粒的境界」",
		"魍魉「二重黑死蝶」",
		"红符「Scarlet Shoot」",
		"「全人类的绯想天」",
		"女仆秘技「杀人玩偶」",
		"冻符「Perfect Freeze」",
		"幻巢「飞光虫之巢」",
		"水符「河童之河口浪潮」",
		"魔符「Stardust Reverie」",
		"土著神「小小青蛙不输风雨」",
		"奇迹「Miracle Fruit」",
		"奇迹「空中落物的奇迹」",
		"妖怪退治「妖力掠夺者」",
		"开海「摩西的奇迹」",
		"大奇迹「八坂之神风」",
		"冰符「Icicle Fall」",
		"禁弹「Starbow Break」",
		"禁弹「Catadioptric」",
		"Scourge Sign \"Mishaguji-sama\"",
		"\"Red Magic\"",
		"Conjuring \"Eternal Meek\"",
		"恋符「Non-Directional Laser」",
		"Fantasy \"The Beauty of Nature\"",
		"Divine Spear \"Spear the Gungnir\""
	};
	
	//スペルカードの中国語（繁体字）名
	public static final String scTwName[] = {
		"靈符「夢想封印」",
		"戀符「Master Spark」",
		"死蝶「華胥的永眠」",
		"星符「Meteonic Shower」",
		"境符「波與粒的境界」",
		"魍魎「二重黑死蝶」",
		"紅符「Scarlet Shoot」",
		"「全人類的緋想天」",
		"女僕秘技「殺人玩偶」",
		"凍符「Perfect Freeze」",
		"幻巢「飛光蟲之巢」",
		"水符「河童之河口浪潮」",
		"魔符「Stardust Reverie」",
		"土著神「小小青蛙不輸風雨」",
		"奇跡「Miracle Fruit」",
		"奇跡「空中落物的奇跡」",
		"妖怪退治「妖力掠奪者」",
		"開海「摩西的奇跡」",
		"大奇跡「八阪之神風」",
		"冰符「Icicle Fall」",
		"禁彈「Starbow Break」",
		"禁彈「Catadioptric」",
		"Scourge Sign \"Mishaguji-sama\"",
		"\"Red Magic\"",
		"Conjuring \"Eternal Meek\"",
		"戀符「Non-Directional Laser」",
		"Fantasy \"The Beauty of Nature\"",
		"Divine Spear \"Spear the Gungnir\""
	};
	
	private ItemStack[] spellCard = new ItemStack[scEnName.length];
	
	//防具の素材設定
	static EnumArmorMaterial enumArmorHinezumi;
	static EnumArmorMaterial enumArmorMarisa;
	static EnumArmorMaterial enumArmorSuwako;
	
	public static int hinezumiIndex; 
	public static int marisaIndex;
	public static int suwakoIndex;
	
	//武器の素材設定
	public static EnumToolMaterial enumRoukanken = EnumHelper.addToolMaterial("roukanken", 0, 251, 4.0F, 3.0F, 0);
	public static EnumToolMaterial enumHakurouken = EnumHelper.addToolMaterial("hakurou", 0, 100, 0.0F, 0.0F, 0);
	public static EnumToolMaterial enumHisou = EnumHelper.addToolMaterial("hisou", 0, 200, 4.0F, 0.0F, 0);
	public static EnumToolMaterial enumKaigo = EnumHelper.addToolMaterial("kaigo", 0, 1, 0.0F, -4.0F, 0);
	public static EnumToolMaterial enumIcicle = EnumHelper.addToolMaterial("icicle", 0, 30, 0.0F, 2.0F, 0);
	public static EnumToolMaterial enumLaevateinn = EnumHelper.addToolMaterial("laevateinn", 0, 95, 9.0F, 3.0F, 0);
	
	
	//スキマの効果音の設定
	public static String sukimaWarpSE = "mob.endermen.portal";
	//public static String sukimaWarpSE = "random.sukima";
	
	//コンフィグで変更できる変数
	private int setSpellCardVol;
	private int setMasterSparkVol;
	private int setHisoutenVol;
	public static float SpellCardVol;//スペルカード音の音量
	public static float MasterSparkVol;//マスタースパークの音量
	public static float HisoutenVol;	//全人類の緋想天の音量
	public static boolean UsingMasterSpark;//マスタースパークが使用できるか
	public static boolean MasterSparkDestroysBlocks;//マスタースパークでブロックを破壊できるか
	public static boolean useDefaultGapSE;//デフォルトのスキマのSEを使うかどうか
	public static boolean spawnFairy;//妖精が自然スポーンするか
	public static int danmakuLevel;//弾幕のレベル 1～4を指定して、1がEasy、4がLunatic。 0は弾を出さない
	public static int fairySpawnRate;//妖精のスポーンする率。
	public static boolean isSpawnHanabeeper;//ハナビーパーが自然すぽーんするか
	
	public static boolean danmakuOneKillMode;//弾幕攻撃に当たると即死するモードにするかの設定
	public static boolean canUseWallPassingChisel;//壁抜けの鑿が使用できるかどうか
	public static int shotMaxNumber;//弾アイテムで出せる弾幕の限界量
	public static int laserMaxNumber;//レーザーアイテムで出せる弾幕の限界量
	
	//クリエイティブタグの登録
	public static final CreativeTabs tabSpellCard = new CreativeTabSpellCard("spellcard");//スペルカードのタグを追加
	
	// 前処理
	//@Mod.PreInit
	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent event)
	{
		Configuration cfg = new Configuration(event.getSuggestedConfigurationFile());
		//VillagerRegistry villagerRegistry = VillagerRegistry.instance();
		try
		{
			cfg.load();
			//ItemIDのコンフィグ
			// 設定する変数    = cfg.get("カテゴリ名", "項目名", 設定する値).getInt();       
			itemIdBase         = cfg.get("ItemID"  , "ItemID Base", 4360).getInt();//ItemIDの出発点のコンフィグ設定
			houraiedaItemId      	= itemIdBase+ 0;
			houraiPearlItemId    	= itemIdBase+ 1;
			shotMaterialItemId   	= itemIdBase+ 2;
			thShotItemId         	= itemIdBase+ 3;
			thLaserItemId        	= itemIdBase+ 4;
			oharaibouRItemId     	= itemIdBase+ 5;
			hotokehachiItemId    	= itemIdBase+ 6;
			hinezumiItemId       	= itemIdBase+ 7;
			koyasugaiItemId      	= itemIdBase+ 8;
			ryuutamaItemId       	= itemIdBase+ 9;
			kinkakuziItemId      	= itemIdBase+10;
			ajaRedStoneItemId    	= itemIdBase+11;
			
			hisyaku2ItemId       	= itemIdBase+13;
			hisyakuItemId        	= itemIdBase+14;
			deathScytheItemId    	= itemIdBase+15;
			kaigoItemId          	= itemIdBase+16;
			
			//houtouItemId         	= itemIdBase+17;
			
			pendulumItemId       	= itemIdBase+18;
			hakuroukenItemId     	= itemIdBase+19;
			roukankenItemId      	= itemIdBase+20;
			sakuyawatchItemId    	= itemIdBase+21;
			silverKnifeItemId    	= itemIdBase+22;
			sukimaItemId         	= itemIdBase+23;
			thirdeyeItemId       	= itemIdBase+24;
			mazinkyoukanItemId   	= itemIdBase+25;
			heavenlyPeachItemId  	= itemIdBase+26;
			hisouItemId          	= itemIdBase+27;
			yuyukoOugiItemId     	= itemIdBase+28;
			oharaibouSItemId     	= itemIdBase+29;
			onbashiraItemId			= itemIdBase+30;
			
			homingAmuletItemId		= itemIdBase+32;
			hakkeroItemId			= itemIdBase+33;
			marisaBroomItemId       = itemIdBase+34;
			kabenukenomiItemId      = itemIdBase+35;
			mikoSwordItemId         = itemIdBase+36;
			closedThirdEyeItemId    = itemIdBase+37;
			yuukaParasolItemId      = itemIdBase+38;
			kappaCapItemId          = itemIdBase+39;
			spellCardItemId         = itemIdBase+40;
			ibukihyouItemId         = itemIdBase+41;
			tenguFanItemId          = itemIdBase+42;
			pointItemId             = itemIdBase+43;
			powerItemId             = itemIdBase+44;
			kappaWaterPistolItemId  = itemIdBase+45;
			nuclearControlRodItemId = itemIdBase+46;
			frandreRodItemId      	= itemIdBase+47;
			onmyoudamaItemId        = itemIdBase+48;
			uchideItemId			= itemIdBase+49;
			marisaHatItemId			= itemIdBase+50;
			icicleSwordItemId		= itemIdBase+51;
			kerobouItemId			= itemIdBase+52;
			spearTheGungnirItemId	= itemIdBase+53;
			laevateinnItemId		= itemIdBase+54;
			
			//BlockIDのコンフィグ
			danmakuCraftingTableBlockId = cfg.get("BlockID"  , "DanmakuCraftingTable", 3119).getInt();
			divineSpiritBlockId			= cfg.get("BlockID"  , "DivineSpirit", 3120).getInt();
			
			//EntityIDのコンフィグ
			entityIdEntityTHFairy            = cfg.get("EntityID", "Fairy"                     ,530).getInt();
			entityIdEntityRyuuLightningBolt  = cfg.get("EntityID", "Brilliant Dragon Bullet"   ,531).getInt();
			entityIdEntityColorLightningBolt = cfg.get("EntityID", "Color LightningBolt"       ,532).getInt();
			entityIdEntityKinkakuzi          = cfg.get("EntityID", "Kinkakuzi "                ,533).getInt();
			entityIdEntityPrivateSquare      = cfg.get("EntityID", "Sakuya's Pocket Watch"     ,534).getInt();
			entityIdEntitySilverKnife        = cfg.get("EntityID", "Silver Knife"              ,535).getInt();
			entityIdEntitySukima             = cfg.get("EntityID", "Sukima "                   ,536).getInt();
			entityIdEntityMazinkyoukan       = cfg.get("EntityID", "Mazinkyoukan "             ,537).getInt();
			entityIdEntityHisou              = cfg.get("EntityID", "Hisou Sword"               ,538).getInt();
			entityIdEntityObjectEye          = cfg.get("EntityID", "Object Eye"                ,539).getInt();
			entityIdEntityPendulum           = cfg.get("EntityID", "Nazrin Pendulum"           ,540).getInt();
			////entityIdEntityButterflyShot      = cfg.get("EntityID", "Butterfly Shot"            ,541).getInt();
			
			entityIdEntityMiracleCircle      = cfg.get("EntityID", "Miracle Magic Square"      ,542).getInt();
			entityIdEntitySanaeWind          = cfg.get("EntityID", "Sanae Wind"                ,543).getInt();
			entityIdEntityUmiware            = cfg.get("EntityID", "Miracle of Moses"          ,544).getInt();
			entityIdEntityYouryokuSpoiler    = cfg.get("EntityID", "Youryoku Spoiler"          ,545).getInt();
			entityIdEntityMiniHakkero        = cfg.get("EntityID", "MiniHakkero "              ,546).getInt();
			entityIdEntityMasterSpark        = cfg.get("EntityID", "MasterSpark "              ,547).getInt();
			entityIdEntityHomingAmulet       = cfg.get("EntityID", "Homing Amulet"             ,548).getInt();
			//entityIdEntityUrokoShot          = cfg.get("EntityID", "Uroko Shot"                ,549).getInt();
			entityIdEntityYuukaParasol       = cfg.get("EntityID", "Yuuka Parasol"             ,550).getInt();
			entityIdEntityAjaRedStoneEffect  = cfg.get("EntityID", "Effect of Red Stone of Aja",551).getInt();
			entityIdEntityMarisaBroom        = cfg.get("EntityID", "Marisa Broom"              ,552).getInt();
			entityIdEntityTHShot             = cfg.get("EntityID", "Normal Shot"               ,553).getInt();
			entityIdEntityTHLaser            = cfg.get("EntityID", "Normal Laser"              ,554).getInt();
			entityIdEntitySpellCard          = cfg.get("EntityID", "Spell Card"                ,555).getInt();
			entityIdEntityMusouFuuin         = cfg.get("EntityID", "Musou Fuuin"               ,556).getInt();
			//entityIdEntityHakureiShield      = cfg.get("EntityID", "Hakurei Shield"            ,541).getInt();
			//entityIdEntityTHHenyoriLaser     = cfg.get("EntityID", "Henyori Laser"             ,549).getInt();
			entityIdEntityDanmakuCreeper     = cfg.get("EntityID", "Danmaku Creeper"             ,557).getInt();
			entityIdEntityNuclearShot        = cfg.get("EntityID", "Nuclear Shot"              ,558).getInt();
			entityIdEntityHakurouReflecter   = cfg.get("EntityID", "Hakurou Reflecter"         ,559).getInt();
			entityIdEntityOnmyoudama         = cfg.get("EntityID", "Onmyoudama"                ,560).getInt();
			entityIdEntityTHFairyCirno       = cfg.get("EntityID", "Cirno"                     ,561).getInt();
			entityIdEntityTHSetLaser         = cfg.get("EntityID", "Set Laser"                 ,549).getInt();
			entityIdEntityDivineSpirit       = cfg.get("EntityID", "Divine Spirit"             ,562).getInt();
			
			/*File sukimaFile = new File("../resources/mod/sound/random/sukima.wav");
			if(sukimaFile.exists())
			{
				sukimaWarpSE = "random.sukima";
			}*/
			
			//SEのボリュームのコンフィグ
			setSpellCardVol   = cfg.get("SE vol", "SpellCarVol"   , 50).getInt();
			setMasterSparkVol = cfg.get("SE vol", "MasterSparkVol", 50).getInt();
			setHisoutenVol    = cfg.get("SE vol", "HisoutenVol"   , 20).getInt();
			
			if(setSpellCardVol > 500)setSpellCardVol = 500;
			if(setMasterSparkVol > 500)setMasterSparkVol = 500;
			if(setHisoutenVol > 500)setHisoutenVol = 500;
			SpellCardVol = (float)setSpellCardVol / 100F;
			MasterSparkVol = (float)setMasterSparkVol / 100F;
			HisoutenVol = (float)setHisoutenVol / 100F;
			
			UsingMasterSpark = true;
			//マスタースパークの使用ができるか？
			UsingMasterSpark = cfg.get("Other", "Using the MasterSpark", true).getBoolean(true);
			//マスタースパークが地形を破壊するかどうか
			MasterSparkDestroysBlocks = cfg.get("Other", "MasterSpark destroys blocks", true).getBoolean(true);
			//壁抜けの鑿の仕様を許可するか
			canUseWallPassingChisel = cfg.get("Other", "Can Use Wall-Passing Chisel", true).getBoolean(true);
			//スキマのSEをデフォルトのものを使うか
			useDefaultGapSE = cfg.get("Other", "Using default Gap(Sukima)SE", true).getBoolean(true);
			if(!useDefaultGapSE)
			{
				sukimaWarpSE = "thKaguyaMod.sukima";
			}
			
			//妖精が出現するか
			spawnFairy = cfg.get("Other", "Spawn Fairy", true).getBoolean(false);
			//妖精の出す弾幕のレベル デフォルトはノーマル
			danmakuLevel    = cfg.get("Game Mode", "Danmaku Level"   , 2).getInt();
			if(danmakuLevel > 20)
			{
				danmakuLevel = 20;
			}
			//弾幕攻撃で即死するモードにするか
			danmakuOneKillMode = cfg.get("Game Mode", "Danmaku 1 Kill Mode", false).getBoolean(false);
			//妖精の出現確率
			fairySpawnRate    = 100 - cfg.get("Other", "Fairy Spawn Rate(%)"   , 50).getInt();
			
			//ハナビーパーが出現するか
			isSpawnHanabeeper = cfg.get("Other", "Is Spawn Hanabeeper", false).getBoolean(false);
			
			//弾アイテムで出せる弾幕の限界量
			shotMaxNumber    = cfg.get("Game Mode", "Shot Max Number"   , 32).getInt();
			//レーザーアイテムで出せる弾幕の限界量
			laserMaxNumber   = cfg.get("Game Mode", "Laser Max Number"   , 8).getInt();
			
			
			
			//villagerRegistry.registerVillagerId(6);
			//villagerRegistry.registerVillagerSkin(6, new ResourceLocation("thkaguyamod", "textures/Rinnosuke.png"));
		}
		catch (Exception e)
		{
			// 失敗した場合強制終了
			FMLLog.log(Level.SEVERE, e, "Error Massage");
		}
		finally
		{
			cfg.save();
		}
	}
	
	/*@SideOnly(Side.CLIENT)
	public void loadArmorTexture()
	{
		hinezumiIndex = RenderingRegistry.addNewArmourRendererPrefix("hinezumi");
	}*/
	
	// load()に相当
	//@Mod.Init
	@Mod.EventHandler
	public void init(FMLInitializationEvent event)
	{
		enumArmorHinezumi = EnumHelper.addArmorMaterial("HINEZUMI",1, new int[] {1, 2, 2, 2}, 0);//新しいアーマー素材を登録
		enumArmorMarisa   = EnumHelper.addArmorMaterial("MARISA", 1, new int[]{1,  1, 1, 1}, 0);
		enumArmorSuwako   = EnumHelper.addArmorMaterial("SUWAKO", 1, new int[] {1, 1, 1,1}, 0);
		hinezumiIndex = proxy.addArmor("HINEZUMI");
		marisaIndex = proxy.addArmor("MARISA");
		suwakoIndex = proxy.addArmor("SUWAKO");
		blockRenderId = proxy.getNewRenderType();
		
		houraiedaItem = new ItemHouraiEda(houraiedaItemId).setUnlocalizedName("houraiEda");
		hotokehachiItem = new ItemHotokeHachi(hotokehachiItemId,EnumToolMaterial.STONE).setUnlocalizedName("hotokeHachi");
		ryuutamaItem = new ItemRyuuTama(ryuutamaItemId).setUnlocalizedName("ryuuTama");
		hinezumiItem = new ItemHinezumi(hinezumiItemId,enumArmorHinezumi, hinezumiIndex, 1).setUnlocalizedName("hinezumi");
		//hinezumiItem = new ItemHinezumi(hinezumiItemId,EnumArmorMaterial.CHAIN, hinezumiindex, 1).setIconCoord(3,0).setItemName("hinezumiItem");
		koyasugaiItem = new ItemKoyasugai(koyasugaiItemId, 0, false).setUnlocalizedName("koyasugai");
		houraiPearlItem = new ItemHouraiPearl(houraiPearlItemId).setUnlocalizedName("houraiPearl");
		kinkakuziItem = new ItemKinkakuzi(kinkakuziItemId).setUnlocalizedName("kinkakuzi");
		hisyaku2Item = new ItemHisyaku(hisyaku2ItemId, 1).setUnlocalizedName("emptyHisyaku");
		hisyakuItem = new ItemHisyaku(hisyakuItemId, 0).setUnlocalizedName("hisyaku");
		//hisyaku2Item = new ItemHisyaku2(hisyaku2ItemId).setIconCoord(4,6).setItemName("Hisyaku2Item");
		deathScytheItem = new ItemDeathScythe(deathScytheItemId, EnumToolMaterial.IRON).setUnlocalizedName("deathScythe");
		kaigoItem = new ItemKaigo(kaigoItemId, enumKaigo).setUnlocalizedName("kaigoStick");
		
		GameRegistry.registerItem(kaigoItem, "kaigo");
		
		//houtouItem = new ItemHoutou(houtouItemId).setUnlocalizedName("houtou");
		pendulumItem = new ItemPendulum(pendulumItemId).setUnlocalizedName("pendulum");
		hakuroukenItem= new ItemHakurouken(hakuroukenItemId, enumHakurouken).setUnlocalizedName("hakurouken");
		
		GameRegistry.registerItem(hakuroukenItem, "hakurouken");
		roukankenItem = new ItemRoukanken(roukankenItemId, enumRoukanken).setUnlocalizedName("roukanSword");
		
		GameRegistry.registerItem(roukankenItem, "roukanken");
		
		sakuyawatchItem = new ItemSakuyaWatch(sakuyawatchItemId).setUnlocalizedName("sakuyaWatch");
		silverKnifeItem = new ItemSilverKnife(silverKnifeItemId).setUnlocalizedName("silverKnife");
		sukimaItem = new ItemSukima(sukimaItemId).setUnlocalizedName("sukima");
		thirdeyeItem = new ItemThirdEye(thirdeyeItemId).setUnlocalizedName("thirdEye");
		mazinkyoukanItem = new ItemMazinKyoukan(mazinkyoukanItemId).setUnlocalizedName("mazinKyoukan");
		heavenlyPeachItem = new ItemHeavenlyPeach(heavenlyPeachItemId, 2, true).setUnlocalizedName("heavenlyPeach");
		hisouItem = new ItemHisou(hisouItemId, enumHisou).setUnlocalizedName("hisouSword");
		
		GameRegistry.registerItem(hisouItem, "hisou");
		
		yuyukoOugiItem = new ItemYuyukoFan(yuyukoOugiItemId).setUnlocalizedName("yuyukoOugi");
		oharaibouSItem = new ItemOharaibouS(oharaibouSItemId).setUnlocalizedName("mikoStick_S");
		onbashiraItem = new ItemOnbashira(onbashiraItemId, EnumToolMaterial.WOOD).setUnlocalizedName("onbashira");
		
		//GameRegistry.registerItem(onbashiraItem, "onbashira");
		
		hakkeroItem = new ItemMiniHakkero(hakkeroItemId).setUnlocalizedName("miniHakkero");
		kabenukenomiItem = new ItemKabenuke(kabenukenomiItemId).setUnlocalizedName("kabenuke");
		mikoSwordItem = new ItemMikoSword(mikoSwordItemId, EnumToolMaterial.IRON).setUnlocalizedName("toyosatomimiSword");
		closedThirdEyeItem = new ItemClosedThirdEye(closedThirdEyeItemId).setUnlocalizedName("closedThirdEye");
		homingAmuletItem = new ItemHomingAmulet(homingAmuletItemId).setUnlocalizedName("homingAmulet");
		yuukaParasolItem = new ItemYuukaParasol(yuukaParasolItemId).setUnlocalizedName("yuukaParasol");
		ajaRedStoneItem = new ItemAjaRedStone(ajaRedStoneItemId).setUnlocalizedName("ajaRedStone");
		kappaCapItem = new ItemKappaCap(kappaCapItemId,enumArmorHinezumi, hinezumiIndex, 0).setUnlocalizedName("kappaCap");
		spellCardItem = new ItemSpellCard(spellCardItemId).setUnlocalizedName("spellCard/0");
		shotMaterialItem = new ItemShotMaterial(shotMaterialItemId).setUnlocalizedName("shotMaterial");
		thShotItem = new ItemTHShot(thShotItemId).setUnlocalizedName("thShot");
		//danmakuMemoItem = new ItemDanmakuMemo(danmakuMemoItemId).setUnlocalizedName("shotMaterial");
		oharaibouRItem = new ItemOharaibouR(oharaibouRItemId).setUnlocalizedName("hakureiOharaibou");
		ibukihyouItem = new ItemIbukihyou(ibukihyouItemId, 0, false).setUnlocalizedName("ibukihyou");
		tenguFanItem = new ItemTenguFan(tenguFanItemId).setUnlocalizedName("tenguFan");
		marisaBroomItem = new ItemMarisaBroom(marisaBroomItemId).setUnlocalizedName("magicBroom");
		pointItem = new ItemTHPointItem(pointItemId).setUnlocalizedName("THPointItem");
		powerItem = new ItemTHPowerItem(powerItemId).setUnlocalizedName("THPowerItem");
		thLaserItem = new ItemTHLaser(thLaserItemId).setUnlocalizedName("thLaser");
		kappaWaterPistolItem = new ItemKappaWaterPistol(kappaWaterPistolItemId).setUnlocalizedName("kappaWaterPistol");
		nuclearControlRodItem = new ItemNuclearControlRod(nuclearControlRodItemId).setUnlocalizedName("nuclearControlRod");
		//frandreRodItem = new ItemFrandreRod(frandreRodItemId, EnumToolMaterial.IRON).setUnlocalizedName("frandreRod");
		onmyoudamaItem = new ItemOnmyoudama(onmyoudamaItemId).setUnlocalizedName("onmyoudama");
		uchideItem = new ItemUchide(uchideItemId).setUnlocalizedName("uchide");
		marisaHatItem = new ItemMarisaHat(marisaHatItemId,enumArmorMarisa, marisaIndex, 0).setUnlocalizedName("marisaHat");
		icicleSwordItem = new ItemIcicleSword(icicleSwordItemId, enumIcicle).setUnlocalizedName("icicleSword");
		kerobouItem = new ItemKerobou(kerobouItemId,enumArmorSuwako, suwakoIndex, 0).setUnlocalizedName("kerobou");
		spearTheGungnirItem = new ItemSpearTheGungnir(spearTheGungnirItemId).setUnlocalizedName("spearTheGungnir");
		laevateinnItem = new ItemLaevateinn(laevateinnItemId, enumLaevateinn).setUnlocalizedName("Laevateinn");
		
		GameRegistry.registerItem(icicleSwordItem, "icicle");
		
		redPearl    = new ItemStack(houraiPearlItem,1, 0);
		bluePearl   = new ItemStack(houraiPearlItem,1, 1);
		greenPearl  = new ItemStack(houraiPearlItem,1, 2);
		yellowPearl = new ItemStack(houraiPearlItem,1, 3);
		purplePearl = new ItemStack(houraiPearlItem,1, 4);
		aquaPearl   = new ItemStack(houraiPearlItem,1, 5);
		orangePearl = new ItemStack(houraiPearlItem,1, 6);

		silverKnifeBlue  = new ItemStack(silverKnifeItem,4, 0);
		silverKnifeRed   = new ItemStack(silverKnifeItem,2, 1);
		silverKnifeGreen = new ItemStack(silverKnifeItem,2, 2);
		silverKnifeWhite = new ItemStack(silverKnifeItem,1, 3);
		
		smallShot = new ItemStack(thShotItem, 1, 0);
		tinyShot  = new ItemStack(thShotItem, 1, 1);
		mediumShot = new ItemStack(thShotItem, 2, 2);
		bigShot    = new ItemStack(thShotItem, 3, 3);
		starShot   = new ItemStack(thShotItem, 1, 4);
		smallStarShot = new ItemStack(thShotItem, 5, 5);
		circleShot = new ItemStack(thShotItem, 3, 6);
		scaleShot = new ItemStack(thShotItem, 4, 7);
		butterflyShot = new ItemStack(thShotItem, 2, 8);
		lightShot = new ItemStack(thShotItem, 1, 9);
		knifeShot = new ItemStack(thShotItem, 2, 10);
		heartShot = new ItemStack(thShotItem, 2, 11);
		kunaiShot = new ItemStack(thShotItem, 3, 12);
		talismanShot = new ItemStack(thShotItem, 2, 13);
		bigLightShot = new ItemStack(thShotItem, 1, 14);
		riceShot = new ItemStack(thShotItem, 2, 15);
		ovalShot = new ItemStack(thShotItem, 2, 16);
		
		homingAmulet = new ItemStack(homingAmuletItem, 16, 0);
		diffusionAmulet = new ItemStack(homingAmuletItem, 16, 1);
		
		laser1      = new ItemStack(thLaserItem, 1, 0);
		laser2      = new ItemStack(thLaserItem, 1, 1);
		laser3      = new ItemStack(thLaserItem, 1, 2);
		
		smallPowerUpItem = new ItemStack(powerItem, 1, 0);
		bigPowerUpItem   = new ItemStack(powerItem, 1, 1);
		
		for(int i = 0; i < scEnName.length; i++)
		{
			spellCard[i] = new ItemStack(spellCardItem, 1, i);
			setItemName(spellCard[i], scEnName[i], scJpName[i], scCnName[i], scTwName[i]);
		}
		
		
		//ブロックの登録
		danmakuCraftingTable = new BlockDanmakuCraftingTable(danmakuCraftingTableBlockId, Material.wood).setUnlocalizedName("danmakuCraftingTable");
		danmakuCraftingTable_shot  = new ItemStack(danmakuCraftingTable, 1, 0);
		danmakuCraftingTable_laser = new ItemStack(danmakuCraftingTable, 1, 1);
		divineSpirit = new BlockDivineSpirit(divineSpiritBlockId, Material.glass).setUnlocalizedName("divineSpirit");
		divineSpirit_red = new ItemStack(divineSpirit, 1, 0);
		divineSpirit_blue = new ItemStack(divineSpirit, 1, 1);
		divineSpirit_green = new ItemStack(divineSpirit, 1, 2);
		divineSpirit_yellow = new ItemStack(divineSpirit, 1, 3);
		divineSpirit_purple = new ItemStack(divineSpirit, 1, 4);
		divineSpirit_aqua = new ItemStack(divineSpirit, 1, 5);
		divineSpirit_orange = new ItemStack(divineSpirit, 1, 6);
		divineSpirit_white = new ItemStack(divineSpirit, 1, 7);
		
		GameRegistry.registerBlock(danmakuCraftingTable, ItemBlockDanmakuCraftingTable.class, "danmakuCraftingTable");
		
		GameRegistry.registerBlock(divineSpirit, ItemBlockDivineSpirit.class, "divineSpirit");
		
		//TileEntityの登録
		GameRegistry.registerTileEntity(TileEntityDivineSpirit.class, "TileEntityDivineSpirit");
		
		//GUIの登録
		NetworkRegistry.instance().registerGuiHandler(this, new GuiHandler());

		//エンティティの登録
		// ModLoader.registerEntityに相当
		EntityRegistry.registerGlobalEntityID(EntityTHFairy.class, "THFairy", entityIdEntityTHFairy, 0xFFFF80, 0xC0C000);
		EntityRegistry.registerGlobalEntityID(EntityTHFairyCirno.class, "THFairyCirno", entityIdEntityTHFairyCirno, 0x00FFE0, 0x00E0E0);
		EntityRegistry.registerGlobalEntityID(EntityDanmakuCreeper.class, "DanmakuCreeper", entityIdEntityDanmakuCreeper, 0x0FF080, 0xC0C000);
		//EntityRegistry.registerGlobalEntityID(EntityHouraiTama.class         , "HouraiTama"         , entityIdEntityHouraiTama        );
		EntityRegistry.registerGlobalEntityID(EntityRyuuLightningBolt.class  , "BrilliantDragonBullet"  , entityIdEntityRyuuLightningBolt );
		EntityRegistry.registerGlobalEntityID(EntityColorLightningBolt.class , "ColorLightningBolt" , entityIdEntityColorLightningBolt);
		EntityRegistry.registerGlobalEntityID(EntityKinkakuzi.class          , "Kinkakuzi"          , entityIdEntityKinkakuzi         );
		EntityRegistry.registerGlobalEntityID(EntitySilverKnife.class        , "SilverKnife"        , entityIdEntitySilverKnife       );
		EntityRegistry.registerGlobalEntityID(EntityPrivateSquare.class      , "PrivateSquare"      , entityIdEntityPrivateSquare     );
		EntityRegistry.registerGlobalEntityID(EntitySukima.class             , "Sukima"             , entityIdEntitySukima            );
		EntityRegistry.registerGlobalEntityID(EntityMazinkyoukan.class       , "Mazinkyoukan"       , entityIdEntityMazinkyoukan      );
		EntityRegistry.registerGlobalEntityID(EntityHisou.class              , "Hisou"              , entityIdEntityHisou             );
		EntityRegistry.registerGlobalEntityID(EntityObjectEye.class          , "Object Eye"         , entityIdEntityObjectEye        );
		//EntityRegistry.registerGlobalEntityID(EntityKishitudan.class         , "Kisihtudan"         , entityIdEntityKishitudan        );
		EntityRegistry.registerGlobalEntityID(EntityPendulum.class           , "NazrinPendulum"     , entityIdEntityPendulum          );
		//EntityRegistry.registerGlobalEntityID(EntityButterflyShot.class      , "ButterflyShot"      , entityIdEntityButterflyShot     );
		EntityRegistry.registerGlobalEntityID(EntityMiracleCircle.class      , "MiracleCircle"      , entityIdEntityMiracleCircle     );
		EntityRegistry.registerGlobalEntityID(EntitySanaeWind.class          , "SanaeWind"          , entityIdEntitySanaeWind         );
		EntityRegistry.registerGlobalEntityID(EntityUmiware.class            , "Umiware"            , entityIdEntityUmiware           );
		EntityRegistry.registerGlobalEntityID(EntityYouryokuSpoiler.class    , "YouryokuSpoiler"    , entityIdEntityYouryokuSpoiler   );
		EntityRegistry.registerGlobalEntityID(EntityMiniHakkero.class        , "MiniHakkero"        , entityIdEntityMiniHakkero       );
		EntityRegistry.registerGlobalEntityID(EntityMasterSpark.class        , "MasterSpark"        , entityIdEntityMasterSpark       );
		EntityRegistry.registerGlobalEntityID(EntityHomingAmulet.class       , "HomingAmulet"       , entityIdEntityHomingAmulet      );
		//EntityRegistry.registerGlobalEntityID(EntityUrokoShot.class          , "UrokoShot"          , entityIdEntityUrokoShot         );
		EntityRegistry.registerGlobalEntityID(EntityYuukaParasol.class       , "YuukaParasol"       , entityIdEntityYuukaParasol      );
		EntityRegistry.registerGlobalEntityID(EntityAjaRedStoneEffect.class  , "AjaRedStoneEffect"  , entityIdEntityAjaRedStoneEffect );
		//EntityRegistry.registerGlobalEntityID(EntityAjaRedStoneLaser.class   , "AjaRedStoneLaser"   , entityIdEntityAjaRedStoneLaser  );
		EntityRegistry.registerGlobalEntityID(EntityTHShot.class             , "NormalShot"         , entityIdEntityTHShot            );
		EntityRegistry.registerGlobalEntityID(EntityTHLaser.class            , "NormalLaser"        , entityIdEntityTHLaser           );
		EntityRegistry.registerGlobalEntityID(EntitySpellCard.class          , "SpellCard"          , entityIdEntitySpellCard         );
		EntityRegistry.registerGlobalEntityID(EntityHakureiShield.class      , "HakureiShield"      , entityIdEntityHakureiShield     );
		EntityRegistry.registerGlobalEntityID(EntityTHHenyoriLaser.class     , "HenyoriLaser"       , entityIdEntityTHHenyoriLaser     );
		EntityRegistry.registerGlobalEntityID(EntityMarisaBroom.class        , "MarisaBroom"        , entityIdEntityMarisaBroom       );
		EntityRegistry.registerGlobalEntityID(EntityHakurouReflecter.class   , "HakurouReflecter"   , entityIdEntityHakurouReflecter  );
		EntityRegistry.registerGlobalEntityID(EntityHakurouReflecter.class   , "Onmyoudama"         , entityIdEntityOnmyoudama        );
		EntityRegistry.registerGlobalEntityID(EntityTHSetLaser.class         , "SetLaser"           , entityIdEntityTHSetLaser        );
		EntityRegistry.registerGlobalEntityID(EntityDivineSpirit.class       , "DivineSpirit"       , entityIdEntityDivineSpirit      );
		
		/*MOBをスポーンさせる
		entityClass    : スポーンさせるEntityのclass
		weightedProb   : スポーンする割合。大きいほどスポーンしやすい
		min            : 一度にスポーンする最低数
		max            : 一度にスポーンする最大数
		typeOfCreature : MOBのタイプ
		biomes         : スポーンするバイオーム
		*/
		if(spawnFairy)
		{
			/*EntityRegistry.addSpawn(EntityTHFairy.class,  2, 2, 3,EnumCreatureType.monster, BiomeGenBase.plains);
			EntityRegistry.addSpawn(EntityTHFairy.class,  1, 1, 3,EnumCreatureType.monster, BiomeGenBase.desert);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 2, 2,EnumCreatureType.monster, BiomeGenBase.extremeHills);
			EntityRegistry.addSpawn(EntityTHFairy.class,  7, 1, 5,EnumCreatureType.monster, BiomeGenBase.forest);
			EntityRegistry.addSpawn(EntityTHFairy.class,  4, 1, 2,EnumCreatureType.monster, BiomeGenBase.taiga);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 1, 2,EnumCreatureType.monster, BiomeGenBase.swampland);
			EntityRegistry.addSpawn(EntityTHFairy.class,  2, 1, 4,EnumCreatureType.monster, BiomeGenBase.icePlains);
			EntityRegistry.addSpawn(EntityTHFairy.class,  2, 1, 4,EnumCreatureType.monster, BiomeGenBase.iceMountains);
			EntityRegistry.addSpawn(EntityTHFairy.class,  7, 1, 4,EnumCreatureType.monster, BiomeGenBase.jungle);
			EntityRegistry.addSpawn(EntityTHFairy.class,  7, 1, 4,EnumCreatureType.monster, BiomeGenBase.jungleHills);*/
			
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.plains);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.desert);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.extremeHills);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.forest);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.taiga);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.swampland);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.icePlains);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.iceMountains);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.jungle);
			EntityRegistry.addSpawn(EntityTHFairy.class,  3, 3, 10,EnumCreatureType.monster, BiomeGenBase.jungleHills);
			
			EntityRegistry.addSpawn(EntityTHFairyCirno.class,  1, 1, 1,EnumCreatureType.monster, BiomeGenBase.icePlains);
			EntityRegistry.addSpawn(EntityTHFairyCirno.class,  1, 1, 1,EnumCreatureType.monster, BiomeGenBase.taiga);
		}
		
		if( isSpawnHanabeeper)
		{
			EntityRegistry.addSpawn(EntityDanmakuCreeper.class,  2, 1, 4,EnumCreatureType.monster, BiomeGenBase.desert);
		}
		
		
		/*
		 サーバーとクライアントのエンティティを同期させるメソッド
		 各引数はそれぞれ以下のとおり
		 Entityのクラス, 
		 Entityの内部名, 
		 このmod内で使用する同期取り用のID,
		 @Modのクラス(ここに書くのであればthis, そうでないならinstanceを参照)
		 更新可能な距離
		 更新頻度(tickごと)
		 Entityが速度情報を持つかどうか
		*/
		EntityRegistry.registerModEntity(EntityTHFairy.class            , "THFairy"            , 0, this, 80, 1, true);
		//EntityRegistry.registerModEntity(EntityHouraiTama.class         , "HouraiTama"         , 0, this, 250, 5, true );
		EntityRegistry.registerModEntity(EntityRyuuLightningBolt.class  , "BrilliantDragonBullet"  , 1, this, 80, 1, true );
		EntityRegistry.registerModEntity(EntityColorLightningBolt.class , "ColorLightningBolt" , 2, this, 250, 1, false);
		EntityRegistry.registerModEntity(EntityKinkakuzi.class          , "Kinkakuzi"          , 3, this, 250, 1, true);
		EntityRegistry.registerModEntity(EntitySilverKnife.class        , "SilverKnife"        , 4, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntityPrivateSquare.class      , "PrivateSquare"      , 5, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntitySukima.class             , "Sukima"             , 6, this, 40, 5, false);
		EntityRegistry.registerModEntity(EntityMazinkyoukan.class       , "Mazinkyoukan"       , 7, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntityHisou.class              , "Hisou"              , 8, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntityObjectEye.class          , "ObjectEye"          , 9, this, 40, 1, true);
		//EntityRegistry.registerModEntity(EntityKishitudan.class         , "Kishitudan"         , 9, this, 250, 1, true);
		EntityRegistry.registerModEntity(EntityPendulum.class           , "NazrinPendulum"     ,10, this, 40, 1, true);
		////EntityRegistry.registerModEntity(EntityButterflyShot.class      , "ButterflyShot"      ,11, this, 250, 5, true);
		EntityRegistry.registerModEntity(EntityMiracleCircle.class      , "MiracleCircle"      ,12, this, 40, 1, false);
		EntityRegistry.registerModEntity(EntitySanaeWind.class          , "SanaeWind"          ,13, this, 80, 1, true);
		EntityRegistry.registerModEntity(EntityUmiware.class            , "Umiware"            ,14, this, 40, 5, true);
		EntityRegistry.registerModEntity(EntityYouryokuSpoiler.class    , "YouryokuSpoiler"    ,15, this, 40, 5, true);
		EntityRegistry.registerModEntity(EntityMiniHakkero.class        , "MiniHakkero"        ,16, this, 40, 5, false);
		EntityRegistry.registerModEntity(EntityMasterSpark.class        , "MasterSpark"        ,17, this, 250, 5, false);
		EntityRegistry.registerModEntity(EntityHomingAmulet.class       , "HomingAmulet"       ,18, this, 80, 1, true);
		//EntityRegistry.registerModEntity(EntityUrokoShot.class          , "UrokoShot"          ,19, this, 250, 1, true);
		EntityRegistry.registerModEntity(EntityYuukaParasol.class       , "YuukaParasol"       ,20, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntityAjaRedStoneEffect.class  , "AjaRedStoneEffect"  ,21, this, 40, 1, true);
		//EntityRegistry.registerModEntity(EntityAjaRedStoneLaser.class   , "AjaRedStoneLaser"   ,22, this, 250, 1, true);
		EntityRegistry.registerModEntity(EntityTHShot.class             , "NormalShot"         ,23, this, 40, 5, false);
		EntityRegistry.registerModEntity(EntityTHLaser.class            , "NormalLaser"        ,24, this, 40, 5, false);
		EntityRegistry.registerModEntity(EntitySpellCard.class          , "SpellCard"          ,25, this, 40, 5, false);
		EntityRegistry.registerModEntity(EntityMusouFuuin.class         , "MusouFuuin"         ,26, this, 80, 1, true);
		//EntityRegistry.registerModEntity(EntityHakureiShield.class      , "HakureiShield"      ,11, this, 250, 3, true);
		
		//EntityRegistry.registerModEntity(EntityTHHenyoriLaser.class     , "HenyoriLaser"       ,19, this, 250, 1, true);
		EntityRegistry.registerModEntity(EntityMarisaBroom.class        , "MarisaBroom"        , 22, this, 80, 1, true);
		EntityRegistry.registerModEntity(EntityDanmakuCreeper.class     , "DanmakuCreeper"     , 27, this, 80, 1, true);
		EntityRegistry.registerModEntity(EntityNuclearShot.class        , "NuclearShot"        , 28, this, 80, 1, true);
		EntityRegistry.registerModEntity(EntityHakurouReflecter.class   , "HakurouReflecter"   , 29, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntityOnmyoudama.class         , "Onmyoudama"         , 30, this, 80, 1, true);
		EntityRegistry.registerModEntity(EntityTHFairyCirno.class       , "THFairyCirno"       , 31, this, 80, 1, true);
		EntityRegistry.registerModEntity(EntityTHSetLaser.class         , "THSetLaser"         , 19, this, 40, 1, true);
		EntityRegistry.registerModEntity(EntityDivineSpirit.class       , "DivineSpirit"       , 32, this, 80, 1, true);
		
		//名称を登録
		setNameForObject();
		
		//テクスチャの登録
		proxy.registerTextures();
		// サーバー側は何もしない, クライアント側ではレンダーの登録が行われる
		proxy.registerRenderers();
		
		
		//レシピの登録
		setAllAddRecipes();
		
	}
	
	//名称の設定（言語関係はスペルカード以外全部ここに移動しました）
		private void setNameForObject()
		{
			//弾アイテムの色
			setName("thKaguya.color.0"	, "Red"			, "赤", "红", "紅");
			setName("thKaguya.color.1"	, "Blue"		, "青", "蓝", "藍");
			setName("thKaguya.color.2"	, "Green"		, "緑", "绿", "綠");
			setName("thKaguya.color.3"	, "Yellow"		, "黄", "黄", "黃");
			setName("thKaguya,color.4"	, "Purple"		, "紫", "紫", "紫");
			setName("thKaguya.color.5"	, "Aqua"		, "水色", "青", "青");
			setName("thKaguya.color.6"	, "Orange"		, "橙", "橙", "橙");
			setName("thKaguya.color.7"	, "White"		, "白", "白", "白");
			setName("thKaguya.color.8"	, "Random"		, "ランダム", "随机", "隨機");
			setName("thKaguya.color.9"	, "Rainbow"		, "虹色", "虹色", "虹色");
			setName("thKaguya.color.10" , "Hot Color"	, "暖色", "暖色", "暖色");
			setName("thKaguya.color.11" , "Cold Color"	, "寒色", "冷色", "冷色");
			
			//アイテム名を設定
			setItemName(houraiedaItem    , "Jeweled Branch of Hourai"     , "蓬莱の玉の枝"          , "蓬莱玉枝"		, "蓬萊玉枝"		);
			setItemName(hotokehachiItem  , "Buddha's Stone Bowl"          , "仏の御石の鉢"          , "佛御石之钵"		, "佛禦石之缽"		);
			setItemName(ryuutamaItem     , "Jewel from the Dragon's Neck" , "龍の頸の玉"            , "龙颈之玉"			, "龍頸之玉"		);
			setItemName(hinezumiItem     , "Robe of the Fire Rat"         , "火鼠の皮衣"            , "火鼠的皮衣"		, "火鼠的皮衣"		);
			setItemName(koyasugaiItem    , "Swallow's Cowrie Shell"       , "燕の子安貝"            , "燕的子安贝"		, "燕的子安貝"		);
			
			setItemName(houraiPearlItem  , "Color Pearl"                  , "色真珠"                , "色珍珠"			, "色珍珠"			);
			
			setItemName(kinkakuziItem    , "Seamless Ceiling of Kinkaku-ji", "金閣寺の一枚天井"     , "金阁寺的一块天花板"	, "金閣寺的一塊天花板");
			setItemName(ajaRedStoneItem  , "Red Stone of Aja"             , "エイジャの赤石"        , "艾哲红石"		, "艾哲紅石"		);
			setItemName(hisyaku2Item     , "Ship Ghost's Dipper"          , "舟幽霊の柄杓"          , "船幽灵的长勺"	, "船幽靈的長勺"	);
			setItemName(hisyakuItem      , "Ship Ghost's Dipper"          , "舟幽霊の柄杓"          , "船幽灵的长勺"	, "船幽靈的長勺"	);
			setItemName(deathScytheItem  , "Scythe of Death"              , "死神の大鎌"            , "死神的大镰刀"	, "死神的大鐮刀"	);
			
			setItemName(kaigoItem        , "Rod of Remorse"               , "悔悟の棒"              , "悔悟之棒"		, "悔悟之棒"		);
			//setItemName(houtouItem       , "Bishamonten's Jeweled Pagoda" , "毘沙門天の宝塔"        , "毗沙门天的宝塔"	, "毗沙門天的寶塔");
			setItemName(pendulumItem     , "Nazrin Pendulum"              , "ナズーリンペンデュラム", "娜兹玲灵摆"			, "娜茲玲靈擺"		);
			setItemName(hakuroukenItem   , "Hakurouken"                   , "白楼剣"                , "白楼剑"			, "白樓劍"			);
			setItemName(roukankenItem    , "Roukanken"                    , "楼観剣"                , "楼观剑"			, "樓觀劍"			);
			
			setItemName(silverKnifeItem  , "Silver Knife"                 , "銀のナイフ"            , "银质小刀"			, "銀質小刀"		);
			setItemName(sakuyawatchItem  , "Sakuya's Pocket Watch"        , "咲夜の懐中時計"        , "咲夜的怀表"		, "咲夜的懷錶"		);
			setItemName(sukimaItem       , "Gap"                          , "スキマ"                , "隙间"				, "隙間"			);
			setItemName(thirdeyeItem     , "3rd Eye"                      , "第三の眼"              , "第三只眼"		, "第三隻眼"		);
			setItemName(mazinkyoukanItem , "Sorcerer's Sutra Scroll"      , "魔人経巻"              , "魔人经卷"		, "魔人經卷"		);
			
			setItemName(heavenlyPeachItem, "Heavenly Peach"               , "天界の桃"              , "天界之桃"		, "天界之桃"		);
			setItemName(hisouItem        , "Sword of Scarlet Perception " , "緋想の剣"              , "绯想之剑"			, "緋想之劍"		);
			setItemName(yuyukoOugiItem   , "Yuyuko's Fan"                 , "幽々子の扇"            , "幽幽子的扇子"	, "幽幽子的扇子"	);
			setItemName(oharaibouSItem   , "Wind Shrine Maiden Stick"     , "風祝のお祓い棒"        , "风祝的驱魔棒"		, "風祝的驅魔棒"	);
			setItemName(onbashiraItem    , "Onbashira"                    , "御柱"                  , "御柱"			, "禦柱"			);
			
			setItemName(hakkeroItem      , "Mini Hakkero"                 , "ミニ八卦炉"            , "迷你八卦炉"		, "迷你八卦爐"		);
			setItemName(kabenukenomiItem , "Wall-Passing Chisel"          , "壁抜けの鑿"            , "穿墙之凿"			, "穿牆之鑿"		);
			setItemName(mikoSwordItem    , "Sacred Sword of Toyosatomimi" , "豊聡耳の宝剣"          , "丰聪耳的宝剑"		, "豐聰耳的寶劍"	);
			setItemName(closedThirdEyeItem, "Closed 3rd Eye"              , "閉ざした第三の眼"      , "闭上的第三只眼"		, "閉上的第三隻眼"	);
			setItemName(homingAmuletItem , "Homing Amulet"                , "ホーミングアミュレット", "追踪灵符"		, "追蹤靈符"		);
			
			setItemName(yuukaParasolItem , "Yuuka's Parasol"              , "幽香の日傘"            , "幽香的阳伞"		, "幽香的陽傘"		);
			setItemName(kappaCapItem     , "Kappa Cap"                    , "河童の帽子"            , "河童的帽子"		, "河童的帽子"		);
			setItemName(spellCardItem    , "Spell Card"                   , "スペルカード"          , "符卡"			, "符卡"			);
			setItemName(shotMaterialItem , "Shot Material"                , "弾の素"                , "子弹之素"			, "子彈之素"		);
			setItemName(thShotItem       , "Shot"                         , "弾"                    , "子弹"				, "子彈"			);
			
			//setItemName(danmakuMemoItem  , "Danmaku Memo"                 , "弾幕メモ"              , "弹幕笔记"		, "彈幕筆記"		);
			setItemName(oharaibouRItem   , "Hakurei Shrine Maiden Stick"  , "博麗のお祓い棒"        , "博丽的驱魔棒"		, "博麗的驅魔棒"	);
			setItemName(ibukihyouItem    , "Ibuki Gourd"                  , "伊吹瓢"                , "伊吹瓢"			, "伊吹瓢"			);
			setItemName(tenguFanItem     , "Tengu's Fan"                  , "天狗の団扇"            , "天狗的团扇"		, "天狗的團扇"		);
			setItemName(marisaBroomItem  , "Magic Broom"                  , "魔法の箒"              , "魔法扫帚"		, "魔法掃帚"		);
			
			setItemName(pointItem        , "Point Item"                   , "得点アイテム"          , "得分道具"		, "得分道具"		);
			setItemName(powerItem        , "Power Up Item"                , "パワーアップアイテム"  , "灵力提升道具"	, "靈力提升道具"	);
			setItemName(thLaserItem      , "Laser"                        , "レーザー"              , "激光"			, "激光"			);
			setItemName(kappaWaterPistolItem      , "Kappa's Water Pistol", "河童の水鉄砲"          , "河童的水枪"		, "河童的水槍"		);
			setItemName(nuclearControlRodItem, "Nuclear Control Rod"      , "制御棒"                , "控制棒"			, "控制棒"			);
			
			//setItemName(frandreRodItem   , "Frandre's Rod"                , "フランドールの棒"         , "芙兰朵露之棒"  , "芙蘭朵露之棒"	);
			setItemName(onmyoudamaItem   , "Yin-Yang Orb"                 , "陰陽玉"                , "阴阳玉"			, "陰陽玉"			);
			setItemName(uchideItem		 , "Miracle Mallet"				  , "打ち出の小槌"          , "万宝槌"			, "萬寶槌"			);
			setItemName(marisaHatItem    , "Marisa's Hat"				  , "魔理沙の帽子"			, "魔理沙的帽子"	, "魔理沙的帽子"	);
			setItemName(icicleSwordItem  , "Icicle Sword"				  , "アイシクルソード"		, "冰剑"				, "冰劍"			);
			
			setItemName(kerobouItem      , "Suwako's Hat"				  , "諏訪子の帽子"		    , "诹访子的帽子"		, "諏訪子的帽子"	);
			setItemName(spearTheGungnirItem	, "Spear the Gungnir"		  	, "スピア・ザ・グングニル"	, "Spear the Gungnir"	, "Spear the Gungnir");
			setItemName(laevateinnItem		, "Lævateinn"					," レーヴァテイン"			, "Lævateinn"			, "Lævateinn");
			
			/*===============================================================================================================================*/
			//ダメージ値で名称が異なるアイテム名を設定
			setItemName(redPearl    , "Red Pearl"   , "赤真珠", "红珍珠", "紅珍珠");
			setItemName(bluePearl   , "Blue Pearl"  , "青真珠", "蓝珍珠", "藍珍珠");
			setItemName(greenPearl  , "Green Pearl" , "緑真珠", "绿珍珠", "綠珍珠");
			setItemName(yellowPearl , "Yellow Pearl", "黄真珠", "黄珍珠", "黃珍珠");
			setItemName(purplePearl , "Purple Pearl", "紫真珠", "紫珍珠", "紫珍珠");
			setItemName(aquaPearl   , "Aqua Pearl"  , "青真珠", "青珍珠", "青珍珠");
			setItemName(orangePearl , "Orange Pearl", "橙真珠", "橙珍珠", "橙珍珠");
			
			setItemName(silverKnifeBlue , "Silver Knife", "銀のナイフ", "银质小刀", "銀質小刀");
			setItemName(silverKnifeRed  , "Silver Knife", "銀のナイフ", "银质小刀", "銀質小刀");
			setItemName(silverKnifeGreen, "Silver Knife", "銀のナイフ", "银质小刀", "銀質小刀");
			setItemName(silverKnifeWhite, "Time Paradox Knife", "タイムパラドックスナイフ", "时间悖论小刀", "時間悖論小刀");
			
			setItemName(smallShot		, "Small Shot"		, "小弾"	, "小弹"			, "小彈");
			setItemName(tinyShot		, "Tiny Shot"		, "粒弾"	, "粒弹"			, "粒彈");
			setItemName(mediumShot		, "Medium Shot"		, "中弾"	, "中弹"			, "中彈");
			setItemName(bigShot			, "Big Shot"		, "大弾"	, "大弹"			, "大彈");
			setItemName(starShot		, "Star Shot"		, "星弾"	, "星弹"			, "星彈");
			setItemName(smallStarShot	, "Small Star Shot"	, "小星弾"	, "小星弹"		, "小星彈");
			setItemName(circleShot		, "Circle Shot"		, "輪弾"	, "轮弹"			, "輪彈");
			setItemName(scaleShot		, "Scale Shot"		, "鱗弾"	, "鳞弹"			, "鱗彈");
			setItemName(butterflyShot	, "Butterfly Shot"	, "蝶弾"	, "蝶弹"			, "蝶彈");
			setItemName(lightShot		, "Light Shot"		, "光弾"	, "光弹"			, "光彈");
			setItemName(knifeShot		, "Knife Shot"		, "ナイフ弾", "小刀弹"		, "小刀彈");
			setItemName(heartShot		, "Heart Shot"		, "ハート弾", "Heart Shot"	, "Heart Shot");
			setItemName(kunaiShot		, "Kunai Shot"		, "クナイ弾", "Kunai Shot"	, "Kunai Shot");
			setItemName(talismanShot	, "Talisman Shot"	, "札弾"	, "Talisman Shot", "Talisman Shot");
			setItemName(bigLightShot	, "Big Light Shot"	, "大光弾"	, "大光弹"		, "大光彈");
			setItemName(riceShot		, "Rice Shot"		, "米弾"	, "米弹"			, "米彈");
			setItemName(ovalShot		, "Oval Shot"		, "楕円弾"	, "Oval Shot"	, "Oval Shot");
			/*
			setItemName(pearlShot, "Pearl Shot", "真珠弾", "珍珠弹", "珍珠彈");
			
			setItemName(crystalShot, "Crystal Shot", "結晶弾", "结晶弹", "結晶彈");
			setItemName(windShot, "Wind Shot", "風弾", "风弹", "風彈");
			setItemName(kishituShot, "Kishitu Shot", "気質弾", "气质弹", "氣質彈");
			*/
			
			setItemName(homingAmulet, "Homing Amulet", "ホーミングアミュレット", "追踪灵符", "追蹤靈符");
			setItemName(diffusionAmulet, "Diffusion Amulet", "拡散アミュレット", "扩散灵符", "擴散靈符");
			
			setItemName(laser1, "Laser"      , "レーザー"        , "激光"  , "激光");
			setItemName(laser2, "Short Laser", "ショートレーザー", "短激光", "短激光");
			setItemName(laser3, "Long Laser" , "ロングレーザー"  , "长激光", "長激光");
			
			setItemName(smallPowerUpItem, "Small Power Up Item", "パワーアップアイテム 小", "灵力提升道具 小", "靈力提升道具 小");
			setItemName(bigPowerUpItem,   "Big Power Up Item"  , "パワーアップアイテム 大", "灵力提升道具 大", "靈力提升道具 大");
			
			/*===============================================================================================================================*/
			//ブロック名を設定
			setItemName(danmakuCraftingTable_shot, "Danmaku Crafting Table", "弾幕作業台", "弹幕工作台", "彈幕工作臺");
			setItemName(danmakuCraftingTable_laser, "Laser Crafting Table", "レーザー弾幕作業台", "激光弹幕工作台", "激光彈幕工作臺");
			
			setItemName(divineSpirit_red,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_blue,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_green,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_yellow,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_purple,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_aqua,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_orange,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			setItemName(divineSpirit_white,  "Divine Spirit", "小神霊", "小神灵", "小神靈");
			
			/*===============================================================================================================================*/
			// Entityの名前を登録
			setName("entity.THFairy.name"		, "Fairy"		, "妖精"		, "妖精"		, "妖精");
			setName("entity.THFairyCirno.name"	, "Cirno"		, "チルノ"		, "琪露诺"		, "琪露諾");
			setName("entity.DanmakuCreeper.name", "Hanabeeper"	, "ハナビーパー", "花田尖叫者"	, "花田尖叫者");
			
			/*===============================================================================================================================*/
			//弾幕作業台、レーザー弾幕作業台の文字
			setName("danmakuCrafting.name", "Danmaku Crafting Table", "弾幕作業台", "弹幕工作台", "彈幕工作臺");
			setName("danmakuCrafting.material", "Material", "素材      ", "素材", "素材");
			setName("danmakuCrafting.number"  , "Number  ", "弾数      ", "弹数", "彈數");
			setName("danmakuCrafting.speed"   , "Speed   ", "弾速      ", "弹速", "彈速");
			setName("danmakuCrafting.damage"  , "Damage  ", "威力      ", "威力", "威力");
			setName("danmakuCrafting.color"   , "Color   ", "色        ", "颜色", "顏色");
			setName("danmakuCrafting.gravity" , "Gravity ", "重力加速度", "重力加速度", "重力加速度");
			setName("danmakuCrafting.bound"   , "Bound   ", "跳ね返り数", "反弹次数", "反彈次數");
			setName("danmakuCrafting.form"    , "Form    ", "弾幕形状  ", "弹幕形状", "彈幕形狀");
			setName("danmakuCrafting.copy"    , "Copy    ", "複製      ", "复制", "複製");
			setName("laserCrafting.name", "Laser Crafting Table", "レーザー弾幕作業台", "激光弹幕工作台", "激光彈幕工作臺");
			
			/*===============================================================================================================================*/
			
			//全スペルカードの名称
			for(int i = 0; i < scEnName.length; i++)
			{
				setName("spellCard." + i, scEnName[i], scJpName[i], scCnName[i], scTwName[i]);
			}
			
			//緋想の剣の状態を表す文字
			setName("thKaguya.item.kishitu", "Temperament", "気質", "气质", "氣質");
			
			//銀のナイフの色
			setName("shotColor.0", "Red", "赤", "红", "紅");
			setName("shotColor.1", "Blue", "青", "蓝", "藍");
			setName("shotColor.2", "Green", "緑", "绿", "綠");
			
			//豊聡耳の宝剣で探知した時のメッセージ
			setName("thKaguya.front", "Front ", "前", "前", "前");
			setName("thKaguya.back", "Back ", "後ろ", "后", "後");
			setName("thKaguya.right", "Right ", "右", "右", "右");
			setName("thKaguya.left", "Left ", "左", "左", "左");
			setName("thKaguya.up", "Up ", "上", "上", "上");
			setName("thKaguya.down", "Down ", "下", "下", "下");
					
			//ナズーリンペンデュラム使用時のメッセージ
			setName("thKaguya.pendulum1", "Pendulum started searching for ", "ペンデュラムは", "灵摆开始寻找", "靈擺開始尋找");
			setName("thKaguya.pendulum2", "!", "を探し始めた！", "了！", "了！");
			setName("thKaguya.pendulum3", " by High sensitivity mode!", "を高感度モードで探し始めた！", "，以高敏感度模式！", "，以高敏感度模式！");
			
			//早苗のスペルカードの説明文
			setName("thKaguya.sneSc1", "Need ", "レベルが", "需要等级", "需要等級");
			setName("thKaguya.sneSc2", " Levels & Drawing ", "必要で、星を", "且画", "且畫");
			setName("thKaguya.sneSc3", " Stars", "つ描く必要がある", "个星星", "個星星");
			setName("thKaguya.sneSc4", "MiraclePower : ", "奇跡の力 : ", "奇迹之力 ：", "奇跡之力 ：");
					
			//弾アイテムの弾幕系上名
			setName("thKaguya.danmakuForm.0", "Point"	, "一点"		, "一点"	, "一點"	);
			setName("thKaguya.danmakuForm.1", "Random"	, "ランダム"	, "随机"	, "隨機"	);
			setName("thKaguya.danmakuForm.2", "Sector"	, "扇状"		, "扇形"	, "扇形"	);
			setName("thKaguya.danmakuForm.3", "Around"	, "全方位"		, "全方位"	, "全方位"	);
			setName("thKaguya.danmakuForm.4", "Sphere"	, "球状"		, "球状"	, "球狀"	);
			setName("thKaguya.danmakuForm.5", "Ring"	, "リング"		, "环状"		, "環狀"		);
			setName("thKaguya.danmakuForm.6", "null"	, "未定義"		, "未定义"	, "未定義"	);
		}
		
		/*
		アイテムの英語名（日本語以外の言語での名前）と日本語名を同時登録
		 strEn : 英語その他大半の言語での名前
		 strJp : 日本語名
		 strCn : 中国語（簡体字）名
		 strTw : 中国語（繁体字）名
		*/
		private void setItemName(Item item, String strEn, String strJp, String strCn, String strTw)
		{
			LanguageRegistry.addName(item,strEn);
			LanguageRegistry.instance().addNameForObject(item,"ja_JP",strJp);
			LanguageRegistry.instance().addNameForObject(item,"zh_CN",strCn);
			LanguageRegistry.instance().addNameForObject(item,"zh_TW",strTw);
		}
		
		/*
		ブロックの英語名（日本語以外の言語での名前）と日本語名を同時登録
		 strEn : 英語その他大半の言語での名前
		 strJp : 日本語名
		 strCn : 中国語（簡体字）名
		 strTw : 中国語（繁体字）名
		*/
		private void setItemName(Block block, String strEn, String strJp, String strCn, String strTw)
		{
			LanguageRegistry.addName(block,strEn);
			LanguageRegistry.instance().addNameForObject(block,"ja_JP",strJp);
			LanguageRegistry.instance().addNameForObject(block,"zh_CN",strCn);
			LanguageRegistry.instance().addNameForObject(block,"zh_TW",strTw);
		}
		
		/*
		ほぼ同上。こちらはitemStackを引数とする
		ダメージ値によって名称を変えるものはこれで登録させる
		*/
		private void setItemName(ItemStack itemstack, String strEn, String strJp, String strCn, String strTw)
		{
			LanguageRegistry.addName(itemstack,strEn);
			LanguageRegistry.instance().addNameForObject(itemstack,"ja_JP",strJp);
			LanguageRegistry.instance().addNameForObject(itemstack,"zh_CN",strCn);
			LanguageRegistry.instance().addNameForObject(itemstack,"zh_TW",strTw);
		}
		
		//英語、日本語、中国語での呼び方を登録する
		private void setName(String key, String strEn, String strJp, String strCn, String strTw)
		{
			LanguageRegistry.instance().addStringLocalization(key, "en_US", strEn);
			LanguageRegistry.instance().addStringLocalization(key, "ja_JP", strJp);
			LanguageRegistry.instance().addStringLocalization(key, "zh_CN", strCn);
			LanguageRegistry.instance().addStringLocalization(key, "zh_TW", strTw);
		}

	//レシピの登録
	private void setAllAddRecipes()
	{
		//赤真珠
		ModLoader.addRecipe(redPearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),Item.redstone,
							Character.valueOf('Y'),Item.enderPearl });
		//青真珠
		ModLoader.addRecipe(bluePearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),new ItemStack(Item.dyePowder, 1, 4),
							Character.valueOf('Y'),Item.enderPearl });
		//緑真珠
		ModLoader.addRecipe(greenPearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),Item.emerald,
							Character.valueOf('Y'),Item.enderPearl });
		//黄真珠
		ModLoader.addRecipe(yellowPearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),Item.glowstone,
							Character.valueOf('Y'),Item.enderPearl });
		//紫真珠
		ModLoader.addRecipe(purplePearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),Block.obsidian,
							Character.valueOf('Y'),Item.enderPearl });
		
		//水真珠
		/*ModLoader.addRecipe(aquaPearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),Block.ice,
							Character.valueOf('Y'),Item.enderPearl });*/
		
		//橙真珠
		ModLoader.addRecipe(orangePearl,
							new Object[]{	"XXX",
											"XYX",
											"XXX",
							Character.valueOf('X'),Item.blazePowder,
							Character.valueOf('Y'),Item.enderPearl });
		
		//蓬莱の玉の枝
		ModLoader.addRecipe(new ItemStack(houraiedaItem),
							new Object[]{	"YRB",
											"GEP",
											" E ",
							Character.valueOf('Y'),yellowPearl,
							Character.valueOf('R'),redPearl,
							Character.valueOf('B'),bluePearl,
							Character.valueOf('G'),greenPearl,
							Character.valueOf('P'),purplePearl,
							Character.valueOf('E'),Item.ingotGold });
		//仏の御石の鉢
		ModLoader.addRecipe(new ItemStack(hotokehachiItem),
							new Object[]{	"DOD",
											"O O",
											"DOD",
							Character.valueOf('D'),Item.diamond,
							Character.valueOf('O'),Block.obsidian });
		//火鼠の皮衣
		ModLoader.addRecipe(new ItemStack(hinezumiItem),
							new Object[]{	"BDB",
											"BPB",
											"B B",
							Character.valueOf('B'),Item.blazePowder,
							Character.valueOf('D'),Item.diamond,
							Character.valueOf('P'),Item.plateLeather });
		//燕の子安貝
		ModLoader.addRecipe(new ItemStack(koyasugaiItem),
							new Object[]{	"GGG",
											"FEF",
											"WWW",
							Character.valueOf('E'),Item.egg,
							Character.valueOf('W'),Item.wheat,
							Character.valueOf('F'),Item.feather,
							Character.valueOf('G'),Item.ghastTear });
		//龍の頸の玉
		ModLoader.addRecipe(new ItemStack(ryuutamaItem),
							new Object[]{ 	"GWG",
											"LDL",
											"GWG",
							Character.valueOf('D'),Item.diamond,
							Character.valueOf('L'),Item.bucketLava,
							Character.valueOf('W'),Item.bucketWater,
							Character.valueOf('G'),Block.glowStone});
		//金閣寺の一枚天井
		ModLoader.addRecipe(new ItemStack(kinkakuziItem),
							new Object[]{	"WWW",
											"GGG",
							Character.valueOf('W'),Block.planks,
							Character.valueOf('G'),Block.blockGold});
		//金閣寺の一枚天井を金ブロック3つに還元するレシピ
		ModLoader.addRecipe(new ItemStack(Block.blockGold,3),
							new Object[]{	"K",
							Character.valueOf('K'),kinkakuziItem});
		
		//エイジャの赤石
		ModLoader.addRecipe(new ItemStack(ajaRedStoneItem),
							new Object[]{	"RRR",
											"RRR",
											"RRR",
							Character.valueOf('R'),redPearl});
		
		//舟幽霊の柄杓
		ModLoader.addRecipe(new ItemStack(hisyakuItem),
							new Object[]{	" SB",
											" WS",
											"W  ",
							Character.valueOf('B'),Item.bowlEmpty,
							Character.valueOf('W'),Item.stick,
							Character.valueOf('S'),Block.slowSand});
		//死神の大鎌
		ModLoader.addRecipe(new ItemStack(deathScytheItem),
							new Object[]{	"III",
											" S ",
											"S  ",
							Character.valueOf('I'),Item.ingotIron,
							Character.valueOf('S'),Block.slowSand});
		//悔悟の棒
		ModLoader.addRecipe(new ItemStack(kaigoItem),
							new Object[]{	"WPB",
											"WPB",
											" S ",
							Character.valueOf('W'),new ItemStack(Item.dyePowder, 1, 0),
							Character.valueOf('B'),new ItemStack(Item.dyePowder, 1, 15),
							Character.valueOf('S'),Item.stick,
							Character.valueOf('P'),Block.planks});
		//ナズーリンペンデュラム
		ModLoader.addRecipe(new ItemStack(pendulumItem),
							new Object[]{	" I ",
											"I I",
											" D ",
							Character.valueOf('I'),Item.ingotIron,
							Character.valueOf('D'),Item.diamond});
		//楼観剣
		ModLoader.addRecipe(new ItemStack(roukankenItem),
							new Object[]{	"  I",
											"FI ",
											"S  ",
							Character.valueOf('I'),Item.ingotIron,
							Character.valueOf('F'),BlockFlower.plantRed,
							Character.valueOf('S'),Item.swordIron});
		
		//白楼剣
		ModLoader.addRecipe(new ItemStack(hakuroukenItem),
								new Object[]{	"  I",
												"FI ",
												"S  ",
								Character.valueOf('I'),Item.ingotIron,
								Character.valueOf('F'),Item.snowball,
								Character.valueOf('S'),Item.stick});
			
		//咲夜の懐中時計
		ModLoader.addRecipe(new ItemStack(sakuyawatchItem),
							new Object[]{	" Y ",
											"RCR",
											" R ",
							Character.valueOf('Y'),yellowPearl,
							Character.valueOf('R'), Item.redstone ,
							Character.valueOf('C'), Item.pocketSundial});
		//銀のナイフ 青
		ModLoader.addRecipe(silverKnifeBlue,
							new Object[]{	"I ",
											" R",
							Character.valueOf('R'),new ItemStack(Item.dyePowder, 1, 4) ,
							Character.valueOf('I'),Item.ingotIron });
		
		//銀のナイフ 赤
		ModLoader.addRecipe(silverKnifeRed,
							new Object[]{	"I ",
											" R",
							Character.valueOf('R'),Item.redstone ,
							Character.valueOf('I'),Item.ingotIron });
		//銀のナイフ 緑
		ModLoader.addRecipe(silverKnifeGreen,
							new Object[]{	"I ",
											" R",
							Character.valueOf('R'),Item.emerald ,
							Character.valueOf('I'),Item.ingotIron });
		
		//スキマ
		ModLoader.addRecipe(new ItemStack(sukimaItem, 2),
							new Object[]{	" KR",
											"KEK",
											"RK ",
							Character.valueOf('K'),Block.obsidian,
							Character.valueOf('R'),new ItemStack(Item.dyePowder, 1, 1),
							Character.valueOf('E'),Item.eyeOfEnder });
		//第三の眼
		ModLoader.addRecipe(new ItemStack(thirdeyeItem),
							new Object[]{	" X ",
											"XYX",
											" X ",
							Character.valueOf('X'),new ItemStack(Item.dyePowder, 1, 1),
							Character.valueOf('Y'),Item.eyeOfEnder });
		//魔人経巻
		ModLoader.addRecipe(new ItemStack(mazinkyoukanItem),
							new Object[]{	"BRB",
											"BRB",
											"BRB",
							Character.valueOf('B'),Block.blockLapis,
							Character.valueOf('R'),Block.blockRedstone});
		//緋想の剣
		ModLoader.addRecipe(new ItemStack(hisouItem),
							new Object[]{	" PG",
											"PGP",
											"RP ",
							Character.valueOf('P'),Item.blazePowder,
							Character.valueOf('G'),Block.glowStone,
							Character.valueOf('R'),Item.blazeRod});
		//幽々子の扇
		ModLoader.addRecipe(new ItemStack(yuyukoOugiItem),
							new Object[]{	"RDL",
											"SPS",
											"TST",
							Character.valueOf('D'),Item.diamond,
							Character.valueOf('P'),Item.paper,
							Character.valueOf('S'),Item.stick,
							Character.valueOf('T'),Item.ghastTear,
							Character.valueOf('R'),Item.redstone,
							Character.valueOf('L'),new ItemStack(Item.dyePowder, 1, 4)});
		//風祝のお祓い棒
		ModLoader.addRecipe(new ItemStack(oharaibouSItem),
							new Object[]{	" FP",
											" S ",
											"S  ",
							Character.valueOf('S'),Item.stick,
							Character.valueOf('P'),Item.paper,
							Character.valueOf('F'),Item.feather});
		//御柱
		ModLoader.addRecipe(new ItemStack(onbashiraItem),
							new Object[]{	"PWP",
											" W ",
											" W ",
							Character.valueOf('W'),Block.wood,
							Character.valueOf('P'),Item.paper});
		//ミニ八卦炉
		ModLoader.addRecipe(new ItemStack(hakkeroItem),
							new Object[]{	"IBI",
											"BFB",
											"IBI",
							Character.valueOf('I'),Item.ingotIron,
							Character.valueOf('F'),Item.flintAndSteel,
							Character.valueOf('B'),Item.blazeRod});
		//壁抜けの鑿
		ModLoader.addRecipe(new ItemStack(kabenukenomiItem),
							new Object[]{	"GSS",
											"E  ",
							Character.valueOf('G'),Item.ingotGold,
							Character.valueOf('S'),Item.stick,
							Character.valueOf('E'),Item.enderPearl});
		//豊聡耳の宝剣
		ModLoader.addRecipe(new ItemStack(mikoSwordItem),
							new Object[]{	"DID",
											"DID",
											"DGD",
							Character.valueOf('D'),Item.glowstone,
							Character.valueOf('I'), Item.ingotIron,
							Character.valueOf('G'), Item.ingotGold});
		
		//閉ざした第三の眼
		ModLoader.addRecipe(new ItemStack(closedThirdEyeItem),
							new Object[]{	"OOO",
											"OTO",
											"OOO",
							Character.valueOf('O'),Block.obsidian,
							Character.valueOf('T'),thirdeyeItem});
		
		//ホーミングアミュレット
		ModLoader.addRecipe(homingAmulet,
							new Object[]{	"PPP",
											"PRP",
											"PPP",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('R'),new ItemStack(Item.dyePowder, 1, 1)});
		
		//拡散アミュレット
			ModLoader.addRecipe(diffusionAmulet,
								new Object[]{	"PPP",
												"PBP",
												"PPP",
								Character.valueOf('P'),Item.paper,
								Character.valueOf('B'),new ItemStack(Item.dyePowder, 1, 4)});
		
		//幽香の日傘
		ModLoader.addRecipe(new ItemStack(yuukaParasolItem),
							new Object[]{	"YRO",
											" IR",
											"I Y",
							Character.valueOf('O'),orangePearl,
							Character.valueOf('I'),Item.ingotIron,
							Character.valueOf('Y'),BlockFlower.plantYellow,
							Character.valueOf('R'),BlockFlower.plantRed});
		
		//河童の帽子
		ModLoader.addRecipe(new ItemStack(kappaCapItem),
							new Object[]{	"LWL",
											"SCS",
							Character.valueOf('L'),Block.waterlily,
							Character.valueOf('W'),Item.bucketWater,
							Character.valueOf('S'),Item.slimeBall,
							Character.valueOf('C'),Item.helmetLeather });
		
		//伊吹瓢
		ModLoader.addRecipe(new ItemStack(ibukihyouItem),
							new Object[]{	"PLL",
											"LWL",
											"LLP",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('L'),Block.blockLapis,
							Character.valueOf('W'),Item.netherStalkSeeds
							});
		
		//天狗の団扇
		ModLoader.addRecipe(new ItemStack(tenguFanItem),
							new Object[]{	"ORO",
											"LRR",
											"SLO",
							Character.valueOf('O'),new ItemStack(Item.dyePowder, 1, 14),
							Character.valueOf('R'),new ItemStack(Item.dyePowder, 1, 1),
							Character.valueOf('L'),BlockLeaves.leaves,
							Character.valueOf('S'),Item.stick
							});
		
		//河童の水鉄砲
		ModLoader.addRecipe(new ItemStack(kappaWaterPistolItem),
							new Object[]{	"LLL",
											"GGP",
											" TB",
							Character.valueOf('L'),new ItemStack(Item.dyePowder, 1, 4),
							Character.valueOf('G'),Block.glass,
							Character.valueOf('P'),Block.pistonBase,
							Character.valueOf('T'),Block.tripWireSource,
							Character.valueOf('B'),Item.glassBottle,
							});
		
		//制御棒
		ModLoader.addRecipe(new ItemStack(nuclearControlRodItem),
							new Object[]{	"BOB",
											"BOB",
											"BOB",
							Character.valueOf('B'),Item.blazeRod,
							Character.valueOf('O'),Block.obsidian});
		
		//陰陽玉
		ModLoader.addRecipe(new ItemStack(onmyoudamaItem),
							new Object[]{	"RRQ",
											"REQ",
											"RQQ",
							Character.valueOf('E'),Item.enderPearl,
							Character.valueOf('R'),Item.redstone,
							Character.valueOf('Q'),Item.netherQuartz});
		
		//博麗のお祓い棒
		ModLoader.addRecipe(new ItemStack(oharaibouRItem),
							new Object[]{	"PPO",
											" SP",
											"S P",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('S'),Item.stick,
							Character.valueOf('O'),onmyoudamaItem});
		
		//魔理沙の帽子
		ModLoader.addRecipe(new ItemStack(marisaHatItem),
							new Object[]{	" B ",
											"WWW",
											"BBB",
							Character.valueOf('B'),new ItemStack(Block.cloth, 1 ,15),
							Character.valueOf('W'),new ItemStack(Block.cloth, 1, 0)});
		
		//諏訪子の帽子
		ModLoader.addRecipe(new ItemStack(kerobouItem),
							new Object[]{	"E E",
											" C ",
							Character.valueOf('E'),Item.eyeOfEnder,
							Character.valueOf('C'),Item.helmetLeather });
		
		//スピア・ザ・グングニル
		ModLoader.addRecipe(new ItemStack(spearTheGungnirItem),
							new Object[]{	"LLR",
											" RL",
											"R L",
							Character.valueOf('L'),laser1,
							Character.valueOf('R'),Block.blockRedstone});
		
		//レーヴァテイン
		ModLoader.addRecipe(new ItemStack(laevateinnItem),
							new Object[]{	" PB",
											"POP",
											"GP ",
							Character.valueOf('P'),Item.blazePowder,
							Character.valueOf('G'),Item.swordGold,
							Character.valueOf('O'),orangePearl,
							Character.valueOf('B'),Item.blazeRod});
		
		//パワーアップアイテム（大）
		ModLoader.addRecipe(bigPowerUpItem, 
							new Object[]{	"PPP",
											"PPP",
											"PPP",
							Character.valueOf('P'), smallPowerUpItem});
		
		//弾の素
		ModLoader.addShapelessRecipe(new ItemStack(shotMaterialItem, 64),
							new Object[]{
							new ItemStack(Item.glowstone, 1), new ItemStack(Item.gunpowder, 1)});
		//粒弾
		ModLoader.addRecipe(tinyShot,
							new Object[]{	"B",
							Character.valueOf('B'),shotMaterialItem });
		//小弾
		ModLoader.addRecipe(smallShot,
							new Object[]{	"BB",
							Character.valueOf('B'),shotMaterialItem });
		//中弾
		ModLoader.addRecipe(mediumShot,
							new Object[]{	"BB",
											"BB",
							Character.valueOf('B'),shotMaterialItem });
		//大弾
		ModLoader.addRecipe(bigShot,
							new Object[]{	"BBB",
											"BBB",
											"BBB",
							Character.valueOf('B'),shotMaterialItem });
		//輪弾
		ModLoader.addRecipe(circleShot,
							new Object[]{	" B ",
											"BBB",
											" B " ,
							Character.valueOf('B'),shotMaterialItem });
		//星
		ModLoader.addRecipe(smallStarShot,
							new Object[]{	" B ",
											"BBB",
											"B B",
							Character.valueOf('B'),shotMaterialItem });
		//星
		ModLoader.addRecipe(starShot,
							new Object[]{	"BB",
							Character.valueOf('B'),smallStarShot });
		//鱗弾
		ModLoader.addRecipe(scaleShot,
							new Object[]{	" B ",
											"B B",
											"B B",
							Character.valueOf('B'),shotMaterialItem });
		//蝶弾
		ModLoader.addRecipe(butterflyShot,
							new Object[]{	"B B",
											" B ",
											"B B",
							Character.valueOf('B'),shotMaterialItem });
		//光弾
		ModLoader.addRecipe(lightShot,
							new Object[]{	"B B",
											"   ",
											"B B",
							Character.valueOf('B'),shotMaterialItem });
		
		//ナイフ弾
		ModLoader.addRecipe(knifeShot,
							new Object[]{	"  B",
											"BB ",
											"BB ",
							Character.valueOf('B'),shotMaterialItem });
		
		//ハート弾
				ModLoader.addRecipe(heartShot,
									new Object[]{	"B B",
													"BBB",
													" B ",
									Character.valueOf('B'),shotMaterialItem });
				
		//クナイ弾
		ModLoader.addRecipe(kunaiShot,
						new Object[]{	" BB",
										" BB",
										"B  ",
						Character.valueOf('B'),shotMaterialItem });
		
		//札弾
		ModLoader.addRecipe(talismanShot,
						new Object[]{	"B",
										"B",
						Character.valueOf('B'),shotMaterialItem });
		
		//大光弾
		ModLoader.addRecipe(bigLightShot,
						new Object[]{	"BB",
						Character.valueOf('B'),lightShot });
		
		//米弾
		ModLoader.addRecipe(riceShot,
				new Object[]{	" B",
								"B ",
				Character.valueOf('B'),shotMaterialItem });
		
		//楕円弾
		ModLoader.addRecipe(ovalShot,
				new Object[]{	" BB",
								"BBB",
								"BB ",
				Character.valueOf('B'),shotMaterialItem });
		
		//レーザー
		ModLoader.addRecipe(laser1,
							new Object[]{	"L",
											"L",
											"L",
							Character.valueOf('L'),lightShot });
		//ショートレーザー
		ModLoader.addRecipe(laser2,
							new Object[]{	"L",
											"L",
							Character.valueOf('L'),lightShot });
		
		//ロングレーザー
		ModLoader.addRecipe(laser3,
							new Object[]{	"L",
											"L",
							Character.valueOf('L'),laser2 });
		
		//霊符「夢想封印」
		ModLoader.addRecipe(spellCard[0],
							new Object[]{	"GOG",
											"OPO",
											"GOG",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('O'),bigShot,
							Character.valueOf('G'),Item.glowstone});
		//恋符「マスタースパーク」
		ModLoader.addRecipe(spellCard[1],
							new Object[]{	"SRS",
											"SPS",
											"SHS",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('H'),hakkeroItem,
							Character.valueOf('S'),starShot,
							Character.valueOf('R'),Block.blockRedstone});
		//死蝶「華胥の永眠」
		ModLoader.addRecipe(spellCard[2],
							new Object[]{	"BBB",
											"BPB",
											"BBB",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('B'),butterflyShot});
		//星符「メテオニックシャワー」
		ModLoader.addRecipe(spellCard[3],
							new Object[]{	"BBB",
											"BPB",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('B'),starShot});
		//境符「粒と波の境界」
		ModLoader.addRecipe(spellCard[4],
							new Object[]{	"LWL",
											"WPW",
											"LWL",
							Character.valueOf('P'),Item.paper,
							Character.valueOf('W'),Item.bucketWater,
							Character.valueOf('L'), lightShot});
		//魍魎「二重黒死蝶」
		ModLoader.addRecipe(spellCard[5],
							new Object[]{	"BZB",
											"ZPZ",
											"BZB",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('Z'), Item.rottenFlesh,
							Character.valueOf('B'), butterflyShot});
		//紅符「スカーレットシュート」
		ModLoader.addRecipe(spellCard[6],
							new Object[]{	"BBB",
											"MPM",
											"SSS",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('S'), smallShot,
							Character.valueOf('M'), mediumShot,
							Character.valueOf('B'), bigShot});
		
		//メイド秘技「殺人ドール」
		ModLoader.addRecipe(spellCard[8],
							new Object[]{	" K ",
											"KPK",
											" C ",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('K'), knifeShot,
							Character.valueOf('C'), sakuyawatchItem});
		
		//幻巣「飛行虫ネスト」
		ModLoader.addRecipe(spellCard[10],
							new Object[]{	"L",
											"P",
											"S",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('L'), laser1,
							Character.valueOf('S'), sukimaItem});
		
		//水符「河童のポロロッカ」
		ModLoader.addRecipe(spellCard[11],
							new Object[]{	"WWW",
											"WPW",
											"LLL",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('L'), lightShot,
							Character.valueOf('W'), Item.bucketWater});
		
		//魔符「スターダストレヴァリエ」
		ModLoader.addRecipe(spellCard[12],
							new Object[]{	"MSM",
											"SPS",
											"MSM",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('M'), smallStarShot,
							Character.valueOf('S'), starShot});
		
		//土着神「ケロちゃん風雨に負けず」
		ModLoader.addRecipe(spellCard[13],
							new Object[]{	" L ",
											"LPL",
											"L L",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('L'), lightShot});
		
		//奇跡「ミラクルフルーツ」
			ModLoader.addRecipe(spellCard[14],
								new Object[]{	" S ",
												" P ",
												"   ",
								Character.valueOf('P'), Item.paper,
								Character.valueOf('S'), starShot});
			
		//奇跡「ファフロッキーズの奇跡」
			ModLoader.addRecipe(spellCard[15],
								new Object[]{	"   ",
												"SPS",
												"   ",
								Character.valueOf('P'), Item.paper,
								Character.valueOf('S'), starShot});
		
		//妖怪退治「妖力スポイラー」
			ModLoader.addRecipe(spellCard[16],
								new Object[]{	" S ",
												" P ",
												"S S",
								Character.valueOf('P'), Item.paper,
								Character.valueOf('S'), starShot});
			
		//開海「モーゼの奇跡」
			ModLoader.addRecipe(spellCard[17],
								new Object[]{	"S S",
												" P ",
												"S S",
								Character.valueOf('P'), Item.paper,
								Character.valueOf('S'), starShot});
		
		//大奇跡「八坂の神風」
			ModLoader.addRecipe(spellCard[18],
								new Object[]{	" S ",
												"SPS",
												"S S",
								Character.valueOf('P'), Item.paper,
								Character.valueOf('S'), starShot});
			
		//禁弾「スターボウブレイク」
		ModLoader.addRecipe(spellCard[20],
							new Object[]{	" S ",
											"LPL",
											"L L",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('S'), starShot,
							Character.valueOf('L'), lightShot});
			
		//禁弾「カタディオプトリック」
		ModLoader.addRecipe(spellCard[21],
							new Object[]{	"SSS",
											"MPM",
											"BBB",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('S'), smallShot,
							Character.valueOf('M'), mediumShot,
							Character.valueOf('B'), bigShot});
		
		//祟符「ミシャグジさま」
		ModLoader.addRecipe(spellCard[22],
				new Object[]{	"RRR",
								"RPR",
								"RRR",
				Character.valueOf('P'), Item.paper,
				Character.valueOf('R'), riceShot});
		
		//「レッドマジック」
		ModLoader.addRecipe(spellCard[23],
							new Object[]{	"SSB",
											"SPS",
											"BSS",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('S'), smallShot,
							Character.valueOf('B'), bigShot});
		
		//奇術「エターナルミーク」
		ModLoader.addRecipe(spellCard[24],
							new Object[]{	"KKK",
											" P ",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('K'), knifeShot});
		
		//恋符「ノンディレクショナルレーザー」
		ModLoader.addRecipe(spellCard[25],
							new Object[]{	" L ",
											"LPL",
											"L L",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('L'), laser1});
		
		//幻想「花鳥風月、嘯風弄月」
		ModLoader.addRecipe(spellCard[26],
							new Object[]{	"RYR",
											"YPY",
											"RYR",
							Character.valueOf('P'), Item.paper,
							Character.valueOf('Y'),BlockFlower.plantYellow,
							Character.valueOf('R'),BlockFlower.plantRed});
		
		//弾幕作業台（弾）
		ModLoader.addRecipe(danmakuCraftingTable_shot,
							new Object[]{	"DDD",
											"DCD",
											"DDD",
							Character.valueOf('D'), shotMaterialItem,
							Character.valueOf('C'), Block.workbench});
		
		//弾幕作業台（レーザー）
		ModLoader.addRecipe(danmakuCraftingTable_laser,
							new Object[]{	"DDD",
											"DCD",
											"DDD",
							Character.valueOf('D'), lightShot,
							Character.valueOf('C'), Block.workbench});
		
	}

	
	
	
}