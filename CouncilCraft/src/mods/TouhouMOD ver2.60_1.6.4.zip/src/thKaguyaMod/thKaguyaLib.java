package thKaguyaMod;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.util.StringTranslate;
import net.minecraft.world.World;

import thKaguyaMod.entity.*;
import thKaguyaMod.item.*;

import java.util.List;

public class thKaguyaLib
{
	//汎用関数群
	
	/* 持ち主の指定のポジションにぬるぬるついていく処理
	 * itemEntity    : 追尾するアイテムのEntity。通常はthis
	 * userEntity    : アイテムの持ち主。ついていく対象
	 * lengthToUser  : アイテムと持ち主の距離
	 * positionAngle : 持ち主から見てアイテムの来る角度。0Fで正面。
	 * yForrow       : 垂直方向の角度変化にも反応するか
	 * yOffset       : 垂直方向に反応しない場合の高さ
	 */
	public static final void itemEffectFollowUser(Entity itemEntity, Entity userEntity, double lengthToUser, float positionAngle, boolean yForrow, double yOffset)
	{
		if(userEntity != null)
		{
			float angleXZ,angleY, speed;
    		float disXZ;
    		double posX, posY, posZ;

			if(yForrow)
			{
				posX = userEntity.posX - Math.sin((userEntity.rotationYaw + positionAngle) / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F) * lengthToUser;
    			posZ = userEntity.posZ + Math.cos((userEntity.rotationYaw + positionAngle) / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F) * lengthToUser;
				posY = userEntity.posY - Math.sin(userEntity.rotationPitch / 180F * 3.141593F) * lengthToUser +  (double)userEntity.getEyeHeight() - 0.5D;//若干目の高さより下に設置
			}
			else
			{
				posX = userEntity.posX - Math.sin((userEntity.rotationYaw + positionAngle) / 180F * 3.141593F) * lengthToUser;
    			posZ = userEntity.posZ + Math.cos((userEntity.rotationYaw + positionAngle) / 180F * 3.141593F) * lengthToUser;
				posY = userEntity.posY + yOffset;//若干目の高さより下に設置
			}
    		disXZ = (float)Math.sqrt( (posX - itemEntity.posX) * (posX - itemEntity.posX) + (posZ - itemEntity.posZ) * (posZ - itemEntity.posZ) );
    		angleXZ = (float)Math.atan2(posZ - itemEntity.posZ, posX - itemEntity.posX);
    		angleY  = (float)Math.atan2(disXZ, posY - itemEntity.posY);
    		speed = 0.3F * (float)Math.sqrt((posX - itemEntity.posX) * (posX - itemEntity.posX) + 
    										(posY - itemEntity.posY) * (posY - itemEntity.posY) + 
    										(posZ - itemEntity.posZ) * (posZ - itemEntity.posZ) );//離れるほど速くなる
    		itemEntity.motionX = userEntity.motionX + (posX - itemEntity.posX);
    		itemEntity.motionY = userEntity.motionY + (posY - itemEntity.posY);
    		itemEntity.motionZ = userEntity.motionZ + (posZ - itemEntity.posZ);
    		itemEntity.setPosition(posX, posY, posZ);
		}
	}
	
	//↑と同じだが、垂直方向の角度の影響を受ける場合の簡易
	public static final void itemEffectFollowUser(Entity itemEntity, Entity userEntity, double lengthToUser, float positionAngle)
	{
		itemEffectFollowUser(itemEntity, userEntity, lengthToUser, positionAngle, true, 0.0D);
	}
	
	/* Entityとして出現しているアイテムの効果が切れたときの処理
	 * itemEntity : 効果を終えるEntity。通常はthis
	 * userEntity : アイテムの持ち主。プレイヤー
	 * item       : アイテム化するアイテム
	 * damage     : アイテム化したときのダメージ値
	 */
	public static final boolean itemEffectFinish(Entity itemEntity, EntityLivingBase userEntity, Item item, int damage)
	{	
		//使用者がクリエイティブではなく、存在するなら
		if(userEntity != null )
		{
			if(userEntity instanceof EntityPlayer)
			{
				EntityPlayer userEntity_p = (EntityPlayer)userEntity;
				if(userEntity_p.capabilities.isCreativeMode)//使用者がクリエイティブモードなら
				{
					itemEntity.setDead();//そのまま消滅させる
					return true;
				}
				//アイテムをインベントリに加える
				if(userEntity_p.inventory.addItemStackToInventory(new ItemStack(item, 1, damage)) == false)
				{
					//インベントリが一杯なら使用者の目の前でアイテム化
					//（クリエイティブでは常にインベントリには物が吸収される仕様があるらしく、クリエイティブでは落とさない（false判定がでない)）
					if(!itemEntity.worldObj.isRemote)
					{
						itemEntity.worldObj.spawnEntityInWorld(new EntityItem(itemEntity.worldObj, itemEntity.posX, itemEntity.posY, itemEntity.posZ, new ItemStack(item, 1, damage)));
					}
					itemEntity.setDead();
					return true;
				}
			}
			if(userEntity.isDead)//使用者が死んでいるなら
			{
				if(!itemEntity.worldObj.isRemote)
				{
					//アイテム化し、その場にドロップ
					itemEntity.worldObj.spawnEntityInWorld(new EntityItem(itemEntity.worldObj, itemEntity.posX, itemEntity.posY, itemEntity.posZ, new ItemStack(item, 1, damage)));
				}
			}
		}
		else//使用者がいない場合（再起動した際など）にはその場にアイテム化
		{
			if(!itemEntity.worldObj.isRemote)
			{
				itemEntity.worldObj.spawnEntityInWorld(new EntityItem(itemEntity.worldObj, itemEntity.posX, itemEntity.posY, itemEntity.posZ, new ItemStack(item, 1, damage)));
			}
    	}
		itemEntity.setDead();
		return true;
	}
	
	//↑のダメージ値のないアイテム版
	public static final boolean itemEffectFinish(Entity itemEntity, EntityLivingBase userEntity, Item item)
	{
		return itemEffectFinish(itemEntity, userEntity, item, 0);
	}
	
	/*スペルカードを宣言する
	 * スペルカード宣言は相手を選択（遠くの相手でも可）することで可能
	 * スペルカードは一人あたり多重には宣言できない
	 * world            : 宣言するワールド（知らん）
	 * itemStack        : スペルカード
	 * EntityLivingBase : スペルカードの宣言者
	 * spellCardNumber  : スペルカードナンバー。使用するスペルカードを指定
	 * level            : スペルカードの難易度。1～4でEasy～Lunaticに相当。プレイヤー使用のスペルカードは2のNormal
	 * firstAttack      : スペルカード名とスペルカード宣言音を出すかどうか。trueなら出す
	 * 返り値:スペルカード宣言に成功したらtrue
	 */
	public static final boolean checkSpellCardDeclaration(World world, ItemStack itemStack, EntityLivingBase EntityLivingBase, int spellCardNumber, int level, boolean firstAttack)
	{
		if(itemStack.getItemDamage() >= 14 && itemStack.getItemDamage() <=18)
		{
			NBTTagCompound nbt = itemStack.getTagCompound();
			if(nbt != null)
			{
				if(nbt.getInteger("Charge") <= 0)
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		
		double angleX = -Math.sin(radTrans(EntityLivingBase.rotationYaw)) * Math.cos(radTrans(EntityLivingBase.rotationPitch));
    	double angleY = -Math.sin(radTrans(EntityLivingBase.rotationPitch));
    	double angleZ =  Math.cos(radTrans(EntityLivingBase.rotationYaw)) * Math.cos(radTrans(EntityLivingBase.rotationPitch));
    	//始点を登録
    	Vec3 vec3d = world.getWorldVec3Pool().getVecFromPool(EntityLivingBase.posX, EntityLivingBase.posY + EntityLivingBase.getEyeHeight(), EntityLivingBase.posZ);
    	//終点を登録
    	Vec3 vec3d1 = world.getWorldVec3Pool().getVecFromPool(EntityLivingBase.posX + angleX * 32.0D, EntityLivingBase.posY + angleY * 32.0D, EntityLivingBase.posZ + angleZ * 32.0D);
        //始点と終点からブロックとの衝突を取得
    	MovingObjectPosition movingObjectPosition = world.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
    	//始点を再登録
    	vec3d = world.getWorldVec3Pool().getVecFromPool(EntityLivingBase.posX, EntityLivingBase.posY + EntityLivingBase.getEyeHeight(), EntityLivingBase.posZ);
    	//終点を再登録
    	vec3d1 = world.getWorldVec3Pool().getVecFromPool(EntityLivingBase.posX + angleX * 32.0D, EntityLivingBase.posY + angleY * 32.0D, EntityLivingBase.posZ + angleZ * 32.0D);
        //ブロックと衝突していたなら
    	if (movingObjectPosition != null)
        {
        	//終点を衝突した点に変更
        	vec3d1 = world.getWorldVec3Pool().getVecFromPool(movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord);
        }
    	Entity entity = null;

    	//このEntityから移動後までの線分に、指定分の範囲を追加した直方体と衝突するEntityのリストを取得
        List list = world.getEntitiesWithinAABBExcludingEntity(EntityLivingBase, EntityLivingBase.boundingBox.addCoord(angleX * 32.0D, angleY * 32.0D, angleZ * 32.0D).expand(1.0D, 1.0D, 1.0D));
        double nearDistance = 0.0D;
        for (int j = 0; j < list.size(); j++)
        {
        	// 衝突リストから、i番目のEntityを取得
            Entity entity1 = (Entity)list.get(j);

    		if(entity1 instanceof EntityLivingBase && entity1 instanceof EntityAnimal == false && entity1 instanceof EntityVillager == false)
    		{
        		float expand = 0.3F;//当たり判定の加算値
            	AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(expand, expand, expand);//参照中のEntityの当たり判定の拡張？
            	MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);//視点終点の線分との衝突判定
        		//Entityとの衝突がないなら、このEntityはパスする
            	if (movingObjectPosition1 != null)
            	{
        			//始点からEntityに衝突した点までの距離を取得
            		double distanceToHitEntity = vec3d.distanceTo(movingObjectPosition1.hitVec);
        			//今までで一番近いEntityなら、Entityと距離を記憶する
            		if (distanceToHitEntity < nearDistance || nearDistance == 0.0D)
            		{		
                		entity = entity1;
                		nearDistance = distanceToHitEntity;
            		}
            	}
            }
        }
    	
    	List list2 = world.getEntitiesWithinAABBExcludingEntity(EntityLivingBase, EntityLivingBase.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(64.0D, 64.0D, 64.0D));
    	for(int k = 0; k < list2.size(); k++)
    	{
    		Entity entity2 = (Entity)list2.get(k);
    		if(entity2 instanceof EntitySpellCard)
    		{
    			EntitySpellCard entitySpellCard2 = (EntitySpellCard)entity2;
    			if(entitySpellCard2.user == EntityLivingBase)
    			{
    				entity = null;//スペルカード宣言を無効化
    				return false;
    			}
    		}
    	}
    	
    	//Entityに当たっていたなら
        if (entity != null)
        {
            movingObjectPosition = new MovingObjectPosition(entity);
        }
        else
        {
        	return false;
        }
    	
    	if (movingObjectPosition != null && movingObjectPosition.entityHit != null &&itemPossessionCheck(world, EntityLivingBase, spellCardNumber))
        {
        	if(movingObjectPosition.entityHit instanceof EntityLivingBase)
        	{
        		EntityLivingBase EntityLivingBase_target = (EntityLivingBase)movingObjectPosition.entityHit;
        		spellCardDeclaration(world, EntityLivingBase, (EntityLivingBase)movingObjectPosition.entityHit, spellCardNumber, level, firstAttack);
        		return true;
        	}
        }
		return false;	
	}
	
	//上のスペルカードの宣言で宣言が可能だった場合の処理
	public static void spellCardDeclaration(World world, EntityLivingBase EntityLivingBase_user, EntityLivingBase EntityLivingBase_target, int spellCardNumber, int level, boolean firstAttack)
	{
		EntitySpellCard entitySpellCard;
	    entitySpellCard = new EntitySpellCard(world, EntityLivingBase_user, EntityLivingBase_target, spellCardNumber, level);
	    //world.playSoundAtEntity(EntityLivingBase_user, "random.spellcard", mod_thKaguya.SpellCardVol, 1.0F);
		
		if(!world.isRemote)
		{
			world.spawnEntityInWorld(entitySpellCard);//スペルカードを出現させる
			String spellCardName;
			
	       	spellCardName = "spellCard." + spellCardNumber;//mod_thKaguya.scJpName[spellCardNumber];

	       	if(EntityLivingBase_user instanceof EntityPlayer)
	       	{
	       		if(firstAttack)
	       		{
	       			EntityPlayer entityPlayer_user = (EntityPlayer)EntityLivingBase_user;
	       			entityPlayer_user.addChatMessage(spellCardName);
	       			world.playSoundAtEntity(entityPlayer_user, "random.spellcard", mod_thKaguya.SpellCardVol, 1.0F);
	       		}
	       	
	       	}
	       	if(EntityLivingBase_target instanceof EntityPlayer)
	       	{
	       		if(firstAttack)
	       		{
		       		EntityPlayer entityPlayer_target = (EntityPlayer)EntityLivingBase_target;
		       		entityPlayer_target.addChatMessage(spellCardName);
		       		world.playSoundAtEntity(entityPlayer_target, "random.spellcard", mod_thKaguya.SpellCardVol, 1.0F);
	       		}
	       	}
		}
	}
	
	private static boolean itemPossessionCheck(World world, EntityLivingBase EntityLivingBase, int nomber)
	{
		/*switch(nomber)
		{
			case 1:*/
		return true;		
	}
	
	
	//銀のナイフを出現させる
	public static final EntitySilverKnife createSilverKnife(World world, EntityLivingBase user, double posX, double posY, double posZ, double motionX, double motionY, double motionZ, double speed, int color, int startCount )
	{
		EntitySilverKnife silverKnife;
		if(user != null)
		{
			silverKnife = new EntitySilverKnife(world, user, posX, posY, posZ, motionX, motionY, motionZ, speed, 3);
			silverKnife.setKnifeCount(startCount);

		    if(!world.isRemote)
		    {
				world.spawnEntityInWorld(silverKnife);//銀のナイフを出現させる
				 return silverKnife;
		    }
		   
		}
		return null;
	}
	
	/*ホーミングアミュレットを生成する
	 * ほとんど弾の生成処理と同じ
	 * colorは 0で小さいホーミングアミュレット、1で大きいホーミングアミュレット、2で小さい拡散しないアミュレット、3で大きい拡散アミュレット
	 */
	public static final EntityHomingAmulet createHomingAmulet(World world, EntityLivingBase user, Entity source, double posX, double posY, double posZ, double vectorX, double vectorY, double vectorZ, 
			double firstSpeed, double limitSpeed, double acceleration, double xVectorG, double yVectorG, double zVectorG, 
			float damage, int color, float size, int end, int delay)
	{
		EntityHomingAmulet amulet = null;
		if(user != null)
		{
			amulet = new EntityHomingAmulet(world, user, source, posX, posY, posZ, vectorX, vectorY, vectorZ, firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, color, size, end, delay, 0);
			if(!world.isRemote)
			{
				world.spawnEntityInWorld(amulet);//ホーミングアミュレットを出現させる
			}
		}
		return amulet;
	}
		
	public static final float radTrans(float deg)
	{
		return deg / 180F * (float)Math.PI;
	}
		
	public static final float degTrans(float rad)
	{
		return rad / (float)Math.PI * 180F;
	}
			
	//３Dベクトルを返す
}