package thKaguyaMod;

import net.minecraft.inventory.*;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class SlotDanmakuCraftingA extends Slot
{
    /** The beacon this slot belongs to. */
    //final ContainerDanmakuCrafting danmaku;
	protected int slotType;
	//private final IInventory craftMatrix;
	
    public SlotDanmakuCraftingA(IInventory iInventory, int index, int x, int y, int type)
    {
        super(iInventory, index, x, y);
        slotType = type;
        //craftMatrix = iInventory;
        
        //this.danmaku = containerDanmakuCrafting;
    }

    /**
     * Check if the stack is a valid item for this slot. Always true beside for the armor slots.
     */
    public boolean isItemValid(ItemStack itemStack)
    {
    	switch(slotType)
    	{
    		case 0:
    			return itemStack == null ? false : (itemStack.itemID == mod_thKaguya.powerItem.itemID && itemStack.getItemDamage() == 0);
    		case 1:
    			return itemStack == null ? false : itemStack.itemID == mod_thKaguya.pointItem.itemID;
    		case 2:
    			return itemStack == null ? false : itemStack.itemID == mod_thKaguya.thShotItem.itemID;
    		case 3:
    			return itemStack == null ? false : itemStack.itemID == Item.dyePowder.itemID;
    		case 4:
    			return itemStack == null ? false : (itemStack.itemID == mod_thKaguya.powerItem.itemID && itemStack.getItemDamage() == 1);
    		case 5:
    			return itemStack == null ? false : itemStack.itemID == mod_thKaguya.thLaserItem.itemID;
    		default:
    			return false;
    	}
    }

    /**
     * Returns the maximum stack size for a given slot (usually the same as getInventoryStackLimit(), but 1 in the case
     * of armor slots)
     */
    public int getSlotStackLimit()
    {
    	return 64;
    	/*switch(slotType)
    	{
    		case 0:
    			return 64;
    	}
        return 1;*/
    }
}
