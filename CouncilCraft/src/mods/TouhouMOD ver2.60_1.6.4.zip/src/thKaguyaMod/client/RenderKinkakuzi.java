package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntityKinkakuzi;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.Random;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderKinkakuzi extends Render
{
	
	//金閣寺の一枚天井を描画
	private static final ResourceLocation field_110782_f = new ResourceLocation("thkaguyamod", "textures/Kinkakuzi.png");
    /** instance of ModelBoat for rendering */
    protected ModelBase modelKinkakuzi;

    public RenderKinkakuzi()
    {
        shadowSize = 3.0F;//多分影のサイズ
        modelKinkakuzi = new ModelKinkakuzi();
    }

    public void renderKinkakuzi(EntityKinkakuzi entityKinkakuzi, double x, double y, double z, float par8, float par9)
    {
        GL11.glPushMatrix();
        func_110777_b(entityKinkakuzi);
        GL11.glTranslatef((float)x, (float)y, (float)z);
        GL11.glRotatef(180F - par8, 0.0F, 1.0F, 0.0F);
        float f = (float)entityKinkakuzi.getTimeSinceHit() - par9;
        float f1 = (float)entityKinkakuzi.getDamageTaken() - par9;

        if (f1 < 0.0F)
        {
            f1 = 0.0F;
        }

        if (f > 0.0F)
        {
            GL11.glRotatef(((MathHelper.sin(f) * f * f1) / 10.0F) * (float)entityKinkakuzi.getForwardDirection(), 1.0F, 0.0F, 0.0F);
        }

        //loadTexture("/terrain.png");
        //loadTexture("/textures/Kinkakuzi.png");//テクスチャ画像を読み込み
    	GL11.glScalef(3.0F, 0.75F, 3.0F);
        //GL11.glScalef(0.75, 0.75, 0.75);//倍率　縦方向 高さ　幅
        modelKinkakuzi.render(entityKinkakuzi, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110781_a(EntityKinkakuzi entityKinkakuzi)
    {
        return field_110782_f;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityKinkakuzi)entity);
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity) and this method has signature public void doRender(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doesn't do that.
     */
    public void doRender(Entity entity, double x, double y, double z, float par8, float par9)
    {
        renderKinkakuzi((EntityKinkakuzi)entity, x, y, z, par8, par9);
    }
}
