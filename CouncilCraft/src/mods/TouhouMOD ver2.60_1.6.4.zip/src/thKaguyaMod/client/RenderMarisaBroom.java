package thKaguyaMod.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import org.lwjgl.opengl.GL11;

import thKaguyaMod.entity.EntityMarisaBroom;

@SideOnly(Side.CLIENT)
public class RenderMarisaBroom extends Render
{
    //魔理沙の箒を描画
	private static final ResourceLocation field_110782_f = new ResourceLocation("thkaguyamod", "textures/MagicBloom.png");
    protected ModelBase modelMarisaBroom;

    public RenderMarisaBroom()
    {
        this.shadowSize = 0.5F;
        this.modelMarisaBroom = new ModelMarisaBroom();
    }

    /**
     * The render method used in RenderBoat that renders the boat model.
     */
    public void renderMarisaBroom(EntityMarisaBroom entityMarisaBroom, double x, double y, double z, float par8, float par9)
    {
        GL11.glPushMatrix();
        func_110777_b(entityMarisaBroom);
        GL11.glTranslatef((float)x, (float)y, (float)z);
        GL11.glRotatef(180.0F - par8, 0.0F, 1.0F, 0.0F);
        float f2 = (float)entityMarisaBroom.getTimeSinceHit() - par9;
        float f3 = entityMarisaBroom.getDamageTaken() - par9;

        if (f3 < 0.0F)
        {
            f3 = 0.0F;
        }

        if (f2 > 0.0F)
        {
            GL11.glRotatef(MathHelper.sin(f2) * f2 * f3 / 10.0F * (float)entityMarisaBroom.getForwardDirection(), 1.0F, 0.0F, 0.0F);
        }

        //this.loadTexture("/terrain.png");
        float size = 0.75F;
        GL11.glScalef(size, size, size);
        GL11.glScalef(1.0F / size, 1.0F / size, 1.0F / size);
        //this.loadTexture("/item/boat.png");
        GL11.glScalef(-1.0F, -1.0F, 1.0F);
        //this.modelMarisaBroom.render(entityMarisaBroom, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
        Tessellator tessellator = Tessellator.instance;
        //GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        //GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    	//int randColor = random.nextInt(7);
        GL11.glRotatef(-90F, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-entityMarisaBroom.rotationPitch, 1.0F, 0.0F, 0.0F);
        float rodWidth = 0.05F;
        float rodWidth2 = 0.3F;
        float rodWidth3 = 0.4F;
        float rodWidth4 = 0.15F;
        double rodLength = 2.8D;
        double rodLengthHalf = rodLength / 2.0D;
    	
        for(int i = 0; i < 4; i++)
        {
	    	tessellator.startDrawingQuads();
	    	//tessellator.setColorRGBA_F(colorR[randColor], colorG[randColor], colorB[randColor], 0.3F);
	        tessellator.setNormal(0.0F, 1.0F, 0.0F);
	        tessellator.addVertexWithUV( rodWidth, -rodWidth,  rodLengthHalf, 0F, 2F / 32F);
	        tessellator.addVertexWithUV( rodWidth, -rodWidth, -rodLengthHalf, 1F, 2F / 32F);
	        tessellator.addVertexWithUV( rodWidth,  rodWidth, -rodLengthHalf, 1F, 0F);
	        tessellator.addVertexWithUV( rodWidth,  rodWidth,  rodLengthHalf, 0F, 0F);
	        tessellator.draw();
	        GL11.glRotatef(90F, 0.0F, 0.0F, 1.0F);
        }
    	tessellator.startDrawingQuads();
        tessellator.setNormal(0.0F, 1.0F, 0.0F);
        tessellator.addVertexWithUV( -rodWidth, -rodWidth,  rodLengthHalf, 0F      , 2F / 32F);
        tessellator.addVertexWithUV(  rodWidth, -rodWidth,  rodLengthHalf, 2F / 32F, 2F / 32F);
        tessellator.addVertexWithUV(  rodWidth,  rodWidth,  rodLengthHalf, 2F / 32F, 4F / 32F);
        tessellator.addVertexWithUV( -rodWidth,  rodWidth,  rodLengthHalf, 0F      , 4F / 32F);
        tessellator.draw();
        
    	tessellator.startDrawingQuads();
        tessellator.setNormal(0.0F, 1.0F, 0.0F);
        tessellator.addVertexWithUV( -rodWidth4, -rodWidth4,  -rodLengthHalf+0.3D, 0.25F, 0.5F);
        tessellator.addVertexWithUV(  rodWidth4, -rodWidth4,  -rodLengthHalf+0.3D, 0.50F, 0.5F);
        tessellator.addVertexWithUV(  rodWidth4,  rodWidth4,  -rodLengthHalf+0.3D, 0.50F, 1.0F);
        tessellator.addVertexWithUV( -rodWidth4,  rodWidth4,  -rodLengthHalf+0.3D, 0.25F, 1.0F);
        tessellator.draw();
        
    	tessellator.startDrawingQuads();
        tessellator.setNormal(0.0F, 1.0F, 0.0F);
        tessellator.addVertexWithUV( -rodWidth3, -rodWidth3,  -rodLengthHalf-1.3D, 0.25F, 0.5F);
        tessellator.addVertexWithUV( -rodWidth3,  rodWidth3,  -rodLengthHalf-1.3D, 0.25F, 1.0F);
        tessellator.addVertexWithUV(  rodWidth3,  rodWidth3,  -rodLengthHalf-1.3D, 0.50F, 1.0F);
        tessellator.addVertexWithUV(  rodWidth3, -rodWidth3,  -rodLengthHalf-1.3D, 0.50F, 0.5F);
        
        
        tessellator.draw();
        
        for(int i = 0; i < 4; i++)
        {
        	tessellator.startDrawingQuads();
	        tessellator.setNormal(0.0F, 1.0F, 0.0F);
	        tessellator.addVertexWithUV( rodWidth4,   -rodWidth4, -rodLengthHalf+0.3D      , 0.5D, 0.5F);
	        tessellator.addVertexWithUV( rodWidth,  -rodWidth, -rodLengthHalf          , 0.5F, 3F / 32F);
	        tessellator.addVertexWithUV( rodWidth,   rodWidth, -rodLengthHalf          , 1.0F, 3F / 32F);
	        tessellator.addVertexWithUV( rodWidth4,    rodWidth4, -rodLengthHalf+0.3D      , 1.0D, 0.5F);
	        tessellator.draw();
	        
	    	tessellator.startDrawingQuads();
	        tessellator.setNormal(0.0F, 1.0F, 0.0F);
	        tessellator.addVertexWithUV( rodWidth,   -rodWidth, -rodLengthHalf      , 0.5D, 0.5F);
	        tessellator.addVertexWithUV( rodWidth2,  -rodWidth2, -rodLengthHalf-0.6D, 0.5F, 3F / 32F);
	        tessellator.addVertexWithUV( rodWidth2,   rodWidth2, -rodLengthHalf-0.6D, 1.0F, 3F / 32F);
	        tessellator.addVertexWithUV( rodWidth,    rodWidth, -rodLengthHalf      , 1.0D, 0.5F);
	        tessellator.draw();
	        
	    	tessellator.startDrawingQuads();
	        tessellator.setNormal(0.0F, 1.0F, 0.0F);
	        tessellator.addVertexWithUV( rodWidth2,  -rodWidth2, -rodLengthHalf-0.6D, 0.5F, 1.0F);
	        tessellator.addVertexWithUV( rodWidth3,  -rodWidth3, -rodLengthHalf-1.3D, 0.5F, 16F / 32F);
	        tessellator.addVertexWithUV( rodWidth3,   rodWidth3, -rodLengthHalf-1.3D, 1.0F, 16F / 32F);
	        tessellator.addVertexWithUV( rodWidth2,   rodWidth2, -rodLengthHalf-0.6D, 1.0F, 1.0F);
	        tessellator.draw();
	        GL11.glRotatef(90F, 0.0F, 0.0F, 1.0F);
        }
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110781_a(EntityMarisaBroom entityMarisaBroom)
    {
        return field_110782_f;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityMarisaBroom)entity);
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity) and this method has signature public void doRender(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doesn't do that.
     */
    public void doRender(Entity entity, double x, double y, double z, float par8, float par9)
    {
        this.renderMarisaBroom((EntityMarisaBroom)entity, x, y, z, par8, par9);
    }
}
