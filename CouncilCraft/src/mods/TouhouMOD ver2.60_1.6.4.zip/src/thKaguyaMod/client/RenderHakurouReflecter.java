package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thKaguyaMod.entity.EntityHakurouReflecter;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderHakurouReflecter extends Render
{
	
	//霊夢の結界の描画
	private static final ResourceLocation field_110782_f = new ResourceLocation("thkaguyamod", "textures/HakurouReflect.png");
	private Random random = new Random();

    public RenderHakurouReflecter()
    {
    }

    public void doRenderHakurouReflecter(EntityHakurouReflecter entityHakurouReflecter, double x, double y, double z,
            float f, float f1)
    {
        GL11.glPushMatrix();
        func_110777_b(entityHakurouReflecter);
        GL11.glTranslatef((float)x, (float)y, (float)z);
		GL11.glDisable(GL11.GL_LIGHTING);
    	GL11.glEnable(GL11.GL_BLEND);
    	GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
    	GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
        float size = 1.0F;
        GL11.glScalef(size, size, size);
        //loadTexture("/textures/Kishitudan2.png");
        
    	Tessellator tessellator = Tessellator.instance;

        float minU = 0.0F;
        float maxU = 0.5F;
        float minV = 0.0F;
        float maxV = 1.0F;
    	float width = 1.5F;
        float height= 1.5F;
        GL11.glRotatef(f, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(entityHakurouReflecter.rotationPitch, 1.0F, 0.0F, 0.0F);
        
        float angle = entityHakurouReflecter.ticksExisted / 5F;
        float span = (float)Math.PI / 8F;
        double length = 1.8D;
        for(int i = 0; i < 3; i++)
        {
	        double xPos1 = Math.cos(angle) * length; 
	        double xPos2 = Math.cos(angle + span) * length;
	        double yPos1 = Math.sin(angle) * length;
	        double yPos2 = Math.sin(angle + span) * length;
	        for(int j = 0; j < 16; j++)
	        {
	        	tessellator.startDrawingQuads();
		    	tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.2F + j * 0.3F);
		        tessellator.setNormal(0.0F, 1.0F, 0.0F);
		        tessellator.addVertexWithUV( xPos1,  yPos1, 0.0D, minU, maxV);
		        tessellator.addVertexWithUV( xPos2,  yPos2, 0.0D, maxU, maxV);
		        tessellator.addVertexWithUV(     0,      0, 0.0D, maxU, minV);
		        tessellator.addVertexWithUV(     0,      0, 0.0D, minU, minV);	
		        tessellator.draw();
		        //GL11.glRotatef(22.5F, 0.0F, 0.0F, 1.0F);
		        angle += span;
		        xPos1 = Math.cos(angle) * length; 
		        xPos2 = Math.cos(angle + span) * length;
		        yPos1 = Math.sin(angle) * length;
		        yPos2 = Math.sin(angle + span) * length;
	        }
	        length -= 0.3D;
        }
        GL11.glEnable(GL11.GL_CULL_FACE);//表綿描画
    	GL11.glDisable(GL11.GL_BLEND);
    	GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110784_a(EntityHakurouReflecter entityHakurouReflecter)
    {
        return field_110782_f;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110784_a((EntityHakurouReflecter)entity);
    }

    public void doRender(Entity entity, double x, double y, double z,
            float f, float f1)
    {
        doRenderHakurouReflecter((EntityHakurouReflecter)entity, x, y, z, f, f1);
    }
}
