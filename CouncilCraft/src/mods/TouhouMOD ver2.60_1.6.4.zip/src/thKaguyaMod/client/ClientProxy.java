package thKaguyaMod.client;

import net.minecraftforge.client.MinecraftForgeClient;
import thKaguyaMod.CommonProxy;
import thKaguyaMod.entity.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderCreeper;
import thKaguyaMod.tileentity.TileEntityDivineSpirit;

// レンダーに関するレジストリ
import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.client.registry.RenderingRegistry;

//import thkaguyamod.*;

// クライアント側のみのクラスはこのアノテーションをつける
@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy
{
	public static int hinezumiID;
	
	public void registerTextures()
	{
		//MinecraftForgeClient.preloadTexture("/gui/thKaguyaTerrain.png");
		//MinecraftForgeClient.preloadTexture("/armor/hinezumi_1.png");
	}
	
	public void registerRenderers()
	{
		// ModLoader.addRendererでのmap.putに相当
		// Entityのクラスと描画, モデルを結びつける
		RenderingRegistry.registerEntityRenderingHandler(EntityTHFairy.class, new RenderTHFairy());
		RenderingRegistry.registerEntityRenderingHandler(EntityTHFairyCirno.class, new RenderTHFairyCirno());
		//RenderingRegistry.registerEntityRenderingHandler(EntityHouraiTama.class, new RenderHouraiTama());
		RenderingRegistry.registerEntityRenderingHandler(EntityRyuuLightningBolt.class, new RenderRyuuLightningBolt());
		RenderingRegistry.registerEntityRenderingHandler(EntityColorLightningBolt.class, new RenderColorLightningBolt());
		RenderingRegistry.registerEntityRenderingHandler(EntityKinkakuzi.class, new RenderKinkakuzi());
		RenderingRegistry.registerEntityRenderingHandler(EntityPendulum.class, new RenderPendulum());
		RenderingRegistry.registerEntityRenderingHandler(EntityPrivateSquare.class, new RenderPrivateSquare());
		RenderingRegistry.registerEntityRenderingHandler(EntitySilverKnife.class, new RenderSilverKnife());
		RenderingRegistry.registerEntityRenderingHandler(EntitySukima.class, new RenderSukima());
		RenderingRegistry.registerEntityRenderingHandler(EntityMazinkyoukan.class, new RenderMazinkyoukan());
		RenderingRegistry.registerEntityRenderingHandler(EntityHisou.class, new RenderHisou());
		//RenderingRegistry.registerEntityRenderingHandler(EntityKishitudan.class, new RenderKishitudan());
		//RenderingRegistry.registerEntityRenderingHandler(EntityButterflyShot.class, new RenderButterflyShot());
		RenderingRegistry.registerEntityRenderingHandler(EntityMiniHakkero.class, new RenderMiniHakkero());
		RenderingRegistry.registerEntityRenderingHandler(EntityMiracleCircle.class, new RenderMiracleCircle());
		RenderingRegistry.registerEntityRenderingHandler(EntitySanaeWind.class, new RenderSanaeWind());
		RenderingRegistry.registerEntityRenderingHandler(EntityUmiware.class, new RenderUmiware());
		RenderingRegistry.registerEntityRenderingHandler(EntityYouryokuSpoiler.class, new RenderYouryokuSpoiler());		
		RenderingRegistry.registerEntityRenderingHandler(EntityMasterSpark.class, new RenderMasterSpark());
		RenderingRegistry.registerEntityRenderingHandler(EntityHomingAmulet.class, new RenderHomingAmulet());
		RenderingRegistry.registerEntityRenderingHandler(EntityYuukaParasol.class, new RenderYuukaParasol());
		//RenderingRegistry.registerEntityRenderingHandler(EntityUrokoShot.class, new RenderUrokoShot());
		RenderingRegistry.registerEntityRenderingHandler(EntityAjaRedStoneEffect.class, new RenderAjaRedStoneEffect());
		//RenderingRegistry.registerEntityRenderingHandler(EntityAjaRedStoneLaser.class, new RenderAjaRedStoneLaser());
		RenderingRegistry.registerEntityRenderingHandler(EntityTHShot.class, new RenderTHShot());
		RenderingRegistry.registerEntityRenderingHandler(EntityTHLaser.class, new RenderTHLaser());
		RenderingRegistry.registerEntityRenderingHandler(EntitySpellCard.class, new RenderSpellCard());
		RenderingRegistry.registerEntityRenderingHandler(EntityMusouFuuin.class, new RenderMusouFuuin());
		//RenderingRegistry.registerEntityRenderingHandler(EntityHakureiShield.class, new RenderHakureiShield());
		//RenderingRegistry.registerEntityRenderingHandler(EntityTHHenyoriLaser.class, new RenderTHHenyoriLaser());
		RenderingRegistry.registerEntityRenderingHandler(EntityDanmakuCreeper.class, new RenderCreeper());
		
		RenderingRegistry.registerEntityRenderingHandler(EntityMarisaBroom.class, new RenderMarisaBroom());
		RenderingRegistry.registerEntityRenderingHandler(EntityNuclearShot.class, new RenderNuclearShot());
		RenderingRegistry.registerEntityRenderingHandler(EntityHakurouReflecter.class, new RenderHakurouReflecter());
		RenderingRegistry.registerEntityRenderingHandler(EntityOnmyoudama.class, new RenderOnmyoudama());
		RenderingRegistry.registerEntityRenderingHandler(EntityTHSetLaser.class, new RenderTHLaser());
		RenderingRegistry.registerEntityRenderingHandler(EntityDivineSpirit.class, new RenderDivineSpirit());
		
		
		RenderingRegistry.addNewArmourRendererPrefix("hinezumiw");
		
		RenderingRegistry.getNextAvailableRenderId();
		RenderingRegistry.registerBlockHandler(new RenderDivineSpiritBlock());
		
		ClientRegistry.bindTileEntitySpecialRenderer(TileEntityDivineSpirit.class, new TileEntityDivineSpiritRenderer());
	}
	
	public int addArmor(String armor)
	{
		return RenderingRegistry.addNewArmourRendererPrefix(armor);
	}
	
	@Override
	public int getNewRenderType()
	{
		return RenderingRegistry.getNextAvailableRenderId();
	}

}