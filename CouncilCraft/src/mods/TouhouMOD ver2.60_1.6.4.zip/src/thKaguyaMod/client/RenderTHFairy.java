package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.entity.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntityTHFairy;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderTHFairy extends RenderLiving
{
	//妖精を描画する

    public RenderTHFairy()
    {
        super(new ModelTHFairy2(), 0.25F);
    }

	public void doRenderTHFairy(EntityTHFairy entityTHFairy, double x, double y, double z, float yaw, float pitch)
	{
        super.doRenderLiving(entityTHFairy, x, y, z, yaw, pitch);
        func_110777_b(entityTHFairy);
        
        if(entityTHFairy.func_110143_aJ() <= 0 && entityTHFairy.getFairyType() < 0)
        {
        	GL11.glDisable(GL11.GL_LIGHTING);
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        	GL11.glDisable(GL11.GL_CULL_FACE);//両面描画

        	Tessellator tessellator = Tessellator.instance;
        	float f3 = 0.75F;//(float)((color % 16) * 16 +  0) / 256F;
            float f4 = 1.0F;//(float)((color % 16) * 16 + 16) / 256F;
            float f5 = 0.5F;//(float)((color / 16) * 16 +  0) / 256F;
            float f6 = 0.75F;//(float)((color / 16) * 16 + 16) / 256F;
            float f7 = 1.0F;
            float f8 = 0.5F;
            float f9 = 0.5F;
            
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 1.0F, 0.0F);
            tessellator.addVertexWithUV( x - 0.5F, y + 2.5F, z + 0.5D, f3, f6);
            tessellator.addVertexWithUV( x + 0.5F, y + 2.5F, z + 0.5D, f4, f6);
            tessellator.addVertexWithUV( x + 0.5F, y + 2.5F, z - 0.5D, f4, f5);
            tessellator.addVertexWithUV( x - 0.5F, y + 2.5F, z - 0.5D, f3, f5);
    		tessellator.draw();
    		GL11.glEnable(GL11.GL_CULL_FACE);//両面描画
    		GL11.glDisable(GL11.GL_BLEND);
    		GL11.glEnable(GL11.GL_LIGHTING);
        }
	}
    /*public void func_82443_a(EntityTHFairy entityTHFairy, double par2, double par4, double par6, float par8, float par9)
    {
        //int var10 = ((ModelTHFairy)this.mainModel).getBatSize();

        int var10 = 36;
    	
    	if (var10 != this.renderedFailySize)
        {
            this.renderedFailySize = var10;
            this.mainModel = new ModelTHFairy();
        }

        super.doRenderLiving(entityTHFairy, par2, par4, par6, par8, par9);
    }*/

    protected void func_82442_a(EntityTHFairy entityFaily, float par2)
    {
        GL11.glScalef(1.00F, 1.00F, 1.00F);
    }

    protected void func_82445_a(EntityTHFairy entityTHFairy, double x, double y, double z)
    {
        super.renderLivingAt(entityTHFairy, x, y, z);
    }

    protected void func_82444_a(EntityTHFairy entityTHFairy, float x, float y, float z)
    {
        //if (!entityTHFairy.getIsTHFairyHanging())
        {
            GL11.glTranslatef(0.0F, MathHelper.cos(x * 0.3F) * 0.1F, 0.0F);
        }
        //else
        {
            GL11.glTranslatef(0.0F, -0.1F, 0.0F);
        }

        super.rotateCorpse(entityTHFairy, x, y, z);
    }

    /**
     * Allows the render to do any OpenGL state modifications necessary before the model is rendered. Args:
     * entityLiving, partialTickTime
     */
    protected void preRenderCallback(EntityLiving entityLiving, float par2)
    {
        this.func_82442_a((EntityTHFairy)entityLiving, par2);
    }

    protected void rotateCorpse(EntityLiving par1EntityLiving, float par2, float par3, float par4)
    {
        this.func_82444_a((EntityTHFairy)par1EntityLiving, par2, par3, par4);
    }

    /**
     * Sets a simple glTranslate on a LivingEntity.
     */
    protected void renderLivingAt(EntityLiving par1EntityLiving, double par2, double par4, double par6)
    {
        this.func_82445_a((EntityTHFairy)par1EntityLiving, par2, par4, par6);
    }

    public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float yaw, float pitch)
    {
        //this.func_82443_a((EntityTHFairy)par1EntityLiving, par2, par4, par6, par8, par9);
    	this.doRenderTHFairy((EntityTHFairy)entityLiving, x, y, z, yaw, pitch);
    }
    
    protected ResourceLocation func_110781_a(EntityTHFairy entityTHFairy)
    {
    	ResourceLocation resourceLocation;
    	if(entityTHFairy.getFairyType() >= 0)
    	{
    		resourceLocation = new ResourceLocation("thkaguyamod", "textures/fairy" + entityTHFairy.getFairyType() % 3 + ".png");
    	}
    	else
    	{
    		resourceLocation = new ResourceLocation("thkaguyamod", "textures/zombieFairy.png");
    	}
        return resourceLocation;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityTHFairy)entity);
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity) and this method has signature public void doRender(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doesn't do that.
     */
    public void doRender(Entity entity, double x, double y, double z, float yaw, float pitch)
    {
        //this.func_82443_a((EntityTHFairy)par1Entity, par2, par4, par6, par8, par9);
    	this.doRenderTHFairy((EntityTHFairy)entity, x, y, z, yaw, pitch);
    }
}
