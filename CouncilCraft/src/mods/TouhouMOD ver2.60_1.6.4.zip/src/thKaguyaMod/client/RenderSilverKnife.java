package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntitySilverKnife;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

@SideOnly(Side.CLIENT)
public class RenderSilverKnife extends Render
{
	
	//銀のナイフの描画
	private static final ResourceLocation resourceLocation_Knife_Blue = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Blue.png");
	private static final ResourceLocation resourceLocation_Knife_Red = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Red.png");
	private static final ResourceLocation resourceLocation_Knife_Green = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Green.png");
	private static final ResourceLocation resourceLocation_Knife_White= new ResourceLocation("thkaguyamod", "textures/SilverKnife_White.png");
	
    protected ModelBase modelSilverKnife;

    public RenderSilverKnife()
    {
        shadowSize = 0.3F;//多分影のサイズ
        modelSilverKnife = new ModelSilverKnife();
    }

    public void renderSilverKnife(EntitySilverKnife entitySilverKnife, double x, double y, double z, float yaw, float pitch)
    {

        GL11.glPushMatrix();
        func_110777_b(entitySilverKnife);
        GL11.glTranslatef((float)x, (float)y, (float)z);
        
        //double angleXZ = Math.atan2(entitySilverKnife.posX - entitySilverKnife.lastTickPosX, entitySilverKnife.posZ - entitySilverKnife.lastTickPosZ) / Math.PI * 180.0D;
    	GL11.glRotatef( 180F - yaw,   0F, 1F, 0F);
    	GL11.glRotatef(-entitySilverKnife.rotationPitch, 1F, 0F, 0F);
        //GL11.glRotatef((float)angleXZ, 1F, 0F, 0F);
		//GL11.glRotatef( entitySilverKnife.getKnifeYAngle(),   0F, 1F, 0F);
		//GL11.glRotatef(-entitySilverKnife.rotationPitch, 1F, 0F, 0F);
		//GL11.glRotatef(entitySilverKnife.prevRotationYaw + (entitySilverKnife.rotationYaw - entitySilverKnife.prevRotationYaw) * pitch - 90.0F, 0.0F, 1.0F, 0.0F);
        //GL11.glRotatef(entitySilverKnife.prevRotationPitch + (entitySilverKnife.rotationPitch - entitySilverKnife.prevRotationPitch) * pitch, 0.0F, 0.0F, 1.0F);
    	//GL11.glRotatef(-pitch, 1F, 0F, 0F);
    	GL11.glRotatef( entitySilverKnife.getKnifeZAngle(), 0F, 0F, 1F);

    	GL11.glScalef(0.5F, 0.5F, 0.5F);//倍率　縦方向 高さ　幅
		//modelSilverKnife.render(entitySilverKnife, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
    	//最後の引数がサイズの倍率
    	modelSilverKnife.render(entitySilverKnife, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110781_a(EntitySilverKnife entitySilverKnife)
    {
    	switch(entitySilverKnife.getKnifeColor())
    	{
    		case 0:
    			return resourceLocation_Knife_Blue;
    		case 1:
    			return resourceLocation_Knife_Red;
    		case 2:
    			return resourceLocation_Knife_Green;
    		default:
    			return resourceLocation_Knife_White;
    	}
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntitySilverKnife)entity);
    }

    public void doRender(Entity entity, double x, double y, double z, float yaw, float pitch)
    {
        renderSilverKnife((EntitySilverKnife)entity, x, y, z, yaw, pitch);
    }
}
