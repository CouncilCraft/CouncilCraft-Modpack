package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityTHShot;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderTHShot extends Render
{
	
	//弾の描画
	private static final ResourceLocation resourceLocation_Normal = new ResourceLocation("thkaguyamod", "textures/Shot.png");
	private static final ResourceLocation resourceLocation_Butterfly = new ResourceLocation("thkaguyamod", "textures/ButterflyShot.png");
	private static final ResourceLocation resourceLocation_Star = new ResourceLocation("thkaguyamod", "textures/StarShot.png");
	private static final ResourceLocation resourceLocation_Scale = new ResourceLocation("thkaguyamod", "textures/ScaleShot.png");
	private static final ResourceLocation resourceLocation_Wind = new ResourceLocation("thkaguyamod", "textures/Wind.png");
	private static final ResourceLocation resourceLocation_Knife_Blue = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Blue.png");
	private static final ResourceLocation resourceLocation_Knife_Red = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Red.png");
	private static final ResourceLocation resourceLocation_Knife_Green = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Green.png");
	private static final ResourceLocation resourceLocation_Knife_Yellow = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Yellow.png");
	private static final ResourceLocation resourceLocation_Knife_Purple = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Purple.png");
	private static final ResourceLocation resourceLocation_Knife_Orange = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Orange.png");
	private static final ResourceLocation resourceLocation_Knife_Aqua = new ResourceLocation("thkaguyamod", "textures/SilverKnife_Aqua.png");
	private static final ResourceLocation resourceLocation_Knife_White= new ResourceLocation("thkaguyamod", "textures/SilverKnife_White.png");
	private static final ResourceLocation resourceLocation_Light= new ResourceLocation("thkaguyamod", "textures/MusouFuuin.png");
	private static final ResourceLocation resourceLocation_Kunai= new ResourceLocation("thkaguyamod", "textures/KunaiShot.png");
	private static final ResourceLocation resourceLocation_Laser= new ResourceLocation("thkaguyamod", "textures/Laser.png");
	
	private Random random = new Random();
	
	protected float colorR[] = { 224F/255F,   0F/255F,   0F/255F, 224F/255F, 224F/255F,   0F/255F, 255F/255F, 255F/255F};
	protected float colorG[] = {   0F/255F,   0F/255F, 224F/255F, 224F/255F,   0F/255F, 224F/255F, 128F/255F, 255F/255F};
	protected float colorB[] = {   0F/255F, 224F/255F,   0F/255F,   0F/255F, 224F/255F, 224F/255F,   0F/255F, 255F/255F};

    public RenderTHShot()
    {
    }

    public void doRenderTHShot(EntityTHShot entityTHShot, double x, double y, double z,
            float yaw, float f1)
    {
        GL11.glPushMatrix();
        func_110777_b(entityTHShot);
        GL11.glTranslatef((float)x, (float)y, (float)z);
    	GL11.glDisable(GL11.GL_LIGHTING);
    	//GL11.glEnable(GL11.GL_NORMALIZE);
    	//GL11.glEnable(GL11.GL_BLEND);
    	//GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
    	//GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    	float size = entityTHShot.getShotSize();
    	float size2;
        Tessellator tessellator = Tessellator.instance;
    	int color = entityTHShot.getShotColor();
    	
    	//弾の遅延描画（光だけ見える）
    	if(entityTHShot.getAnimationCount() < 0)
    	{
    		int delayCount = -entityTHShot.getAnimationCount();
    		if(delayCount > 10)
    		{
    			delayCount = 10;
    		}
    		size2 = delayCount * 0.3F * size;
    		if(size2 > 1.0F)
    		{
    			size2 = 1.0F;
    		}
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
    		GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        	renderLightEffect(tessellator, color % 8, size2, entityTHShot);
        	GL11.glDisable(GL11.GL_BLEND);
    	}
    	//粒弾、小弾、中弾、大弾、輪弾の描画
    	else if(color <= thShotLib.CIRCLE[7]
    			
    			|| (color >= thShotLib.BIG[0] && color <= thShotLib.BIG[7])
    			|| (color >= thShotLib.HEART[0] && color <= thShotLib.HEART[7])
    			)
    	{
    		//GL11.glDisable(GL11.GL_LIGHTING);
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		//GL11.glEnable(GL11.GL_NORMALIZE);
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    		renderNormalShot(tessellator, color);
    		//GL11.glDisable(GL11.GL_NORMALIZE);
    		GL11.glDisable(GL11.GL_BLEND);
    	}
    	//光弾の描画
    	else if(color <= thShotLib.LIGHT[7]
    			|| (color >= thShotLib.BIGLIGHT[0] && color <= thShotLib.BIGLIGHT[7])
    			)
    	{
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    		int count = entityTHShot.getAnimationCount() % 2;
    		renderLightShot(tessellator, color, entityTHShot);
    		GL11.glDisable(GL11.GL_BLEND);
    	}
    	//鱗弾の描画
    	else if(color <= thShotLib.SCALE[7])
    	{
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		size *= 2.0F;
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
        	GL11.glRotatef( entityTHShot.getAngleZ(), 0F, 0F, 1F);
    		renderScaleShot(tessellator, color);
    		GL11.glPopMatrix();//行列を元に戻す
    		
    		GL11.glPushMatrix();
    		GL11.glTranslatef((float)x, (float)y, (float)z);
    		GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        	
    		float size3 = size * 0.9F;
    		GL11.glScalef(size3, size3, size3);
    		
			float f3 = 0.5F;
	        float u2 = 1.0F;
	        float f5 = 0.0F;
	        float f6 = 1.0F;
	        float f7 = 1.0F;
	        float f8 = 0.5F;
	        float f9 = 0.25F;
	        tessellator.startDrawingQuads();
	        tessellator.setNormal(0.0F, 1.0F, 0.0F);
	        tessellator.addVertexWithUV(0.0F - f8, 0.0F - f9, 0.0D, f3, f6);
	        tessellator.addVertexWithUV(f7 - f8, 0.0F - f9, 0.0D, u2, f6);
	        tessellator.addVertexWithUV(f7 - f8, 1.0F - f9, 0.0D, u2, f5);
	        tessellator.addVertexWithUV(0.0F - f8, 1.0F - f9, 0.0D, f3, f5);
			tessellator.draw();
			GL11.glDisable(GL11.GL_BLEND);
			
    		//renderNormalShot(tessellator, color % 8);
    	}
    	//蝶弾の描画
    	else if(color <= thShotLib.BUTTERFLY[7])
    	{
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		GL11.glScalef(size, size, size);
    		float wingAngle = MathHelper.sin((float)entityTHShot.getAnimationCount() / 3.0F) * 45F;
    		float pitch = entityTHShot.rotationPitch;
    		if(pitch > 90F)
    		{
    			pitch = 90F - pitch % 90F;
    		}
    		else if(pitch < -90F)
    		{
    			pitch = -90F - pitch % 90F;
    		}
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
        	GL11.glRotatef( entityTHShot.getAngleZ(), 0F, 0F, 1F);
    		GL11.glRotatef(wingAngle, 0.0F, 0.0F, 1.0F);
    		renderButterflyShot(tessellator, color, wingAngle);
    		GL11.glDisable(GL11.GL_BLEND);
    	}
    	//星弾の描画
    	else if(color <= thShotLib.STAR[7])
    	{
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    		GL11.glRotatef((float)entityTHShot.getAnimationCount() * 3.7F, 0.0F, 0.0F, 1.0F);
    		renderStarShot(tessellator, color);
    		GL11.glDisable(GL11.GL_BLEND);
    	}
    	else if(color <= thShotLib.RICE[7])
    	{
    		/*float sizeX = size * 2F - MathHelper.sin(( entityTHShot.rotationYaw + renderManager.playerViewY) % 360F / 180F * 3.141593F) * size;
    		//float sizeZ = size * 2F + MathHelper.cos((entityTHShot.rotationPitch - renderManager.playerViewX) / 180F * 3.141593F) * size;
    		float sizeY = size * 2F + MathHelper.sin((entityTHShot.rotationPitch - renderManager.playerViewX) / 180F * 3.141593F) * size;
    		float sizeZ = size * 2F + MathHelper.cos(( entityTHShot.rotationYaw + renderManager.playerViewY) % 360F / 180F * 3.141593F) * size;;
    		GL11.glScalef(sizeX, sizeY, sizeZ);
    		if(color >= thShotLib.BIG[0])
    		{
    			size2 = size * 1.5F;
    			GL11.glScalef(size2, size2, size2);
    		}*/
        	
        	/*float yawDifference = (entityTHShot.rotationYaw - (180F - renderManager.playerViewY)) % 180;
        	float pitchDifference = (entityTHShot.rotationPitch - ( -renderManager.playerViewX)) % 180;
        	//float sizeX = size * 2F - MathHelper.sin(( entityTHShot.rotationYaw + renderManager.playerViewY) % 360F / 180F * 3.141593F) * size;
    		//float sizeY = size * 2F + MathHelper.sin((entityTHShot.rotationPitch - renderManager.playerViewX) / 180F * 3.141593F) * size;
    		//float sizeZ = size * 2F + MathHelper.cos(( entityTHShot.rotationYaw + renderManager.playerViewY) % 360F / 180F * 3.141593F) * size;;
        	float sizeX = 1.0F;// + (float)Math.sin(yawDifference / 180F * 3.141593F);
        	float sizeY = 1.0F + (float)Math.sin(pitchDifference / 180F * 3.141593F);
        	float sizeZ = 1.0F;
        	GL11.glScalef(sizeX,  sizeY, sizeZ);
        	GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        	GL11.glRotatef(entityTHShot.rotationYaw, 0.0F, 0.0F, 1.0F);*/
        	
    		
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
    		color %= 8;
    		//renderNormalShot(tessellator, color);
    		renderRiceShot(tessellator, 3.2F, 0.96F, -1.6D, 7, 5, 7, 1.0F);
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		
    		
    		renderRiceShot(tessellator, 4.0F,  1.20F, -2.0D, 7, 5, color, 0.7F);
    		GL11.glDisable(GL11.GL_BLEND);
    		
    	}
    	else if(color <= thShotLib.CRYSTAL[7])
    	{
    		//size2 = size * 2.0F;
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
        	//renderCrystalShot(tessellator, 7, 1.0F);
    		color %= 8;
    		//GL11.glScalef(size2, size2, size2);
    		renderCrystalShot(tessellator, color);
    	}
    	else if(color <= thShotLib.KUNAI[7])
    	{
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
        	GL11.glRotatef( entityTHShot.getAngleZ(), 0F, 0F, 1F);
    		renderKunaiShot(tessellator, color);
    	}
    	else if(color <= thShotLib.TALISMAN[7])
    	{
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
        	GL11.glRotatef( entityTHShot.getAngleZ(), 0F, 0F, 1F);
    		renderTalismanShot(tessellator, color);
    	}
    	else if(color <= thShotLib.OVAL[7])
    	{		
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
    		color %= 8;
    		//renderNormalShot(tessellator, color);
    		
    		renderOvalShot(tessellator, 1.6F, 0.8F, -0.8D, 7, 5, 7, 1.0F);
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		renderOvalShot(tessellator, 2.0F,  1.0F, -1.0D, 7, 5, color, 0.7F);
    		GL11.glDisable(GL11.GL_BLEND);
    	}
    	else if(color <= thShotLib.KNIFE[7])
    	{
    		size2 = size * 3.0F;
    		GL11.glScalef(size2, size2, size2);
    		ModelBase modelSilverKnife;
    		modelSilverKnife = new ModelSilverKnife();
    		GL11.glRotatef( yaw,   0F, 1F, 0F);
        	GL11.glRotatef(-entityTHShot.rotationPitch, 1F, 0F, 0F);
    		modelSilverKnife.render(entityTHShot, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
    	}
    	else if(color <= thShotLib.WIND[7])
    	{
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		size2 = size * 0.5F;
    		GL11.glScalef(size2, size2, size2);
    		renderWindShot(tessellator, color, entityTHShot);
    		GL11.glDisable(GL11.GL_BLEND);
    	}
    	else
    	{
    		GL11.glEnable(GL11.GL_BLEND);
        	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
    		GL11.glScalef(size, size, size);
    		GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        	GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    		int count = entityTHShot.getAnimationCount() % 2;
    		renderKishituShot(tessellator, color, entityTHShot);
    		GL11.glDisable(GL11.GL_BLEND);
    	}

        //GL11.glDisable(GL11.GL_BLEND);
        //GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }
	
	//円形弾の描画
	public void renderNormalShot(Tessellator tessellator, int color)
	{
		//loadTexture("/textures/Shot.png");
		float width = 1.0F;
		float height = 1.0F;
		
		//ハート弾か大弾なら
		if(color >= thShotLib.HEART[0])
		{
			if(color >= thShotLib.BIG[0])
			{
				width = 1.5F;
				height = 1.5F;
			}
			float u1 = (float)((color % 16) * 32 +  0) / 256F;
	        float u2 = (float)((color % 16) * 32 + 32) / 256F;
	        float v1 = (float)((color / 16) * 32 +  0) / 256F;
	        float v2 = (float)((color / 16) * 32 + 32) / 256F;
	        tessellator.startDrawingQuads();
	        tessellator.addVertexWithUV(-width, -height, 0.0D, u1, v2);
	        tessellator.addVertexWithUV( width, -height, 0.0D, u2, v2);
	        tessellator.addVertexWithUV( width,  height, 0.0D, u2, v1);
	        tessellator.addVertexWithUV(-width,  height, 0.0D, u1, v1);
			tessellator.draw();
		}
		//その他の円形弾なら
		else
		{
			float u1 = (float)((color % 16) * 16 +  0) / 256F;
	        float u2 = (float)((color % 16) * 16 + 16) / 256F;
	        float v1 = (float)((color / 16) * 16 +  0) / 256F;
	        float v2 = (float)((color / 16) * 16 + 16) / 256F;
	        tessellator.startDrawingQuads();
	        tessellator.addVertexWithUV(-width, -height, 0.0D, u1, v2);
	        tessellator.addVertexWithUV( width, -height, 0.0D, u2, v2);
	        tessellator.addVertexWithUV( width,  height, 0.0D, u2, v1);
	        tessellator.addVertexWithUV(-width,  height, 0.0D, u1, v1);
			tessellator.draw();
		}
	}
	
	//光の弾の描画
	public void renderLightShot(Tessellator tessellator, int color, EntityTHShot entityTHShot)
	{
		//loadTexture("/textures/MusouFuuin.png");
		color %= 8;
		int count = entityTHShot.getAnimationCount() % 2;
		float uMin = (float)(count * 32 +  0) / 64F;
	    float uMax = (float)(count * 32 + 32) / 64F;
	    float vMin = 0F;
	    float vMax = 1F;
		float width = 2.0F;

	    tessellator.startDrawingQuads();
		tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.5F);
	    tessellator.addVertexWithUV(-width, -width, 0.0D, uMin, vMax);
	    tessellator.addVertexWithUV( width, -width, 0.0D, uMax, vMax);
	    tessellator.addVertexWithUV( width,  width, 0.0D, uMax, vMin);
	    tessellator.addVertexWithUV(-width,  width, 0.0D, uMin, vMin);
		tessellator.draw();

		width = 1.0F;
		tessellator.startDrawingQuads();
		tessellator.setColorRGBA_F(1F, 1F, 1F, 0.8F);
	    tessellator.addVertexWithUV(-width, -width, 0.01D, uMin, vMax);
	    tessellator.addVertexWithUV( width, -width, 0.01D, uMax, vMax);
	    tessellator.addVertexWithUV( width,  width, 0.01D, uMax, vMin);
	    tessellator.addVertexWithUV(-width,  width, 0.01D, uMin, vMin);
		tessellator.draw();

	}
	
	//気質弾の描画
	public void renderKishituShot(Tessellator tessellator, int color, EntityTHShot entityTHShot)
	{
		//loadTexture("/textures/MusouFuuin.png");
		color %= 8;
		int count = entityTHShot.getAnimationCount() % 2;
		float uMin = (float)(count * 32 +  0) / 64F;
	    float uMax = (float)(count * 32 + 32) / 64F;
	    float vMin = 0F;
	    float vMax = 1F;
		float width = 2.0F;

	    tessellator.startDrawingQuads();
	    tessellator.setNormal(0.0F, 1.0F, 0.0F);
		tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.5F);
	    tessellator.addVertexWithUV(-width, -width, 0.0D, uMin, vMax);
	    tessellator.addVertexWithUV( width, -width, 0.0D, uMax, vMax);
	    tessellator.addVertexWithUV( width,  width, 0.0D, uMax, vMin);
	    tessellator.addVertexWithUV(-width,  width, 0.0D, uMin, vMin);
		tessellator.draw();

		width = 1.6F;
		tessellator.startDrawingQuads();
	    tessellator.setNormal(0.0F, 1.0F, 0.0F);
		tessellator.setColorRGBA_F(1F, 1F, 1F, 0.8F);
	    tessellator.addVertexWithUV(-width, -width, 0.01D, uMin, vMax);
	    tessellator.addVertexWithUV( width, -width, 0.01D, uMax, vMax);
	    tessellator.addVertexWithUV( width,  width, 0.01D, uMax, vMin);
	    tessellator.addVertexWithUV(-width,  width, 0.01D, uMin, vMin);
		tessellator.draw();

	}
	
	//光のエフェクト
	public void renderLightEffect(Tessellator tessellator, int color, float size, EntityTHShot entityTHShot)
	{
		//loadTexture("/textures/MusouFuuin.png");
		color %= 8;
		int count = entityTHShot.getAnimationCount() % 2;
		//float size = entityTHShot.getShotSize();
		float u1 = (float)(count * 32 +  0) / 64F;
	    float u2 = (float)(count * 32 + 32) / 64F;
	    float v1 = 0F;
	    float v2 = 1F;
	    float width = 1.0F;
		GL11.glScalef(size, size, size);
	    tessellator.startDrawingQuads();
		tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.5F);
	    tessellator.addVertexWithUV(-width, -width, 0.0D, u1, v2);
	    tessellator.addVertexWithUV( width, -width, 0.0D, u2, v2);
	    tessellator.addVertexWithUV( width,  width, 0.0D, u2, v1);
	    tessellator.addVertexWithUV(-width,  width, 0.0D, u1, v1);
		tessellator.draw();
	}
	
	//鱗弾の描画
	public void renderScaleShot(Tessellator tessellator, int color)
	{
		GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
		color %= 8;
		//loadTexture("/textures/ScaleShot.png");
    	float xLength = 1.00F;
    	double zLength = 1.00F;
    	float uMin = 0.0F;
    	float uMax = 0.5F;
    	float vMin = 0.0F;
    	float vMax = 1.0F;
    	tessellator.startDrawingQuads();  
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.8F);
        tessellator.addVertexWithUV(-xLength, 0.1F,  zLength + 0.15F, uMin, vMin);
        tessellator.addVertexWithUV( xLength, 0.1F,  zLength + 0.15F, uMax, vMin);
        tessellator.addVertexWithUV( xLength, 0.1F, -zLength + 0.15F, uMax, vMax);
        tessellator.addVertexWithUV(-xLength, 0.1F, -zLength + 0.15F, uMin, vMax);
		tessellator.draw();
		GL11.glEnable(GL11.GL_CULL_FACE);//表綿描画
	}
	
	//蝶弾
	public void renderButterflyShot(Tessellator tessellator, int color, float wingAngle)
	{
		GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
		color %= 8;
		//loadTexture("/textures/ButterflyShot2.png");
		float minU =  0F / 128F;
        float maxU = 32F / 128F;
        float minV = 0F;
        float maxV = 1F;
        float width = 2.0F;
        float width2 = 1.8F;

	    	tessellator.startDrawingQuads();
    		tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
	        tessellator.addVertexWithUV( 0.0F, 0.0F,  width, maxU, minV);
	        tessellator.addVertexWithUV(width, 0.0F,  width, minU, minV);
	        tessellator.addVertexWithUV(width, 0.0F, -width, minU, maxV);
	        tessellator.addVertexWithUV( 0.0F, 0.0F, -width, maxU, maxV);
	        tessellator.draw();	
			tessellator.startDrawingQuads();
    		tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.4F);
	        tessellator.addVertexWithUV( 0.0F , 0.000F,  width2, maxU, minV);
	        tessellator.addVertexWithUV(width2, 0.000F,  width2, minU, minV);
	        tessellator.addVertexWithUV(width2, 0.000F, -width2, minU, maxV);
	        tessellator.addVertexWithUV( 0.0F , 0.000F, -width2, maxU, maxV);
	        tessellator.draw();	
	        GL11.glRotatef(-wingAngle * 2F, 0.0F, 0.0F, 1.0F);
	        width *= 1.0F;
	        width2 *= 1.0F;

	    	tessellator.startDrawingQuads();
    		tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
	    	tessellator.addVertexWithUV( 0.0F, 0.0F,  width, maxU, minV);
	    	tessellator.addVertexWithUV(-width, 0.0F, width, minU, minV);
	    	tessellator.addVertexWithUV(-width, 0.0F, -width, minU, maxV);
	    	tessellator.addVertexWithUV( 0.0F, 0.0F, -width, maxU, maxV);
	    	tessellator.draw();
			tessellator.startDrawingQuads();
    		tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.4F);
	    	tessellator.addVertexWithUV( 0.0F , 0.000F,  width2, maxU, minV);
	    	tessellator.addVertexWithUV(-width2, 0.000F, width2, minU, minV);
	    	tessellator.addVertexWithUV(-width2, 0.000F, -width2, minU, maxV);
	    	tessellator.addVertexWithUV( 0.0F , 0.000F, -width2, maxU, maxV);
	    	tessellator.draw();
		GL11.glEnable(GL11.GL_CULL_FACE);//表綿描画
	}

	//星弾の描画
	public void renderStarShot(Tessellator tessellator, int color)
	{
		//loadTexture("/textures/StarShot.png");
		color %= 8;
		float[] topPointX = new float[11];
		float[] topPointY = new float[11];
		float angle = 0F;
		float spanAngle = (float)Math.PI * 0.2F;//36°
		for(int i = 0; i < 10; i+=2)
		{
			topPointX[i] = (float)Math.cos(angle) * 2.0F;
			topPointY[i] = (float)Math.sin(angle) * 2.0F;
			angle += spanAngle;
			topPointX[i+1] = (float)Math.cos(angle) * 1.2F;
			topPointY[i+1] = (float)Math.sin(angle) * 1.2F;
			angle += spanAngle;
		}
		topPointX[10] = topPointX[0];
		topPointY[10] = topPointY[0];
		for(int i = 0; i < 9; i+=2)
		{
			//星の枠部
			tessellator.startDrawingQuads();
			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.7F);
        	tessellator.addVertexWithUV(topPointX[i]  , topPointY[i]  , 0.0D, 0F, 0F);
        	tessellator.addVertexWithUV(topPointX[i+1], topPointY[i+1], 0.0D, 1F, 0F);
        	tessellator.addVertexWithUV(topPointX[i+2], topPointY[i+2], 0.0D, 1F, 1F);
			tessellator.addVertexWithUV(          0.0F,           0.0F, 0.0D, 0F, 1F);
			tessellator.draw();
			//星の中心部　白い
			tessellator.startDrawingQuads();
			tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.7F);
			tessellator.addVertexWithUV(topPointX[i]   * 0.7F, topPointY[i]   * 0.7F,  0.01D, 0F, 0F);
			tessellator.addVertexWithUV(topPointX[i+1] * 0.95F, topPointY[i+1] * 0.95F,  0.01D, 1F, 0F);
        	tessellator.addVertexWithUV(topPointX[i+2] * 0.7F, topPointY[i+2] * 0.7F,  0.01D, 1F, 1F);
			tessellator.addVertexWithUV(          0.0F,           0.0F, 0.01D, 0F, 1F);
			tessellator.draw();
		}
	}
	
	//結晶弾の描画
	public void renderCrystalShot(Tessellator tessellator, int color)
	{
		float width = 0.48F;
		double length = 2.0D, length_b = 1.0D;
		float width2 = width * 0.8F;
		double length2 = length * 0.8D, length2_b = length * 0.4D;
		int i;
		
		for(i = 0; i < 4; i++)
		{
			GL11.glRotatef(90F, 0.0F, 0.0F, 1.0F);
			tessellator.startDrawingQuads();
		    tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(1F, 1F, 1F, 1.0F);
			tessellator.addVertexWithUV(  0.0F  , width2  , 0.0D  , 1F, 0F);
			tessellator.addVertexWithUV(-width2  , 0.0F   , 0.0D  , 0F, 0F);
			tessellator.addVertexWithUV(  0.0F  , 0.0F   , length2, 0F, 1F);
		    tessellator.addVertexWithUV(  0.0F  , 0.0F   , length2, 0F, 1F);
			tessellator.draw();
			tessellator.startDrawingQuads();
		    tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(1F, 1F, 1F, 1.0F);
			tessellator.addVertexWithUV( 0.0F   , width2  ,  0.0D  , 1F, 0F);
			tessellator.addVertexWithUV( width2  , 0.0F   ,  0.0D  , 0F, 0F);
			tessellator.addVertexWithUV( 0.0F   , 0.0F   , -length2_b, 0F, 1F);
		    tessellator.addVertexWithUV( 0.0F   , 0.0F   , -length2_b, 0F, 1F);
			tessellator.draw();
		}
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
		for(i = 0; i < 4; i++)
		{
			GL11.glRotatef(90F, 0.0F, 0.0F, 1.0F);
			tessellator.startDrawingQuads();
		    tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.7F);
			tessellator.addVertexWithUV(  0.0F  , width  , 0.0D  , 1F, 0F);
			tessellator.addVertexWithUV(-width  , 0.0F   , 0.0D  , 0F, 0F);
			tessellator.addVertexWithUV(  0.0F  , 0.0F   , length, 0F, 1F);
		    tessellator.addVertexWithUV(  0.0F  , 0.0F   , length, 0F, 1F);
			tessellator.draw();
			tessellator.startDrawingQuads();
		    tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.7F);
			tessellator.addVertexWithUV( 0.0F   , width  ,  0.0D  , 1F, 0F);
			tessellator.addVertexWithUV( width  , 0.0F   ,  0.0D  , 0F, 0F);
			tessellator.addVertexWithUV( 0.0F   , 0.0F   , -length_b, 0F, 1F);
		    tessellator.addVertexWithUV( 0.0F   , 0.0F   , -length_b, 0F, 1F);
			tessellator.draw();
		}
		GL11.glDisable(GL11.GL_BLEND);
	}
	
	//クナイ弾の描画
	public void renderKunaiShot(Tessellator tessellator, int color)
	{
		color %= 8;
		
		float width = 1.0F;//クナイの幅
		float width2 = 0.6F;//取っ手の幅
		float flont = 1.4F;//クナイの先端
		float back  = -0.8F;//クナイの中心
		float back2 = -1.0F;//クナイの後ろ
		float root  = -2.6F;//取っ手の先端
		float height = 0.3F;//クナイの厚さ
		//上
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(-width,   0.0F,  back, 0.50F, 1.0F);
        tessellator.addVertexWithUV(  0.0F,   0.0F,  flont, 0.25F, 0.0F);
        tessellator.addVertexWithUV( width,   0.0F,  back, 0.00F, 1.0F);
        tessellator.addVertexWithUV(  0.0F, height,  back, 0.25F, 1.0F);
		tessellator.draw();
		//下
        /*tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(  0.0F,    0.0F,  flont, 0.25F, 0.0F);
        tessellator.addVertexWithUV(-width,    0.0F,   back, 0.50F, 1.0F);
        tessellator.addVertexWithUV(  0.0F, -height,   back, 0.25F, 1.0F);
        tessellator.addVertexWithUV( width,    0.0F,   back, 0.00F, 1.0F);
		tessellator.draw();*/
		
		//下左
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F,  flont, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F,  flont, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F, -height,  back, 0.25F, 1.0F);
        tessellator.addVertexWithUV(width,  0.0F,  back, 0.00F, 1.0F);
		tessellator.draw();
		//下右
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F,  flont, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F,  flont, 0.25F, 0.0F);
        tessellator.addVertexWithUV(-width,  0.0F, back, 0.50F, 1.0F);
        tessellator.addVertexWithUV(0.0F, -height,  back, 0.25F, 1.0F);
		tessellator.draw();
		
		//上左
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  height,  back, 0.25F, 1.0F);
        tessellator.addVertexWithUV(width,  0.0F,  back, 0.00F, 1.0F);
		tessellator.draw();
		//下左
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(width,  0.0F,  back, 0.00F, 1.0F);
        tessellator.addVertexWithUV(0.0F, -height,  back, 0.25F, 1.0F);
		tessellator.draw();
		//上右
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(-width, 0.0F,  back, 0.50F, 1.0F);
        tessellator.addVertexWithUV(0.0F,  height,  back, 0.25F, 1.0F);
		tessellator.draw();
		//下右
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F,  0.0F, back2, 0.25F, 0.0F);
        tessellator.addVertexWithUV(0.0F, -height,  back, 0.25F, 1.0F);
        tessellator.addVertexWithUV(-width, 0.0F,  back, 0.50F, 1.0F);
		tessellator.draw();
		
		//取っ手
		GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
        tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV( width2,  0.0F,  back2, 0.50F, 0.375F);
        tessellator.addVertexWithUV(-width2,  0.0F,  back2, 0.75F, 0.375F);
        tessellator.addVertexWithUV(-width2,  0.0F,  root, 0.75F, 1.0F);
        tessellator.addVertexWithUV( width2,  0.0F,  root, 0.50F, 1.0F);
		tessellator.draw();
		GL11.glEnable(GL11.GL_CULL_FACE);//表面描画
	}
	
	//札弾の描画
	public void renderTalismanShot(Tessellator tessellator, int color)
	{
		color %= 8;
		float u1 = color / 16F;
		float u2 = u1 + 0.0625F;
		float v1 = 3F / 16F;
		float v2 = v1 + 0.0625F;
		
		float width = 1.6F;
		double length = 2.0D;
		
		GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
        tessellator.startDrawingQuads();
    	//tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 1.0F);
        tessellator.addVertexWithUV( width,  0.0F,  length, u2, v1);
        tessellator.addVertexWithUV(-width,  0.0F,  length, u1, v1);
        tessellator.addVertexWithUV(-width,  0.0F, -length, u1, v2);
        tessellator.addVertexWithUV( width,  0.0F, -length, u2, v2);
		tessellator.draw();
		GL11.glEnable(GL11.GL_CULL_FACE);//表面描画
	}
	
	//風弾の描画
	public void renderWindShot(Tessellator tessellator, int color, EntityTHShot entityTHShot)
	{
		//loadTexture("/textures/SanaeWind.png");

		color %= 8;
    	Random random = new Random();
    	float rand1 = (float)random.nextInt(50) / 100F;
    	float rand2 = (float)random.nextInt(100) / 100F;
    	int pattern = entityTHShot.getAnimationCount() % 4;
        float f3 = (float)((pattern % 2) * 32 + 0) / 64F;
        float u2 = (float)((pattern % 2) * 32 + 32) / 64F;
        float f5 = (float)((int)(pattern / 2) * 16 + 0) / 32F;
        float f6 = (float)((int)(pattern / 2) * 16 + 16) / 32F;
    	float f7 = rand1;
    	float f8 = 4.0F + rand2;
        float f9 = 0.5F;

		GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
    	for(int i = 0; i < 8; i++)
    	{
    		GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
	        tessellator.startDrawingQuads();
    		tessellator.setNormal(0.0F, 1.0F, 0.0F);
	    	tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.3F);
	        tessellator.addVertexWithUV(0.0F - f7, -1.0F - f9, 0.0D, f3, f6);
	        tessellator.addVertexWithUV(0.0F + f7, -1.0F - f9, 0.0D, u2, f6);
	        tessellator.addVertexWithUV(0.0F + f8,  2.0F - f9, 2.0D, u2, f5);
	        tessellator.addVertexWithUV(0.0F - f8,  2.0F - f9, 2.0D, f3, f5);
			tessellator.draw();
    	}
		GL11.glEnable(GL11.GL_CULL_FACE);//表面描画
	}
	
	//米弾の描画をする
	protected void renderRiceShot(Tessellator tessellator, double length, float width, double zPos, int zAngleDivNum, int zDivNum, int color, float alpha)
	{
		
		float maxWidth = (float)width;//最大の太さをmaxWidthとして保存
		
    	//int zAngleDivNum = 6;//Z軸回転の分割数
    	float zSpan = 360F / zAngleDivNum;
    	double angleZ = 0F;//Z軸回転変数
    	double angleSpanZ = Math.PI * 2.0D / (double)zAngleDivNum;//Z軸回転の変化量
    	
    	//int zDivNum = 5;//レーザーの奥方向への分割数。必ず奇数
    	double zLength = length;//レーザーの長さ（Z方向の長さ、奥行き）
    	double zDivLength = zLength / (double)(zDivNum - 1);//Z方向へ分割したときの1分割分の長さ
    	double zLength2 = zLength / 2.0D;//長さの半分
		//double zPos = 0.0D;
    	//double zPos = -zLength2;//奥行き方向の現在の描画位置
    	//zPos = Math.sin(-Math.PI / 2.0D) * maxWidth;
    	double zPosOld = zPos;//ひとつ前の描画位置
		//初期のXとYの座標（レーザーの始点は点）
    	float xPos = 0F;
    	float yPos = 0F;
    	float xPos2 = 0F;
    	float yPos2 = 0F;
    	//初期のXとYの座標
    	float xPosOld = xPos;
    	float yPosOld = yPos;
    	float xPos2Old = xPos2;
    	float yPos2Old = yPos2;
    	//半円を描くようにレーザーが太くなるための変数。cos0 ~ cos180で処理
    	float angle = -(float)Math.PI / 2.0F;
    	float angleSpan = (float)Math.PI / (float)(zDivNum);
    	angle += angleSpan;
    	//レーザーの太さ。Z軸方向への進行で２つ必要
    	//width = (float)Math.sin(angle) * maxWidth;
    	float widthOld = 0.0F;
    	
    	//奥行きが長さの半分に達するまで（奥行きの初期値は長さの半分のマイナス値）
    	//while(zPos < zLength2)
		for(int j = 0; j < zDivNum; j++)
		{
    		zPos += zDivLength;//奥行きを１段階増やす
    		//widthOld = width;
    		//angle += angleSpan;//レーザーの描く半円の角度を更新
    		width = (float)Math.cos(angle) * maxWidth;
    		//XとY座標は初期値、0度のときの座標に戻る。
    		xPos = width;
    		yPos = 0F;
    		xPosOld = (float)Math.cos(angleZ) * width;
			yPosOld = (float)Math.sin(angleZ) * width;
			xPos2Old = (float)Math.cos(angleZ) * widthOld;
			yPos2Old = (float)Math.sin(angleZ) * widthOld;
    		//Z軸回転の始点
    		angleZ = angleSpanZ;
    		
    		
    		for(int i = 0; i <= zAngleDivNum; i++)
    		{
    			xPos = (float)Math.cos(angleZ) * width;
    			yPos = (float)Math.sin(angleZ) * width;
    			xPos2 = (float)Math.cos(angleZ) * widthOld;
    			yPos2 = (float)Math.sin(angleZ) * widthOld;
	    			
    			tessellator.startDrawingQuads();
    			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], alpha);
	        	tessellator.addVertexWithUV(  xPosOld , yPosOld , zPos   , 0.0F, 0.0F);
	        	tessellator.addVertexWithUV(  xPos2Old, yPos2Old, zPosOld, 0.0F, 1.0F);
	        	tessellator.addVertexWithUV(  xPos2   , yPos2   , zPosOld, 1.0F, 1.0F);
	        	tessellator.addVertexWithUV(  xPos    , yPos    , zPos   , 1.0F, 0.0F);
	    		tessellator.draw();
    			
    			xPosOld = xPos;
    			yPosOld = yPos;
    			xPos2Old = xPos2;
    			yPos2Old = yPos2;
    			angleZ += angleSpanZ;
    			
    			
    		}
    		
    		zPosOld = zPos;//古い奥行きを今の奥行きに更新
    		angle += angleSpan;//レーザーの描く半円の角度を更新
    		widthOld = width;
    		
    	}
	}
	
	//楕円弾の描画をする
	protected void renderOvalShot(Tessellator tessellator, double length, float width, double zPos, int zAngleDivNum, int zDivNum, int color, float alpha)
	{
		
		float maxWidth = (float)width;//最大の太さをmaxWidthとして保存
		
    	//int zAngleDivNum = 6;//Z軸回転の分割数
    	float zSpan = 360F / zAngleDivNum;
    	double angleZ = 0F;//Z軸回転変数
    	double angleSpanZ = Math.PI * 2.0D / (double)zAngleDivNum;//Z軸回転の変化量
    	
    	//int zDivNum = 5;//レーザーの奥方向への分割数。必ず奇数
    	double zLength = length;//レーザーの長さ（Z方向の長さ、奥行き）
    	double zDivLength = zLength / (double)(zDivNum - 1);//Z方向へ分割したときの1分割分の長さ
    	double zLength2 = zLength / 2.0D;//長さの半分
		//double zPos = 0.0D;
    	//double zPos = -zLength2;//奥行き方向の現在の描画位置
    	//zPos = Math.sin(-Math.PI / 2.0D) * maxWidth;
    	double zPosOld = -length;//zPos;//ひとつ前の描画位置
		//初期のXとYの座標（レーザーの始点は点）
    	float xPos = 0F;
    	float yPos = 0F;
    	float xPos2 = 0F;
    	float yPos2 = 0F;
    	//初期のXとYの座標
    	float xPosOld = xPos;
    	float yPosOld = yPos;
    	float xPos2Old = xPos2;
    	float yPos2Old = yPos2;
    	//半円を描くようにレーザーが太くなるための変数。cos0 ~ cos180で処理
    	float angle = -(float)Math.PI / 2.0F;
    	float angleSpan = (float)Math.PI / (float)(zDivNum);
    	angle += angleSpan;
    	//レーザーの太さ。Z軸方向への進行で２つ必要
    	//width = (float)Math.sin(angle) * maxWidth;
    	float widthOld = 0.0F;
    	
    	//奥行きが長さの半分に達するまで（奥行きの初期値は長さの半分のマイナス値）
    	//while(zPos < zLength2)
		for(int j = 0; j < zDivNum; j++)
		{
    		//zPos += zDivLength;//奥行きを１段階増やす
			zPos = Math.sin(angle) * length;
    		//widthOld = width;
    		//angle += angleSpan;//レーザーの描く半円の角度を更新
    		width = (float)Math.cos(angle) * maxWidth;
    		//XとY座標は初期値、0度のときの座標に戻る。
    		xPos = width;
    		yPos = 0F;
    		xPosOld = (float)Math.cos(angleZ) * width;
			yPosOld = (float)Math.sin(angleZ) * width;
			xPos2Old = (float)Math.cos(angleZ) * widthOld;
			yPos2Old = (float)Math.sin(angleZ) * widthOld;
    		//Z軸回転の始点
    		angleZ = angleSpanZ;
    		
    		
    		for(int i = 0; i <= zAngleDivNum; i++)
    		{
    			xPos = (float)Math.cos(angleZ) * width;
    			yPos = (float)Math.sin(angleZ) * width;
    			xPos2 = (float)Math.cos(angleZ) * widthOld;
    			yPos2 = (float)Math.sin(angleZ) * widthOld;
	    			
    			tessellator.startDrawingQuads();
    			tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], alpha);
	        	tessellator.addVertexWithUV(  xPosOld , yPosOld , zPos   , 0.0F, 0.0F);
	        	tessellator.addVertexWithUV(  xPos2Old, yPos2Old, zPosOld, 0.0F, 1.0F);
	        	tessellator.addVertexWithUV(  xPos2   , yPos2   , zPosOld, 1.0F, 1.0F);
	        	tessellator.addVertexWithUV(  xPos    , yPos    , zPos   , 1.0F, 0.0F);
	    		tessellator.draw();
    			
    			xPosOld = xPos;
    			yPosOld = yPos;
    			xPos2Old = xPos2;
    			yPos2Old = yPos2;
    			angleZ += angleSpanZ;
    			
    			
    		}
    		
    		zPosOld = zPos;//古い奥行きを今の奥行きに更新
    		angle += angleSpan;//レーザーの描く半円の角度を更新
    		widthOld = width;
    		
    	}
	}
	
    protected ResourceLocation func_110781_a(EntityTHShot entityTHShot)
    {
    	int color = entityTHShot.getShotColor();
    	
    	if(entityTHShot.getAnimationCount() < 0)
    	{
    		return resourceLocation_Light;
    	}
    	else if(color <= thShotLib.CIRCLE[7] || (color >= thShotLib.BIG[0] && color <= thShotLib.BIG[7]))
    	{
    		return resourceLocation_Normal;
    	}
    	//光弾の描画
    	else if(color <= thShotLib.LIGHT[7])
    	{
    		return resourceLocation_Light;
    	}
    	//鱗弾の描画
    	else if(color <= thShotLib.SCALE[7])
    	{
    		return resourceLocation_Scale;
    	}
    	//蝶弾の描画
    	else if(color <= thShotLib.BUTTERFLY[7])
    	{
    		return resourceLocation_Butterfly;
    	}
    	//星弾の描画
    	else if(color <= thShotLib.STAR[7])
    	{
    		return resourceLocation_Star;
    	}
    	else if(color <= thShotLib.RICE[7])
    	{
    		return resourceLocation_Laser;
    	}
    	else if(color <= thShotLib.CRYSTAL[7])
    	{
    		return resourceLocation_Star;
    	}
    	else if(color <= thShotLib.HEART[7])
    	{
    		return resourceLocation_Normal;
    	}
    	else if(color <= thShotLib.KUNAI[7])
    	{
    		return resourceLocation_Kunai;
    	}
    	else if(color <= thShotLib.TALISMAN[7])
    	{
    		return resourceLocation_Normal;
    	}
    	else if(color <= thShotLib.BIGLIGHT[7])
    	{
    		return resourceLocation_Light;
    	}
    	else if(color <= thShotLib.OVAL[7])
    	{
    		return resourceLocation_Laser;
    	}
    	else if(color <= thShotLib.KNIFE[7])
    	{
    		switch(color % 8)
    		{
    			case 0:
        			return resourceLocation_Knife_Red;
    			case 1:
    				return resourceLocation_Knife_Blue;
    			case 2:
    				return resourceLocation_Knife_Green;
    			case 3:
    				return resourceLocation_Knife_Yellow;
    			case 4:
    				return resourceLocation_Knife_Purple;
    			case 5:
    				return resourceLocation_Knife_Aqua;
    			case 6:
    				return resourceLocation_Knife_Orange;
    			default:
    				return resourceLocation_Knife_White;
    		}
    	}
    	else if(color <= thShotLib.WIND[7])
    	{
    		return resourceLocation_Wind;
    	}
    	else
    	{
    		return resourceLocation_Light;
    	}
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityTHShot)entity);
    }
	
    public void doRender(Entity entity, double d, double d1, double d2,
            float f, float f1)
    {
        doRenderTHShot((EntityTHShot)entity, d, d1, d2, f, f1);
    }
}
