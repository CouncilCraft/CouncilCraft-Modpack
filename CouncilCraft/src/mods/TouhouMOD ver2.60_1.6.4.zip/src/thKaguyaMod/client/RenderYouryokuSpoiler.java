package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntityYouryokuSpoiler;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderYouryokuSpoiler extends Render
{
	
	//妖力スポイラーの描画
	private static final ResourceLocation field_110782_f = new ResourceLocation("thkaguyamod", "textures/Spoiler.png");
	private Random random = new Random();

    public RenderYouryokuSpoiler()
    {
    }

    public void doRenderYouryokuSpoiler(EntityYouryokuSpoiler entityYouryokuSpoiler, double d, double d1, double d2,
            float f, float f1)
    {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
    	//GL11.glDisable(GL11.GL_TEXTURE_2D);
    	GL11.glDisable(GL11.GL_LIGHTING);
        //GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
    	GL11.glEnable(GL11.GL_NORMALIZE);
    	GL11.glEnable(GL11.GL_BLEND);
    	GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
    	//GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        float f2 = 0.5F;
        GL11.glScalef(f2 / 1.0F, f2 / 1.0F, f2 / 1.0F);
        //loadTexture("/textures/Spoiler.png");
        Tessellator tessellator = Tessellator.instance;
    	int color = entityYouryokuSpoiler.getPattern();
    	//int color = 0;
        float f3 = (float)(color * 32 + 0) / 64F;
        float f4 = (float)(color * 32 + 32) / 64F;
        float f5 = 0F;
        float f6 = 1F;
        float f7 = 1.0F;
        float f8 = 0.5F;
        float f9 = 0.25F;
        GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    	for(int i = 0; i < 3; i++)
    	{
        tessellator.startDrawingQuads();
    	//tessellator.startDrawing(5);
    	//tessellator.setColorRGBA_F(1.0F * f, 0.1F * f, 0.1F * f, 0.3F);
        tessellator.setNormal(0.0F, 1.0F, 0.0F);
        tessellator.addVertexWithUV(0.0F - f8, 0.0F - f9, 0.0D, f3, f6);
        tessellator.addVertexWithUV(f7 - f8, 0.0F - f9, 0.0D, f4, f6);
        tessellator.addVertexWithUV(f7 - f8, 1.0F - f9, 0.0D, f4, f5);
        tessellator.addVertexWithUV(0.0F - f8, 1.0F - f9, 0.0D, f3, f5);
		tessellator.draw();
    	}
        //GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LIGHTING);
    	//GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110781_a(EntityYouryokuSpoiler entityYouryokuSpoiler)
    {
        return field_110782_f;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityYouryokuSpoiler)entity);
    }

    public void doRender(Entity entity, double d, double d1, double d2,
            float f, float f1)
    {
        doRenderYouryokuSpoiler((EntityYouryokuSpoiler)entity, d, d1, d2, f, f1);
    }
}
