package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.entity.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntityTHFairyCirno;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderTHFairyCirno extends RenderLiving
{
	//妖精を描画する

    public RenderTHFairyCirno()
    {
        super(new ModelTHFairyCirno(), 0.25F);
        
        
    }

	public void doRenderTHFairy(EntityTHFairyCirno entityTHFairyCirno, double x, double y, double z, float yaw, float pitch)
	{
        super.doRenderLiving(entityTHFairyCirno, x, y, z, yaw, pitch);
        func_110777_b(entityTHFairyCirno);
        
    	GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_BLEND);
    	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y, (float)z);
        GL11.glRotatef( -renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
    	GL11.glRotatef(  renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    	
        Tessellator tessellator = Tessellator.instance;
        
		tessellator.startDrawingQuads();
		tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.9F);
		tessellator.setNormal(0.0F, 1.0F, 0.0F);
    	tessellator.addVertexWithUV(  -1.0F, 3.0F, 0.0D, 0.00F, 63F / 64F);
    	tessellator.addVertexWithUV(   1.0F, 3.0F, 0.0D, 0.25F, 63F / 64F);
    	tessellator.addVertexWithUV(   1.0F, 2.8F, 0.0D, 0.25F, 1F);
    	tessellator.addVertexWithUV(  -1.0F, 2.8F, 0.0D, 0.00F, 1F);
    	tessellator.draw();
    	
    	float hp = entityTHFairyCirno.func_110143_aJ() / entityTHFairyCirno.func_110138_aP() * 2.0F - 1.0F;
    	tessellator.startDrawingQuads();
    	tessellator.setColorRGBA_F(0.0F, 1.0F, 0.0F, 0.9F);
		tessellator.setNormal(0.0F, 1.0F, 0.0F);
    	tessellator.addVertexWithUV(    -hp, 3.0F, -0.001D, 0.25F, 63F / 64F);
    	tessellator.addVertexWithUV(   1.0F, 3.0F, -0.001D, 0.50F, 63F / 64F);
    	tessellator.addVertexWithUV(   1.0F, 2.8F, -0.001D, 0.50F, 1F);
    	tessellator.addVertexWithUV(    -hp, 2.8F, -0.001D, 0.25F, 1F);
    	tessellator.draw();
    	
    	GL11.glPopMatrix();
    	GL11.glDisable(GL11.GL_BLEND);
    	GL11.glEnable(GL11.GL_LIGHTING);
	}

    protected void func_82442_a(EntityTHFairyCirno entityFaily, float par2)
    {
        GL11.glScalef(1.00F, 1.00F, 1.00F);
    }

    protected void func_82445_a(EntityTHFairyCirno entityTHFairyCirno, double x, double y, double z)
    {
        super.renderLivingAt(entityTHFairyCirno, x, y, z);
    }

    protected void func_82444_a(EntityTHFairyCirno entityTHFairyCirno, float x, float y, float z)
    {
        //if (!entityTHFairy.getIsTHFairyHanging())
        {
            GL11.glTranslatef(0.0F, MathHelper.cos(x * 0.3F) * 0.1F, 0.0F);
        }
        //else
        {
            GL11.glTranslatef(0.0F, -0.1F, 0.0F);
        }

        super.rotateCorpse(entityTHFairyCirno, x, y, z);
    }

    /**
     * Allows the render to do any OpenGL state modifications necessary before the model is rendered. Args:
     * entityLiving, partialTickTime
     */
    protected void preRenderCallback(EntityLiving entityLiving, float par2)
    {
        this.func_82442_a((EntityTHFairyCirno)entityLiving, par2);
    }

    protected void rotateCorpse(EntityLiving par1EntityLiving, float par2, float par3, float par4)
    {
        this.func_82444_a((EntityTHFairyCirno)par1EntityLiving, par2, par3, par4);
    }

    /**
     * Sets a simple glTranslate on a LivingEntity.
     */
    protected void renderLivingAt(EntityLiving par1EntityLiving, double par2, double par4, double par6)
    {
        this.func_82445_a((EntityTHFairyCirno)par1EntityLiving, par2, par4, par6);
    }

    public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float yaw, float pitch)
    {
        //this.func_82443_a((EntityTHFairy)par1EntityLiving, par2, par4, par6, par8, par9);
    	this.doRenderTHFairy((EntityTHFairyCirno)entityLiving, x, y, z, yaw, pitch);
    }
    
    protected ResourceLocation func_110781_a(EntityTHFairyCirno entityTHFairy)
    {
    	ResourceLocation resourceLocation = new ResourceLocation("thkaguyamod", "textures/cirno.png");
        return resourceLocation;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityTHFairyCirno)entity);
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity) and this method has signature public void doRender(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doesn't do that.
     */
    public void doRender(Entity entity, double x, double y, double z, float yaw, float pitch)
    {
        //this.func_82443_a((EntityTHFairy)par1Entity, par2, par4, par6, par8, par9);
    	this.doRenderTHFairy((EntityTHFairyCirno)entity, x, y, z, yaw, pitch);
    }
}
