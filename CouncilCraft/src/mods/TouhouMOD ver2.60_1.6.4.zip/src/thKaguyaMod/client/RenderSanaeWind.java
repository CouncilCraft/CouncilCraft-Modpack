package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntitySanaeWind;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderSanaeWind extends Render
{
	
	//早苗の風の描画
	private Random random = new Random();

	private static final ResourceLocation field_110782_f = new ResourceLocation("thkaguyamod", "textures/Wind.png");
    public RenderSanaeWind()
    {
    }

    public void doRenderSanaeWind(EntitySanaeWind entitySanaeWind, double d, double d1, double d2,
            float f, float f1)
    {
        GL11.glPushMatrix();
        func_110777_b(entitySanaeWind);
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
    	//GL11.glDisable(GL11.GL_TEXTURE_2D);
    	GL11.glDisable(GL11.GL_LIGHTING);
        //GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
    	GL11.glEnable(GL11.GL_NORMALIZE);
    	GL11.glEnable(GL11.GL_BLEND);
    	GL11.glDisable(GL11.GL_CULL_FACE);//両面描画
    	GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
    	//GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        float f2 = 0.5F;
        GL11.glScalef(f2 / 1.0F, f2 / 1.0F, f2 / 1.0F);
        //loadTexture("/textures/SanaeWind.png");
        Tessellator tessellator = Tessellator.instance;
    	Random random = new Random();
    	float rand1 = (float)random.nextInt(50) / 100F;
    	float rand2 = (float)random.nextInt(100) / 100F;
    	int pattern = entitySanaeWind.ticksExisted % 4;//entitySanaeWind.getWindRenderPattern();
        float f3 = (float)((pattern % 2) * 32 + 0) / 64F;
        float f4 = (float)((pattern % 2) * 32 + 32) / 64F;
        float f5 = (float)((int)(pattern / 2) * 16 + 0) / 32F;
        float f6 = (float)((int)(pattern / 2) * 16 + 16) / 32F;
    	float f7 = rand1;
    	float f8 = 4.0F + rand2;
        float f9 = 0.5F;

    	for(int i = 0; i < 8; i++)
    	{
    		GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
	        tessellator.startDrawingQuads();
	    	tessellator.setColorRGBA_F(0.1F, 0.9F, 0.6F, 0.3F);
	        tessellator.setNormal(0.0F, 1.0F, 0.0F);
	        tessellator.addVertexWithUV(0.0F - f7, -1.0F - f9, 0.0D, f3, f6);
	        tessellator.addVertexWithUV(0.0F + f7, -1.0F - f9, 0.0D, f4, f6);
	        tessellator.addVertexWithUV(0.0F + f8,  2.0F - f9, 2.0D, f4, f5);
	        tessellator.addVertexWithUV(0.0F - f8,  2.0F - f9, 2.0D, f3, f5);
			tessellator.draw();
    		//tessellator.startDrawingQuads();
    	}
        //GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        GL11.glDisable(GL11.GL_BLEND);
    	GL11.glEnable(GL11.GL_CULL_FACE);//表綿描画
        GL11.glEnable(GL11.GL_LIGHTING);
    	//GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110781_a(EntitySanaeWind entitySanaeWind)
    {
        return field_110782_f;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntitySanaeWind)entity);
    }

    public void doRender(Entity entity, double d, double d1, double d2,
            float f, float f1)
    {
        doRenderSanaeWind((EntitySanaeWind)entity, d, d1, d2, f, f1);
    }
}
