package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntityRyuuLightningBolt;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

@SideOnly(Side.CLIENT)
public class RenderRyuuLightningBolt extends Render
{
	//龍の玉の描画
	//ほとんど雪玉と同じ　なのでよくわからん
	private static final ResourceLocation field_110782_f = new ResourceLocation("thkaguyamod", "textures/thKaguyaTerrain.png");
	private Random random = new Random();

    public RenderRyuuLightningBolt()
    {
    }

    public void doRenderRyuuLightningBolt(EntityRyuuLightningBolt entityfireball, double d, double d1, double d2,
            float f, float f1)
    {
    	
        GL11.glPushMatrix();
        func_110777_b(entityfireball);
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        float f2 = 1.0F;
        GL11.glScalef(f2 / 1.0F, f2 / 1.0F, f2 / 1.0F);
        //loadTexture("/textures/thKaguyaTerrain.png");
        Tessellator tessellator = Tessellator.instance;
    	int color = 1+16;
    	if(random.nextInt(3)==0)
    	{	
    		color = random.nextInt(5)+16;
    	}
        float f3 = (float)((color % 16) * 16 + 0) / 256F;
        float f4 = (float)((color % 16) * 16 + 16) / 256F;
        float f5 = (float)((color / 16) * 16 + 0) / 256F;
        float f6 = (float)((color / 16) * 16 + 16) / 256F;
        float f7 = 1.0F;
        float f8 = 0.5F;
        float f9 = 0.25F;
        GL11.glRotatef(180F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        tessellator.startDrawingQuads();
        tessellator.setNormal(0.0F, 1.0F, 0.0F);
        tessellator.addVertexWithUV(0.0F - f8, 0.0F - f9, 0.0D, f3, f6);
        tessellator.addVertexWithUV(f7 - f8, 0.0F - f9, 0.0D, f4, f6);
        tessellator.addVertexWithUV(f7 - f8, 1.0F - f9, 0.0D, f4, f5);
        tessellator.addVertexWithUV(0.0F - f8, 1.0F - f9, 0.0D, f3, f5);
        tessellator.draw();
        GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation func_110781_a(EntityRyuuLightningBolt entityRyuuLightningBolt)
    {
        return field_110782_f;
    }

    protected ResourceLocation func_110775_a(Entity entity)
    {
        return this.func_110781_a((EntityRyuuLightningBolt)entity);
    }

    public void doRender(Entity entity, double d, double d1, double d2,
            float f, float f1)
    {
        doRenderRyuuLightningBolt((EntityRyuuLightningBolt)entity, d, d1, d2, f, f1);
    }
}
