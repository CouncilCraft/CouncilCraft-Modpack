package thKaguyaMod.client;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

import thKaguyaMod.tileentity.TileEntityDivineSpirit;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class TileEntityDivineSpiritRenderer extends TileEntitySpecialRenderer
{
	private static final ResourceLocation resourceLocation_Shinrei = new ResourceLocation("thkaguyamod", "textures/Shinrei.png");
	protected float colorR[] = { 224F/255F,   0F/255F,   0F/255F, 224F/255F, 224F/255F,   0F/255F, 255F/255F, 255F/255F};
	protected float colorG[] = {   0F/255F,   0F/255F, 224F/255F, 224F/255F,   0F/255F, 224F/255F, 128F/255F, 255F/255F};
	protected float colorB[] = {   0F/255F, 224F/255F,   0F/255F,   0F/255F, 224F/255F, 224F/255F,   0F/255F, 255F/255F};
	
    public void renderTileEntityDivineSpirit(TileEntityDivineSpirit tileEntityDivineSpirit, double x, double y, double z, float par8)
    {
        GL11.glPushMatrix();
        
        GL11.glTranslatef((float)x + 0.5F, (float)y + 0.5F, (float)z + 0.5F);
    	GL11.glDisable(GL11.GL_LIGHTING);
    	GL11.glEnable(GL11.GL_NORMALIZE);
    	GL11.glEnable(GL11.GL_BLEND);
    	GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
    	GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);

    	this.func_110628_a(resourceLocation_Shinrei);
        Tessellator tessellator = Tessellator.instance;
    	int color = tileEntityDivineSpirit.getBlockMetadata();
    	
    	//this.bindTextureByName("/gui/Shinrei.png");
    	
    	int time = (int)tileEntityDivineSpirit.worldObj.getTotalWorldTime();
    	float size =  1.0F + (float)Math.sin((float)tileEntityDivineSpirit.worldObj.getTotalWorldTime() * 0.3F) * 0.06F;
    	/*if(tileEntityDivineSpirit.blockMetadata >= 8)
    	{
    		int end = 100 - tileEntityDivineSpirit.time;//(int)(y - (int)y) * 10000;
    		//size = size * (float)(end / 100);
    	}*/
    	float size2 = size * 0.7F;
        renderLaser(tessellator, size2, size2, size2, color, 1F, time, 10);
		renderLaser(tessellator, size, size, size, color, 0.7F, time, 10);

		GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }
    
	//レーザーの描画をする
	protected void renderLaser(Tessellator tessellator, double length, float width, double zPos, int color, float alpha, int time, int div)
	{
		
		float maxWidth = (float)width / 2.0F;//最大の太さをmaxWidthとして保存
		float vPos = 0.0F;
		/*if(alpha != 1.0F)
		{
			vPos = 0.0F;
		}*/
		float uPos = 0F;//time / 64F;
		
    	int zAngleDivNum = div;//Z軸回転の分割数
    	float zSpan = 360F / zAngleDivNum;
    	double angleZ = 0F;//Z軸回転変数
    	double angleSpanZ = Math.PI * 2.0D / (double)zAngleDivNum;//Z軸回転の変化量
    	
    	int zDivNum = div / 2;//レーザーの奥方向への分割数。必ず奇数
    	double zLength = width;//レーザーの長さ（Z方向の長さ、奥行き）
    	double zDivLength = zLength / (double)(zDivNum - 1);//Z方向へ分割したときの1分割分の長さ
    	double zLength2 = zLength / 2.0D;//長さの半分
		//double zPos = 0.0D;
    	//double zPos = -zLength2;//奥行き方向の現在の描画位置
    	zPos = Math.sin(-Math.PI / 2.0D) * maxWidth;
    	double zPosOld = zPos;//ひとつ前の描画位置
		//初期のXとYの座標（レーザーの始点は点）
    	float xPos = 0F;
    	float yPos = 0F;
    	float xPos2 = xPos;
    	float yPos2 = yPos;
    	//初期のXとYの座標
    	float xPosOld = xPos;
    	float yPosOld = yPos;
    	float xPos2Old = xPos2;
    	float yPos2Old = yPos2;
    	//半円を描くようにレーザーが太くなるための変数。cos0 ~ cos180で処理
    	float angle = -(float)Math.PI / 2.0F;
    	float angleSpan = (float)Math.PI / (float)(zDivNum);
    	angle += angleSpan;
    	//レーザーの太さ。Z軸方向への進行で２つ必要
    	//width = (float)Math.cos(angle) * maxWidth;
    	float widthOld = 0.0F;
    	
    	//奥行きが長さの半分に達するまで（奥行きの初期値は長さの半分のマイナス値）
    	//while(zPos < zLength2)
		for(int j = 1; j <= zDivNum; j++)
		{
    		//zPos += Math.sin(angle)* zDivLength;//奥行きを１段階増やす
			zPos = Math.sin(angle) * maxWidth;
    		width = (float)Math.cos(angle) * maxWidth;
    		
    		//XとY座標は初期値、0度のときの座標に戻る。
    		xPos = width;
    		yPos = 0F;//(float)width;
    		angleZ = 0F;
    		xPosOld = (float)Math.cos(angleZ) * width;
			yPosOld = (float)Math.sin(angleZ) * width;
			xPos2Old = (float)Math.cos(angleZ) * widthOld;
			yPos2Old = (float)Math.sin(angleZ) * widthOld;
    		//Z軸回転の始点
    		angleZ = angleSpanZ;
    		
    		for(int i = 1; i <= zAngleDivNum; i++)
    		{
	    		xPos = (float)Math.cos(angleZ) * width;
	    		yPos = (float)Math.sin(angleZ) * width;
	    		xPos2 = (float)Math.cos(angleZ) * widthOld;
	    		yPos2 = (float)Math.sin(angleZ) * widthOld;
	    		
    			double colorVar = 0.0D;
    			/*if(time != 0)
    			{
    				colorVar = (time + j) / 10.0D;
    			}*/
    			tessellator.startDrawingQuads();
	    		tessellator.setColorRGBA_F(colorR[color] + (float)Math.sin(colorVar) * 0.2F, colorG[color] + (float)Math.cos(colorVar) * 0.2F, colorB[color] - (float)Math.sin(colorVar) * 0.2F , alpha);
	    		//tessellator.setNormal(0.0F, 1.0F, 0.0F);
	    		tessellator.addVertexWithUV(  xPos    , yPos    , zPos   , uPos + 1.0F, vPos);
	    		tessellator.addVertexWithUV(  xPosOld , yPosOld , zPos   , uPos, vPos);
	    		tessellator.addVertexWithUV(  xPos2Old, yPos2Old, zPosOld, uPos, vPos + 0.5F);
	        	tessellator.addVertexWithUV(  xPos2   , yPos2   , zPosOld, uPos + 1.0F, vPos + 0.5F);
	        	
	    		tessellator.draw();
    			
    			xPosOld = xPos;
    			yPosOld = yPos;
    			xPos2Old = xPos2;
    			yPos2Old = yPos2;
    			angleZ += angleSpanZ;
    			
    		}
    		zPosOld = zPos;//古い奥行きを今の奥行きに更新
    		angle += angleSpan;//レーザーの描く半円の角度を更新
    		widthOld = width;
    		
    	}
	}

	//光の弾の描画
	public void renderLightShot(Tessellator tessellator, int color, float size, int time)
	{
		//loadTexture("/textures/MusouFuuin.png");
		color %= 8;
		int count = time;
		float uMin = (float)(count * 32 +  0) / 64F;
	    float uMax = (float)(count * 32 + 32) / 64F;
	    float vMin = 0F;
	    float vMax = 1F;
		float width = 1.0F;
	
	    tessellator.startDrawingQuads();
	    tessellator.setNormal(0.0F, 1.0F, 0.0F);
		tessellator.setColorRGBA_F(colorR[color], colorG[color], colorB[color], 0.5F);
	    tessellator.addVertexWithUV(-width, -width, 0.0D, uMin, vMax);
	    tessellator.addVertexWithUV( width, -width, 0.0D, uMax, vMax);
	    tessellator.addVertexWithUV( width,  width, 0.0D, uMax, vMin);
	    tessellator.addVertexWithUV(-width,  width, 0.0D, uMin, vMin);
		tessellator.draw();
	
		width = 0.5F;
		tessellator.startDrawingQuads();
	    tessellator.setNormal(0.0F, 1.0F, 0.0F);
		tessellator.setColorRGBA_F(1F, 1F, 1F, 0.8F);
	    tessellator.addVertexWithUV(-width, -width, 0.01D, uMin, vMax);
	    tessellator.addVertexWithUV( width, -width, 0.01D, uMax, vMax);
	    tessellator.addVertexWithUV( width,  width, 0.01D, uMax, vMin);
	    tessellator.addVertexWithUV(-width,  width, 0.01D, uMin, vMin);
		tessellator.draw();
	
	}

    public void renderTileEntityAt(TileEntity par1TileEntity, double par2, double par4, double par6, float par8)
    {
        this.renderTileEntityDivineSpirit((TileEntityDivineSpirit)par1TileEntity, par2, par4, par6, par8);
    }
}