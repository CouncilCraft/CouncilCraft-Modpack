package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityFallingSand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;

public class EntityNuclearShot extends EntityTHShot
{
	//お空の核弾
	
	public boolean shootingFlag;
	
	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityNuclearShot(World world)
    {
        super(world);
    }
    
   
	
	public EntityNuclearShot(World world, EntityLivingBase entityUser, Entity entity,
		double xPos, double yPos, double zPos,
    	double xVector, double yVector, double zVector,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	double xVectorG, double yVectorG, double zVectorG, float damage, int color, float size, int dead, int delay, int special)
    {
        super(world, entityUser, entity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, firstSpeed, maxSpeed, addSpeed,
        		xVectorG, yVectorG, zVectorG, damage, color, size, dead, delay, special);
        shootingFlag = false;
    }
	
	/*public boolean shotFinishBonus()
	{
    	//使用者が死んでいるなら弾をアイテム化させ、消滅させる
    	if(userEntity != null)
    	{
			if(!worldObj.isRemote && (userEntity.isDead))
			{
				if(userEntity instanceof EntityPlayer == false)
				{
					EntityItem entityItem = new EntityItem(worldObj, posX, posY, posZ, new ItemStack(mod_thKaguya.shotMaterialItem, 1));
					worldObj.spawnEntityInWorld(entityItem);
					entityItem.age = 5700;//アイテムがすぐ消滅するよう設定（１5秒で消える）
				}
				setDead();
				return true;
			}
    	}
    	return false;
	}*/
	
	//ショットが存在する限り呼び出されるメソッド
	@Override
    public void onUpdate()
    {	
		if(userEntity != null)
		{
			if(userEntity instanceof EntityPlayer)
			{
				EntityPlayer player = (EntityPlayer)userEntity;
				if(player.isUsingItem() && !shootingFlag)
				{
					Vec3 vec3 = thShotLib.getVecFromAngle(-rotationYaw + 20F, -rotationPitch, 0.3D + getShotSize() / 2.0D);
					/*double xPos = userEntity.posX - (double)(MathHelper.cos(userEntity.rotationYaw / 180.0F * (float)Math.PI) * 0.32F) * getShotSize() * 2.0D;
					double yPos = userEntity.posY - 0.1D;
					double zPos = userEntity.posZ - (double)(MathHelper.sin(userEntity.rotationYaw / 180.0F * (float)Math.PI) * 0.32F) * getShotSize() * 2.0D;*/
					prevPosX = posX;
		        	prevPosY = posY;
		        	prevPosZ = posZ;
		        	
					setPositionAndRotation(userEntity.posX + vec3.xCoord, thShotLib.getPosYFromEye(userEntity, -0.1D) + vec3.yCoord, userEntity.posZ + vec3.zCoord, -userEntity.rotationYaw, -userEntity.rotationPitch);
					
					if(getShotSize() < 6.00F)
					{
						setShotSize(getShotSize() + 0.06F);
					}
					if(player.inventory.getCurrentItem() != null)
					{
						if(player.inventory.getCurrentItem().getItem() != mod_thKaguya.nuclearControlRodItem)
						{
						
							if(!worldObj.isRemote)
							{
								worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
								setDead();
							}
							return;
						}
					}
					else
					{
						if(!worldObj.isRemote)
						{
							worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
							setDead();
						}
						return;
					}
					return;
				}
				else if(shootingFlag == false)
				{
					
					if(player.inventory.getCurrentItem() != null)
					{
						if(player.inventory.getCurrentItem().getItem() != mod_thKaguya.nuclearControlRodItem)
						{
						
							if(!worldObj.isRemote)
							{
								worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
								setDead();
							}
							return;
						}
					}
					else
					{
						if(!worldObj.isRemote)
						{
							worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
							setDead();
						}
						return;
					}
					ticksExisted = 1;
					setVector();
					shotAcceleration = 0.2D;
					shootingFlag = true;
				}
			}

		}
		else
		{
			if(!worldObj.isRemote)
			{
				setDead();
				return;
			}
		}
		
		shotDamage = getShotSize() * 8.0F;

    	super.onUpdate();
    	

    }
	
	public boolean userHitCheck(Entity entity)
	{
		if(this.shotType == thShotLib.SPOILER02 || shotType == thShotLib.SPOILER01)
		{
			return true;
			
		}
		return !entity.isEntityEqual(userEntity);
	}
	
	public MovingObjectPosition hitEntityCheck(MovingObjectPosition movingObjectPosition, Vec3 vec3d, Vec3 vec3d1)
	{
        Entity entity = null;//実際に当たったことにするEntity
    	double d = 0.0D;//そのEntityまでの仮の距離
		float hitSize = getShotSize() * 0.5F;
    	//ここから移動量分の線分を作り、それに弾の大きさの２倍の肉付けをし直方体を作る。それに当たったEntityをリスト化する\\
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(motionX, motionY, motionZ).expand(hitSize, hitSize, hitSize));//指定範囲内のEntityをリストに登録
		
    	for (int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);//entity1にリストの先端のentityを保存
        	//entity1が、当たり判定を取らない　または　entity1が使用者　または　飛んで25カウント以下？　または　EntityTHShotならパス
            if ( entity1.canBeCollidedWith() && 
            	userHitCheck(entity1) && 
            	/*!entity1.isEntityEqual(shootingEntity) &&*/
            	!hitCheckEx(entity1) && 
            	entity1 instanceof EntityPrivateSquare == false &&
            	entity1 instanceof EntityAnimal == false &&
            	entity1 instanceof EntityVillager == false &&
            	(entity1 instanceof EntityLivingBase || entity1 instanceof EntityDragonPart || entity1 instanceof EntityTHShot) &&
            	!(userEntity instanceof EntityTHFairy && entity1 instanceof EntityTHFairy))
        	{
        		//判定を弾の大きさに変更
            	AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(hitSize, hitSize, hitSize);
            	MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);
            	
        		//この判定で当たっているなら
            	if (movingObjectPosition1 != null)
            	{
            		movingObjectPosition1 = new MovingObjectPosition(entity1);
            		onImpact(movingObjectPosition1);
        		}
        	}
        }
    	
    	

    	//当たったEntityがいるなら、当たったEntityをMovingObjectPositionで登録
        /*if (entity != null)
        {
            movingObjectPosition = new MovingObjectPosition(entity);
        }
		*/
    	//MovingObjectPositionで当たっているなら
        if (movingObjectPosition != null)
        {
        	//当たった場合の処理をする
            onImpact(movingObjectPosition);
        }
    	
    	return movingObjectPosition;
	}
	
	//衝突処理
	public void hitCheck()
	{
	    //始点（現在地）
    	Vec3 vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    	//終点（現在地に移動量を足した点）
    	Vec3 vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX, posY + motionY, posZ + motionZ);
        //始点と終点からブロックとの当たりを取得
    	MovingObjectPosition movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
    	vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX, posY + motionY, posZ + motionZ);
    	//何らかのブロックに当たっているなら
        if (movingObjectPosition != null)
        {
        	//終点を当たった点に変更
        	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord);
        }
    	
        hitEntityCheck(movingObjectPosition, vec3d, vec3d1);

	}

	//ブロックやEntityに当たった時の処理
    protected void onImpact(MovingObjectPosition movingObjectPosition)
    {
    	//当たった時の処理
    	if (!worldObj.isRemote)
    	{
    		Entity hitEntity = movingObjectPosition.entityHit;
        
    		//当たったEntityがいるなら
    		if ( hitEntity != null )
        	{
        		//それがEntityTHShotに属していないなら
        		if(hitEntity instanceof EntityTHShot == false)
        		{
        			boolean isHitDelete = true;
        			//Entityに当たった時の特殊な処理
        			isHitDelete = entityHitSpecialProcess(hitEntity);
        			//指定したダメージ分の魔法ダメージを与える
        			//if(shotType != thShotLib.SPOILER01 && shotType != thShotLib.SPOILER02)
        			if(!hitEntity.isEntityEqual(userEntity))
        			{
        				if (!hitEntity.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), shotDamage));
        			}
        			//弾を消滅させる
					/*if(isHitDelete)
					{
						if(!worldObj.isRemote)
						{
							setDead();
						}
					}*/
        		}
        		//EntityTHShotに属しているなら
        		else
        		{
        			EntityTHShot entityTHShot = (EntityTHShot)hitEntity;
        			/*if(getShotStrength() == entityTHShot.getShotStrength())
        			{
        				//setDead();
        				//entityTHShot.setDead();
        			}
        			//相手の方が強いなら
        			else if(getShotStrength() < entityTHShot.getShotStrength())
        			{
        				//この弾を消滅させる
        				this.setDead();
        			}
        			//自分の方が強いなら
        			else
        			{
        				//相手の弾を消滅させる
        				entityTHShot.setDead();
        			}*/
        			if(userEntity != entityTHShot.userEntity)//使用者の違う弾同士は打ち消し合う
        			{
        				//弾同士の相殺
        				//お互い弾のダメージ分だけ小さくする
        				float shotDamageA = this.shotDamage;
        				this.shotDamage -= entityTHShot.shotDamage;
        				entityTHShot.shotDamage -= shotDamageA;
        				//setDead();
        				//entityTHShot.setDead();
        			}
        		}
			}
    		else
    		{
    			if(blockHitSpecialProcess(movingObjectPosition))
    			{
        			this.setDead();//ブロックに当たったら消滅
    			}
    		}
    	}
    }
	
	//当たり判定の追加
	public boolean hitCheckEx(Entity entity)
	{
		return false;
	}
    	
    //弾の強さ
    public int getShotStrength()
    {
    	return 10;
    }
	
}

