package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;

public class EntityTHLaser extends EntityTHShot
{
	//レーザー系のEntityの共通処理
	EntityTHLaser mother;
	
	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityTHLaser(World world)
    {
        super(world);
    	if(worldObj.isRemote)
    	{
    		//setSize((float)getLaserLength(), getShotSize());
    	}
    }
    
	public EntityTHLaser(World world, EntityLivingBase entityUser, Entity entity,
			double xPos, double yPos, double zPos,
	    	double xVector, double yVector, double zVector, double overVectorX, double overVectorY, double overVectorZ, float rotationYawSpeed,
	    	double firstSpeed, double maxSpeed, double addSpeed,
	    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int endTime, int delay, int special, double length)
	    {
	        super(world, entityUser, entity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, overVectorX, overVectorY, overVectorZ, rotationYawSpeed,
	        		firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG, damage, c, size, endTime, delay, special);
	    	setLaserLength(0.0D);
	    	setMaxLaserLength(length);
	    	mother = null;
	    }
	
	public EntityTHLaser(World world, EntityLivingBase entityUser, Entity entity,
		double xPos, double yPos, double zPos,
    	double xVector, double yVector, double zVector,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int endTime, int delay, int special, double length)
    {
        super(world, entityUser, entity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, 0F,
        		firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG, damage, c, size, endTime, delay, special);
    	setLaserLength(0.0D);
    	//setLaserLength(length);
    	setMaxLaserLength(length);
    	//setMaxLaserLength(0.6D);
    	/*mother = null;
    	setMotherAndChild(0);
    	
    	if(length > 0.6D)
    	{
	    	EntityTHLaser motherLaser = this;
	    	double leng = 0.0D;
	    	int count = 1;
	    	while(leng <= length)
	    	{
	    		motherLaser = new EntityTHLaser(world, entityUser, entity,
	    				xPos, yPos, zPos, xVector, yVector, zVector, firstSpeed, maxSpeed, addSpeed,
	    				xVectorG, yVectorG, zVectorG, damage, c, size, endTime, delay + count, special, 0.6D, motherLaser);
	    		if(!world.isRemote)
	    		{
	    			world.spawnEntityInWorld(motherLaser);
	    		}
	    		leng += 0.6D;
	    		count++;
	    	}
    	}*/
    }
	
	public EntityTHLaser(World world, EntityLivingBase entityUser, Entity entity,
			double xPos, double yPos, double zPos,
	    	double xVector, double yVector, double zVector,
	    	double firstSpeed, double maxSpeed, double addSpeed,
	    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int endTime, int delay, int special, double length, EntityTHLaser motherLaser)
	{
        super(world, entityUser, entity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, 0F,
        		firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG, damage, c, size, endTime, delay, special);
        
    	setLaserLength(0.0D);
    	setMaxLaserLength(0.6D);
    	setMotherAndChild(1);
        mother = motherLaser;
	}

	
	//Entity生成時に一度だけ呼ばれる
	@Override
	protected void entityInit()
	{
		super.entityInit();
		dataWatcher.addObject(21, new Integer(0));
		dataWatcher.addObject(22, new Integer(0));
		dataWatcher.addObject(23, new Integer(0));
		dataWatcher.addObject(24, new Integer(0));
		dataWatcher.addObject(25, new Integer(0));
		dataWatcher.addObject(26, new Integer(0));
	}
	
	//角度の更新処理
	@Override
	public void updateAngle()
	{
    	float f = MathHelper.sqrt_double(shotVectorX * shotVectorX + shotVectorZ * shotVectorZ);
    	if(!worldObj.isRemote)
    	{
    		rotationYaw = (float)((Math.atan2(shotVectorX, shotVectorZ) * 180D) / 3.1415927410125732D);
    		if(rotationYaw >= 180F)
    		{
    			rotationYaw = -180F + (rotationYaw - 180F);
    		}
    		else if(rotationYaw <= -180F)
    		{
    			rotationYaw = 180F + (rotationYaw + 180F);
    		}
    	}
        //for (rotationPitch = (float)((Math.atan2(motionY, f) * 180D) / 3.1415927410125732D); rotationPitch - prevRotationPitch < -180F; prevRotationPitch -= 360F) { }
        if(!worldObj.isRemote)
        {
        	rotationPitch = (float)((Math.atan2(shotVectorY, f) * 180D) / 3.1415927410125732D);
        	//for (rotationPitch = (float)((Math.atan2(shotVectorY, f) * 180D) / 3.1415927410125732D); rotationPitch - prevRotationPitch < -180F; prevRotationPitch -= 360F) { }
        }
	}

	
	@Override
	public void shotFinishBonus()
	{
		double zPos = 0.0D;
		while(zPos < getLaserLength())
		{
			EntityItem entityItem = new EntityItem(worldObj, posX - shotVectorX * zPos, posY - shotVectorY * zPos, posZ - shotVectorZ * zPos, new ItemStack(mod_thKaguya.shotMaterialItem, 1));
			if(!worldObj.isRemote)
			{
				worldObj.spawnEntityInWorld(entityItem);
			}
			entityItem.age = 5700;//アイテムがすぐ消滅するよう設定（１5秒で消える）
			zPos += 0.3D;
		}
		if(!worldObj.isRemote)
		{
			setDead();
		}
	}
	
	@Override
	public void  onUpdate()
	{
		super.onUpdate();
		
		if(this instanceof EntityTHSetLaser == false)
		{
			double laserLength = getLaserLength() + getSpeed() * 2.0D;
			if(laserLength > getMaxLaserLength())
			{
				setLaserLength(getMaxLaserLength());
			}
			else
			{
				setLaserLength(laserLength);
			}
		}
		
		if(mother != null)
		{
			motionY += 0.4D;
			
			setMotherAndChild(1);
			setMotherPosX(mother.posX);
			setMotherPosY(mother.posY);
			setMotherPosZ(mother.posZ);
		}
		else
		{
			setMotherAndChild(0);
			//setMotherPosY(-9999999);
		}
	}
	
	//衝突処理
	@Override
	public void hitCheck()
	{
		double width = getShotSize();
		double length = getLaserLength();
	    //始点（現在地）
    	Vec3 vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    	//終点（現在地に移動量を足した点）
    	Vec3 vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX + shotVectorX * length, posY + motionY + shotVectorY * length, posZ + motionZ + shotVectorZ * length);
        //始点と終点からブロックとの当たりを取得
    	MovingObjectPosition movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
    	vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX + shotVectorX * length, posY + motionY + shotVectorY * length, posZ + motionZ + shotVectorZ * length);
    	//何らかのブロックに当たっているなら
        if (movingObjectPosition != null)
        {
        	//終点を当たった点に変更
        	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord);
        	/*if(movingObjectPosition.entityHit == null)
        	{
        		shotDamage -= 2;
        		if(shotDamage <= 0)
        		{
        			if(!worldObj.isRemote)
        			{
        				setDead();
        			}
        		}
        	}*/
        	onImpact(movingObjectPosition);
        }
    	
    	
        Entity entity = null;//実際に当たったことにするEntity
    	double d = 0.0D;//そのEntityまでの仮の距離
    	//ここから移動量分の線分を作り、それに弾の大きさの２倍の肉付けをし直方体を作る。それに当たったEntityをリスト化する
		double xLength = motionX + Math.sin(rotationYaw / 180F * 3.141593F) * Math.cos(rotationPitch / 180F * 3.141593F) * getLaserLength();
		double yLength = motionY + Math.sin(rotationPitch / 180F * 3.141593F) * getLaserLength();
		double zLength = motionZ + Math.cos(rotationYaw / 180F * 3.141593F) * Math.cos(rotationPitch / 180F * 3.141593F) * getLaserLength();
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(xLength, yLength, zLength).expand(width, width, width));//指定範囲内のEntityをリストに登録

    	for (int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);//entity1にリストの先端のentityを保存
        	//entity1が、当たり判定を取らない　または　entity1が使用者　または　飛んで25カウント以下？　または　EntityTHShotならパス
            if ( entity1.canBeCollidedWith() && 
            	!entity1.isEntityEqual(userEntity) && 
            	!entity1.isEntityEqual(shootingEntity) && 
            	!hitCheckEx(entity1) && 
            	/*entity1 instanceof EntityTHShot == false &&*/  
            	entity1 instanceof EntityPrivateSquare == false &&
            	entity1 instanceof EntityAnimal == false &&
            	entity1 instanceof EntityVillager == false &&
            	entity1 instanceof EntityLivingBase &&
            	!(userEntity instanceof EntityTHFairy && entity1 instanceof EntityTHFairy))
            {
        		//float f2 = 0.3F;
        		//判定を弾の大きさに変更
            	AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(width, width, width);
            	MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);
        		//この判定で何も当たっていないならパス
            	if (movingObjectPosition1 != null)
            	{
            		movingObjectPosition = new MovingObjectPosition(entity1);
            		boolean creative = false;
            		if (movingObjectPosition != null && movingObjectPosition.entityHit != null && movingObjectPosition.entityHit instanceof EntityPlayer)
        			{
        				EntityPlayer entityPlayer = (EntityPlayer)movingObjectPosition.entityHit;
						/*if(entityPlayer.capabilities.isCreativeMode)
        				{
        					creative = true;
        				}*/
            			if (entityPlayer.capabilities.disableDamage || shootingEntity instanceof EntityPlayer && !((EntityPlayer)shootingEntity).func_96122_a(entityPlayer))
        				//if ( entityPlayer.capabilities.disableDamage && !((EntityPlayer)shootingEntity).func_96122_a(entityPlayer))
            			{
            				movingObjectPosition = null;
            			}
        			}
            		if(movingObjectPosition != null)
            		{
            			onImpact(movingObjectPosition);
            		}
            	}
        	
            }
        }

    	//当たったEntityがいるなら、当たったEntityをMovingObjectPositionで登録
        /*if (entity != null)
        {
            movingObjectPosition = new MovingObjectPosition(entity);
        }
    	//MovingObjectPositionで当たっているなら
        if (movingObjectPosition != null)
        {
        	//当たった場合の処理をする
            onImpact(movingObjectPosition);
        }*/
    	if(worldObj.isRemote)
    	{
    		setSize((float)getLaserLength(), getShotSize());
    	}
	}

	//ブロックやEntityに当たった時の処理
	@Override
    protected void onImpact(MovingObjectPosition movingObjectPosition)
    {
    	if(movingObjectPosition.entityHit != null)
    	{
	    	Entity hitEntity = movingObjectPosition.entityHit;
        
	    	//当たったEntityがいるなら
	    	if ( hitEntity != null )
	        {
	        	//それがEntityTHShotに属していないなら
	        	if(hitEntity instanceof EntityTHShot == false)
	        	{
	        		//Entityに当たった時の特殊な処理
	        		entityHitSpecialProcess(hitEntity);
	        		//指定したダメージ分の魔法ダメージを与える
	        		if(!worldObj.isRemote)
	        		{
	        			if (!hitEntity.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), this.getShotDamageWithDifficulty()));
	        		}
	        		/*hitEntity.motionX = 0.0D;
	        		hitEntity.motionY = 0.0D;
	        		hitEntity.motionZ = 0.0D;*/
					if(hitEntity.hurtResistantTime == 0)
	        		{
	        			shotDamage--;
	        		}
	        		if(shotDamage <= 0)
	        		{
	        			shotDamage = 1;
	        		}
	        		
	        		/*double distance = this.getDistance(hitEntity.posX, hitEntity.posY, hitEntity.posZ);
	        		EntityTHLaser laser = thShotLib.createLaserA(userEntity, this, userEntity.posX + shotVectorX * distance, userEntity.posY + shotVectorY * distance, userEntity.posZ + shotVectorZ * distance, this.shotVectorX, this.shotVectorY, this.shotVectorZ, 
	        						this.shotSpeed, this.shotLimitSpeed, this.shotAcceleration, 0.0D, 0.0D, 0.0D, 200F, this.shotType, this.shotSize, this.lastTime - this.ticksExisted, 0, this.shotType, this.getMaxLaserLength() - distance);
	        		laser.setLaserLength(this.getLaserLength() - distance);
	        		setLaserLength(distance);
	        		setMaxLaserLength(distance);*/
	        		
	        		
	        		//shotDamage -= 2;ww
	        		/*double hitLength = this.getDistanceSqToEntity(hitEntity);
	        		//if(hitLength > 0.3D && hitLength < getLaserLength() - 0.3D)
	        		if(hitEntity instanceof EntityLivingBase)
	        		{
	        			EntityLivingBase hitLivingEntity = (EntityLivingBase)hitEntity;
		        		if(hitLivingEntity.hurtTime >= hitLivingEntity.maxHurtTime - 3 || !hitLivingEntity.isDead)
		        		{
		        			if(!worldObj.isRemote)
		        			{
		        				if(this.getLaserLength() > hitLength + 0.4D)
		        				{
		        					thShotLib.createLaserABaseA(userEntity, this, posX + xVec * (hitLength + 0.1D), posY + yVec * (hitLength + 0.1D), posZ + zVec * (hitLength + 0.1D),
		        							xVec, yVec, zVec, shotSpeed, shotMaxSpeed, shotAddSpeed, shotGravityX, shotGravityY, shotGravityZ, shotDamage, color, width, deadTime - ticksExisted, shotType, getLaserLength() - hitLength - 0.1D);
		        				}
		        			}
		        			if(!worldObj.isRemote)
		        			{
		        				if(this.getLaserLength() > hitLength - 0.1D)
		        				{
		        					this.setLaserLength(hitLength - 0.1D);
		        				}
		        				this.setMaxLaserLength(hitLength - 0.1D);
		        			}
		        			
		        		}
	        		}*/
	        	}
	        	//EntityTHShotに属しているなら
	        	else
	        	{
        			EntityTHShot entityTHShot = (EntityTHShot)hitEntity;

        			if(userEntity != entityTHShot.userEntity)//使用者の違う弾同士は打ち消し合う
        			{
        				//弾同士の相殺
        				//お互い弾のダメージ分だけ小さくする
        				float shotDamageA = this.shotDamage;
        				this.shotDamage -= entityTHShot.shotDamage;
        				entityTHShot.shotDamage -= shotDamageA;
        				if(this.shotDamage < 0.0F)
        				{
        					shotDamage = 0.0F;
        				}
        				if(entityTHShot.shotDamage < 0.0F)
        				{
        					entityTHShot.shotDamage = 0.0F;
        				}
        			}
	        	}
			}
    	}
    	else
    	{
    		blockHitSpecialProcess(movingObjectPosition);
    		double hitDistance = this.getDistance(movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord);
    		if(hitDistance > 0.3D)
    		{
    			if(!worldObj.isRemote)
    			{
    				setLaserLength(hitDistance);
    				setMaxLaserLength(hitDistance);
    			}
    		}
    		else
    		{
    			if(!worldObj.isRemote)
    			{
    				setDead();
    			}
    		}
    		//shotDamage -= 20;
    		/*if(!worldObj.isRemote)
    		{
    			setDead();
    			return;
    		}*/
    	}
    	
    	if(shotDamage <= 0)
    	{
    		if(!worldObj.isRemote)
    		{
        		this.setDead();//ブロックに当たったら消滅
    		}
    	}
    }
	
	//独自の動きを追加するためのもの
	@Override
	public void specialMotion()
	{
		super.specialMotion();
		
		switch(shotType)
		{
			case thShotLib.GUNGNIR:
				/*if(ticksExisted == 1)
				{
					Vec3 over = thShotLib.getVecFromAngle(rotationYaw, rotationPitch + 90F);
					Vec3 rotate= thShotLib.getVectorFromRotation(shotVectorX, shotVectorY, shotVectorZ, over.xCoord, over.yCoord, over.zCoord, 90F);
					//Vec3 rotate = thShotLib.getVecFromAngle(rotationYaw + 90F, 0F);
					this.overVectorX = rotate.xCoord;
					this.overVectorY = rotate.yCoord;
					this.overVectorZ = rotate.zCoord;
				}*/
				
				
				if(ticksExisted <= 10)
				{
					Vec3 move = thShotLib.getVectorFromRotation(overVectorX, overVectorY, overVectorZ, shotVectorX, shotVectorY, shotVectorZ, 18F);
					if(this.getLaserLength() < this.getMaxLaserLength())
					{
						this.setLaserLength(this.getLaserLength() + 1.0D);
						
					}
					else
					{
						this.setLaserLength(this.getMaxLaserLength());
					}
					/*rotationPitch += 18;
					if(rotationPitch > 90F)
					{
						rotationYaw += 180F;
						//rotationPitch -= 180F;
					}
					else if(rotationPitch < -90F)
					{
						rotationYaw += 180F;
						//rotationPitch += 180F;
					}*/
					shotVectorX = move.xCoord;
					shotVectorY = move.yCoord;
					shotVectorZ = move.zCoord;
					//setVector();
					updateAngle();
				}
				if(ticksExisted == 10)
				{
					userEntity.motionX += shotVectorX;
					userEntity.motionZ += shotVectorZ;
					this.shotLimitSpeed = 2.0D;
					this.shotAcceleration = 0.6D;
				}
				if(ticksExisted > 10)
				{
					
					thShotLib.createRingShot(this.userEntity, this, this.posX, this.posY, this.posZ, shotVectorX, shotVectorY, shotVectorZ, 0F, 1.4D, 0.1D, -0.1D, 0.0D, 0.0D, 0.0D, 6.0F, thShotLib.CRYSTAL[thShotLib.RED], 0.45F, 40, 0, 0, 4, 0.3D, 240F, ticksExisted * 10F);
				}
				break;
			default:
				break;
			
		}
	}
    	

    //Entityからの攻撃を受けたときの処理　要は跳ね返す処理
	@Override
    public boolean attackEntityFrom(DamageSource damagesource, float i)
    {
		return false;
    }
	
	
	//レーザーの長さを設定
	public void setLaserLength(double length)
	{
		dataWatcher.updateObject(21, Integer.valueOf((int)(length * 10000.0D)));
	}
	//レーザーの長さを返す
	public double getLaserLength()
	{
		return (double)dataWatcher.getWatchableObjectInt(21) / 10000.0D;
	}
	
	//レーザーの最大の長さを設定
	public void setMaxLaserLength(double length)
	{
		dataWatcher.updateObject(22, Integer.valueOf((int)(length * 10000.0D)));
	}
	//レーザーの最大の長さを返す
	public double getMaxLaserLength()
	{
		return (double)dataWatcher.getWatchableObjectInt(22) / 10000.0D;
	}
	
	//親のレーザーのX座標を設定する
	public void setMotherPosX(double x)
	{
		dataWatcher.updateObject(23, Integer.valueOf((int)(x * 10000.0D)));
	}
	
	//親のレーザーのX座標を返す
	public double getMotherPosX()
	{
		return dataWatcher.getWatchableObjectInt(23) / 10000.0D;
	}
	
	//親のレーザーのY座標を設定する
	public void setMotherPosY(double y)
	{
		dataWatcher.updateObject(24, Integer.valueOf((int)(y * 10000.0D)));
	}
	
	//親のレーザーのY座標を返す
	public double getMotherPosY()
	{
		return dataWatcher.getWatchableObjectInt(24) / 10000.0D;
	}
	
	//親のレーザーのZ座標を設定する
	public void setMotherPosZ(double z)
	{
		dataWatcher.updateObject(25, Integer.valueOf((int)(z * 10000.0D)));
	}
	
	//親のレーザーのZ座標を返す
	public double getMotherPosZ()
	{
		return dataWatcher.getWatchableObjectInt(25) / 10000.0D;
	}
	
	//親子がいるかを設定する
	public void setMotherAndChild(int b)
	{
		dataWatcher.updateObject(26, Integer.valueOf(b));
	}
	
	//親子がいるかを返す
	public int isMotherAndChild()
	{
		return dataWatcher.getWatchableObjectInt(26);
	}
}
