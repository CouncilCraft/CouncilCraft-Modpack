package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.audio.SoundManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;

public class EntityMiniHakkero extends Entity
{
	//ミニ八卦炉

	private EntityLivingBase userEntity;
	private EntityLivingBase tgEntity;
	public int count;
	private float circleAngle;
	private int moveTexture;
	public int num;
	private int damage;
	private int lastTime;

    public EntityMiniHakkero(World world)
    {
        super(world);
        preventEntitySpawning = true;
        setSize(0.4F, 0.4F);//サイズを設定　平面上の横と奥行きサイズ、高さ
        yOffset = 0.0F;//高さを設定
    }
	
    public EntityMiniHakkero(World world,EntityLivingBase EntityLivingBase, int da)
    {
        this(world);

    	userEntity = EntityLivingBase;//使用者をuserEntityに保存
        setPosition(userEntity.posX - Math.sin(userEntity.rotationYaw / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F),
        			userEntity.posY - Math.sin(userEntity.rotationPitch / 180F * 3.141593F) + (double)userEntity.getEyeHeight() - 0.10000000149011612D ,
					userEntity.posZ + Math.cos(userEntity.rotationYaw / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F));//初期位置を設定(x,y,z)
    	rotationYaw = userEntity.rotationYaw;
    	rotationPitch = userEntity.rotationPitch;
    	tgEntity = null;
    	count = 0;
    	circleAngle = 0F;
    	moveTexture = 0;
    	damage = da;
    	
    	worldObj.playSoundAtEntity(this, "thKaguyaMod.masterspark", mod_thKaguya.MasterSparkVol, 1.0F);
    	lastTime = 0;
    }
	
    public EntityMiniHakkero(World world,EntityLivingBase EntityLivingBase, EntityLivingBase target)
    {
        this(world);

    	userEntity = EntityLivingBase;//使用者をuserEntityに保存
        setPosition(userEntity.posX - Math.sin(userEntity.rotationYaw / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F),
        			userEntity.posY - Math.sin(userEntity.rotationPitch / 180F * 3.141593F) + (double)userEntity.getEyeHeight() - 0.10000000149011612D ,
					userEntity.posZ + Math.cos(userEntity.rotationYaw / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F));//初期位置を設定(x,y,z)
    	rotationYaw = userEntity.rotationYaw;
    	rotationPitch = userEntity.rotationPitch;
    	tgEntity = target;
    	count = 0;
    	circleAngle = 0F;
    	moveTexture = 0;
    	damage = 1;
    	//SoundManager.addSound("thkaguyamod:masuterspark");
    	//worldObj.playSoundAtEntity(this, "thkaguyamod:sound/masterspark.wav", mod_thKaguya.MasterSparkVol, 1.0F);
    	//worldObj.playSoundAtEntity(this, "thkaguyamod.masterspark", mod_thKaguya.MasterSparkVol, 1.0F);
    	worldObj.playSoundAtEntity(this, "thKaguyaMod.masterspark", mod_thKaguya.MasterSparkVol, 1.0F);
    	lastTime = 0;
    }

	//
    protected void entityInit()
    {
    }

    /**
     * Returns true if this entity should push and be pushed by other entities when colliding.
     */
    public boolean canBePushed()
    {
        return false;
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
    	return false;
    }
	
	//Entityが存在する限り毎フレーム呼び出されるメソッド
	@Override
    public void onUpdate()
    {
        super.onUpdate();
    	if(!worldObj.isRemote && userEntity == null)
    	{
    		thKaguyaLib.itemEffectFinish(this, userEntity, mod_thKaguya.hakkeroItem);
    		return;
    	}
    	
    	if(ticksExisted <= lastTime)
    	{
    		return;
    	}

    	circleAngle += 4.7F;

    
	    double length = 0.0D;
	    double speed = 0.0D;
	    Vec3 vec3d;
	    Vec3 vec3d1;
	    MovingObjectPosition movingObjectPosition;
	    float yawRad = rotationYaw / 180F * 3.141593F;
	    float pitchRad = rotationPitch / 180F * 3.141593F;
	    double sinYaw = Math.sin(yawRad);
	    double cosYaw = Math.cos(yawRad);
	    double sinPitch = Math.sin(pitchRad);
	    double cosPitch = Math.cos(pitchRad);
	    double ax, ay, az, dx, dy, dz, px, py, pz;
	    
	    if(userEntity != null)
	    {
	    	do
	    	{	
	    		
	    		vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX - sinYaw * cosPitch * length, posY - sinPitch * length, posZ + cosYaw * cosPitch * length);
	    		if(speed < 1.6D)
	    		{
	    			speed += 0.2D;
	    		}
	    		else
	    		{
	    			speed = 1.6D;
	    		}
	    		length += speed;
	    		ax = -sinYaw * cosPitch * length;
	    		ay = -sinPitch * length;
	    		az =  cosYaw * cosPitch * length;
	    		px = posX + ax;
	    		py = posY + ay;
	    		pz = posZ + az;
	    		vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(px, py, pz);
	    		movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
				float angleXZ, angleY;

				dx = posX - userEntity.posX;
				dy = posY - userEntity.posY;
				dz = posZ - userEntity.posZ;

				angleY  = (float)Math.atan2(dx, dz);
				angleXZ = (float)Math.atan2( Math.sqrt(dx*dx + dz*dz), dy);
			}while(movingObjectPosition == null && length < 30.0D);
	    	
	    	ax = -sinYaw * cosPitch;
	    	ay = -sinPitch;
	    	az =  cosYaw * cosPitch;

	    	EntityMasterSpark entityMasterSpark;
			entityMasterSpark = new EntityMasterSpark(worldObj, userEntity, this, posX, posY, posZ, ax, ay, az, 0.3F, length, ticksExisted);

			if(!worldObj.isRemote)
			{
				worldObj.spawnEntityInWorld(entityMasterSpark);
    		}
	    	if(ticksExisted > 30)//30ticks以上ならマスタースパークの当たり判定を出現させる
	    	{	
	    		double shotSize = 2.0D;
	        	List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(-sinYaw * cosPitch * length, -sinPitch * length, cosYaw * cosPitch * length).expand(shotSize , shotSize , 0.1D ));//指定範囲内のEntityをリストに登録
	    		Entity entity = null;
	    		double d = 0.0D;
	    		vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX - sinYaw * cosPitch, posY - sinPitch, posZ + cosYaw * cosPitch);
	    		vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX - sinYaw * cosPitch * length, posY - sinPitch * length, posZ + cosYaw * cosPitch * length);
	    		
	    		for (int j = 0; j < list.size(); j++)
	        	{
	            	Entity entity1 = (Entity)list.get(j);//entity1にリストの先端のentityを保存
	        		//entity1に当たり判定があり、ミニ八卦炉ではなく、使用者でもなく、弾幕でもなければ
	            	if ( entity1.canBeCollidedWith() && entity1 instanceof EntityMiniHakkero == false && !entity1.isEntityEqual(userEntity) && entity1 instanceof EntityTHShot == false &&
	            			hitCheckEx(entity1))
	            	{
	            		AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(shotSize, shotSize, shotSize);
	            		MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);
	            		if (movingObjectPosition1 != null)
	            		{
	            			//当たっているならここからその点までの距離を取得
            				//double d1 = vec3d.distanceTo(movingObjectPosition1.hitVec);
        					//今までの一番近くにいるなら、一番近いEntityを更新する
            				/*if (d1 < d || d == 0.0D)
            				{
                				entity = entity1;
                				d = d1;
            				}*/
	            			movingObjectPosition = new MovingObjectPosition(entity1);
	        	        	if (movingObjectPosition != null && movingObjectPosition.entityHit != null)//Entityに当たっているなら
	        	        	{
	        	        		if(tgEntity != null)
	        	    			{
	        	    				if (!movingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), 8));
	        	    			}
	        	        		else
	        	        		{
	        	            		if(!worldObj.isRemote)
	        	    				{
	        	    					//威力5.0の強力な爆発を起こす。ブロックを破壊するかはコンフィグで設定（デフォは破壊する）
	        	    					worldObj.createExplosion(userEntity, movingObjectPosition.entityHit.posX, movingObjectPosition.entityHit.posY, movingObjectPosition.entityHit.posZ, getExplosionLevel() * 0.1F, tgEntity == null && mod_thKaguya.MasterSparkDestroysBlocks);
	        	    				}
	        	        		}
	        	        	}
	            		}
	            	}
	        	}
				/*if (entity != null)
	        	{
	            	movingObjectPosition = new MovingObjectPosition(entity);
	        	}*/

	        	/*if (movingObjectPosition != null && movingObjectPosition.entityHit != null)//Entityに当たっているなら
	        	{
	        		if(tgEntity != null)
	    			{
	    				if (!movingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), 8));
	    			}
	        		else
	        		{
	            		if(!worldObj.isRemote)
	    				{
	    					//威力5.0の強力な爆発を起こす。ブロックを破壊するかはコンフィグで設定（デフォは破壊する）
	    					worldObj.createExplosion(userEntity, movingObjectPosition.entityHit.posX, movingObjectPosition.entityHit.posY, movingObjectPosition.entityHit.posZ, getExplosionLevel(), tgEntity == null && mod_thKaguya.MasterSparkDestroysBlocks);
	    				}
	        		}
	        	}
	    		else*/ if( movingObjectPosition != null && tgEntity == null)//ブロックに当たっているなら
	    		{
	    			if(!worldObj.isRemote)
	    			{
	    				//同上
	    				worldObj.createExplosion(userEntity, movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord, getExplosionLevel(), tgEntity == null && mod_thKaguya.MasterSparkDestroysBlocks);
	    			}
	    		}
	    	}
    	}

    	if(ticksExisted > lastTime)
    	{
    		lastTime = ticksExisted;
    	}
		//時間で消滅
		if(ticksExisted >= 109)
		{
			if(!worldObj.isRemote)
			{
				thKaguyaLib.itemEffectFinish(this, userEntity, mod_thKaguya.hakkeroItem);
			}
		}
	}
	
	public boolean hitCheckEx(Entity entity)
	{
		if(tgEntity == null)
		{
			return true;
		}
		else
		{
			return entity instanceof EntityDragonPart || entity instanceof EntityLivingBase && !(entity instanceof EntityAnimal) && !(entity instanceof EntityVillager);
		}
	}
	
	//マスパの爆発力
	public float getExplosionLevel()
	{
		return 5.0F;
	}

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
    	nbttagcompound.setShort("count", (short)count);
    	nbttagcompound.setShort("damage", (short)damage);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
    	count = nbttagcompound.getShort("count");
    	damage = nbttagcompound.getShort("damage");
    }

    public float getShadowSize()
    {
        return 0.5F;
    }

    protected boolean isValidLightLevel()
    {
        return true;
    }

    public int getBrightnessForRender(float par1)
    {
        return 0xf000f0;
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float par1)
    {
        return 0.5F;
    }

	public float getCircleAngle()
	{
		return circleAngle;
	}
}
