package thKaguyaMod.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.item.ItemYuukaParasol;

public class EntityYuukaParasol extends Entity
{
	//幽香の日傘

	public EntityPlayer user;
	public int damage;
	public int mode;
	
	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityYuukaParasol(World world)
    {
        super(world);
        //preventEntitySpawning = true;
        setSize(2.0F, 0.5F);//サイズを設定　平面上の横と奥行きサイズ、高さ
        yOffset =  1.5F;//高さを設定*/
    	mode = getParasolMode();
    }

	//出現時に呼び出されるコンストラクト
    public EntityYuukaParasol(World world,EntityPlayer entityPlayer, int da)
    {
        this(world);
        //mode = 0;
    	setParasolMode(0);
    	ridingEntity = entityPlayer;
    	//ridingEntity = entityPlayer;
    	user = entityPlayer;
    	//prevPosX = user.posX;
        //prevPosY = user.posY;
        //prevPosZ = user.posZ;
    	posX = user.posX - Math.sin((user.rotationYaw + 23F) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * 1.0D;
		posY = user.posY - Math.sin(user.rotationPitch / 180F * 3.141593F) * Math.cos(23F / 180F * 3.141593F) * 1.0D + user.getEyeHeight();
		posZ = user.posZ + Math.cos((user.rotationYaw + 23F) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * 1.0D;
        setPosition(posX, posY, posZ);//初期位置を設定(x,y,z)
    	setRotation(user.rotationYaw,  0.0F);
    	//setPosX(user.posX);
    	//setPosY(user.posY);
    	//setPosZ(user.posZ);
    	damage = da;
    }
	
	//他の物体と衝突したときのその物体の当たり判定？
    /*public AxisAlignedBB getCollisionBox(Entity par1Entity)
    {
        return par1Entity.boundingBox;
    }

	//当たり判定を設定
    public AxisAlignedBB getBoundingBox()
    {
        return boundingBox;
    }*/

	
	//押すことができるかどうか
    public boolean canBePushed()
    {
        return false;
    }
	
	//生成時に呼ばれる
    protected void entityInit()
    {
    	dataWatcher.addObject(19, new Integer(0));
    	//dataWatcher.addObject(20, new Integer(0));
    	//dataWatcher.addObject(21, new Integer(0));
    	//dataWatcher.addObject(22, new Integer(0));
    }

	/**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
	@Override
    protected boolean canTriggerWalking()
    {
        return false;
    }

	//当たり判定の有無　falseだと右クリックの選択ですらできない。trueならsetSize()で設定したボックスの当たり判定が出現する
	@Override
    public boolean canBeCollidedWith()
    {
        return true;
    }

	//Entityが存在する限り毎フレーム呼び出されるメソッド
	@Override
    public void onUpdate()
    {
    	super.onUpdate();
    	
    	//使用者がいないなら終了処理
    	if(!worldObj.isRemote && (user == null || user.isDead) )
    	{
    		thKaguyaLib.itemEffectFinish(this, user, mod_thKaguya.yuukaParasolItem, damage);
    		return;
    	}
    	
    	float posAngle = 23F;//(float)motionY * -92F;
		double distance = 1.0D;
		double yPos = -0.2D;
    	
    	//使用者がいるなら
    	if(/*!worldObj.isRemote &&*/ user != null)
    	{			

			
			if(getParasolMode() == 0)
			{
				//easyFalling();
				rotationPitch = -user.rotationPitch;
			}
			else if(getParasolMode() == 1)
			{
				posAngle = 23F;
				rotationPitch = -user.rotationPitch + 40F;
				yPos = -0.2D;
			}
			else
			{
				posAngle = 23F;
				rotationPitch = -user.rotationPitch - 90F;
				distance = 0.7D;
				yPos = 0.2D;
			}
    		
    		
    		if(getParasolMode() == 0)
    		{
    			//使用者が地面に立っているなら
    			if(user.isSneaking() && ticksExisted > 10)
    			{
    				setParasolMode(1);
    				ticksExisted = 0;
    			}
    			user.fallDistance *= 0.7F;
    		}
    		else if(getParasolMode() == 1)
    		{
    			if(user.isSneaking() && ticksExisted > 10)
    			{
    				setParasolMode(2);
    				ticksExisted = 0;
    			}
    		}
    		else
    		{
    			if(user.isSneaking() && ticksExisted > 10)
    			{
    				thKaguyaLib.itemEffectFinish(this, user, mod_thKaguya.yuukaParasolItem, damage);
    			}
    		}
    		rotationYaw = user.rotationYaw;
    		
    		posX = user.posX - Math.sin((user.rotationYaw + posAngle) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * distance;
    		posY = user.posY - Math.sin(user.rotationPitch / 180F * 3.141593F) * Math.cos(posAngle / 180F * 3.141593F) * distance + user.getEyeHeight();
    		posZ = user.posZ + Math.cos((user.rotationYaw + posAngle) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * distance;
    		//thKaguyaLib.itemEffectFollowUser(this, user, distance, posAngle, true, yPos + (float)user.getEyeHeight());
			//setPosX(posX);
			//setPosY(posY);
			//setPosZ(posZ);
    		setPosition(posX, posY, posZ);
    	}
    	
    	
    	if(!worldObj.isRemote && damage >= ItemYuukaParasol.PARASOL_MAX_DAMAGE)//ダメージが武器の耐久を越したら
    	{
    		setDead();//消滅
    	}


    	/*if(rotationYaw >  180F)rotationYaw -= 360F;
    	if(rotationYaw < -180F)rotationYaw += 360F;
    	if(rotationPitch >  180F)rotationPitch -= 360F;
    	if(rotationPitch < -180F)rotationPitch += 360F;*/
    	//setPosition(getPosX(), getPosY(), getPosZ());
    	setRotation(rotationYaw, rotationPitch);
    }
    
    //乗っているEntityの処理
    //ここでは使用者の処理。使用者のmotionXなどは恐らくここでしかまともに操作できない
    @Override
    public void updateRidden()
	{
		if(ridingEntity != null)
		{
			float posAngle = (float)motionY * -92F;
			double distance = 1.0D;
			double yPos = -0.8D;
			
			if(getParasolMode() == 0)
			{
				easyFalling();
			}
			ridingEntity.motionX *= 0.95D;
			ridingEntity.motionZ *= 0.95D;
			/*else if(getParasolMode() == 1)
			{
				posAngle = 23F;
				rotationPitch = 40F;
				yPos = -0.6D;
			}
			else
			{
				posAngle = 23F;
				rotationPitch = -90F;
				distance = 0.4D;
				yPos = -0.4D;
			}
			//ridingEntity.fallDistance *= 0.7F;
			posX = ridingEntity.posX - Math.sin((ridingEntity.rotationYaw + posAngle) / 180F * (float)Math.PI) * distance;
    		posY = ridingEntity.posY + ridingEntity.getEyeHeight() + yPos;
    		posZ = ridingEntity.posZ + Math.cos((ridingEntity.rotationYaw + posAngle) / 180F * (float)Math.PI) * distance;
			*/
			//setPosition(posX, posY, posZ);
			motionY = ridingEntity.motionY;
			motionX = ridingEntity.motionX;
			motionZ = ridingEntity.motionZ;
			//posX += 0.05D;
			/*setPosition(posX, posY, posZ);
			rotationYaw = ridingEntity.rotationYaw;
			*/
			/*if(ridingEntity.isSneaking())
			{
				if(!worldObj.isRemote)
				{
					finish();
				}
			}*/
			
			//setPosX(ridingEntity.posX);
			//setPosY(ridingEntity.posY);
			//setPosZ(ridingEntity.posZ);
			
		}
		else
		{
			if(!worldObj.isRemote)
			{
				thKaguyaLib.itemEffectFinish(this, user, mod_thKaguya.yuukaParasolItem, damage);
			}
		}
	}
	
	protected void easyFalling()
	{
		if(ridingEntity.motionY < 0.0D)
		{
			ridingEntity.motionY *= 0.7D;
		}
	}
	
	//プレイヤーから右クリックされたときの処理
	/*@Override
	public boolean interact(EntityPlayer par1EntityPlayer)
	{
		if(!worldObj.isRemote)
		{
			finish();
			return true;
		}
		return true;
	}*/
	
	//Entityに攻撃されたときに呼び出されるメソッド　破壊とか関係なしに攻撃されれば呼び出される
	@Override
	public boolean attackEntityFrom(DamageSource par1DamageSource, float par2)
    {
    	if(!worldObj.isRemote && getParasolMode() == 0 && ticksExisted >= 3)
    	{
    		thKaguyaLib.itemEffectFinish(this, user, mod_thKaguya.yuukaParasolItem, damage);
    	}

        return true;
    }
    
    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
    	nbttagcompound.setInteger("damage", damage);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
    	damage = nbttagcompound.getInteger("damage");
    }
    
    public void setParasolMode(int mode)
	{
		dataWatcher.updateObject(19, Integer.valueOf(mode));
	}
	
	public int getParasolMode()
	{
		return dataWatcher.getWatchableObjectInt(19);
	}
	
    /*public void setPosX(double x)
	{
		dataWatcher.updateObject(20, Integer.valueOf((int)(x * 10000D)));
	}
	
	public double getPosX()
	{
		return (double)dataWatcher.getWatchableObjectInt(20) / 10000D;
	}
	
	public void setPosY(double y)
	{
		dataWatcher.updateObject(21, Integer.valueOf((int)(y * 10000D)));
	}
		
	public double getPosY()
	{
		return (double)dataWatcher.getWatchableObjectInt(21) / 10000D;
	}
	
	public void setPosZ(double z)
	{
		dataWatcher.updateObject(22, Integer.valueOf((int)(z * 10000D)));
	}
		
	public double getPosZ()
	{
		return (double)dataWatcher.getWatchableObjectInt(22) / 10000D;
	}*/

}
