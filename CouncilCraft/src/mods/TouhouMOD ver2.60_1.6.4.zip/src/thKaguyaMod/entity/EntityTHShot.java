package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;
import java.util.Calendar;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityFallingSand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;

public class EntityTHShot extends Entity
{
	//ショット系のEntityの共通処理

	
	//種類特性変数
	protected float shotSize;//弾のサイズ
	
	//個別特性変数
	public EntityLivingBase userEntity;//弾の持ち主
	public Entity shootingEntity;//発射したEntity
	public double shotSpeed;//弾のスピード
	public double shotLimitSpeed;//弾の限界速度
	public double shotAcceleration;//弾の加速力
	public boolean hasAccelerations;//加速するか
	public double shotGravityX;//受ける重力値　0.0Dでデフォルト
	public double shotGravityY;
	public double shotGravityZ;
	boolean isGravity;//重力の影響を受けるかどうか
	protected float shotDamage;//弾によるダメージ
	public int color;//弾の色
	public int deadTime;//消滅時間
	public double shotVectorX;//X軸方向の移動ベクトル
	public double shotVectorY;//Y軸方向の移動ベクトル
	public double shotVectorZ;//Z軸方向の移動ベクトル
	public int shotType;//弾独自の動作を表す 0は何もしない
	protected int lastTime;
	
	
	public double lastSpeed;
	public float lastRotationYaw;
	public float lastRotationPitch;
	public boolean stopFlag;
	public double lastShotMotionX;
	public double lastShotMotionY;
	public double lastShotMotionZ;
	
	protected int xTile;
    protected int yTile;
    protected int zTile;
    protected int inTile;
    protected boolean inGround;//地面に触れているかのチェック
    protected int ticksAlive;//
    protected int ticksInAir;//空中にいる時間
	
	public int delayTime;
	
	public float shotAngleX;
	
	protected float damageRate;//特殊な場合にかかるダメージ倍率
	

	public double overVectorX;
	public double overVectorY;
	public double overVectorZ;

	private float rotationYawSpeed;
	
	//private EntityTHShot child;
	
	
	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityTHShot(World world)
    {
        super(world);
        xTile = -1;
        yTile = -1;
        zTile = -1;
        inTile = 0;
        inGround = false;
        ticksInAir = 0;
        setSize(0.1F, 0.1F);
    	setAnimationCount(0);
    	setAngleZ(0F);
    	
    }
    
    

	/*
	*わからんので、翻訳機使用　描画判定のチェックか？
	*エンティティかどうかをチェックするには、遠くに過去を使用し、その平均エッジと比較することで、レンダリングする範囲内にある
	*長さ* 64 * renderDistanceWeightの引数：距離
	*/
	@SideOnly(Side.CLIENT)
	public boolean isInRangeToRenderDist(double par1)
    {
        double d1 = this.boundingBox.getAverageEdgeLength() * 4.0D;
        d1 *= 128.0D;
        return par1 < d1 * d1;
    }
	
	public EntityTHShot(World world, EntityLivingBase entityUser, Entity entity,
			double xPos, double yPos, double zPos,
	    	double xVector, double yVector, double zVector, float angleZ, 
	    	double rotateVectorX, double rotateVectorY, double rotateVectorZ, float rotationYawSpeed,
	    	double firstSpeed, double maxSpeed, double addSpeed,
	    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int dead, int delay, int special)
	    {
	        super(world);
	    	
	    	userEntity = entityUser;//弾の持ち主
	    	shootingEntity = entity;//弾を発射したもの
	    	
	    	//重力ベクトルの設定
	    	isGravity = false;
	    	shotGravityX = xVectorG;
	    	shotGravityY = yVectorG;
	    	shotGravityZ = zVectorG;
	    	
	    	//弾の効果が形状を設定
	    	shotDamage = damage;//当たったときのダメージ
	    	color = c;//弾幕の形状、色
	    	setShotColor(color);//弾の色を設定
			deadTime = dead + delay;//消滅時間
	    	setDeadTime(deadTime);//弾の消滅時間を設定
	    	shotType = special;//特殊動作や特殊効果のタイプ
	    	//大きさを設定
	    	setShotSize(size);
	        setSize(size, size);
	    	
	    	//速さ関係の設定
			shotSpeed = firstSpeed;//弾の初期速度
	    	shotLimitSpeed = maxSpeed;//弾の最大速度、または最低速度
	    	shotAcceleration = addSpeed;//弾の加速度
	    	shotVectorX = xVector;
	    	shotVectorY = yVector;
	    	shotVectorZ = zVector;

	    	lastSpeed = shotSpeed;
	    	
	    	//移動量の設定
	    	motionX = shotVectorX * shotSpeed;//初期移動量はベクトル*初期速度
	    	motionY = shotVectorY * shotSpeed;
	    	motionZ = shotVectorZ * shotSpeed;
	    	lastShotMotionX = motionX;
	    	lastShotMotionY = motionY;
	    	lastShotMotionZ = motionZ;
	    	//角度の設定
	    	rotationYaw = (float)Math.atan2(motionX, motionZ) / 3.141593F * 180F;//移動量から水平方向角度を算出
	    	rotationPitch = (float)Math.atan2( motionY, Math.sqrt(motionX * motionX + motionZ * motionZ)) / 3.141593F * 180F;//移動量から垂直方向角度を算出
	    	setAngleZ(angleZ);
	    	//setAngleZ(0F);
	    	//rotationPitch %= 90F;
	    	shotAngleX = rotationPitch;
	        setRotation(rotationYaw, rotationPitch);
	    	lastRotationYaw = rotationYaw;
	    	lastRotationPitch = rotationPitch;
	    	
	    	setPosition(xPos, yPos, zPos);
	    	
	    	stopFlag = false;
	    	lastTime = 0;
	    	setAnimationCount(-delay);
	    	delayTime = delay;
	    	
	    	setRotationYawSpeed(rotationYawSpeed);
	    	
	    	/*float pitch = thShotLib.getPitchFromVector(motionX, motionY, motionZ);
	    	Vec3 overVec = thShotLib.getVecFromAngle(rotationYaw, pitch + 90F, 1.0D);
	    	setOverVector(-overVec.xCoord, -overVec.yCoord, overVec.zCoord);*/
	    	//setOverVector(0, 1, 0);
	    	//float baseYaw = thShotLib.getYawFromVector(shotVectorX, shotVectorZ);
			//float basePitch = thShotLib.getPitchFromVector(shotVectorX, shotVectorY, shotVectorZ);
			
	    	//Vec3 rotateVec = thShotLib.getVecFromAngle(rotationYaw, rotationPitch + 90F, 1.0F);
			//Vec3 vec = getVectorFromRotation(shotVectorX, shotVectorY, shotVectorZ,rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord,  angleZ);//this.getAngleZ());
			//setOverVector(-vec.xCoord, -vec.yCoord, vec.zCoord);
	    	setOverVector(rotateVectorX, rotateVectorY, rotateVectorZ);
			
			/*shotVectorX = -vec.xCoord;
			shotVectorY = -vec.yCoord;
			shotVectorZ = vec.zCoord;
	    	motionX = shotVectorX * shotSpeed;//初期移動量はベクトル*初期速度
	    	motionY = shotVectorY * shotSpeed;
	    	motionZ = shotVectorZ * shotSpeed;
	    	lastShotMotionX = motionX;
	    	lastShotMotionY = motionY;
	    	lastShotMotionZ = motionZ;
			*/
	    	//child = childShot;
	    	
	    	updateAngle();
	    }
	
	public EntityTHShot(World world, EntityLivingBase entityUser, Entity entity,
		double xPos, double yPos, double zPos,
    	double xVector, double yVector, double zVector, float angleZ, double rotateVectorX, double rotateVectorY, double rotateVectorZ,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int dead, int delay, int special)
    {
        super(world);
    	
    	userEntity = entityUser;//弾の持ち主
    	shootingEntity = entity;//弾を発射したもの
    	
    	//重力ベクトルの設定
    	isGravity = false;
    	shotGravityX = xVectorG;
    	shotGravityY = yVectorG;
    	shotGravityZ = zVectorG;
    	
    	//弾の効果が形状を設定
    	shotDamage = damage;//当たったときのダメージ
    	color = c;//弾幕の形状、色
    	setShotColor(color);//弾の色を設定
		deadTime = dead + delay;//消滅時間
    	setDeadTime(deadTime);//弾の消滅時間を設定
    	shotType = special;//特殊動作や特殊効果のタイプ
    	//大きさを設定
    	setShotSize(size);
        setSize(size, size);
    	
    	//速さ関係の設定
		shotSpeed = firstSpeed;//弾の初期速度
    	shotLimitSpeed = maxSpeed;//弾の最大速度、または最低速度
    	shotAcceleration = addSpeed;//弾の加速度
    	shotVectorX = xVector;
    	shotVectorY = yVector;
    	shotVectorZ = zVector;

    	lastSpeed = shotSpeed;
    	
    	//移動量の設定
    	motionX = shotVectorX * shotSpeed;//初期移動量はベクトル*初期速度
    	motionY = shotVectorY * shotSpeed;
    	motionZ = shotVectorZ * shotSpeed;
    	lastShotMotionX = motionX;
    	lastShotMotionY = motionY;
    	lastShotMotionZ = motionZ;
    	//角度の設定
    	rotationYaw = (float)Math.atan2(motionX, motionZ) / 3.141593F * 180F;//移動量から水平方向角度を算出
    	rotationPitch = (float)Math.atan2( motionY, Math.sqrt(motionX * motionX + motionZ * motionZ)) / 3.141593F * 180F;//移動量から垂直方向角度を算出
    	setAngleZ(angleZ);
    	//setAngleZ(0F);
    	//rotationPitch %= 90F;
    	shotAngleX = rotationPitch;
        setRotation(rotationYaw, rotationPitch);
    	lastRotationYaw = rotationYaw;
    	lastRotationPitch = rotationPitch;
    	
    	setPosition(xPos, yPos, zPos);
    	
    	stopFlag = false;
    	lastTime = 0;
    	setAnimationCount(-delay);
    	delayTime = delay;
    	
    	//setRotationYawSpeed(3F);
    	
    	/*float pitch = thShotLib.getPitchFromVector(motionX, motionY, motionZ);
    	Vec3 overVec = thShotLib.getVecFromAngle(rotationYaw, pitch + 90F, 1.0D);
    	setOverVector(-overVec.xCoord, -overVec.yCoord, overVec.zCoord);*/
    	//setOverVector(0, 1, 0);
    	//float baseYaw = thShotLib.getYawFromVector(shotVectorX, shotVectorZ);
		//float basePitch = thShotLib.getPitchFromVector(shotVectorX, shotVectorY, shotVectorZ);
		
    	//Vec3 rotateVec = thShotLib.getVecFromAngle(rotationYaw, rotationPitch + 90F, 1.0F);
		//Vec3 vec = getVectorFromRotation(shotVectorX, shotVectorY, shotVectorZ,rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord,  angleZ);//this.getAngleZ());
		//setOverVector(-vec.xCoord, -vec.yCoord, vec.zCoord);
    	setOverVector(rotateVectorX, rotateVectorY, rotateVectorZ);
		
		/*shotVectorX = -vec.xCoord;
		shotVectorY = -vec.yCoord;
		shotVectorZ = vec.zCoord;
    	motionX = shotVectorX * shotSpeed;//初期移動量はベクトル*初期速度
    	motionY = shotVectorY * shotSpeed;
    	motionZ = shotVectorZ * shotSpeed;
    	lastShotMotionX = motionX;
    	lastShotMotionY = motionY;
    	lastShotMotionZ = motionZ;
		*/
    	
    	updateAngle();
    }
	
	//通常弾の基本設定
	public EntityTHShot(World world, EntityLivingBase entityUser, Entity entity,
		double xPos, double yPos, double zPos,
    	double xVector, double yVector, double zVector,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int dead)
    {
    	this(world, entityUser, entity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D,
    		firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG, damage, c, size, dead, 0, 0);
    }
	
	public EntityTHShot(World world, EntityLivingBase EntityLivingBase,
    	double xVector, double yVector, double zVector,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	float damage, int color, float size, int dead)
    {
    	this(world, EntityLivingBase, EntityLivingBase, EntityLivingBase.posX, EntityLivingBase.posY, EntityLivingBase.posZ,
    		xVector, yVector, zVector, firstSpeed, maxSpeed, addSpeed, damage, color, size, dead);
    }

	//発射地点が発射元と同じ場合の基本設定
    public EntityTHShot(World world, EntityLivingBase entityUser, Entity entity,
    	double xVector, double yVector, double zVector,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	double xVectorG, double yVectorG, double zVectorG, float damage, int c, float size, int dead)
    {
    	this(world, entityUser, entity, entity.posX, entity.posY, entity.posZ, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D,
    		firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG, damage, c, size, dead, 0 , 0);
    }
	
	//最も一般的なショット　加速なし、機動変化なし
	public EntityTHShot(World world, EntityLivingBase EntityLivingBase, double xVector, double yVector, double zVector,
		double speed, float damage, int c ,float size)
    {
    	this(world, EntityLivingBase, EntityLivingBase, xVector, yVector, zVector,
    		speed, speed, 1.0D, 0.0D, 0.0D, 0.0D, damage, c, size, 120);
    }
	
	//最も一般的なショットに初速度と最高速と加速度があるもの
	public EntityTHShot(World world, EntityLivingBase EntityLivingBase, double xVector, double yVector, double zVector,
		double firstSpeed, double maxSpeed, double addSpeed, float damage, int c, float size)
    {
    	this(world, EntityLivingBase, EntityLivingBase, xVector, yVector, zVector,
    		firstSpeed, maxSpeed, addSpeed, 0.0D, 0.0D, 0.0D, damage, c, size, 120);
    }
	
	//Entity生成時に一度だけ呼ばれる
	protected void entityInit()
	{
		dataWatcher.addObject(16, new Integer(0));
		dataWatcher.addObject(17, new Integer(0));
		dataWatcher.addObject(18, new Integer(0));
		dataWatcher.addObject(19, new Integer(0));
		dataWatcher.addObject(20, new Integer(0));
	}
	
	//移動量から弾の速度を返す
	public double getSpeed()
	{
		return (double)MathHelper.sqrt_double( motionX * motionX + motionY * motionY + motionZ * motionZ);
	}
	
	//最後に時間が動いていた時の弾の速度を返す
	public double getLastSpeed()
	{
		return (double)MathHelper.sqrt_double( lastShotMotionX * lastShotMotionX + lastShotMotionY * lastShotMotionY + lastShotMotionZ * lastShotMotionZ);
	}

	//ベクトルを更新する（角度を変更する処理をしたあとは必ず入れる）
	public void setVector()
	{	
        //角度に合わせてベクトルを更新
        shotVectorX =  Math.sin( rotationYaw / 180F * (float)Math.PI) * Math.cos( rotationPitch / 180F * (float)Math.PI);//X方向　水平方向
        shotVectorY =  Math.sin( rotationPitch / 180F * (float)Math.PI);//Y方向　上下
        shotVectorZ =  Math.cos( rotationYaw / 180F * (float)Math.PI) * Math.cos( rotationPitch / 180F * (float)Math.PI);//Z方向　水平方向
        
        motionX = shotVectorX * getSpeed();
        motionY = shotVectorY * getSpeed();
        motionZ = shotVectorZ * getSpeed();
        
        lastShotMotionX = motionX;
        lastShotMotionY = motionY;
        lastShotMotionZ = motionZ;
	}
	
	//進行方向に対して真上になるベクトルを設定
	public void setOverVector(double vectorX, double vectorY, double vectorZ)
	{
		overVectorX = vectorX;
		overVectorY = vectorY;
		overVectorZ = vectorZ;
	}
	
	//ショットの左右の方向の角度を変更する
	public void setShotRotationYaw(float angle)
	{
		Vec3 vec = getVectorFromRotation(overVectorX, overVectorY, overVectorZ, shotVectorX, shotVectorY, shotVectorZ, angle);
		
		shotVectorX = vec.xCoord;
		shotVectorY = vec.yCoord;
		shotVectorZ = vec.zCoord;
		
		double speed = getSpeed();
		
        motionX = shotVectorX * speed;
        motionY = shotVectorY * speed;
        motionZ = shotVectorZ * speed;
        
        lastShotMotionX = motionX;
        lastShotMotionY = motionY;
        lastShotMotionZ = motionZ;
	}
	
	//任意の回転軸に対して、任意のベクトルがA度回転したベクトルを返す
	public Vec3 getVectorFromRotation(double rotateVecX, double rotateVecY, double rotateVecZ, double vecX, double vecY, double vecZ, float angle)
	{
		double angleRad = (double)angle / 180.0D * (double)Math.PI;
		double sinA = Math.sin(angleRad);
		double cosA = Math.cos(angleRad);
		double returnVectorX = (rotateVecX * rotateVecX * (1 - cosA) + cosA)              * vecX + (rotateVecX * rotateVecY * (1 - cosA) - rotateVecZ * sinA) * vecY + (rotateVecZ * rotateVecX * (1 - cosA) + rotateVecY * sinA) * vecZ;
		double returnVectorY = (rotateVecX * rotateVecY * (1 - cosA) + rotateVecZ * sinA) * vecX + (rotateVecY * rotateVecY * (1 - cosA) + cosA)              * vecY + (rotateVecY * rotateVecZ * (1 - cosA) - rotateVecX * sinA) * vecZ;
		double returnVectorZ = (rotateVecZ * rotateVecX * (1 - cosA) - rotateVecY * sinA) * vecX + (rotateVecY * rotateVecZ * (1 - cosA) + rotateVecX * sinA) * vecY + (rotateVecZ * rotateVecZ * (1 - cosA) + cosA)              * vecZ;
		
		return Vec3.createVectorHelper(returnVectorX, returnVectorY, returnVectorZ);
		
		/*float baseYaw = thShotLib.getYawFromVector(rotateVecX, rotateVecZ);
		float basePitch = thShotLib.getPitchFromVector(rotateVecX, rotateVecY, rotateVecZ);
		thShotLib.getVecFromAngle(baseYaw, basePitch + 90F, 1.0F);*/
		
	}
	
	//角度の更新処理
	public void updateAngle()
	{
		
    	float f = MathHelper.sqrt_double(motionX * motionX + motionZ * motionZ);
    	if(!worldObj.isRemote)
    	{
    		rotationYaw = (float)((Math.atan2(motionX, motionZ) * 180D) / 3.1415927410125732D);
    	//}
        for (rotationPitch = (float)((Math.atan2(motionY, f) * 180D) / 3.1415927410125732D); rotationPitch - prevRotationPitch < -180F; prevRotationPitch -= 360F) { }
        //if(!worldObj.isRemote)
        {
        	for (rotationPitch = (float)((Math.atan2(motionY, f) * 180D) / 3.1415927410125732D); rotationPitch - prevRotationPitch < -180F; prevRotationPitch -= 360F) { }
        }
        if(rotationYaw - prevRotationYaw > 180F)
        {
        }
        /*if(rotationYaw >= 180F)
        {
        	rotationYaw = 360F - rotationYaw; 
        }
        else if(rotationYaw < -180F)
        {
        	rotationYaw = -360F + rotationYaw;
        }*/
        
    	
        for (; rotationPitch - prevRotationPitch >= 180F; prevRotationPitch += 360F) { }
        for (; rotationYaw - prevRotationYaw < -180F; prevRotationYaw -= 360F) { }
        for (; rotationYaw - prevRotationYaw >= 180F; prevRotationYaw += 360F) { }
        rotationPitch = prevRotationPitch + (rotationPitch - prevRotationPitch) * 1.0F;
        
        /*rotationYaw = rotationYaw % 180;
        rotationPitch = rotationPitch % 180;
        
        if(worldObj.isRemote)
        {
        	setAngles(rotationYaw, rotationPitch);
        }*/
        //setRotation(rotationYaw, rotationPitch);
    	}
        
	}
	
	//弾消しボーナス
	public void shotFinishBonus()
	{
		EntityItem entityItem = new EntityItem(worldObj, posX, posY, posZ, new ItemStack(mod_thKaguya.shotMaterialItem, 1));
		entityItem.age = 5700;//アイテムがすぐ消滅するよう設定（１5秒で消える）
		if(!worldObj.isRemote)
		{
			worldObj.spawnEntityInWorld(entityItem);
			setDead();
		}
	}
	
	//水平方向に変化する回転速度を設定する（毎tick変化する角度）
	public void setRotationYawSpeed(float rotation)
	{
		rotationYawSpeed = rotation;
	}
	
	//水平方向に変化する回転速度を返す
	public float getRotationYawSpeed()
	{
		return rotationYawSpeed;
	}
	
	//ショットが存在する限り呼び出されるメソッド
	@Override
    public void onUpdate()
    {	
    	//弾の主がいないか、死んでいる場合消える
    	if (!worldObj.isRemote && userEntity == null)
        {
            setDead();
        	return;
        }
    	else
    	{
    		//super.onUpdate();
    	}
    	
    	if(this instanceof EntityTHSetLaser && shootingEntity == null)
    	{
    		if(!worldObj.isRemote)
    		{
    			setDead();
    			return;
    		}
    	}
    	
    	//Entityの基本的な処理で必要なもの
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.prevRotationPitch = this.rotationPitch;
        this.prevRotationYaw = this.rotationYaw;
    	
    	//ダメージがない弾なら消滅させる
    	if(shotDamage <= 0.0F)
    	{
    		if(!worldObj.isRemote)
    		{
    			setDead();
    			return;
    		}
    	}
	
    	//使用者が死んでいるなら弾をアイテム化させ、消滅させる
    	if(userEntity != null)
    	{
			if(!worldObj.isRemote && (userEntity.isDead))
			{
				if(userEntity instanceof EntityPlayer == false)//仕様者がEntityPlayerに属していないなら弾消しボーナスを出す
				{
					shotFinishBonus();
					return;
				}
			}
    	}

    	//消滅時間を過ぎたら消滅
    	if(!worldObj.isRemote && getAnimationCount() > getDeadTime())
    	{
    		/*if(!worldObj.isRemote && child != null)
    		{
    			worldObj.spawnEntityInWorld(child);
    		}*/
    		setDead();
    	}
    	
    	extinguish();//火はつかないようにする
    	
    	//時間が進んでいないなら
    	if(ticksExisted <= lastTime)
    	{
    		//衝突処理
        	//hitCheck();
    		return;//処理を終了させる
    		
    	}
    	else//時間が通常通り進んでいるなら
    	{
    		//何事もなかったように移動量を設定する
    		motionX = lastShotMotionX;
    		motionY = lastShotMotionY;
    		motionZ = lastShotMotionZ;
    		if(!worldObj.isRemote)
    		{
    			if(getAnimationCount() >= 0)
    			{
    				setAnimationCount(lastTime);
    			}
    			else
    			{
    				setAnimationCount(getAnimationCount() + 1);
    				return;
    			}
    		}
    		
    	}
    	
		
    	if(getRotationYawSpeed() != 0F)
    	{
    		setShotRotationYaw(getRotationYawSpeed());
    	}
    	
    	/*rotationYaw += 2F;
    	rotationPitch += 4;
    	setVector();*/
    	
    	/*if(rotationPitch > 180F || rotationPitch < -180F)
    	{
    		rotationPitch = -rotationPitch;
    		//rotationYaw += 180F;
    	}*/
    	updateAngle();//角度を更新する
    	
    	//加速減速の処理
    	//加速弾で速度が限界値より遅いなら
    	if( shotAcceleration > 0.0D && getSpeed() < shotLimitSpeed)
    	{
    		motionX += shotVectorX * shotAcceleration;
    		motionY += shotVectorY * shotAcceleration;
    		motionZ += shotVectorZ * shotAcceleration;
    		
    		//移動量に加速分加える
    		if( shotAcceleration > 0.0D && getSpeed() > shotLimitSpeed )//上限下限速を越していたら上限か下限にする
    		{
    			motionX = shotVectorX * shotLimitSpeed;
    			motionY = shotVectorY * shotLimitSpeed;
    			motionZ = shotVectorZ * shotLimitSpeed;
    		}
    	}
    	//減速弾で速度が限界値より速いなら
    	else if(shotAcceleration < 0.0D && getSpeed() > shotLimitSpeed)
    	{	
    		//減速値が現在の速度から最低速を引いた値より大きいなら（今の速度に対して過剰な減速値なら）
    		if(Math.abs(shotAcceleration) > getSpeed() - shotLimitSpeed)
    		{
    			motionX = shotVectorX * shotLimitSpeed;
        		motionY = shotVectorY * shotLimitSpeed;
        		motionZ = shotVectorZ * shotLimitSpeed;
    		}
    		else
    		{
    			motionX += shotVectorX * shotAcceleration;
        		motionY += shotVectorY * shotAcceleration;
        		motionZ += shotVectorZ * shotAcceleration;
    		}
    	}
    	
    	//弾ごとの特殊な動作を発生させる
    	specialMotion();
    	setGravityLevel();
    	//衝突処理
    	hitCheck();
        
        shotSpeed = getSpeed();
        
        
    	
    	//最終的な移動量を現在地に加える
    	if(!worldObj.isRemote && getAnimationCount() >= 0)
    	{
    		this.posX += this.motionX;
    		this.posY += this.motionY;
    		this.posZ += this.motionZ;
    	}
    	
        setPosition(this.posX, this.posY, this.posZ);//位置の更新を行う
    	
    	//通常通り時間が進んでいるなら
    	if(ticksExisted > lastTime)
    	{
    		//最後に時間が動いていたときの時間と移動量を保存する
    		lastTime = ticksExisted;
    		lastShotMotionX = motionX;
    		lastShotMotionY = motionY;
    		lastShotMotionZ = motionZ;
    		lastRotationYaw = (float)Math.atan2(lastShotMotionX, lastShotMotionZ) / 3.141593F * 180F;
    		lastRotationPitch = (float)Math.atan2(lastShotMotionY, Math.sqrt( lastShotMotionX * lastShotMotionX + lastShotMotionZ * lastShotMotionZ)) / 3.141593F * 180F;
    	}
    }
	
	public boolean userHitCheck(Entity entity)
	{
		if(this.shotType == thShotLib.SPOILER02 || shotType == thShotLib.SPOILER01)
		{
			return true;
			
		}
		return !entity.isEntityEqual(userEntity);
	}
	
	//Entityとの当たり判定をとる
	public MovingObjectPosition hitEntityCheck(MovingObjectPosition movingObjectPosition, Vec3 vec3d, Vec3 vec3d1)
	{
        Entity entity = null;//実際に当たったことにするEntity
    	double d = 0.0D;//そのEntityまでの仮の距離
		float hitSize = getShotSize() * 0.5F;
    	//ここから移動量分の線分を作り、それに弾の大きさの２倍の肉付けをし直方体を作る。それに当たったEntityをリスト化する\\
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(this.shotVectorX, this.shotVectorY, this.shotVectorZ).expand(hitSize, hitSize, hitSize));//指定範囲内のEntityをリストに登録
		
    	for (int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);//entity1にリストの先端のentityを保存
        	//entity1が、当たり判定を取らない　または　entity1が使用者　または　飛んで25カウント以下？　または　EntityTHShotならパス
            if ( entity1.canBeCollidedWith() && 
            	userHitCheck(entity1) && 
            	/*!entity1.isEntityEqual(shootingEntity) &&*/
            	!hitCheckEx(entity1) && 
            	entity1 instanceof EntityAnimal == false &&
            	entity1 instanceof EntityVillager == false &&
            	(entity1 instanceof EntityLivingBase || entity1 instanceof EntityDragonPart || entity1 instanceof EntityTHShot) &&
            	!(userEntity instanceof EntityTHFairy && entity1 instanceof EntityTHFairy))
        	{
            	if(entity1 instanceof EntityTHShot)
            	{
            		EntityTHShot shot = (EntityTHShot)entity1;
            		if(userEntity != shot.userEntity)
            		{
    	        		//判定を弾の大きさに変更
    	            	AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(hitSize, hitSize, hitSize);
    	            	MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);
    	        		//この判定で当たっているなら
    	            	if (movingObjectPosition1 != null)
    	            	{
    	        			//当たっているならここからその点までの距離を取得
    	            		double d1 = vec3d.distanceTo(movingObjectPosition1.hitVec);
    	        			//今までの一番近くにいるなら、一番近いEntityを更新する
    	            		if (d1 < d || d == 0.0D)
    	            		{
    	                		entity = entity1;
    	                		d = d1;
    	            		}
    	        		}
            		}
            	}
            	else
            	{
	        		//判定を弾の大きさに変更
	            	AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(hitSize, hitSize, hitSize);
	            	MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);
	        		//この判定で当たっているなら
	            	if (movingObjectPosition1 != null)
	            	{
	        			//当たっているならここからその点までの距離を取得
	            		double d1 = vec3d.distanceTo(movingObjectPosition1.hitVec);
	        			//今までの一番近くにいるなら、一番近いEntityを更新する
	            		if (d1 < d || d == 0.0D)
	            		{
	                		entity = entity1;
	                		d = d1;
	            		}
	        		}
            	}
        	}
        }

    	//当たったEntityがいるなら、当たったEntityをMovingObjectPositionで登録
        if (entity != null)
        {
            movingObjectPosition = new MovingObjectPosition(entity);
        }
		
		/*if (movingObjectPosition != null && movingObjectPosition.entityHit != null && movingObjectPosition.entityHit instanceof EntityPlayer)
        {
        	EntityPlayer entityPlayer = (EntityPlayer)movingObjectPosition.entityHit;

            if (entityPlayer.capabilities.disableDamage || shootingEntity instanceof EntityPlayer && !((EntityPlayer)shootingEntity).func_96122_a(entityPlayer))
            {
            	movingObjectPosition = null;
            }
        }*/
		
        return movingObjectPosition;
	}
	
	//使用者に当たっているかを判定する
	public boolean hitUserCheck(MovingObjectPosition movingObjectPosition, Vec3 vec3d, Vec3 vec3d1)
	{
		float hitSize = getShotSize() * 0.5F;
    	//ここから移動量分の線分を作り、それに弾の大きさの２倍の肉付けをし直方体を作る。それに当たったEntityをリスト化する\\
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(motionX, motionY, motionZ).expand(hitSize, hitSize, hitSize));//指定範囲内のEntityをリストに登録
		
    	for (int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);//entity1にリストの先端のentityを保存
        	//entity1が、当たり判定を取らない　または　entity1が使用者　または　飛んで25カウント以下？　または　EntityTHShotならパス
            if ( entity1.equals(userEntity)  )
        	{
    	        //判定を弾の大きさに変更
    	        AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(hitSize, hitSize, hitSize);
    	        MovingObjectPosition movingObjectPosition1 = axisalignedbb.calculateIntercept(vec3d, vec3d1);
    	        //この判定で当たっているなら
    	        if (movingObjectPosition1 != null)
    	        {
    	        	return true;
    	        }
        	}
        }
		
        return false;
	}
	
	//衝突処理
	public void hitCheck()
	{
		double shotSizeX = shotVectorX * this.getShotSize();
		double shotSizeY = shotVectorY * this.getShotSize();
		double shotSizeZ = shotVectorZ * this.getShotSize();
	    //始点（現在地）
    	Vec3 vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX - shotSizeX, posY - shotSizeY, posZ - shotSizeZ);
    	//終点（現在地に移動量を足した点）
    	Vec3 vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX + shotSizeX, posY + motionY + shotSizeY, posZ + motionZ + shotSizeZ);
        //始点と終点からブロックとの当たりを取得
    	MovingObjectPosition movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
    	vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX - shotSizeX, posY - shotSizeY, posZ - shotSizeZ);
    	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX + shotSizeX, posY + motionY + shotSizeY, posZ + motionZ + shotSizeZ);
    	//何らかのブロックに当たっているなら
        if (movingObjectPosition != null)
        {
        	//終点を当たった点に変更
        	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord);
        }
        
        movingObjectPosition = hitEntityCheck(movingObjectPosition, vec3d, vec3d1);
        
        if (movingObjectPosition != null)
        {
        	//当たった場合の処理をする
            onImpact(movingObjectPosition);
        }

	}
	
	//独自の動きを追加するためのもの
	public void specialMotion()
	{
		switch(shotType)
		{
			case thShotLib.FALL01:
				motionY -= 0.02;
				break;
			case thShotLib.BRAKE01:
				if(ticksExisted == this.getDeadTime() )
				{
					rotationYaw = -rotationYaw + rand.nextFloat() * 14F - 7F;
					rotationPitch = -rotationPitch + rand.nextFloat() * 14F - 7F;
					Vec3 vec = thShotLib.getVecFromAngle(rotationYaw, rotationPitch, 1.0F);
					double gravity = rand.nextDouble() * 0.1D + 0.02D;
					//thShotLib.createCircleShotBaseB(userEntity, this, posX, posY, posZ, rotationYaw, rotationPitch, 0.5D, 0.2D, 0.8D, 0.0D, 0.0D, 0.0D, 6.0F, thShotLib.SMALL[thShotLib.RED], 0.3F, 90, 3, 0, 8, 0.1D);
					thShotLib.createShot(userEntity, this, posX, posY, posZ, rotationYaw, rotationPitch, 0F, 0.0D, 1.0D, 0.0D, -0.3D, 0.7D, rand.nextDouble() * 0.03D, shotGravityX * gravity, shotGravityY * gravity, shotGravityZ * gravity, shotDamage, this.getShotColor(), this.getShotSize(), 90, 10, 0);
					//thShotLib.createShotBaseB(userEntity, this, this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch,
						//	0.01D, 4.0D, 0.01D, 0.0D, 0.0D, 0.0D,/*this.shotGravityY * 0.01D, this.shotGravityZ * 0.01D,*/ this.shotDamage, thShotLib.SMALL[thShotLib.RED]/*this.getShotColor()*/, this.shotSize, 120, 0, 0);
					
				}
				break;
			case thShotLib.KAPPA01:
				if(ticksExisted % 4 == 3)
				{
					thShotLib.createShot(userEntity, userEntity, posX, posY, posZ, userEntity.rotationYaw + rand.nextFloat() * 30F - 15F, -15F, 0F, 0.0D, 1.0D, 0.0D, 0.7D, 0.7D, 0.0D, 0.0D, -0.03D, 0.0D,
											5.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.3F, 100, 0, thShotLib.BOUND01);
				}
				break;
			case thShotLib.FREEZE01:
				if(ticksExisted >= 20)
				{
					shotSpeed = 0.01D;
					shotLimitSpeed = 0.3D;
					//shotAddSpeed = 0.2D;
					shotAcceleration = 0.03D;
					hasAccelerations = true;
					setVector();
				}
				break;
			/*case thShotLib.FLOWER01:
				if(rotationPitch > -90F)
				{
					rotationPitch -= 3;
				}
				break;*/
			case thShotLib.KISHITU01://気質弾
				if(ticksExisted < 20)
				{
					setShotSize(getShotSize() + 0.1F);
				}
				break;
			case thShotLib.STARDUST01:
				setShotRotationYaw(2.0F);
				Vec3 vec = thShotLib.getVectorFromRotation(overVectorX, overVectorY, overVectorZ, shotVectorX, shotVectorY, shotVectorZ, ticksExisted * 13F);
				thShotLib.createShot(userEntity, this, posX, posY, posZ,vec.xCoord, vec.yCoord, vec.zCoord, this.getAngleZ(), overVectorX, overVectorY, overVectorZ, 0.1D, 0.3D, 0.03D, 0.0D, 0.0D, 0.0D, 5, color, 0.3F, 50, 10, 0);
				break;
			case thShotLib.KOKUSHI01://二重黒死蝶の蝶弾
				if(ticksExisted < 25)
				{
					motionX *= 0.90D;
					motionY *= 0.90D;
					motionZ *= 0.90D;
				}
				else if(ticksExisted == 25)
				{
					shotLimitSpeed = 2.0D;
					shotAcceleration = 0.03D;
				}
				else if(ticksExisted < 50)
				{
					if(color % 2 == 0)
					{
						setShotRotationYaw(10F);
					}
					else
					{
						setShotRotationYaw(-10F);
					}
			
				}

				break;
			case thShotLib.SILVERKNIFE:
				if(this.ticksExisted == 30)
				{
					//this.shotGravityY = -0.003D;
					this.motionX *= 100D;
					this.motionY *= 100D;
					this.motionZ *= 100D;
					this.shotAcceleration = 1.2D;
					this.shotType = 0;
				}
				else if(ticksExisted == 35D)
				{
					//shotGravityY = -0.03D;
				}
				/*if(getAnimationCount() >= 30)
				{
					motionY -= 0.008 * (getAnimationCount() - 30);
				}*/
				/*if(ticksExisted == 30)
				{
					shotSpeed = 0.3D;
					motionX *= 1000D;
					motionY *= 1000D;
					motionZ *= 1000D;
					setVector();
				}*/
				break;
			case thShotLib.MIRACLE:
				if(ticksExisted == getDeadTime())
				{
					float angle = rand.nextFloat() * 360F;
					Vec3 look;
					for(int j = 0; j < 8; j++)
					{
						look = thShotLib.getVectorFromRotation(overVectorX, overVectorY, overVectorZ, shotVectorX, shotVectorY, shotVectorZ, angle);
						for(int i = 0; i < 6; i++)
						{
							thShotLib.createShot(userEntity, this, posX, posY, posZ, look.xCoord, look.yCoord, look.zCoord, 0.0F, this.overVectorX, overVectorY, overVectorZ, 0.0F, 0.5D, 0.2D, 0.8D, 0.0D, 0.0D, 0.0D, 6.0F, thShotLib.SMALL[thShotLib.RED], 0.3F, 90, 3 + i * 2, 0);

						}
						angle += 45F;
					}
					
				}
				break;
			case thShotLib.FAFRO:
				if(ticksExisted == getDeadTime())
				{
					int pattern = (int)shotLimitSpeed;
					
					Calendar calendar = this.worldObj.getCurrentDate();
					
					if(calendar.get(calendar.MONTH) + 1 == 12 && calendar.get(calendar.DATE) == 25)
					{
						EntityDanmakuCreeper entityCreeper = new EntityDanmakuCreeper(worldObj);
						entityCreeper.setLocationAndAngles(posX, posY, posZ, rotationYaw, rotationPitch);
						if(!worldObj.isRemote)
						{
							
							worldObj.spawnEntityInWorld(entityCreeper);
							setDead();
						}
						return;
					}
					
					if(calendar.get(calendar.MONTH) + 1 == 1 && (calendar.get(calendar.DATE) >= 1 && calendar.get(calendar.DATE) <= 3))
					{
						if(!worldObj.isRemote)
						{
							EntityNuclearShot nuclearShot = new EntityNuclearShot(worldObj, userEntity, userEntity, posX, posY, posZ, 0.0F, 0.0F, 0.0F,
									0.0D, 0.8D, 0.00D, 0.0D, -0.03D, 0.0D, 10.0F, rand.nextInt(7), 1.6F, 70, 0, 0);
							if(!worldObj.isRemote)
							{
								worldObj.spawnEntityInWorld(nuclearShot);//核弾を出現させる
							}
							nuclearShot.shootingFlag = true;
							setDead();
						}
						return;
					}

					if(pattern <= 70)
					{
						for(int i = 0; i < 8; i++)
						{
							thShotLib.createShot(userEntity, this, posX, posY, posZ, rand.nextFloat() * 360F, rand.nextFloat() * 180 - 90F, 0F, 0.0D, 1.0D, 0.0D, 0.6D, 0.6D, 0.0D, 0.0D, -0.03D, 0.0D, 10.0F, thShotLib.KNIFE[rand.nextInt(8)], 0.3F, 120, 3, 0);
						}
						if(!worldObj.isRemote)
						{
							setDead();
						}
					}
					else if(pattern <= 80)
					{
						if(!worldObj.isRemote)
						{
							worldObj.spawnEntityInWorld(new EntityItem(worldObj, posX, posY, posZ, new ItemStack(Item.fishRaw)));
							setDead();
						}
					}
					else if(pattern <= 90)
					{
						EntityCreeper entityCreeper = new EntityCreeper(worldObj);
						entityCreeper.setLocationAndAngles(posX, posY, posZ, rotationYaw, rotationPitch);
						if(!worldObj.isRemote)
						{
							
							worldObj.spawnEntityInWorld(entityCreeper);
							setDead();
						}
					}
					else
					{
						EntityChicken entitychicken = new EntityChicken(worldObj);
						entitychicken.setLocationAndAngles(posX, posY, posZ, rotationYaw, rotationPitch);
						if(!worldObj.isRemote)
						{
							
							worldObj.spawnEntityInWorld(entitychicken);
							setDead();
						}
					}
				}
				break;
			case thShotLib.SPOILER01:
				if(ticksExisted >= 20)
				{
					if(userEntity != null)
					{
						shotLimitSpeed = 1.0D;
						shotAcceleration = 0.05D;
					
						double lengthToUserX = userEntity.posX - posX;
						double lengthToUserZ = userEntity.posZ - posZ;
						rotationYaw = (float)Math.atan2(lengthToUserX, lengthToUserZ) / 3.141593F * 180F;
						rotationPitch = (float)Math.atan2(userEntity.posY + 1.0D - posY, Math.sqrt(lengthToUserX * lengthToUserX + lengthToUserZ * lengthToUserZ)) / 3.141593F * 180F;
						
						setVector();
						
						if(this.getDistanceToEntity(userEntity) < 1.5F)
						{
							if(!worldObj.isRemote)
							{
								setDead();
							}
						}
					}
				}
				break;
			case thShotLib.SPOILER02:
				if(ticksExisted >= 20)
				{
					if(userEntity != null)
					{
						shotLimitSpeed = 1.0D;
						shotAcceleration = 0.05D;
					
						double lengthToUserX = userEntity.posX - posX;
						double lengthToUserZ = userEntity.posZ - posZ;
						rotationYaw = (float)Math.atan2(lengthToUserX, lengthToUserZ) / 3.141593F * 180F;
						rotationPitch = (float)Math.atan2(userEntity.posY + 1.0D - posY, Math.sqrt(lengthToUserX * lengthToUserX + lengthToUserZ * lengthToUserZ)) / 3.141593F * 180F;
						
						setVector();
					}
				}
				break;
			case thShotLib.ICECLEFALL01:
				if(ticksExisted == getDeadTime())
				{
					//rotationPitch = -90F;
					setShotRotationYaw(90F);
					//rotationYaw += 90F;
					setDeadTime(120);
					this.shotGravityY = -0.03D;
					this.shotAcceleration = 0.01D;
					this.shotLimitSpeed = 10.0D;
					//setVector();
				}
				break;
			case thShotLib.ICECLEFALL02:
				if(ticksExisted == getDeadTime())
				{
					//rotationPitch = -90F;
					setShotRotationYaw(-90F);
					//rotationYaw -= 90F;
					setDeadTime(120);
					this.shotGravityY = -0.03D;
					this.shotAcceleration = 0.01D;
					this.shotLimitSpeed = 10.0D;
					//setVector();
				}
				break;
			case thShotLib.MISHAGUZI:
				if(ticksExisted == 2)
				{
					this.setRotationYawSpeed(0F);
				}
				break;
			case thShotLib.REDMAGIC1:
				if(ticksExisted % 3 == 0)
				{
				Vec3 rotate = thShotLib.getVectorFromRotation(overVectorX, overVectorY, overVectorZ, shotVectorX, shotVectorY, shotVectorZ, 90F + ticksExisted * 3F);

				thShotLib.createShot(userEntity, this, posX, posY, posZ,rotate.xCoord, rotate.yCoord, rotate.zCoord, this.getAngleZ(), overVectorX, overVectorY, overVectorZ, 0.001D, 0.0D, 0.02D, 0.0D, 0.0D, 0.0D, 9.0F, thShotLib.LIGHT[thShotLib.RED], thShotLib.SIZE[thShotLib.LIGHT[0] / 8], 30 - ticksExisted + 120, 20,thShotLib.REDMAGIC3);
				}
				if(ticksExisted == 20)
				{
					this.setRotationYawSpeed(0F);
				}
				break;
			case thShotLib.REDMAGIC2:
				if(ticksExisted % 3 == 0)
				{
				Vec3 rotate2 = thShotLib.getVectorFromRotation(overVectorX, overVectorY, overVectorZ, shotVectorX, shotVectorY, shotVectorZ, 90F + ticksExisted * 3F);

				thShotLib.createShot(userEntity, this, posX, posY, posZ,rotate2.xCoord, rotate2.yCoord, rotate2.zCoord, this.getAngleZ(), overVectorX, overVectorY, overVectorZ, 0.001D, 0.0D, 0.02D, 0.0D, 0.0D, 0.0D, 9.0F, thShotLib.LIGHT[thShotLib.RED], thShotLib.SIZE[thShotLib.LIGHT[0] / 8], 30 - ticksExisted + 120, 20, thShotLib.REDMAGIC3);
				}
				if(ticksExisted == 20)
				{
					this.setRotationYawSpeed(0F);
				}
				break;
			case thShotLib.REDMAGIC3:
				if(ticksExisted == 30)
				{
					//thShotLib.createShot(userEntity, this, posX, posY, posZ,this.shotVectorX, shotVectorY, shotVectorZ, this.getAngleZ(), overVectorX, overVectorY, overVectorZ, 0.001D, 0.2D, 0.005D, 0.0D, 0.0D, 0.0D, 5, this.color, this.shotSize, 80, 0, 0);
					/*if(!worldObj.isRemote)
					{
						setDead();
					}*/
					this.shotSpeed = 0.1D;
					this.shotLimitSpeed = 0.3D;
				}
				break;
			default:
				break;
		}
	}
	
	protected boolean isUserHit()
	{
		return false;
	}

	//ブロックやEntityに当たった時の処理
    protected void onImpact(MovingObjectPosition movingObjectPosition)
    {
    	//当たった時の処理
    	if (!worldObj.isRemote)
    	{
    		Entity hitEntity = movingObjectPosition.entityHit;
        
    		//当たったEntityがいるなら
    		if ( hitEntity != null )
        	{
        		//それがEntityTHShotに属していないなら
        		if(hitEntity instanceof EntityTHShot == false)
        		{
        			boolean isHitDelete = true;
        			damageRate = 1.0F;
        			//Entityに当たった時の特殊な処理
        			isHitDelete = entityHitSpecialProcess(hitEntity);
        			//指定したダメージ分の魔法ダメージを与える
        			if(isUserHit() || !hitEntity.isEntityEqual(userEntity))
        			{
        				if (!hitEntity.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), getShotDamageWithDifficulty() * damageRate));
        			}
        			//弾を消滅させる
					if(isHitDelete)
					{
						if(!worldObj.isRemote)
						{
							setDead();
						}
					}
        		}
        		//EntityTHShotに属しているなら
        		else
        		{
        			EntityTHShot entityTHShot = (EntityTHShot)hitEntity;

        			if(userEntity != entityTHShot.userEntity)//使用者の違う弾同士は打ち消し合う
        			{
        				//弾同士の相殺
        				//お互い弾のダメージ分だけ小さくする
        				float shotDamageA = this.shotDamage;
        				this.shotDamage -= entityTHShot.shotDamage;
        				entityTHShot.shotDamage -= shotDamageA;
        				if(this.shotDamage < 0.0F)
        				{
        					shotDamage = 0.0F;
        				}
        				if(entityTHShot.shotDamage < 0.0F)
        				{
        					entityTHShot.shotDamage = 0.0F;
        				}
        			}
        		}
			}
    		else
    		{
    			if(blockHitSpecialProcess(movingObjectPosition))
    			{
        			this.setDead();//ブロックに当たったら消滅
    			}
    		}
    	}
    }
    
    /* 難易度の違いによる弾のダメージを返す
     * プレイヤーの出した弾の威力は難易度の影響を受けない
     * ノーマルを通常ダメージとし、イージーで０．７倍、ハードで１．５倍になる
     */
    protected float getShotDamageWithDifficulty()
    {
    	if(this.userEntity instanceof EntityPlayer)
    	{
    		return shotDamage;
    	}
    	
    	if(mod_thKaguya.danmakuOneKillMode)
    	{
    		return 999999F;
    	}
    	
    	switch(this.worldObj.difficultySetting)
    	{
    		case 0:
    			return shotDamage * 0.7F;
    		case 1:
    			return shotDamage * 0.7F;
    		case 2:
    			return shotDamage;
    		case 3:
    			return shotDamage * 1.5F;
    		default:
    			return shotDamage;
    	}
    }
	
    //Entityと衝突したときの特殊な処理
	public boolean entityHitSpecialProcess(Entity hitEntity)
	{
		switch(this.shotType)
		{
			case thShotLib.FIRE:
				hitEntity.setFire((int)shotDamage);
				return true;
			case thShotLib.WIND01:
				hitEntity.motionX += motionX * 3.0D;
				hitEntity.motionY += motionY * 3.0D + 2.0D;
				hitEntity.motionZ += motionZ * 3.0D;
				if(!hitEntity.onGround)
				{
					damageRate *= 2.0F;
				}
				return true;
			case thShotLib.AJA01:
				//指定したダメージ分の魔法ダメージを与える
        		if(hitEntity instanceof EntityLivingBase)
        		{
        			EntityLivingBase EntityLivingBase = (EntityLivingBase)hitEntity;
        			if(EntityLivingBase.getCreatureAttribute() == EnumCreatureAttribute.UNDEAD)//アンデッドなら
        			{
        				//通常の2倍のダメージを与える
        				//EntityLivingBase.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), shotDamage * 2);
        				EntityLivingBase.setFire((int)shotDamage);
        				damageRate *= 2.0F;
        				worldObj.playSoundEffect(posX, posY, posZ, "random.fizz", 0.5F, 2.6F + (worldObj.rand.nextFloat() - worldObj.rand.nextFloat()) * 0.8F);
        				for (int l = 0; l < 8; l++)
                    	{
                       		worldObj.spawnParticle("largesmoke", posX + Math.random(), posY + Math.random(), posZ + Math.random(), 0.0D, 0.0D, 0.0D);
                    	}
        			}
        			/*else
        			{
        				EntityLivingBase.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, userEntity), shotDamage);
        			}*/
        		}
				return true;
			case thShotLib.STARDUST01:
				return false;
			case thShotLib.MIRACLE:
				if(hitEntity instanceof EntityLivingBase)
				{
					EntityLivingBase living = (EntityLivingBase)hitEntity;
					living.clearActivePotions();
				}
				return true;
			case thShotLib.SPOILER01:
				if(hitEntity instanceof EntityLivingBase)
				{
					EntityLivingBase living = (EntityLivingBase)hitEntity;
					if(!living.isEntityEqual(userEntity))
					{
						living.addPotionEffect(new PotionEffect(20, 20 * 20, 1));//ウィザー
						living.addPotionEffect(new PotionEffect(18, 20 * 20, 1));//攻撃低下
						shotType = thShotLib.SPOILER02;
					}
					else
					{

						return true;
					}
				}
				return false;
			case thShotLib.SPOILER02:
				if(userEntity != null && hitEntity.isEntityEqual(userEntity))
				{
					EntityLivingBase living = (EntityLivingBase)hitEntity;
					living.addPotionEffect(new PotionEffect(10, 20 * 20, 1));//回復
					living.addPotionEffect(new PotionEffect(5, 20 * 20, 1));//攻撃上昇
					return true;
				}
				else
				{
					return false;
				}
			default:
				return true;
		}
	}
	
	/* ブロックとの衝突時の特別な処理 shotTypeで処理は決めている
	 * 返り値：弾が消滅するならtrue、消滅しないならfalse
	 */
	
	public boolean blockHitSpecialProcess(MovingObjectPosition movingObjectPosition)
	{
		switch(this.shotType)
		{
			case thShotLib.BOUND01:
				bound(movingObjectPosition, 0.9D, 2);
				shotType = 0;
				return false;
			case thShotLib.BOUND02:
				bound(movingObjectPosition, 0.9D, 3);
				shotType = thShotLib.BOUND01;
				return false;
			case thShotLib.BOUND03:
				bound(movingObjectPosition, 0.9D, 4);
				shotType = thShotLib.BOUND02;
				return false;
			case thShotLib.BOUND04:
				bound(movingObjectPosition, 0.9D, 9999);
				//shotType = thShotLib.BOUND03;
				return false;
			case thShotLib.KAPPA01:
				bound(movingObjectPosition, 0.9D, 4);
				return false;
			case thShotLib.KISHITU01:
				kishitudan();
				return true;
			case thShotLib.FLOWER01:
				flowerWorld();
				return true;
			default:
				return true;
			
		}
	}
	
	//モーゼの奇跡の海を割る弾
	private void umiware()
	{
    	int pi;
    	int px  = (int)posX;
    	int pyd = (int)posY;
    	int pyu = pyd;
    	int pz  = (int)posZ;
    	double pxr = posX;
    	double pxl = posX;
    	double pzr = posZ;
    	double pzl = posZ;
    	double movingLengthX;
    	double movingLengthZ;
    	Material mate = null;
    	movingLengthX = -Math.sin( (rotationYaw+90F) / 180F * 3.141593F)*0.5D;
    	movingLengthZ =  Math.cos( (rotationYaw+90F) / 180F * 3.141593F)*0.5D;
    	while( ( worldObj.getBlockMaterial(px, pyd, pz) == Material.water || worldObj.isAirBlock(px, pyd, pz) ) && pyd > 0)
    	{
    		//worldObj.setBlockAndMetadataWithNotify(px, pyd, pz, 0, 0, 0);//空気を設置
    		if(worldObj.isRemote)
    		{
    			worldObj.setBlock(px, pyd, pz, 0, 0, 0);//空気を設置
    		}

    		pxr = posX;
    		pxl = posX;
    		pzr = posZ;
    		pzl = posZ;
    		pi = 0;
    		do
    		{
    			pxr += movingLengthX;
    			pzr -= movingLengthZ;
    			if( (mate = worldObj.getBlockMaterial((int)pxr, pyd, (int)pzr)) == Material.water)
    			{
    				//worldObj.setBlockAndMetadataWithNotify((int)pxr, pyd, (int)pzr, 0, 0, 0);
    				worldObj.setBlock((int)pxr, pyd, (int)pzr, 0, 0, 0);
    			}
    			pi++;
    		}while(pi <= 12 && (mate == Material.water  || worldObj.isAirBlock((int)pxr, pyd, (int)pzr)));
    		pi = 0;
    		do
    		{
    			pxl -= movingLengthX;
    			pzl += movingLengthZ;
    			if( (mate = worldObj.getBlockMaterial((int)pxl, pyd, (int)pzl)) == Material.water)
    			{
    				//worldObj.setBlockAndMetadataWithNotify((int)pxl, pyd, (int)pzl, 0, 0, 0);
    				worldObj.setBlock((int)pxl, pyd, (int)pzl, 0, 0, 0);
    			}
    			pi++;
    		}while(pi <= 12 && (mate == Material.water ||  worldObj.isAirBlock((int)pxl, pyd, (int)pzl)));
    		pyd--;
    	}
    	while(( worldObj.getBlockMaterial(px, pyu, pz) == Material.water || worldObj.isAirBlock(px, pyu, pz) ) && pyu < 256)
    	{
    		//worldObj.setBlockAndMetadataWithNotify(px, pyu, pz, 0, 0, 0);//空気を設置
    		worldObj.setBlock(px, pyu, pz, 0, 0, 0);//空気を設置
    		
    		pxr = posX;
    		pxl = posX;
    		pzr = posZ;
    		pzl = posZ;
    		pi = 0;
    		do
    		{
    			pxr += movingLengthX;
    			pzr -= movingLengthZ;
    			if( (mate = worldObj.getBlockMaterial((int)pxr, pyu, (int)pzr)) == Material.water)
    			{
    				//worldObj.setBlockAndMetadataWithNotify((int)pxr, pyu, (int)pzr, 0, 0, 0);
    				worldObj.setBlock((int)pxr, pyu, (int)pzr, 0, 0, 0);
    			}
    			pi++;
    		}while(pi <= 12 && (mate == Material.water  || worldObj.isAirBlock((int)pxr, pyu, (int)pzr)));
    		pi = 0;
    		do
    		{
    			pxl -= movingLengthX;
    			pzl += movingLengthZ;
    			if( (mate = worldObj.getBlockMaterial((int)pxl, pyu, (int)pzl)) == Material.water)
    			{
    				//worldObj.setBlockAndMetadataWithNotify((int)pxl, pyu, (int)pzl, 0, 0, 0);
    				worldObj.setBlock((int)pxl, pyu, (int)pzl, 0, 0, 0);
    			}
    			pi++;
    		}while(pi <= 12 && (mate == Material.water ||  worldObj.isAirBlock((int)pxl, pyu, (int)pzl)));
    		pyu++;
    	}
	}
	
	//跳ね返り弾
	private void bound(MovingObjectPosition movingObjectPosition, double returnRate, int returnCount)
	{
		//returnRate = 1.0D;
		
		double supPosX1 = posX;
        double supPosX2 = posX + motionX;//movingObjectPosition.hitVec.xCoord;
        double supPosY1 = posY;
        double supPosY2 = posY + motionY;//movingObjectPosition.hitVec.yCoord;
        double supPosZ1 = posZ;
        double supPosZ2 = posZ + motionZ;//movingObjectPosition.hitVec.zCoord;
		
		//始点を登録
        Vec3 supVec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX1, supPosY1, supPosZ1);
    	//終点を登録
    	Vec3 supVec3d2 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX2, supPosY2, supPosZ2);
        //始点と終点からブロックとの衝突を取得
    	movingObjectPosition = worldObj.rayTraceBlocks_do_do(supVec3d1, supVec3d2, false, true);
        //始点を登録
        supVec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX1, supPosY1, supPosZ1);
    	//終点を登録
    	supVec3d2 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX2, supPosY2, supPosZ2);
		
		//int returnCount = 0;//跳ね返り過ぎて無限ループに陥ったときの対処
		
		while(movingObjectPosition != null && movingObjectPosition.entityHit == null)
        {
	        switch(movingObjectPosition.sideHit)
	        {
	            case 0:
	            	motionY *= -returnRate;
	            	//accelerationY *= -returnRate;
	            	break;
	            case 1:
	            	motionY *= -returnRate;
	            	//accelerationY *= -returnRate;
	            	break;
	            case 2:
	            	motionZ *= -returnRate;
	            	//accelerationZ *= -returnRate;
	            	break;
	            case 3:
	            	motionZ *= -returnRate;
	            	//accelerationZ *= -returnRate;
	            	break;
	            case 4:
	            	motionX *= -returnRate;
	            	//accelerationX *= -returnRate;
	            	break;
	            case 5:
	            	motionX *= -returnRate;
	            	//accelerationX *= -returnRate;
	            	break;
	            default:
	            	return;
	        }
	        //motionX -= (movingObjectPosition.hitVec.xCoord - supPosX1);
	        //motionY -= (movingObjectPosition.hitVec.yCoord - supPosY1);
	        //motionZ -= (movingObjectPosition.hitVec.zCoord - supPosZ1);
	        //if()
            supPosX1 = supPosX1 + (movingObjectPosition.hitVec.xCoord - supPosX1) * 0.99D;
            supPosX2 = supPosX1 + motionX;
            supPosY1 = supPosY1 + (movingObjectPosition.hitVec.yCoord - supPosY1) * 0.99D;
            //supPosY1 = supMovingObjectPosition.hitVec.yCoord;
            supPosY2 = supPosY1 + motionY;
            supPosZ1 = supPosZ1 + (movingObjectPosition.hitVec.zCoord - supPosZ1) * 0.99D;
            supPosZ2 = supPosZ1 + motionZ;
        	//始点を登録
            supVec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX1, supPosY1, supPosZ1);
    		//終点を登録
    		supVec3d2 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX2, supPosY2, supPosZ2);
        	//始点と終点からブロックとの衝突を取得
    		movingObjectPosition = worldObj.rayTraceBlocks_do_do(supVec3d1, supVec3d2, false, true);
            //始点を登録
            supVec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX1, supPosY1, supPosZ1);
    		//終点を登録
    		supVec3d2 = worldObj.getWorldVec3Pool().getVecFromPool(supPosX2, supPosY2, supPosZ2);
    		
    		//hitEntityCheck(movingObjectPosition, supVec3d1, supVec3d2);
    		//setVector();
        	
        	returnCount--;
        	if(returnCount <= 0)
        	{
        		setDead();
        		return;
        	}
        }
	}
	
	//気質弾
	private void kishitudan()
	{
		//for(int i = 0; i < 2; i++)
    	{
	    	EntityTHShot entityTHShot;
	    	double xVector, yVector, zVector;
	    	float angleXZ, angleY;
	    	angleXZ = rand.nextFloat() * (float)Math.PI * 2F;
	    	angleY  = rand.nextFloat() * (float)Math.PI * 2F;
	    	xVector = -Math.sin(angleXZ) * Math.cos(angleY);
	    	yVector = -Math.sin(angleY);
	    	zVector =  Math.cos(angleXZ) * Math.cos(angleY);
	    	entityTHShot = new EntityTHShot( worldObj, userEntity, this, posX, posY, posZ,
	    		xVector, yVector, zVector, 0.01D, 0.15D, 0.01D, 0.0D, 0.0D, 0.0D,
	    		4, 40, 0.3F, 90);
	    	worldObj.spawnEntityInWorld(entityTHShot);
    	}
	}
	
	//着弾地点に花を咲かす
	private void flowerWorld()
	{
		Random random = new Random();
    	int hitPointX = (int)posX;
    	int hitPointY = (int)(posY - 0.3D);
    	int hitPointZ = (int)posZ;
    	int hitPointBlock = worldObj.getBlockId(hitPointX, hitPointY, hitPointZ);
    	if(hitPointBlock == Block.grass.blockID)
    	{
    		int setX = hitPointX;
    		int setY = hitPointY + 1;
    		int setZ = hitPointZ;
    		if(worldObj.isAirBlock(setX, setY, setZ))
    		{
    			if(getShotColor() % 8 == 3)//黄色の弾幕なら
    			{
    				if(!worldObj.isRemote)
    				{
    					//黄色い花を咲かす
    					worldObj.setBlock(setX, setY, setZ, BlockFlower.plantYellow.blockID, 1, 3);
    				}
    			}
    			else if(getShotColor() % 8 == 0)//赤色の弾幕なら
    			{
    				if(!worldObj.isRemote)
    				{
    					//赤い花を咲かす
    					worldObj.setBlock(setX, setY, setZ, BlockFlower.plantRed.blockID, 1, 3);
    				}
    			}
    		}
    	}
	}

    //データを保存する
	@Override
    public void writeEntityToNBT(NBTTagCompound nbtTagCompound)
    {
        /*nbtTagCompound.setShort("xTile", (short)this.xTile);
        nbtTagCompound.setShort("yTile", (short)this.yTile);
        nbtTagCompound.setShort("zTile", (short)this.zTile);
        nbtTagCompound.setByte("inTile", (byte)this.inTile);
        nbtTagCompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));*/
        //nbtTagCompound.setTag("direction", this.newDoubleNBTList(new double[] {this.motionX, this.motionY, this.motionZ}));
    }

    //データを読み込む
	@Override
    public void readEntityFromNBT(NBTTagCompound nbtTagCompound)
    {
        /*this.xTile = nbtTagCompound.getShort("xTile");
        this.yTile = nbtTagCompound.getShort("yTile");
        this.zTile = nbtTagCompound.getShort("zTile");
        this.inTile = nbtTagCompound.getByte("inTile") & 255;
        this.inGround = nbtTagCompound.getByte("inGround") == 1;*/

        /*if (nbtTagCompound.hasKey("direction"))
        {
            NBTTagList var2 = nbtTagCompound.getTagList("direction");
            this.motionX = ((NBTTagDouble)var2.tagAt(0)).data;
            this.motionY = ((NBTTagDouble)var2.tagAt(1)).data;
            this.motionZ = ((NBTTagDouble)var2.tagAt(2)).data;
        }
        else
        {
            this.setDead();
        }*/
    }
	
	//当たり判定の追加
	public boolean hitCheckEx(Entity entity)
	{
		return false;
	}
    	
    //弾の強さ
    /*
    public int getShotStrength()
    {
    	return 10;
    }*/
    
	//重力値を設定　0.0Dで通常の重力になる
	public void setGravityLevel()
	{
		motionX += shotGravityX;
		motionY += shotGravityY;
		motionZ += shotGravityZ;
	}
	
	//重力の影響を受けるかどうか返す
	public boolean hasGravityLevel()
	{
		if(shotGravityX == 0.0D && shotGravityY == 0.0D && shotGravityZ == 0.0D)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

    public boolean canBeCollidedWith()
    {
        return true;
    }

    public float getCollisionBorderSize()
    {
        return getShotSize();
    }
    	
    //跳ね返せる弾かどうか
    protected boolean isReturnableShot()
    {
    	return false;
    }

    //Entityからの攻撃を受けたときの処理　要は跳ね返す処理
    public boolean attackEntityFrom(DamageSource damageSource, float i)
    {
        setBeenAttacked();
        if (isReturnableShot() && damageSource.getEntity() != null)
        {
        	Vec3 look = damageSource.getEntity().getLookVec();
            rotationYaw = -damageSource.getEntity().rotationYaw;
            rotationPitch = -damageSource.getEntity().rotationPitch;
            setRotation(rotationYaw, rotationPitch);
            setVector();
            motionX += look.xCoord * 2.0D;
            motionY += look.yCoord * 2.0D;
            motionZ -= look.zCoord * 2.0D;
            worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.3F);//音を出す
            if (damageSource.getEntity() instanceof EntityLivingBase)
            {
                shootingEntity = (EntityLivingBase)damageSource.getEntity();
            }
            return true;
        }
        else
        {
            return false;
        }
    }
    
    //ショットが消える直前のフレームかどうかを返す
    public boolean isEndTime()
    {
    	return ticksExisted == getDeadTime();
    }
	
	//消滅時間を設定
	public void setDeadTime(int time)
	{
		dataWatcher.updateObject(18, Integer.valueOf(time));
	}
	//消滅時間を返す
	public int getDeadTime()
	{
		return dataWatcher.getWatchableObjectInt(18);
	}
	
	//ショットの色を設定
	public void setShotColor(int par1)
	{
		dataWatcher.updateObject(19, Integer.valueOf(par1));
	}
	//ショットの色を返す
	public int getShotColor()
	{
		return dataWatcher.getWatchableObjectInt(19);
	}
	
	//ショットの大きさを設定（レーザーの場合は太さ）
	public void setShotSize(float size)
	{
		dataWatcher.updateObject(20, Integer.valueOf((int)(size * 100F)));
	}
	
	//ショットの大きさを返す（レーザーの場合は太さ）
	public float getShotSize()
	{
		return (float)dataWatcher.getWatchableObjectInt(20) / 100F;
	}
	
	//ショットのアニメーションのカウントを設定する
	public void setAnimationCount(int count)
	{
		dataWatcher.updateObject(17, Integer.valueOf(count));
	}
	
	//ショットのアニメーションのカウントを返す
	public int getAnimationCount()
	{
		return dataWatcher.getWatchableObjectInt(17);
	}
	
	//Z軸の角度を設定する
	public void setAngleZ(float angle)
	{
		dataWatcher.updateObject(16, Integer.valueOf((int)(angle * 10000F)));
		/*Vec3 rotateVec = thShotLib.getVecFromAngle(rotationYaw, rotationPitch + 90F, 1.0F);
		Vec3 vec = getVectorFromRotation(shotVectorX, shotVectorY, shotVectorZ,rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord,  getAngleZ());
		setOverVector(-vec.xCoord, -vec.yCoord, vec.zCoord);*/
	}
	
	//Z軸の角度を返す
	public float getAngleZ()
	{
		return (float)dataWatcher.getWatchableObjectInt(16) / 10000F;
	}

	@SideOnly(Side.CLIENT)
    public float getShadowSize()
    {
        return 0.0F;
    }

    public float getBrightness(float f)
    {
        return 1.0F;
    }

	@SideOnly(Side.CLIENT)
    public int getBrightnessForRender(float f)
    {
        return 0xf000f0;
    }
	
}
