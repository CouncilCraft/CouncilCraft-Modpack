package thKaguyaMod.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import thKaguyaMod.thShotLib;

public class EntityRyuuLightningBolt extends EntityTHShot
{
	//龍の頸の玉　雪玉を改造　着地点に雷を落とす

	public float color_r;
	public float color_g;
	public float color_b;

    public EntityRyuuLightningBolt(World world)
    {
        super(world);
    }

    public EntityRyuuLightningBolt(World world, EntityLivingBase EntityLivingBase, double xVector, double yVector, double zVector, float cr, float cg, float cb)
    {
    	super(world, EntityLivingBase, (Entity)EntityLivingBase, xVector, yVector, zVector, 0.9D, 0.9D, 0.0D, 0.0D, -0.03, 0.0D,  7, 0, 1.0F, 120);
    	color_r = cr;
    	color_g = cg;
    	color_b = cb;
    }

    public EntityRyuuLightningBolt(World world, EntityLivingBase userEntity, Entity sourceEntity, double xPos, double yPos, double zPos, double xVector, double yVector, double zVector, float cr, float cg, float cb)
    {
        super(world, userEntity, sourceEntity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, 0.9D, 0.9D, 0.0D, 0.0D, -0.03, 0.0D, 7, 0, 1.0F, 120, 0, 0);
    	color_r = cr;
    	color_g = cg;
    	color_b = cb;
    }

	//ブロックやEntityに当たったときの処理
	@Override
    protected void onImpact(MovingObjectPosition par1MovingObjectPosition)
    {
    	super.onImpact(par1MovingObjectPosition);
    	
    	int colors[] = {0, 2, 4, 5, 6};
    	float angle = rand.nextFloat() * 360F;
    	for(int i = 0; i < 5; i++)
    	{
    		thShotLib.createLaserA(userEntity, this, posX, posY + 0.4D, posZ, angle, -70F, 0.1D, 0.3D, 0.1D, 0.0D, 0.0D, 0.0D, 3, colors[i], 0.15F, 40, 0, 0, 3.0D);
    		angle += 72F;
    	}
    	for(int i = 0; i < 10; i++)
    	{
    		double xVector = rand.nextGaussian() * 0.2D;
    		double yVector = 0.8D + rand.nextDouble() * 0.2D;
    		double zVector = rand.nextGaussian() * 0.2D;

    		thShotLib.createShot(userEntity, this, posX, posY, posZ, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, 0.4D, 0.4D, 0.00D, 0.0D, -0.01D, 0.0D, 3, thShotLib.LIGHT[0] + colors[rand.nextInt(5)], 0.3F, 120, 1, 0);
    	}

    	//EntityColorLightningBolt entitylightningbolt = new EntityColorLightningBolt(worldObj, posX, posY, posZ, color_r, color_g, color_b);

		EntityLightningBolt entitylightningbolt = new EntityLightningBolt(worldObj, posX, posY, posZ);

    	//if(!worldObj.isRemote)
    	{
    		worldObj.spawnEntityInWorld(entitylightningbolt);//雷を落とす
    	}
    	if(!worldObj.isRemote)
    	{
    		setDead();
    	}
    }
	
	//拡張当たり判定除外チェック
	@Override
	public boolean hitCheckEx(Entity entity)
	{
		return entity instanceof EntityTHShot || entity instanceof EntityRyuuLightningBolt;
	}
}
