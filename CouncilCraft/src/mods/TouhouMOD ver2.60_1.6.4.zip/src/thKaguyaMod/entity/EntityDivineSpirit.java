package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;

public class EntityDivineSpirit extends Entity
{
	//小神霊
	
	public short color;//ナイフの色
	private int xTile;//Xの整数座標
    private int yTile;//Yの整数座標
    private int zTile;//Zの整数座標
    private int inTile;//今いる場所のブロックID
	private int inData;//今いる場所のブロックのメタデータ
    private boolean inGround;//地中にいるか
    private int ticksAlive;
	private int ticksInGround;
    private int ticksInAir;
    public double accelerationX;
    public double accelerationY;
    public double accelerationZ;
	
	private int lastTime;
	private double lastShotMotionX;
	private double lastShotMotionY;
	private double lastShotMotionZ;
	private float lastRotationYaw;
	private float lastRotationPitch;
	
	private double speed;
	
	//private EntityPlayer user;

	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityDivineSpirit(World world)
    {
        super(world);
        xTile = -1;
        yTile = -1;
        zTile = -1;
        inTile = 0;
    	inData = 0;
        inGround = false;
        ticksInAir = 0;
    	setSize(1.2F, 1.2F);
   
    	
    }
    
    
    protected boolean canTriggerWalking()
    {
        return false;
    }
    


    public EntityDivineSpirit(World world, double posX, double posY, double posZ, int t)
    {
        super(world);
        setSize(1.2F, 1.2F);
    	setDivineSpiritColor((short)t);
    	setDivineSpiritCount(0);
    	setLocationAndAngles(	posX + motionX * 0.1D,
    							posY + motionY * 0.1D,
    							posZ + motionZ * 0.1D,
    							rotationYaw, rotationPitch);
    	prevPosX = posX;
    	prevPosY = posY;
    	prevPosZ = posZ;
    	lastTime = 0;
    	speed = 0.0D;
    }
    
	//押すことができるかどうか
    @Override
    public boolean canBePushed()
    {
    	return false;
        //return delay >= 0;
    }
    
	//他の物体と衝突したときのその物体の当たり判定？
    @Override
    public AxisAlignedBB getCollisionBox(Entity entity)
    {
        return null;//entity.boundingBox;
    }

	//当たり判定を設定
    @Override
    public AxisAlignedBB getBoundingBox()
    {
        return null;//boundingBox;
    }

    public boolean isInRangeToRenderDist(double d)
    {
        double d1 = boundingBox.getAverageEdgeLength() * 4D;
        d1 *= 64D;
        return d < d1 * d1;
    }
	
	//Entity生成時に一度だけ呼ばれる
	@Override
    protected void entityInit()
    {
		dataWatcher.addObject(18, new Integer(0));
    	dataWatcher.addObject(19, new Integer(0));
    }

	
	//速度を返す
	public double getEntitySpeed()
	{
		double xx, yy, zz;
		xx = motionX;
		yy = motionY;
		zz = motionZ;
		return Math.sqrt(xx*xx + yy*yy + zz*zz);
	}
	
	@Override
    public void onUpdate()
    {
        super.onUpdate();
    	
        if(getDivineSpiritCount() > 300)
        {
        	if(!worldObj.isRemote)
        	{
        		setDead();
        	}
        }
        
        setDivineSpiritCount(getDivineSpiritCount() + 1);
    	
    	//***********停止空間（時計じゃなくてもっと大きな見えない壁）とEntityの当たり判定を取る****************//
    	MovingObjectPosition movingObjectPosition = new MovingObjectPosition(this);
    	Entity entity = null;
    	double effectiveBoundary = 10.0D;//停止空間の有効範囲
    	double distance = 999.0D;
    	Entity nearEntity = null;
    	EntityPlayer nearPlayer = null;
    	//停止空間内のEntityを全て取得
    	List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(effectiveBoundary, effectiveBoundary, effectiveBoundary));

        if (list != null && list.size() > 0)//取得したリストにEntityがいるなら
        {
            for (int j1 = 0; j1 < list.size(); j1++)//取得したEntityリストの最初から最後まで見る
            {
                entity = (Entity)list.get(j1);//entityに取得したリストのEntityを代入
            	if (entity != null )//Entityがいるなら
        		{
            		movingObjectPosition = new MovingObjectPosition(entity);//MovingObjectPositionにEntityを登録
        		}
            	if(entity instanceof EntityPlayer)//プレイヤーなら
            	{
            		if(distance > entity.getDistanceToEntity(this))
            		{
            			distance = entity.getDistanceToEntity(this);
            			nearPlayer = (EntityPlayer)entity;
            		}
            	}
            }
        }
        
        if(nearPlayer != null)
        {
        	if(speed < 0.5D)
        	{
        		speed += 0.03D;
        	}
        	
        	rotationYaw = (float)Math.atan2(nearPlayer.posX - posX, nearPlayer.posZ - posZ) / (float)Math.PI * 180F;
        	rotationPitch = (float)Math.atan2(nearPlayer.posY + nearPlayer.getEyeHeight() - posY, Math.sqrt((nearPlayer.posX - posX) * (nearPlayer.posX - posX) + (nearPlayer.posZ - posZ) * (nearPlayer.posZ - posZ))) / (float)Math.PI * 180F;
        	
        }
        else
        {
        	speed -= 0.03D;
        	if(speed < 0.0D)
        	{
        		speed = 0.0D;
        	}
        }
        
        Vec3 vec = thShotLib.getVecFromAngle(rotationYaw, rotationPitch, speed);
    	posX -= vec.xCoord;
    	posY -= vec.yCoord;
    	posZ += vec.zCoord;
    	setPosition(posX, posY, posZ);
        
        //posX += motionX;
        //posY += motionY;
        //posZ += motionZ;

    	
		if(ticksExisted > lastTime)
    	{
    		lastTime = ticksExisted;
    		lastShotMotionX = motionX;
    		lastShotMotionY = motionY;
    		lastShotMotionZ = motionZ;
    		lastRotationYaw = rotationYaw;
    		lastRotationPitch = rotationPitch;
    		
    	}
    }

	//恐らくデータの保存　再度読みこむときにここに保存したものを読み込む
	@Override
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("xTile", (short)xTile);
        nbttagcompound.setShort("yTile", (short)yTile);
        nbttagcompound.setShort("zTile", (short)zTile);
        nbttagcompound.setByte("inTile", (byte)inTile);
    	nbttagcompound.setByte("inData", (byte)inData);
    	//nbttagcompound.setByte("shootingEntity;", (byte)inData);
    	
        nbttagcompound.setByte("inGround", (byte)(inGround ? 1 : 0));
    	
    	nbttagcompound.setShort("color", (short)getDivineSpiritColor());
    }

	//保存したデータの読み込み
	@Override
    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        xTile = nbttagcompound.getShort("xTile");
        yTile = nbttagcompound.getShort("yTile");
        zTile = nbttagcompound.getShort("zTile");
        inTile = nbttagcompound.getByte("inTile") & 0xff;
    	inData = nbttagcompound.getByte("inData") & 0xff;
        inGround = nbttagcompound.getByte("inGround") == 1;
    	
    	setDivineSpiritColor(nbttagcompound.getShort("color"));
    	
    }
    
    //刺さっているものなら回収可能
    public void onCollideWithPlayer(EntityPlayer par1EntityPlayer)
    {
        if (!worldObj.isRemote && par1EntityPlayer.inventory.addItemStackToInventory(new ItemStack(mod_thKaguya.divineSpiritBlockId, 1, getDivineSpiritColor() )))
        {
            worldObj.playSoundAtEntity(this, "random.pop", 4.0F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 0.3F);
            par1EntityPlayer.onItemPickup(this, 1 );
            setDead();
        }
    }

	@Override
    public boolean canBeCollidedWith()
    {
        return true;
    }

	//物体の当たり判定　大きいと透明な判定が邪魔だよ
    public float getCollisionBorderSize()
    {
        return 0.1F;
    }
    
	//小神霊のカウントを設定
	public void setDivineSpiritCount(int count)
	{
		dataWatcher.updateObject(18, Integer.valueOf(count));
	}
	
	//小神霊のカウントを返す
	public int getDivineSpiritCount()
	{
		return dataWatcher.getWatchableObjectInt(18);
	}
    
	//小神霊の色を設定
	public void setDivineSpiritColor(int par1)
	{
		dataWatcher.updateObject(19, Integer.valueOf(par1));
	}
	
	//小神霊の色を返す
	public int getDivineSpiritColor()
	{
		return dataWatcher.getWatchableObjectInt(19);
	}

    public float getShadowSize()
    {
        return 0.0F;
    }

    public float getEntityBrightness(float f)
    {
        return 0.0F;
    }

    public int getEntityBrightnessForRender(float f)
    {
        return 0xf000f0;
    }
}