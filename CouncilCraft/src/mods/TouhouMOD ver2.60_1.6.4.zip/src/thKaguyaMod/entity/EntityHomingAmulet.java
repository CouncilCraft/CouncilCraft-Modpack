package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.thKaguyaLib;

public class EntityHomingAmulet extends EntityTHShot
{
	//ホーミングアミュレット
	
	String userPlayerName;

	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityHomingAmulet(World world)
    {
        super(world);
    }

    public EntityHomingAmulet(World world, EntityLivingBase EntityLivingBase, double xVector, double yVector, double zVector,
    		double speed, float power, int color, float size)
    {
        super(world, EntityLivingBase, xVector, yVector, zVector, speed, power, color, size);
    }
    
    public EntityHomingAmulet(World world, EntityLivingBase user, Entity source,
    		double xPos, double yPos, double zPos,
        	double xVector, double yVector, double zVector,
        	double firstSpeed, double maxSpeed, double addSpeed,
        	double xVectorG, double yVectorG, double zVectorG, float damage, int color, float size, int dead, int delay, int special)
    {
    	super(world, user, source, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG, damage, color, size, dead, delay, special);
    	
    	if(user instanceof EntityTameable)
    	{
    		EntityTameable tameable = (EntityTameable)user;
    		this.setOwner(tameable.getOwnerName());
    	}
    	else
    	{
    		this.setOwner("");
    	}
    }
    
	//Entity生成時に一度だけ呼ばれる
	protected void entityInit()
	{
		super.entityInit();
		this.dataWatcher.addObject(21, "");
	}

	//弾幕の特殊な動きを記述
	@Override
	public void specialMotion()
	{
		if(ticksExisted <= 5)
		{
			return;
		}
		
		if(ticksExisted == 16 && this.getShotColor() == 3)
		{
			EntityHomingAmulet amulet;
			double vectorX, vectorY, vectorZ;
			float angle = rand.nextFloat() * 360F;
			double vectorXG = 0.0D, vectorYG = 0.0D, vectorZG = 0.0D;
			if(userEntity != null)
			{
				vectorXG = -Math.sin(userEntity.rotationYaw / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F) * 0.09D;
				vectorYG = -Math.sin(userEntity.rotationPitch / 180F * 3.141593F) * 0.09D;
				vectorZG =  Math.cos(userEntity.rotationYaw / 180F * 3.141593F) * Math.cos(userEntity.rotationPitch / 180F * 3.141593F) * 0.09D;
			}
			
			for(int i = 0; i < 8; i ++)
			{
				vectorX = -Math.sin(angle / 180F * 3.141593F) * Math.cos(rotationPitch / 180F * 3.141593F);
				vectorY = -Math.sin(rotationPitch / 180F * 3.141593F);
				vectorZ =  Math.cos(angle / 180F * 3.141593F) * Math.cos(rotationPitch / 180F * 3.141593F);
				amulet = thKaguyaLib.createHomingAmulet(worldObj, userEntity, this, posX + vectorX * 0.0D, posY + vectorY * 0.0D, posZ + vectorZ * 0.0D, vectorX, vectorY, vectorZ, 
						0.6D, 0.01D, -0.01D, vectorXG, vectorYG, vectorZG, 
						5.0F, 2, 0.4F, 60, 0);
				angle += 45F;
			}
			for(int i = 0; i < 8; i ++)
			{
				vectorX = -Math.sin(rotationYaw / 180F * 3.141593F) * Math.cos(angle / 180F * 3.141593F);
				vectorY = -Math.sin(angle / 180F * 3.141593F);
				vectorZ =  Math.cos(rotationYaw / 180F * 3.141593F) * Math.cos(angle / 180F * 3.141593F);
				amulet = thKaguyaLib.createHomingAmulet(worldObj, userEntity, this, posX + vectorX * 0.0D, posY + vectorY * 0.0D, posZ + vectorZ * 0.0D, vectorX, vectorY, vectorZ, 
						0.6D, 0.01D, -0.01D, vectorXG, vectorYG, vectorZG, 
						5.0F, 2, 0.4F, 60, 0);
				angle += 45F;
			}
			for(int i = 0; i < 8; i ++)
			{
				vectorX = -Math.sin((rotationYaw + 90F) / 180F * 3.141593F) * Math.cos(angle / 180F * 3.141593F);
				vectorY = -Math.sin(angle / 180F * 3.141593F);
				vectorZ =  Math.cos((rotationYaw + 90F)/ 180F * 3.141593F) * Math.cos(angle / 180F * 3.141593F);
				amulet = thKaguyaLib.createHomingAmulet(worldObj, userEntity, this, posX + vectorX * 0.0D, posY + vectorY * 0.0D, posZ + vectorZ * 0.0D, vectorX, vectorY, vectorZ, 
						0.6D, 0.01D, -0.01D, vectorXG, vectorYG, vectorZG, 
						5.0F, 2, 0.4F, 60, 0);
				angle += 45F;
			}
			if(!worldObj.isRemote)
			{
				setDead();
			}
			return;
		}
		if(getShotColor() >= 2)
		{
			return;
		}
		
		//追尾する動きをする
		Entity entity = null;
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(motionX, motionY, motionZ).expand(15.0D, 15.0D, 15.0D));//指定範囲内のEntityをリストに登録

		EntityLivingBase nearEntity = null;
		double nearDistance = 999.9D;
		double ax, ay, az, dx, dy, dz;
		float angleXZ, angleY;
		float epYaw = (360F - rotationYaw) % 360F;
		float motionYaw = (float)Math.atan2(motionX, motionZ) / (float)Math.PI * 180F;//atan2は、-PI ～ PIまでの値を返す　ここで-180 ～ 180に変換
		float motionPitch = ((float)Math.atan2( motionY, (motionX*motionX + motionZ*motionZ)) / (float)Math.PI * 180F) % 90F;
		boolean check;
		boolean rightCheck = false;
		boolean leftCheck = false;
		boolean upCheck = false;
		boolean downCheck = false;
		boolean lastRightCheck = false;
		boolean lastLeftCheck = false;
		boolean lastUpCheck = false;
		boolean lastDownCheck = false;

		if(epYaw < 0F)
		{
			epYaw += 360F;
		}
		if(motionYaw < 0F)//motionYawを0 ～ 360に変換
		{
			motionYaw += 360F;
		}
		for (int j = 0; j < list.size(); j++)
        {
        	Entity entitys = (Entity)list.get(j);//entity1にリストの先端のentityを保存
        	if ( (entitys instanceof EntityLivingBase) == false || entitys instanceof EntityAnimal ||  entitys instanceof EntityVillager || entitys == shootingEntity || entitys == userEntity)//動物や生物でないなら反応しない
            {
                continue;
            }
        	if(entitys.getEntityName().equals(this.getOwnerName()))
        	{
        		continue;
        	}
        	EntityLivingBase entity1 = (EntityLivingBase)entitys;
        	if(entity1.isDead)
        	{
        		continue;
        	}
        	//始点（現在地）
    		Vec3 vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    		//終点（現在地に移動量を足した点）
    		Vec3 vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX, posY + motionY, posZ + motionZ);
        	//始点と終点からブロックとの当たりを取得
    		MovingObjectPosition movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
    		vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    		vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX, posY + motionY, posZ + motionZ);
    		//何らかのブロックに当たっているなら
        	if (movingObjectPosition != null)
        	{
        		continue;
        	}
        	check = false;
        	//視野に収まっているEntityLivingBaseを抽出
            //左右 -30 ～ 30度まで、上下も-30 ～ 30度まで感知
        	dx = entity1.posX - posX;//x方向の距離
        	dy = entity1.posY + entity1.getEyeHeight() - posY;//y方向の距離
        	dz = entity1.posZ - posZ;//z方向の距離

        	angleY  = (float)Math.atan2(dx, dz);//対象のEntityまでの平面角度
        	angleXZ = ((float)Math.atan2( dy, Math.sqrt(dx*dx + dz*dz)) / (float)Math.PI * 180F) % 90F;//対象のEntityまでの垂直方向の角度

        	float angleYDeg = angleY / (float)Math.PI * 180F;//Degreeに変換（-180° ～ 180°)
        	if(angleYDeg < 0F)//angleYDegを0～360度の範囲に設定
        	{
        		angleYDeg += 360F;
        	}

        	//check = true;
        	//進行角度epYawとEntityまでの角度angleYDegを0～360に固定して判定
            //30～330のときはそのまま判定
        	if(motionYaw > 50F && motionYaw < 310F)
        	{
        		if(motionYaw - 50F < angleYDeg && motionYaw + 50F > angleYDeg)
        		{
        			check = true;
        			if(motionYaw < angleYDeg)
        			{
        				check = true;
        				rightCheck = true;
        				leftCheck = false;
        			}
        			else if(motionYaw > angleYDeg)
        			{
        				check = true;
        				leftCheck = true;
        				rightCheck = false;
        			}
        		}
        	}
            //30以下のときは少し特殊な判定を与えないとできない
	        else if(motionYaw <= 50F)
	        {
	            if(0F <= angleYDeg && motionYaw+50F >= angleYDeg )
	            {
	            	check = true;
	            	if(motionYaw > angleYDeg || motionYaw < 360F - (50F - angleYDeg))
        			{
        				check = true;
        				leftCheck = true;
        				rightCheck = false;
        			}
        			else if(motionYaw < angleYDeg)
        			{
        				check = true;
        				rightCheck = true;
        				leftCheck = false;
        			}
	            }
	        	if(360F-motionYaw < angleYDeg && 360F > angleYDeg)
	            {
	            	check = true;
	            	if(motionYaw < angleYDeg || motionYaw > 360F - angleYDeg)
        			{
        				check = true;
        				rightCheck = true;
        				leftCheck = false;
        			}
        			else if(motionYaw > angleYDeg)
        			{
        				check = true;
        				leftCheck = true;
        				rightCheck = false;
        			}
	            }
	        }
            //330以上　同上
	        else
	        {
	            if(50F-(360F-motionYaw) >= angleYDeg && 0F <= angleYDeg )

	            {
	            	check = true;
	            	if(motionYaw < angleYDeg || motionYaw > 360F - angleYDeg)
        			{
        				check = true;
        				rightCheck = true;
        				leftCheck = false;
        			}
        			else if(motionYaw > angleYDeg)
        			{
        				check = true;
        				leftCheck = true;
        				rightCheck = false;
        			}
	            }
	            if(motionYaw-50F < angleYDeg && 360F > angleYDeg)
	            {
	            	check = true;
	            	if(motionYaw > angleYDeg || motionYaw < 360F - (50F - angleYDeg))
        			{
        				check = true;
        				leftCheck = true;
        				rightCheck = false;
        			}
        			else if(motionYaw < angleYDeg)
        			{
        				check = true;
        				rightCheck = true;
        				leftCheck = false;
        			}
	            }
	        }

			if(motionPitch > -40F && motionPitch < 40F)
			{
				if(	angleXZ > motionPitch - 50F && angleXZ < motionPitch + 50F)
				{
				}
				else
				{
					check = false;
				}
			}
			else if(motionPitch <= -40F)
			{
				if(angleXZ < motionPitch + 50F)
				{
				}
				else
				{
					check = false;
				}
			}
			else
			{
				if(angleXZ < motionPitch - 50F)
				{
				}
				else
				{
					check = false;
				}
			}

        	double toEntity1Distance;
        	if(check && (toEntity1Distance = getDistanceToEntity(entity1)) < nearDistance)
        	{
        		//壁越しの相手かどうかチェック
        		//始点（現在地）
    			Vec3 vec3d_2 = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    			//終点（現在地に移動量を足した点）
    			Vec3 vec3d1_2 = worldObj.getWorldVec3Pool().getVecFromPool(entity1.posX, entity1.posY, entity1.posZ);
        		//始点と終点からブロックとの当たりを取得
    			MovingObjectPosition movingObjectPosition_2 = worldObj.rayTraceBlocks_do_do(vec3d_2, vec3d1_2, false, true);
    			//間に壁がないなら
        		if (movingObjectPosition_2 == null)
        		{
        			//一番近くのEntityとして登録
        			nearEntity = entity1;
        			nearDistance = toEntity1Distance;
        			lastRightCheck = rightCheck;
        			lastLeftCheck = leftCheck;
        		}
        	}
        }

		//追尾対象がいるならば
		if(nearEntity != null)
		{
			//setPosition(nearEntity.posX, nearEntity.posY, nearEntity.posZ);
			/*float rotationSpan =13.3F;
			//対象が右側にいるなら
			if(lastRightCheck)
			{
				rotationYaw += rotationSpan;
			}
			//対象が左側にいるなら
			if(lastLeftCheck)
			{
				rotationYaw -= rotationSpan;
			}
			//対象が上部にいるなら
			if(lastUpCheck)
			{
				rotationPitch += rotationSpan;
			}
			//対象が下部にいるなら
			if(lastDownCheck)
			{
				rotationPitch -= rotationSpan;
			}*/
			double xDistance = nearEntity.posX - posX;
			double yDistance = nearEntity.posY + nearEntity.getEyeHeight() - posY;
			double zDistance = nearEntity.posZ - posZ;
			//worldObj.playSoundAtEntity(this, "random.orb", 0.5F, 6.0F);
			rotationYaw = /*360F - */((float)Math.atan2(xDistance, zDistance)) / (float)Math.PI * 180F;
			rotationPitch = (float)Math.atan2( yDistance, Math.sqrt(xDistance * xDistance + zDistance * zDistance)) / (float)Math.PI * 180F;
			rotationPitch = /*360F - */(rotationPitch % 90F);
			setRotation(rotationYaw, rotationPitch);
			setVector();
			/*accelerationX = -Math.sin(rotationYaw / 180F * (float)Math.PI) * Math.cos( rotationPitch / 180F * (float)Math.PI) * shotMaxSpeed * shotAddSpeed;
			accelerationY = -Math.sin( rotationPitch / 180F * (float)Math.PI) * shotMaxSpeed * shotAddSpeed;
			accelerationZ =  Math.cos(rotationYaw / 180F * (float)Math.PI) * Math.cos( rotationPitch / 180F * (float)Math.PI) * shotMaxSpeed * shotAddSpeed;
			if(getSpeed() >= shotMaxSpeed)
			{
				motionX = -Math.sin(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * shotMaxSpeed;
				motionY = -Math.sin(rotationPitch / 180F * (float)Math.PI) * shotMaxSpeed;
				motionZ =  Math.cos(rotationYaw / 180F * (float)Math.PI) * Math.cos( rotationPitch / 180F * (float)Math.PI) * shotMaxSpeed;
			}*/
			//setPosition(posX, posY, posZ);
		}
	}
	
    public String getOwnerName()
    {
        return this.dataWatcher.getWatchableObjectString(21);
    }

    public void setOwner(String par1Str)
    {
        this.dataWatcher.updateObject(21, par1Str);
    }
}
