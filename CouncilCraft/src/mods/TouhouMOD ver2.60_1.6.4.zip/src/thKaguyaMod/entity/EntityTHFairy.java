package thKaguyaMod.entity;

import java.util.Calendar;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;

public class EntityTHFairy extends EntityFlying
{
    //妖精
	
    protected ChunkCoordinates currentFlightTarget;
	public int lastTime;
	
	public EntityLivingBase targetedEntity = null;
	public int attackCounter = 0;
	public int courseChangeCooldown = 0;
	public double waypointX;
    public double waypointY;
    public double waypointZ;
	
	//public int fairyType;
	public int lostTarget;

    public EntityTHFairy(World world)
    {
        super(world);
        
        this.setSize(1.0F, 1.8F);//MOBの当たり判定の大きさ 横奥行き、高さ、大きさ
        setEntityHealth(2.0F);
    	yOffset = -0.2F;
    	lastTime = 0;
    	experienceValue = 5;//経験値の量
    	setFairyType((byte)rand.nextInt(9));
    	lostTarget = 0;
    	//this.tasks.addTask(5, new EntityAIWander(this, this.moveSpeed));
    	//this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
    	//this.tasks.addTask(6, new EntityAILookIdle(this));
    	//this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
    	//this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 16.0F, 0, true));
    }

    protected void entityInit()
    {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    	this.dataWatcher.addObject(17, new Byte((byte)0));
        this.dataWatcher.addObject(18, new Byte((byte)0));
    }
    
    //Entityの属性の設定
    protected void func_110147_ax()
    {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(2.0D);//妖精の最大HPを2に設定
    }

    /**
     * Returns the volume for the sounds this mob makes.
     */
    protected float getSoundVolume()
    {
        return 0.3F;
    }

	//発する音のピッチ
    protected float getSoundPitch()
    {
        return super.getSoundPitch() * 1.95F;
    }

    //生きてるときに出す音
    protected String getLivingSound()
    {
        return this.rand.nextInt(4) != 0 ? null : "mob.bat.idle";
    }

    //攻撃を受けたときの音
    protected String getHurtSound()
    {
        return "mob.bat.hurt";
    }

	//倒れたときの音
    protected String getDeathSound()
    {
        return "mob.bat.death";
    }

	//このEntityは押すことができるか？
    public boolean canBePushed()
    {
        return true;
    }

    protected void collideWithEntity(Entity par1Entity) {}

    protected void func_85033_bc() {}

    /*public boolean getIsTHFairyHanging()
    {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }*/

    /*public void setIsTHFairyHanging(boolean par1)
    {
        byte var2 = this.dataWatcher.getWatchableObjectByte(16);

        if (par1)
        {
            this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 | 1)));
        }
        else
        {
            this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 & -2)));
        }
    }*/

    /**
     * Returns true if the newer Entity AI code should be run
     */
    /*protected boolean isAIEnabled()
    {
        return true;
    }*/
    
    //死んでいるときに呼ばれる
    protected void onDeathUpdate()
    {
    	if(worldObj.provider.isHellWorld && this instanceof EntityTHFairyCirno == false)
    	{
    		if(ticksExisted > 0)
    		{
    			targetedEntity = null;
    			motionY = 0;
    			ticksExisted = -180;
    			thShotLib.banishExplosion(this, 1.0F, 5.0F);
    			
    		}
    		else
    		{
    			ticksExisted ++;
    			
    		}
    		if(ticksExisted == 0)
    		{
    			setFairyType((byte)-1);
    			this.setEntityHealth(2.0F);
    		}
    	}
    	else
    	{
    		super.onDeathUpdate();
    	}
    	
    	//周囲の妖精を巻き込む
    	if(this.deathTime == 7)
    	{
    		thShotLib.banishExplosion(this, 5.0F, 5.0F);
    	}
    	
    }

	//常時呼ばれる
    public void onUpdate()
    {
        super.onUpdate();
    	
    	if (!this.worldObj.isRemote && this.worldObj.difficultySetting == 0)
        {
            this.setDead();
        }
    	
    	//体力がないなら動かない
    	if(this.func_110143_aJ() <= 0 && this instanceof EntityTHFairyCirno == false)
    	{
    		motionX = 0.0D;
    		motionY = 0.00D;
    		motionZ = 0.0D;
    		//setPosition(posX, posY + motionY, posZ);
    		return;
    	}
    	
    	if(ticksExisted <= lastTime)
    	{
    		return;
    	}
    	else
    	{
    		//ticksExisted++;
    	}
    	
    	if(getFairySpellCardMotion() < 0)
    	{
    		setFairySpellCardMotion((byte)(getFairySpellCardMotion() + 1));
    	}

    	
    	double xMove = this.waypointX - this.posX;
        double yMove = this.waypointY - this.posY;
        double zMove = this.waypointZ - this.posZ;
        double speed = xMove * xMove + yMove * yMove + zMove * zMove;

        if (speed < 1.0D || speed > 3600.0D)
        {
            this.waypointX = this.posX + (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
            this.waypointY = this.posY + (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
            this.waypointZ = this.posZ + (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
        }

        if(targetedEntity == null)
        {
	        if (this.courseChangeCooldown-- <= 0)
	        {
	        	float rotateLevel = (float)rand.nextInt(60);
	        	rotationYaw += rand.nextFloat() * rotateLevel - rotateLevel / 2F;
	        	float rotateLevel2 = (float)rand.nextInt(30);
	        	rotationPitch += rand.nextFloat() * rotateLevel - rotateLevel / 2F;
	            this.courseChangeCooldown += this.rand.nextInt(24) + 2;
	            //speed = (double)MathHelper.sqrt_double(speed);
	        	speed = rand.nextDouble() * 0.05D + 0.05D;
	        	
	        	motionX += Math.sin(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * speed;
	        	motionY += Math.sin(rotationPitch / 180F * (float)Math.PI) * speed;
	        	motionZ += Math.cos(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * speed;
	
	            /*if (this.isCourseTraversable(this.waypointX, this.waypointY, this.waypointZ, speed))
	            {
	                this.motionX += xMove / speed * 0.1D;
	                this.motionY += yMove / speed * 0.1D;
	                this.motionZ += zMove / speed * 0.1D;
	            }
	            else
	            {
	                this.waypointX = this.posX;
	                this.waypointY = this.posY;
	                this.waypointZ = this.posZ;
	            }*/
	        }
        }
        else
        {
        	if (this.courseChangeCooldown-- <= 0)
        	{
        		double setLength = getAttackDistance();//8.0D;
        		if(targetedEntity.getDistanceSqToEntity(this) > setLength * setLength)
        		{
        			speed = rand.nextDouble() * 0.005D + 0.005D;
        			motionX -= Math.sin(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * speed;
        			motionY -= Math.sin(rotationPitch / 180F * (float)Math.PI) * speed;
        			motionZ += Math.cos(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * speed;
        		}
        		else
        		{
        			speed = rand.nextDouble() * 0.005D + 0.005D;
        			motionX += Math.sin(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * speed;
        			motionY += Math.sin(rotationPitch / 180F * (float)Math.PI) * speed;
        			motionZ -= Math.cos(rotationYaw / 180F * (float)Math.PI) * Math.cos(rotationPitch / 180F * (float)Math.PI) * speed;
        		}
        	}
        }

    	//高さを調整する
    	int heightCount = 0;
    	while(worldObj.isAirBlock((int)posX, (int)posY - heightCount, (int)posZ) && heightCount < 8)
    	{
    		heightCount++;
    	}
    	
    	if(targetedEntity != null && heightCount > 2)
    	{
    		double distance = targetedEntity.posY - this.posY;
    		if(distance > 15.0D)
    		{
    			distance = 15.0D;
    		}
    		else if(distance < -15.0D)
    		{
    			distance = -15.0D;
    		}
    		
    		motionY += distance * 0.01D;
    	}
    	else if(heightCount < 2 )
    	{
	    	if(heightCount >= 8)
	    	{
	    		motionY -= 0.10D;
	    	}
	    	else if(heightCount < 2)
	    	{
	    		motionY += 0.10D;
	    	}
    	}
    	

        /*if (this.getIsTHFairyHanging())
        {
            this.motionX = this.motionY = this.motionZ = 0.0D;
            this.posY = (double)MathHelper.floor_double(this.posY) + 1.0D - (double)this.height;
        }
        else*/
        {
            this.motionY *= 0.6000000238418579D;
        }
    	
    	//ターゲットがいるが、死んでいるなら
    	if(targetedEntity != null && targetedEntity.isDead)
    	{
    		targetedEntity = null;//ターゲットから外す
    	}
    	
    	if (this.targetedEntity == null)
        {
            this.targetedEntity = this.worldObj.getClosestVulnerablePlayerToEntity(this, getDetectionDistance());

            if (this.targetedEntity != null)
            {
            	//周りの妖精を敵対化させる
            	if(canFairyCall())
            	{
	            	List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(getFairyCallDistance(), getFairyCallDistance(), getFairyCallDistance()));//指定範囲内のEntityをリストに登録
	            	for(int i = 0; i < list.size(); i++)
	            	{
	            		Entity entity1 = (Entity)list.get(i);
	            		if(entity1 instanceof EntityTHFairy)
	            		{
	            			EntityTHFairy entityFairy = (EntityTHFairy)entity1;
	            			if(entityFairy.targetedEntity == null)
	            			{
	            				entityFairy.targetedEntity = targetedEntity;
	            			}
	            		}
	            	}
            	}
                //this.aggroCooldown = 20;
            }
        }
    	
    	double targetableLength = 32.0D;//攻撃する射程
    	
    	//射程圏内にターゲットがいるなら
    	if(targetedEntity != null && !isDead && targetedEntity.getDistanceSqToEntity(this) < targetableLength * targetableLength)
    	{
    		if(canEntityBeSeen(targetedEntity))
    		{
    			lostTarget = 0;
    			
    			double xDistance = targetedEntity.posX - posX;
    			double yDistance = targetedEntity.posY - posY;
    			double zDistance = targetedEntity.posZ - posZ;
    			float angleXZ = 360F - ((float)Math.atan2(xDistance, zDistance)) / 3.141593F * 180F;
				float angleY  = 360F - (float)Math.atan2( yDistance, Math.sqrt(xDistance * xDistance + zDistance * zDistance)) / 3.141593F * 180F;
    			
    			rotationYaw = angleXZ;
    			rotationPitch = angleY;
    			setRotation(rotationYaw, rotationPitch);
    			
    			int level = mod_thKaguya.danmakuLevel;
    			if(level != 0 && attackCounter >= 0)
    			{
    				danmakuPattern(level, angleXZ, angleY);

    			}
    			/*if(attackCounter == 140)
    			{
    				if(targetedEntity instanceof EntityLivingBase)
    				{
    					EntityLivingBase targetedEntityLivingBase = (EntityLivingBase)targetedEntity;
    					thKaguyaLib.spellCardDeclaration(worldObj, this, targetedEntityLivingBase, 9);
    				}
    				attackCounter = 0;
    			}*/
    			attackCounter++;
    		}
    		else
    		{
    			lostTarget++;
    			if(lostTarget > 200)
    			{
    				targetedEntity = null;
    			}
    		}
    	}
    	
    	/*motionX = MathHelper.sin(rotationYaw / 180F * 3.141593F) * 0.1D;
    	motionZ = MathHelper.cos(rotationYaw / 180F * 3.141593F) * 0.1D;
    	
    	posX += motionX;
    	posY += motionY;
    	posZ += motionZ;
    	
    	setPosition(posX, posY, posZ);*/
    	
    	
    	if(ticksExisted > lastTime)
    	{
    		lastTime = ticksExisted;
    	}
    	

    }
    
    //弾幕の処理
    public void danmakuPattern(int level, float angleXZ, float angleY)
    {
    	Vec3 look = this.getLookVec();
		switch(getFairyType())
		{
		case -1:
			if(attackCounter >= 23 - level * 4)
			{
				int shotType = thShotLib.LIGHT[thShotLib.RED];
				/*if(level >= 3)
				{
					shotType = thShotLib.MEDIUM[thShotLib.BLUE];
				}*/
				thShotLib.createShot(this, this.posX + look.xCoord, thShotLib.getPosYFromEye(this, -0.2D) + look.yCoord, this.posZ + look.zCoord, angleXZ, angleY, 0.0D, 0.2D, 0.05D, shotType, 10);
				attackCounter = 0;
				worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
			}
			break;
			case 0:
				if(attackCounter >= 50)
				{
					//Vec3 vec3 = thShotLib.getVecFromAngle(angleXZ, angleY, 1.0D);
					//thKaguyaLib.createHomingAmulet(worldObj, targetedEntity, this, this.posX, this.posY, this.posZ, vec3.xCoord , vec3.yCoord, vec3.zCoord, 0.6D, 0.6D, 0.0D, 0.0D, 0.0D, 0.0D, 2.0F, 0, 0.4F, 120, 5);
					thShotLib.createLaserA(this, this.posX, thShotLib.getPosYFromEye(this,  -0.2D), this.posZ, angleXZ, angleY, 0.01D, 0.20D + (double)level * 0.05, 0.03D, 2.0F, thShotLib.SMALL[thShotLib.RED], 0.1F, 10, 2.0D + (double)level * 0.5D);
					//thShotLib.createLaserA01(this, angleXZ, angleY, 0.20D + (double)level * 0.05, 2.0F, thShotLib.SMALL[thShotLib.RED], 0.1F, 10, 2.0D + (double)level * 0.5D);
					attackCounter = 0;
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				break;
			case 1:
				if(attackCounter >= 46 - level * 8)
				{
					int shotType = thShotLib.SMALL[thShotLib.BLUE];
					if(level >= 3)
					{
						shotType = thShotLib.MEDIUM[thShotLib.BLUE];
					}
					thShotLib.createShot(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.3D, 0.3D, 1.0D, shotType, 3);
					attackCounter = 0;
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				break;
			case 2:
				if(attackCounter >= 50)
				{
					int shotType = thShotLib.SMALL[thShotLib.GREEN];
					if(level >= 4)
					{
						shotType = thShotLib.MEDIUM[thShotLib.GREEN];
					}
					thShotLib.createCircleShot(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.2D, 0.2D, 1.0D, shotType, 4 * level, 5);
					attackCounter = 0;
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				break;
			case 3:
				if(attackCounter >= 50)
				{
					thShotLib.createWideShot(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.2D, 0.2D, 1.0D, thShotLib.SCALE[thShotLib.YELLOW], 7, level * 3, 90);
					//thShotLib.createCircleShot01(this, angleXZ, angleY, 0.2D, shotType, 4 * level);
					attackCounter = 0;
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				break;
			case 4:
				if(attackCounter >= 40)
				{
					int num = 10 + level * 6;
					int colorBase = thShotLib.SMALL[0];
					if(level == 3)
					{
						colorBase = thShotLib.MEDIUM[0];
					}
					else if(level >= 4)
					{
						colorBase = thShotLib.BIG[0];
					}
					for(int i = 0; i < num; i++)
					{
						float angleXZ2 = rand.nextFloat() * 360F;
						float angleY2 = rand.nextFloat() * 360F;
						thShotLib.createShot(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ2, angleY2, 0.1D * level, 0.1D * level, 1.0D, colorBase + rand.nextInt(7), 10);
					}
					//thShotLib.createCircleShot01(this, angleXZ, angleY, 0.2D, shotType, 4 * level);
					attackCounter = 0;
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				break;
			case 5:
				if(attackCounter >= 70)
				{
					thShotLib.createWideLaserA  (this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.01D, 0.2D + (double)level * 0.05, 0.02D, 2.0F, thShotLib.GREEN, 0.1F, 10, 1.6 + level * 0.3D, 1 + level, 120F);
					//thShotLib.createCircleLaserA02(this, angleXZ, angleY, 0.01D, 0.2D + (double)level * 0.05, 0.02D, 2.0F, thShotLib.AQUA,  0.1F, 10, 1.6 + level * 0.3D, 3 + level);
					attackCounter = 0;
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				break;
			case 6:
				if(attackCounter >= 60)
				{
					thShotLib.createRingShot(this, this, this.posX, thShotLib.getPosYFromEye(this), this.posZ, look.xCoord, look.yCoord, look.zCoord, 0.0F, 0.1 + level * 0.1D, 0.1 + level * 0.1D, 0.0D, 0.0D, 0.0D, 0.0D, 3.0F, thShotLib.SMALL[thShotLib.RED], thShotLib.SIZE[thShotLib.SMALL[0] / 8], 120, 2, 0, 3 + level * 2, 0.0D, 30F, rand.nextFloat() * 360F);
					attackCounter = 0;
					thShotLib.playShotSound(this);
				}
				break;
			case 7:
				if(attackCounter >= 50)
				{
					thShotLib.createWideShot(this, this, this.posX, thShotLib.getPosYFromEye(this), this.posZ, rotationYaw, -20F - rand.nextFloat() * 30F , 0.3F + level * 0.1D, 0.3F + level * 0.1D, 0.0D, 0.0D, -0.03D, 0.0D, thShotLib.DAMAGE[thShotLib.KUNAI[0] / 8], thShotLib.KUNAI[thShotLib.BLUE], thShotLib.SIZE[thShotLib.KUNAI[0] / 8], 120, 3, 0, 1 + level, 12F + level * 2F, 0.0D);
					attackCounter = 0;
					thShotLib.playShotSound(this);
				}
				break;
			case 8:
				if(attackCounter >= 100)
				{
					thShotLib.createLaserB(this, this, posX, posY, posZ, look.xCoord, look.yCoord, look.zCoord, 0.0D, 0.0D, 0.0D, 0.0F, 3.0F, thShotLib.GREEN, 0.2F + level * 0.1F, 10, 60, 0, 5.0D + level * 5D, this, 0.3D, 1.3D);
					attackCounter = 0;
				}
				break;
			default:
				break;
		}
    }
    
    //敵との間に取る間合いを返す
    protected double getAttackDistance()
    {
    	return getFairyType() >= 0 ? 8.0D : 2.0D;
    }
    
    //近づいたら妖精が敵対化する距離を返す
    protected double getDetectionDistance()
    {
    	return 8.0D;
    }
    
    //周りの妖精を呼び出すことができるか
    protected boolean canFairyCall()
    {
    	return true;
    }
    
    //妖精を呼び出せる最大距離
    protected double getFairyCallDistance()
    {
    	return 30.0D;
    }

    protected void updateAITasks()
    {
        super.updateAITasks();

        /*if (this.getIsTHFairyHanging())
        {
            if (!this.worldObj.isBlockNormalCube(MathHelper.floor_double(this.posX), (int)this.posY + 1, MathHelper.floor_double(this.posZ)))
            {
                this.setIsTHFairyHanging(false);
                this.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1015, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
            }
            else
            {
                if (this.rand.nextInt(200) == 0)
                {
                    this.rotationYawHead = (float)this.rand.nextInt(360);
                }

                if (this.worldObj.getClosestPlayerToEntity(this, 0.5D) != null)
                {
                    this.setIsTHFairyHanging(false);
                    this.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1015, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
                }
            }
        }
        else
        {
            if (this.currentFlightTarget != null && (!this.worldObj.isAirBlock(this.currentFlightTarget.posX, this.currentFlightTarget.posY, this.currentFlightTarget.posZ) || this.currentFlightTarget.posY < 1))
            {
                this.currentFlightTarget = null;
            }

            if (this.currentFlightTarget == null || this.rand.nextInt(30) == 0 || this.currentFlightTarget.getDistanceSquared((int)this.posX, (int)this.posY, (int)this.posZ) < 4.0F)
            {
                this.currentFlightTarget = new ChunkCoordinates((int)this.posX + this.rand.nextInt(7) - this.rand.nextInt(7), (int)this.posY + this.rand.nextInt(6) - 2, (int)this.posZ + this.rand.nextInt(7) - this.rand.nextInt(7));
            }

            double var1 = (double)this.currentFlightTarget.posX + 0.5D - this.posX;
            double var3 = (double)this.currentFlightTarget.posY + 0.1D - this.posY;
            double var5 = (double)this.currentFlightTarget.posZ + 0.5D - this.posZ;
            this.motionX += (Math.signum(var1) * 0.5D - this.motionX) * 0.10000000149011612D;
            this.motionY += (Math.signum(var3) * 0.699999988079071D - this.motionY) * 0.10000000149011612D;
            this.motionZ += (Math.signum(var5) * 0.5D - this.motionZ) * 0.10000000149011612D;
            float var7 = (float)(Math.atan2(this.motionZ, this.motionX) * 180.0D / Math.PI) - 90.0F;
            float var8 = MathHelper.wrapAngleTo180_float(var7 - this.rotationYaw);
            this.moveForward = 0.5F;
            this.rotationYaw += var8;

            if (this.rand.nextInt(100) == 0 && this.worldObj.isBlockNormalCube(MathHelper.floor_double(this.posX), (int)this.posY + 1, MathHelper.floor_double(this.posZ)))
            {
                this.setIsTHFairyHanging(true);
            }
        }*/
    }
	
	private boolean isCourseTraversable(double par1, double par3, double par5, double par7)
    {
        double d4 = (this.waypointX - this.posX) / par7;
        double d5 = (this.waypointY - this.posY) / par7;
        double d6 = (this.waypointZ - this.posZ) / par7;
        AxisAlignedBB axisalignedbb = this.boundingBox.copy();

        for (int i = 1; (double)i < par7; ++i)
        {
            axisalignedbb.offset(d4, d5, d6);

            if (!this.worldObj.getCollidingBoundingBoxes(this, axisalignedbb).isEmpty())
            {
                return false;
            }
        }

        return true;
    }
	
	//倒れたときに落とすアイテム
    protected int getDropItemId()
    {
    	if(getFairyType() < 0)
    	{
    		return 0;
    	}
    	else
    	{
    		return mod_thKaguya.powerItem.itemID;
    	}
        
    }
	
	//倒れたときに落とすアイテム
	protected void dropFewItems(boolean par1, int par2)
    {
		if(getFairyType() < 0)
		{
			return;
		}
        int j = this.rand.nextInt(5) + this.rand.nextInt(1 + par2);
        int k;


        ItemStack shot = new ItemStack(mod_thKaguya.thShotItem.itemID, rand.nextInt(2), 0);
	        
	    NBTTagCompound nbt = shot.getTagCompound();
		if(nbt == null)
		{
			nbt = new NBTTagCompound();
			nbt.setShort("shotNum", (short)3);
		    nbt.setByte("danmakuForm", (byte)2);
		   	shot.setTagCompound(nbt);
        }

	    this.entityDropItem(shot, 0.0F);
        
        for (k = 0; k < j; ++k)
        {
            this.dropItem(mod_thKaguya.powerItem.itemID, 1);
        }

        j = this.rand.nextInt(5) + this.rand.nextInt(1 + par2);

        for (k = 0; k < j; ++k)
        {
            this.dropItem(mod_thKaguya.pointItem.itemID, 1);
        }
    }

    //感圧板に乗ったときに押されるかどうか（？）
    protected boolean canTriggerWalking()
    {
        return false;
    }

    //落下したときに呼ばれる。落下ダメージなど
    protected void fall(float par1) {}

    /**
     * Takes in the distance the entity has fallen this tick and whether its on the ground to update the fall distance
     * and deal fall damage if landing on the ground.  Args: distanceFallenThisTick, onGround
     */
    //protected void updateFallState(double par1, boolean par3) {}

    /**
     * Return whether this entity should NOT trigger a pressure plate or a tripwire.
     */
    public boolean doesEntityNotTriggerPressurePlate()
    {
        return true;
    }

    /**
     * Called when the entity is attacked.
     */
    /*public boolean attackEntityFrom(DamageSource par1DamageSource, int par2)
    {
        if (this.func_85032_ar())
        {
            return false;
        }
        else
        {
            if (!this.worldObj.isRemote && this.getIsBatHanging())
            {
                this.setIsBatHanging(false);
            }

            return super.attackEntityFrom(par1DamageSource, par2);
        }
    }*/

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound nbtTagCompound)
    {
        super.readEntityFromNBT(nbtTagCompound);
        //this.dataWatcher.updateObject(16, Byte.valueOf(nbtTagCompound.getByte("BatFlags")));
        this.dataWatcher.updateObject(16, Byte.valueOf(nbtTagCompound.getByte("fairyType")));
    	//setFairyType(nbtTagCompound.getByte("fairyType"));
    	
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound nbtTagCompound)
    {
        super.writeEntityToNBT(nbtTagCompound);
        //nbtTagCompound.setByte("BatFlags", this.dataWatcher.getWatchableObjectByte(16));
        nbtTagCompound.setByte("fairyType", this.dataWatcher.getWatchableObjectByte(16));
    	//nbtTagCompound.setByte("fairyType", (byte)getFairyType());
    	
    }
    
    //一つのチャンクに湧く最大数
    public int getMaxSpawnedInChunk()
    {
        return 10;
    }

	//自然スポーンするときに呼ばれる。tureならスポーンする
    public boolean getCanSpawnHere()
    {
    	//妖精のスポーンレートよりランダム値が低いならスポーンしない
    	if(rand.nextInt(100) < mod_thKaguya.fairySpawnRate)
    	{
    		return false;
    	}
    	
    	
    	
        int yPosition = MathHelper.floor_double(this.boundingBox.minY);
    	int xPosition = MathHelper.floor_double(this.posX);
        int zPosition = MathHelper.floor_double(this.posZ);
        
        if(worldObj.getSavedLightValue(EnumSkyBlock.Sky, xPosition, yPosition, zPosition) - worldObj.skylightSubtracted <= 7)
        {
        	return false;
        }
        
    	int pointBlock = worldObj.getBlockId(xPosition, yPosition - 1, zPosition);
    	//地面が草ブロックか土ブロックか砂ブロックならスポーンする
    	if(pointBlock == Block.grass.blockID || pointBlock == Block.dirt.blockID || pointBlock == Block.sand.blockID)
    	{
    		return true;
    	}
    	return false;
    }
    
    //スペルカードを宣言するモーションを始める
    protected void setSpellCardAttack()
    {
    	setFairySpellCardMotion((byte)-30);
    }
    
  //妖精のタイプを返す
    public byte getFairyType()
    {
    	return dataWatcher.getWatchableObjectByte(16);
    }

    //妖精のタイプを設定
    public void setFairyType(byte type)
    {
    	dataWatcher.updateObject(16, Byte.valueOf(type));
    }
    
    //妖精の攻撃モーションを返す
    public byte getFairyAttackMotion()
    {
    	return dataWatcher.getWatchableObjectByte(17);
    }
    
    //妖精の攻撃モーションを設定
    public void setFairyAttackMotion(byte motion)
    {
    	dataWatcher.updateObject(17, Byte.valueOf(motion));
    }
    
    //妖精のスペルカード宣言モーションを返す
    public byte getFairySpellCardMotion()
    {
    	return dataWatcher.getWatchableObjectByte(18);
    }
    
    //妖精のスペルカード宣言モーションを設定
    public void setFairySpellCardMotion(byte motion)
    {
    	dataWatcher.updateObject(18, Byte.valueOf(motion));
    }

    /**
     * Initialize this creature.
     */
    public void initCreature() {}
}



