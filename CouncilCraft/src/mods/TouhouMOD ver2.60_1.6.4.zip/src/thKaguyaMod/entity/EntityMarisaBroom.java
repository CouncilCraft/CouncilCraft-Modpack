package thKaguyaMod.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

import thKaguyaMod.mod_thKaguya;

public class EntityMarisaBroom extends Entity
{
    private boolean field_70279_a;
    private double speedMultiplier;
    private int boatPosRotationIncrements;
    private double broomX;
    private double broomY;
    private double broomZ;
    private double broomYaw;
    private double broomPitch;
    @SideOnly(Side.CLIENT)
    private double velocityX;
    @SideOnly(Side.CLIENT)
    private double velocityY;
    @SideOnly(Side.CLIENT)
    private double velocityZ;

    public EntityMarisaBroom(World world)
    {
        super(world);
        this.field_70279_a = true;
        this.speedMultiplier = 0.07D;
        this.preventEntitySpawning = true;
        this.setSize(0.9F, 0.5F);
        this.yOffset = 0.8F;
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    protected void entityInit()
    {
        this.dataWatcher.addObject(17, new Integer(0));
        this.dataWatcher.addObject(18, new Integer(1));
        this.dataWatcher.addObject(19, new Float(0.0F));
    }

    /**
     * Returns a boundingBox used to collide the entity with other entities and blocks. This enables the entity to be
     * pushable on contact, like boats or minecarts.
     */
    public AxisAlignedBB getCollisionBox(Entity par1Entity)
    {
        return par1Entity.boundingBox;
    }

    /**
     * returns the bounding box for this entity
     */
    public AxisAlignedBB getBoundingBox()
    {
        return this.boundingBox;
    }

    /**
     * Returns true if this entity should push and be pushed by other entities when colliding.
     */
    public boolean canBePushed()
    {
        return true;
    }

    public EntityMarisaBroom(World par1World, double par2, double par4, double par6)
    {
        this(par1World);
        this.setPosition(par2, par4 + (double)this.yOffset, par6);
        this.motionX = 0.0D;
        this.motionY = 0.0D;
        this.motionZ = 0.0D;
        this.prevPosX = par2;
        this.prevPosY = par4;
        this.prevPosZ = par6;
    }

	//魔理沙の箒に乗っているEntityが乗る高さを返す
    public double getMountedYOffset()
    {
        return  0.05D;
    }

	//Entityに攻撃されたときに呼ばれる
    public boolean attackEntityFrom(DamageSource par1DamageSource, float par2)
    {
        if (this.isEntityInvulnerable())
        {
            return false;
        }
        else if (!this.worldObj.isRemote && !this.isDead)
        {
            this.setForwardDirection(-this.getForwardDirection());
            this.setTimeSinceHit(10);
            this.setDamageTaken(this.getDamageTaken() + par2 * 10F);
            this.setBeenAttacked();
            boolean flag = par1DamageSource.getEntity() instanceof EntityPlayer && ((EntityPlayer)par1DamageSource.getEntity()).capabilities.isCreativeMode;

            if (flag || this.getDamageTaken() > 40)//相手がプレイヤーでクリエイティブ、または、４以上のダメージを受けているなら
            {
                if (this.riddenByEntity != null)
                {
                    this.riddenByEntity.mountEntity(this);
                }

                if (!flag)
                {
                    this.dropItemWithOffset(mod_thKaguya.marisaBroomItem.itemID, 1, 0.0F);
                }

                this.setDead();
            }

            return true;
        }
        else
        {
            return true;
        }
    }

    @SideOnly(Side.CLIENT)

	//攻撃された時のアニメーション関連
    public void performHurtAnimation()
    {
        this.setForwardDirection(-this.getForwardDirection());
        this.setTimeSinceHit(10);
        this.setDamageTaken(this.getDamageTaken() * 11);
    }

	//触れることができるかどうか
    public boolean canBeCollidedWith()
    {
        return !this.isDead;
    }

    @SideOnly(Side.CLIENT)

    /**
     * Sets the position and rotation. Only difference from the other one is no bounding on the rotation. Args: posX,
     * posY, posZ, yaw, pitch
     */
    public void setPositionAndRotation2(double par1, double par3, double par5, float par7, float par8, int par9)
    {
        if (this.field_70279_a)
        {
            this.boatPosRotationIncrements = par9 + 5;
        }
        else
        {
            double d3 = par1 - this.posX;
            double d4 = par3 - this.posY;
            double d5 = par5 - this.posZ;
            double d6 = d3 * d3 + d4 * d4 + d5 * d5;

            if (d6 <= 1.0D)
            {
                return;
            }

            this.boatPosRotationIncrements = 3;
        }

        this.broomX = par1;
        this.broomY = par3;
        this.broomZ = par5;
        this.broomYaw = (double)par7;
        this.broomPitch = (double)par8;
        this.motionX = this.velocityX;
        this.motionY = this.velocityY;
        this.motionZ = this.velocityZ;
    }

    @SideOnly(Side.CLIENT)

	//ベクトルを設定
    public void setVelocity(double x, double y, double z)
    {
        this.velocityX = this.motionX = x;
        this.velocityY = this.motionY = y;
        this.velocityZ = this.motionZ = z;
    }

	//毎フレーム呼ばれる
    public void onUpdate()
    {
        super.onUpdate();

    	//ダメージアニメーション関連
        if (this.getTimeSinceHit() > 0)
        {
            this.setTimeSinceHit(this.getTimeSinceHit() - 1);
        }

        if (this.getDamageTaken() > 0)
        {
            this.setDamageTaken(this.getDamageTaken() - 1);
        }
    	
		//前のポジションを今のポジションにする
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
    	
        byte b0 = 5;
        double d0 = 0.0D;

        for (int i = 0; i < b0; ++i)
        {
            double d1 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(i + 0) / (double)b0 - 0.125D;
            double d2 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(i + 1) / (double)b0 - 0.125D;
            AxisAlignedBB axisalignedbb = AxisAlignedBB.getAABBPool().getAABB(this.boundingBox.minX, d1, this.boundingBox.minZ, this.boundingBox.maxX, d2, this.boundingBox.maxZ);

            if (this.worldObj.isAABBInMaterial(axisalignedbb, Material.water))
            {
                d0 += 1.0D / (double)b0;
            }
        }

        double motionXZ = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);//平面方向の移動量
        double cos_yaw_rad;//d4
        double sin_yaw_rad;//d5

    	//水しぶきを発生させる処理
        /*if (motionXZ > 0.26249999999999996D)//一定の移動量があるなら
        {
            cos_yaw_rad = Math.cos((double)this.rotationYaw * Math.PI / 180.0D);
            sin_yaw_rad = Math.sin((double)this.rotationYaw * Math.PI / 180.0D);

            for (int j = 0; (double)j < 1.0D + d3 * 60.0D; ++j)
            {
                double d6 = (double)(this.rand.nextFloat() * 2.0F - 1.0F);
                double d7 = (double)(this.rand.nextInt(2) * 2 - 1) * 0.7D;
                double d8;
                double d9;

                if (this.rand.nextBoolean())
                {
                    d8 = this.posX - cos_yaw_rad * d6 * 0.8D + sin_yaw_rad * d7;
                    d9 = this.posZ - sin_yaw_rad * d6 * 0.8D - cos_yaw_rad * d7;
                    this.worldObj.spawnParticle("splash", d8, this.posY - 0.125D, d9, this.motionX, this.motionY, this.motionZ);
                }
                else
                {
                    d8 = this.posX + cos_yaw_rad + sin_yaw_rad * d6 * 0.7D;
                    d9 = this.posZ + sin_yaw_rad - cos_yaw_rad * d6 * 0.7D;
                    this.worldObj.spawnParticle("splash", d8, this.posY - 0.125D, d9, this.motionX, this.motionY, this.motionZ);
                }
            }
        }*/

        double d10;
        double d11;

        if (this.worldObj.isRemote && this.field_70279_a)
        {
        	//箒の回転増加量が０より大きいなら
            if (this.boatPosRotationIncrements > 0)
            {
            	
                double x_increments = this.posX + (this.broomX - this.posX) / (double)this.boatPosRotationIncrements;
                double y_increments = this.posY + (this.broomY - this.posY) / (double)this.boatPosRotationIncrements;
                double z_increments = this.posZ + (this.broomZ - this.posZ) / (double)this.boatPosRotationIncrements;
                d10 = MathHelper.wrapAngleTo180_double(this.broomYaw - (double)this.rotationYaw);
                this.rotationYaw = (float)((double)this.rotationYaw + d10 / (double)this.boatPosRotationIncrements);
                this.rotationPitch = (float)((double)this.rotationPitch + (this.broomPitch - (double)this.rotationPitch) / (double)this.boatPosRotationIncrements);
                --this.boatPosRotationIncrements;
                this.setPosition(x_increments, y_increments, z_increments);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }
        	//０より小さいなら
            else
            {
                double x_increments = this.posX + this.motionX;
                double y_increments = this.posY + this.motionY;
                double z_increments = this.posZ + this.motionZ;
                this.setPosition(x_increments, y_increments, z_increments);

                if (this.onGround)//地面の上なら
                {
                	//移動量を半減する
                    this.motionX *= 0.5D;
                    this.motionY *= 0.5D;
                    this.motionZ *= 0.5D;
                }

                this.motionX *= 0.9900000095367432D;
                this.motionY *= 0.949999988079071D;
                this.motionZ *= 0.9900000095367432D;
            }
        }
        else
        {
            if (d0 < 1.0D)
            {
                double d4 = d0 * 2.0D - 1.0D;
                //this.motionY += 0.03999999910593033D * d4;
            }
            else
            {
                /*if (this.motionY < 0.0D)//下降気味なら
                {
                    this.motionY /= 2.0D;//下降速度を半減
                }

                this.motionY += 0.007000000216066837D;//若干浮遊させる
            */}

        	//Entityが乗っているなら
            if (this.riddenByEntity != null)
            {
            	float pitch = riddenByEntity.rotationPitch;// * 3F;
            	rotationPitch = pitch;

            	/*if(pitch < 30F && pitch > -30F)
            	{
            		pitch = 0F;
            	}*/
            	if(pitch > 90F)
            	{
            		pitch = 90F;
            	}
            	else if(pitch < -90F)
            	{
            		pitch = -90F;
            	}
            	//Entityの移動量に箒の移動量を合わす
            	motionX -=  Math.sin(riddenByEntity.rotationYaw / 180F * 3.141593F) * speedMultiplier * 0.6D;
            	motionZ +=  Math.cos(riddenByEntity.rotationYaw / 180F * 3.141593F) * speedMultiplier * 0.6D;
            	motionY = -Math.sin(pitch / 180F * 3.141593F) * speedMultiplier * 1.0D;
            	if(pitch < 0F)
            	{
            		pitch *= 0.1F;
            	}
            	//motionY += 3.3D;
            	//motionY = -Math.sin(pitch / 180F * 3.141593F) * speedMultiplier * 9.2D;
                //this.motionX += this.riddenByEntity.motionX * this.speedMultiplier;
                //this.motionZ += this.riddenByEntity.motionZ * this.speedMultiplier;
            	//motionX = riddenByEntity.motionX * 1.2D;
            	//motionZ = riddenByEntity.motionZ * 1.2D;
                //motionY += 0.1D;
            	/*if(riddenByEntity instanceof EntityPlayer)
            	{
            		EntityPlayer player = (EntityPlayer)riddenByEntity;
	            	if(player.jumpMovementFactor > 0.0F)
	            	{
	            		riddenByEntity.motionY += 0.07D;
	            	}
            	}*/
            }
            

            double thisMotionXZ = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);

            if (motionXZ > 0.35D)//一定の水平移動量があるなら
            {
                double motionXZ_rate = 0.35D / motionXZ;
                this.motionX *= motionXZ_rate;//一定の速度を超えないように移動量を制限
                this.motionZ *= motionXZ_rate;
                motionXZ = 0.35D;
            }

            if (thisMotionXZ > motionXZ && this.speedMultiplier < 0.35D)
            {
                this.speedMultiplier += (0.35D - this.speedMultiplier) / 35.0D;

                if (this.speedMultiplier > 0.35D)
                {
                    this.speedMultiplier = 0.35D;
                }
            }
            else
            {
                this.speedMultiplier -= (this.speedMultiplier - 0.07D) / 35.0D;

                if (this.speedMultiplier < 0.07D)
                {
                    this.speedMultiplier = 0.07D;
                }
            }

            /*if (this.onGround)
            {
                this.motionX *= 0.5D;
                this.motionY *= 0.5D;
                this.motionZ *= 0.5D;
            }*/
            if(this.inWater)
            {
            	motionX *= 0.5D;
            	motionY *= 0.5D;
            	motionZ *= 0.5D;
            }

            this.moveEntity(this.motionX, this.motionY, this.motionZ);

            /*if (this.isCollidedHorizontally && motionXZ > 0.2D)
            {
                if (!this.worldObj.isRemote && !this.isDead)
                {
                    this.setDead();
                    int k;

                    for (k = 0; k < 3; ++k)
                    {
                        this.dropItemWithOffset(Block.planks.blockID, 1, 0.0F);
                    }

                    for (k = 0; k < 2; ++k)
                    {
                        this.dropItemWithOffset(Item.stick.itemID, 1, 0.0F);
                    }
                }
            }
            else*/
            {
                this.motionX *= 0.9900000095367432D;
                this.motionY *= 0.949999988079071D;
                this.motionZ *= 0.9900000095367432D;
            }

        	//角度の修正********
            //this.rotationPitch = 0.0F;//垂直角度は常に一定で動かない
            double thisYaw = (double)this.rotationYaw;
            /*d11*/double prevXtoX = this.prevPosX - this.posX;
            /*d10*/double prevZtoZ = this.prevPosZ - this.posZ;

            if (prevXtoX * prevXtoX + prevZtoZ * prevZtoZ > 0.001D)//少しでも動いているなら
            {
                thisYaw = (double)((float)(Math.atan2(prevZtoZ, prevXtoX) * 180.0D / Math.PI));
            }

            double d12 = MathHelper.wrapAngleTo180_double(thisYaw - (double)this.rotationYaw);

            if (d12 > 20.0D)
            {
                d12 = 20.0D;
            }

            if (d12 < -20.0D)
            {
                d12 = -20.0D;
            }

            this.rotationYaw = (float)((double)this.rotationYaw + d12);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        	//*******************

            if (!this.worldObj.isRemote)
            {
                List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.20000000298023224D, 0.0D, 0.20000000298023224D));
                int l;

                if (list != null && !list.isEmpty())
                {
                    for (l = 0; l < list.size(); ++l)
                    {
                        Entity entity = (Entity)list.get(l);

                        if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof EntityMarisaBroom)
                        {
                            entity.applyEntityCollision(this);
                        }
                    }
                }

                /*for (l = 0; l < 4; ++l)
                {
                    int i1 = MathHelper.floor_double(this.posX + ((double)(l % 2) - 0.5D) * 0.8D);
                    int j1 = MathHelper.floor_double(this.posZ + ((double)(l / 2) - 0.5D) * 0.8D);

                    for (int k1 = 0; k1 < 2; ++k1)
                    {
                        int l1 = MathHelper.floor_double(this.posY) + k1;
                        int i2 = this.worldObj.getBlockId(i1, l1, j1);//箒のいる場所のブロックIDを取得

                        if (i2 == Block.snow.blockID)//雪に衝突したなら
                        {
                            this.worldObj.setBlockToAir(i1, l1, j1);//空気ブロックに入れ替える
                        }
                        else if (i2 == Block.waterlily.blockID)//蓮に衝突したなら
                        {
                            this.worldObj.destroyBlock(i1, l1, j1, true);//蓮を破壊し、蓮をアイテム化する
                        }
                    }
                }*/

            	//乗っているEntityがおり、それが死んでいるなら
                if (this.riddenByEntity != null && this.riddenByEntity.isDead)
                {
                    this.riddenByEntity = null;//乗っているEntityをいないことにする
                }
                else
                {
                	//riddenByEntity.fallDistance = 0.0F;
                }
                if(this.riddenByEntity != null)
                {
                	riddenByEntity.fallDistance = 0.0F;
                	fallDistance = 0.0F;
                }
                else
                {
                	motionX *= 0.9D;
                	motionY -= 0.03D;
                	motionZ *= 0.9D;
                	if(rotationPitch > 1.0F)
                	{
                		rotationPitch--;
                	}
                	else if(rotationPitch < -1.0F)
                	{
                		rotationPitch++;
                	}
                	if(onGround)
                	{
                		motionY += 0.06D;
                	}
                }
            }
        }
    }

	//乗っているEntityの位置を更新
    public void updateRiderPosition()
    {
        if (this.riddenByEntity != null)
        {
        	//
            double d0 = Math.cos((double)this.rotationYaw * Math.PI / 180.0D) * 0.4D;
            double d1 = Math.sin((double)this.rotationYaw * Math.PI / 180.0D) * 0.4D;
            this.riddenByEntity.setPosition(this.posX + d0, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ + d1);
        }
    }

	//NBTに書き込む
    protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {}

	//NBTを読み込む
    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {}

    @SideOnly(Side.CLIENT)
    public float getShadowSize()
    {
        return 0.0F;
    }

	//プレイヤーに右クリックされたときに呼ばれる
    //public boolean interact(EntityPlayer entityPlayer)
	public boolean func_130002_c(EntityPlayer entityPlayer)
    {
        if (riddenByEntity != null && riddenByEntity instanceof EntityPlayer && riddenByEntity != entityPlayer)
        {
            return true;
        }
		else
    	{
        	if (!worldObj.isRemote)
        	{
            	entityPlayer.mountEntity(this);
        	}

        	return true;
    	}
    }

    /**
     * Sets the damage taken from the last hit.
     */
    public void setDamageTaken(float par1)
    {
        this.dataWatcher.updateObject(19, Float.valueOf(par1));
    }

    /**
     * Gets the damage taken from the last hit.
     */
    public float getDamageTaken()
    {
        return this.dataWatcher.func_111145_d(19);
    }

    /**
     * Sets the time to count down from since the last time entity was hit.
     */
    public void setTimeSinceHit(int par1)
    {
        this.dataWatcher.updateObject(17, Integer.valueOf(par1));
    }

    /**
     * Gets the time since the last hit.
     */
    public int getTimeSinceHit()
    {
        return this.dataWatcher.getWatchableObjectInt(17);
    }

    /**
     * Sets the forward direction of the entity.
     */
    public void setForwardDirection(int par1)
    {
        this.dataWatcher.updateObject(18, Integer.valueOf(par1));
    }

    /**
     * Gets the forward direction of the entity.
     */
    public int getForwardDirection()
    {
        return this.dataWatcher.getWatchableObjectInt(18);
    }

    @SideOnly(Side.CLIENT)
    public void func_70270_d(boolean par1)
    {
        this.field_70279_a = par1;
    }
}
