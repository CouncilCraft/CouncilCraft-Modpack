package thKaguyaMod.entity;

import java.util.Calendar;
import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityTHFairy;

public class EntityTHFairyCirno extends EntityTHFairy
{
    //チルノ
	public boolean isSpellCardMode;//スペルカードモードか
	
	private int attackInterval;
	
	private int random;
	
	public EntityTHFairyCirno(World world)
    {
        super(world);
        
        this.setSize(1.0F, 1.8F);//MOBの当たり判定の大きさ 横奥行き、高さ、大きさ
        setEntityHealth(40.0F);
    	yOffset = -0.2F;
    	experienceValue = 25;//経験値の量
    	//fairyType = 0;
    	setFairyType((byte)0);
    	
    	isSpellCardMode = false;
    	attackInterval = 0;
    	random = 0;
    }

    /*protected void entityInit()
    {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    	this.dataWatcher.addObject(17, new Byte((byte)0));
    }*/
    
    //Entityの属性の設定
    protected void func_110147_ax()
    {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(40.0D);//妖精の最大HPを2に設定
    }

    /**
     * Returns the volume for the sounds this mob makes.
     */
    protected float getSoundVolume()
    {
        return 0.3F;
    }

	//EntityLivingBaseの音のピッチ
    protected float getSoundPitch()
    {
        return super.getSoundPitch() * 1.95F;
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return this.rand.nextInt(4) != 0 ? null : "mob.bat.idle";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.bat.hurt";
    }

	//倒れたときの音
    protected String getDeathSound()
    {
        return "mob.bat.death";
    }

	//このEntityは押すことができるか？
    public boolean canBePushed()
    {
        return true;
    }

    protected void collideWithEntity(Entity par1Entity) {}

    protected void func_85033_bc() {}

	//MOBの体力
    /*public int getMaxHealth()
    {
        return 2;
    }*/
    
    /*@Override
    public final float func_110138_aP()
    {
    	return 2.0F;
    }*/

    /*public boolean getIsTHFairyHanging()
    {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }

    public void setIsTHFairyHanging(boolean par1)
    {
        byte var2 = this.dataWatcher.getWatchableObjectByte(16);

        if (par1)
        {
            this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 | 1)));
        }
        else
        {
            this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 & -2)));
        }
    }*/

    /**
     * Returns true if the newer Entity AI code should be run
     */
    /*protected boolean isAIEnabled()
    {
        return true;
    }*/
    
    //死んでいるときに呼ばれる
    protected void onDeathUpdate()
    {
    	if(getFairyType() == 0)
    	{
    		
    		moveFairyAttack(1, 40, 60.0F, 20);
    	}
    	else if(getFairyType() == 1)
    	{
    		//if(attackCounter == -20)setSpellCardAttack();
    		moveFairyAttack(2, 90, 40.0F, 10);
    		
    	}
    	else if(getFairyType() == 2)
    	{
    		
    		moveFairyAttack(3, 40, 75.0F, 20);
    		
    	}
    	else if(getFairyType() == 3)
    	{
    		moveFairyAttack(4, 30, 0F, 10);
    	}
    	else
    	{
    		super.onDeathUpdate();
    	}
    }
    
    //妖精の攻撃を次の段階に移す処理
    protected void moveFairyAttack(int nextPattern, int interval, float maxHP, int invincibleTime)
    {
        for (int j = 0; j < 3; ++j)
        {
            this.worldObj.spawnParticle("mobSpell", this.posX + this.rand.nextGaussian() * 1.0D, this.posY + (double)(this.rand.nextFloat() * 3.3F), this.posZ + this.rand.nextGaussian() * 1.0D, 0.699999988079071D, 0.699999988079071D, 0.8999999761581421D);
        }
		setFairyType((byte)nextPattern);
		attackCounter = -interval;
		deathTime = 0;
		if(!worldObj.isRemote)
		{
			this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(maxHP);//妖精の最大HPを2に設定
			setEntityHealth(maxHP);
		}
		attackInterval = invincibleTime;
		thShotLib.danmakuRemove(this, 40.0D, "Enemy", true);
		isSpellCardMode = false;
    }
    
	//常時呼ばれる
    public void onUpdate()
    {
    	super.onUpdate();
    	
    	if(attackInterval > 0)
    	{
    		attackInterval--;
    	}
    	if(getFairyType() == 1 || getFairyType() == 3)
    	{
    		if(attackCounter == -20)setSpellCardAttack();
    	}
    }

    
    //@Override
    public void danmakuPattern(int level, float angleXZ, float angleY)
    {
    	Vec3 look;
		switch(getFairyType())
		{
			case 0:
				if(attackCounter == 40)
				{
					look = this.getLookVec();
					for(int i = 0; i < 7; i++)
					{
						thShotLib.createRingShot(this, this, this.posX, thShotLib.getPosYFromEye(this), this.posZ, look.xCoord, look.yCoord, look.zCoord, 0F, 0.6D + level * 0.15D, 0.6D + level * 0.15D, 0.1D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.CRYSTAL[thShotLib.AQUA], 0.2F, 120, i, 0, i + 2, 0.0D, i * (level), rand.nextFloat() * 360F);
						//thShotLib.createWideShot(this, this, this.posX, thShotLib.getPosYFromEye(this,  -0.2D), this.posZ, angleXZ, angleY, 0.6D + level * 0.15D, 0.6D + level * 0.15D, 0.1D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.CRYSTAL[thShotLib.AQUA], 0.2F, 120, i, 0, i + 2, i * (level + 2), 0.3D);
						//thShotLib.createWideShot01(this, this.posX, this.posY /*+ thShotLib.getPosYFromEye(this, -0.2D)*/, this.posZ, this.rotationYaw, this.rotationPitch, 0.8D, thShotLib.CRYSTAL[thShotLib.AQUA], i, i * 5F);
					}
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				if(attackCounter >= 50)
				{
					attackCounter = 0;
				}
				break;
			case 1:
				if(attackCounter == 1)
				{
					thKaguyaLib.spellCardDeclaration(this.worldObj, this, this.targetedEntity, 19, level, !isSpellCardMode);
					if(!isSpellCardMode)
					{
						isSpellCardMode = true;
					}
				}
				else if(attackCounter > 30 && attackCounter % 17 == 0 && level >= 2)
				{
					float size = thShotLib.SIZE[thShotLib.SMALL[0] / 8];
					if(level >= 3)
					{
						size = thShotLib.SIZE[thShotLib.MEDIUM[0] / 8];
					}
					thShotLib.createWideShot(this, this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.3D + level * 0.1D, 0.5D, 1.0D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.SMALL[thShotLib.YELLOW], size, 120, 3, 0, 3, 70F, 0.2D);
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				else if(attackCounter >= 220)
				{
					attackCounter = 0;
				}
				break;
			case 2:
				if(attackCounter < 50 && attackCounter % 6 == 0)
				{
					thShotLib.createCircleShot(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.2D, thShotLib.TINY[thShotLib.WHITE], 5 + level * 2);
					thShotLib.createCircleShot(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.3D + level * 0.1D, thShotLib.CIRCLE[thShotLib.BLUE], 5 + level * 2);
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				else if(attackCounter == 55 || attackCounter == 65 || attackCounter == 75)
				{
					//thShotLib.createWideLaserA01(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.5D + (double)level * 0.1D, 6.0D, thShotLib.WHITE, 0.1F, 3.0D, 3, 30F);
					thShotLib.createWideLaserA(this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), posZ, angleXZ, angleY, 0.3D + level * 0.2D, 4.0F, thShotLib.WHITE, 0.1F, 4.0D, 3, 30F);
				}
				if(attackCounter > 98)
				{
					attackCounter = 0;
				}
				break;
			case 3:
				if(attackCounter == 1)
				{
					random = rand.nextInt(2);
					thKaguyaLib.spellCardDeclaration(this.worldObj, this, this.targetedEntity, 9, level, !isSpellCardMode);
					if(!isSpellCardMode)
					{
						isSpellCardMode = true;
					}
				}
				else if(attackCounter >= 70 && attackCounter <= 90 && attackCounter % 3 == 0)
				{
					int way = 4 + random;
					for(int i = 0; i < 3 + level; i++)
					{
						thShotLib.createWideShot(this, this, this.posX, thShotLib.getPosYFromEye(this, -0.2D), this.posZ, angleXZ, angleY, 0.3D + level * 0.1D, 0.5D, 1.0D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.CIRCLE[thShotLib.BLUE], 0.3F, 120, i, 0, way, 70F, 0.2D);
					}
					worldObj.playSoundAtEntity(this, "random.bow", 2.0F, 0.8F);//音を出す
				}
				else if(attackCounter >= 140)
				{
					attackCounter = 0;
				}
				break;
			default:
				break;
		}
    }
    
    //敵との間に取る間合いを返す
    @Override
    protected double getAttackDistance()
    {
    	return 14.0D;
    }
    
    //近づいたら妖精が敵対化する距離を返す
    @Override
    protected double getDetectionDistance()
    {
    	return 16.0D;
    }
    
    //周りの妖精を呼び出すことができるか
    @Override
    protected boolean canFairyCall()
    {
    	return false;//チルノは周りの妖精の助けを得ない
    }
    
    /**
     * Called when the entity is attacked.
     */
    public boolean attackEntityFrom(DamageSource par1DamageSource, float par2)
    {
    	//ノックバック耐性が高い
    	motionX *= 0.01D;
    	motionY *= 0.01D;
    	motionZ *= 0.01D;
    	
        if (this.isEntityInvulnerable())
        {
            return false;
        }
        else if (super.attackEntityFrom(par1DamageSource, par2) && par1DamageSource.getEntity() instanceof EntityLivingBase)
        {
            EntityLivingBase entity = (EntityLivingBase)par1DamageSource.getEntity();

            if (this.riddenByEntity != entity && this.ridingEntity != entity)
            {
                if (entity instanceof EntityPlayer)//entity != this)
                {
                    this.targetedEntity = entity;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }
    
    //無敵かどうかを返す
    public boolean isEntityInvulnerable()
    {
    	if(attackInterval > 0)
    	{
    		return true;
    	}
    	else
    	{
    		return super.isEntityInvulnerable();
    	}
    }

    protected void updateAITasks()
    {
        super.updateAITasks();

        /*if (this.getIsTHFairyHanging())
        {
            if (!this.worldObj.isBlockNormalCube(MathHelper.floor_double(this.posX), (int)this.posY + 1, MathHelper.floor_double(this.posZ)))
            {
                this.setIsTHFairyHanging(false);
                this.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1015, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
            }
            else
            {
                if (this.rand.nextInt(200) == 0)
                {
                    this.rotationYawHead = (float)this.rand.nextInt(360);
                }

                if (this.worldObj.getClosestPlayerToEntity(this, 0.5D) != null)
                {
                    this.setIsTHFairyHanging(false);
                    this.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1015, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
                }
            }
        }
        else
        {
            if (this.currentFlightTarget != null && (!this.worldObj.isAirBlock(this.currentFlightTarget.posX, this.currentFlightTarget.posY, this.currentFlightTarget.posZ) || this.currentFlightTarget.posY < 1))
            {
                this.currentFlightTarget = null;
            }

            if (this.currentFlightTarget == null || this.rand.nextInt(30) == 0 || this.currentFlightTarget.getDistanceSquared((int)this.posX, (int)this.posY, (int)this.posZ) < 4.0F)
            {
                this.currentFlightTarget = new ChunkCoordinates((int)this.posX + this.rand.nextInt(7) - this.rand.nextInt(7), (int)this.posY + this.rand.nextInt(6) - 2, (int)this.posZ + this.rand.nextInt(7) - this.rand.nextInt(7));
            }

            double var1 = (double)this.currentFlightTarget.posX + 0.5D - this.posX;
            double var3 = (double)this.currentFlightTarget.posY + 0.1D - this.posY;
            double var5 = (double)this.currentFlightTarget.posZ + 0.5D - this.posZ;
            this.motionX += (Math.signum(var1) * 0.5D - this.motionX) * 0.10000000149011612D;
            this.motionY += (Math.signum(var3) * 0.699999988079071D - this.motionY) * 0.10000000149011612D;
            this.motionZ += (Math.signum(var5) * 0.5D - this.motionZ) * 0.10000000149011612D;
            float var7 = (float)(Math.atan2(this.motionZ, this.motionX) * 180.0D / Math.PI) - 90.0F;
            float var8 = MathHelper.wrapAngleTo180_float(var7 - this.rotationYaw);
            this.moveForward = 0.5F;
            this.rotationYaw += var8;

            if (this.rand.nextInt(100) == 0 && this.worldObj.isBlockNormalCube(MathHelper.floor_double(this.posX), (int)this.posY + 1, MathHelper.floor_double(this.posZ)))
            {
                this.setIsTHFairyHanging(true);
            }
        }*/
    }
	
	private boolean isCourseTraversable(double par1, double par3, double par5, double par7)
    {
        double d4 = (this.waypointX - this.posX) / par7;
        double d5 = (this.waypointY - this.posY) / par7;
        double d6 = (this.waypointZ - this.posZ) / par7;
        AxisAlignedBB axisalignedbb = this.boundingBox.copy();

        for (int i = 1; (double)i < par7; ++i)
        {
            axisalignedbb.offset(d4, d5, d6);

            if (!this.worldObj.getCollidingBoundingBoxes(this, axisalignedbb).isEmpty())
            {
                return false;
            }
        }

        return true;
    }
	
	//倒れたときに落とすアイテム
    protected int getDropItemId()
    {
        return mod_thKaguya.icicleSwordItem.itemID;
    }
	
	//倒れたときに落とすアイテム
	protected void dropFewItems(boolean par1, int par2)
    {
		if(getFairyType()== 1 || getFairyType() == 3)
		{
	        int j = 12;//this.rand.nextInt(15) + this.rand.nextInt(1 + par2);
	        int k;
	        EntityItem item;
	        Vec3 vec3;
	
	        for (k = 0; k < j; ++k)
	        {
	            item = this.dropItem(mod_thKaguya.powerItem.itemID, 1);
	            item.rotationYaw = k * 30F;
	            item.rotationPitch = -60F;
	            vec3 = thShotLib.getVecFromAngle(item.rotationYaw, item.rotationPitch, 0.5F);
	            item.setPosition(item.posX + vec3.xCoord * 2.0D, item.posY, item.posZ + vec3.zCoord * 2.0D);
	            
	            item.motionX = vec3.xCoord;
	            item.motionY = vec3.yCoord;
	            item.motionZ = vec3.zCoord;
	        }
	
	        for (k = 0; k < j; ++k)
	        {
	            item = this.dropItem(mod_thKaguya.pointItem.itemID, 1);
	            item.rotationYaw = k * 30F + 15F;
	            item.rotationPitch = -60F;
	            vec3 = thShotLib.getVecFromAngle(item.rotationYaw, item.rotationPitch, 0.3F);
	            item.setPosition(item.posX + vec3.xCoord * 2.0D, item.posY, item.posZ + vec3.zCoord * 2.0D);
	            
	            item.motionX = vec3.xCoord;
	            item.motionY = vec3.yCoord;
	            item.motionZ = vec3.zCoord;
	        }
		}
        
        if(getFairyType() == 1)
        {
        	//this.dropItem(mod_thKaguya.spellCardItem.itemID, 19);
        	this.entityDropItem(new ItemStack(mod_thKaguya.spellCardItem.itemID, 1, 19), 0.0F);
        }
        if(getFairyType() == 3)
        {
        	this.dropItem(mod_thKaguya.icicleSwordItem.itemID, 1);
        	//this.dropItem(mod_thKaguya.spellCardItem.itemID, 9);
        	this.entityDropItem(new ItemStack(mod_thKaguya.spellCardItem.itemID, 1, 9), 0.0F);
        	
        }
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    /**
     * Called when the mob is falling. Calculates and applies fall damage.
     */
    protected void fall(float par1) {}

    /**
     * Takes in the distance the entity has fallen this tick and whether its on the ground to update the fall distance
     * and deal fall damage if landing on the ground.  Args: distanceFallenThisTick, onGround
     */
    //protected void updateFallState(double par1, boolean par3) {}

    /**
     * Return whether this entity should NOT trigger a pressure plate or a tripwire.
     */
    public boolean doesEntityNotTriggerPressurePlate()
    {
        return true;
    }

    /**
     * Called when the entity is attacked.
     */
    /*public boolean attackEntityFrom(DamageSource par1DamageSource, int par2)
    {
        if (this.func_85032_ar())
        {
            return false;
        }
        else
        {
            if (!this.worldObj.isRemote && this.getIsBatHanging())
            {
                this.setIsBatHanging(false);
            }

            return super.attackEntityFrom(par1DamageSource, par2);
        }
    }*/

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    /*public void readEntityFromNBT(NBTTagCompound nbtTagCompound)
    {
        super.readEntityFromNBT(nbtTagCompound);
        this.dataWatcher.updateObject(16, Byte.valueOf(nbtTagCompound.getByte("BatFlags")));
    	fairyType = nbtTagCompound.getByte("fairyType");
    	
    }*/

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    /*public void writeEntityToNBT(NBTTagCompound nbtTagCompound)
    {
        super.writeEntityToNBT(nbtTagCompound);
        nbtTagCompound.setByte("BatFlags", this.dataWatcher.getWatchableObjectByte(16));
    	nbtTagCompound.setByte("fairyType", (byte)fairyType);
    	
    }*/
    
    public int getMaxSpawnedInChunk()
    {
        return 1;
    }

	//自然スポーンするときに呼ばれる。tureならスポーンする
    public boolean getCanSpawnHere()
    {
    	if(rand.nextInt(100) < mod_thKaguya.fairySpawnRate)
    	{
    		return false;
    	}
    	
        int yPosition = MathHelper.floor_double(this.boundingBox.minY);
    	int xPosition = MathHelper.floor_double(this.posX);
        int zPosition = MathHelper.floor_double(this.posZ);
        int pointBlock, pointBlock2;
        pointBlock = pointBlock2 = worldObj.getBlockId(xPosition, yPosition, zPosition);
        if(pointBlock != Block.snow.blockID)
        {
        	return false;
        }
        for(int i = -2; i <= 2; i++)
        {
        	for(int j = -2; j<= 2; j++)
        	{
            	pointBlock2 = worldObj.getBlockId(xPosition + i, yPosition - 1, zPosition + j);
            	if(pointBlock2 == Block.ice.blockID)
            	{
            		return true;
            	}
        	}
        }
    	return false;
		
        /*if (yPosition >= 63)//高さ６３ｍ以上ならスポーンしない
        {
            return false;
        }
        else
        {

            int lightValue = this.worldObj.getBlockLightValue(xPosition, yPosition, zPosition);
            byte var5 = 4;
            Calendar var6 = this.worldObj.getCurrentDate();

            if ((var6.get(2) + 1 != 10 || var6.get(5) < 20) && (var6.get(2) + 1 != 11 || var6.get(5) > 3))
            {
                if (this.rand.nextBoolean())
                {
                    return false;
                }
            }
            else
            {
                var5 = 7;
            }

            return lightValue > this.rand.nextInt(var5) ? false : super.getCanSpawnHere();
        }*/
    }

    /**
     * Initialize this creature.
     */
    public void initCreature() {}
}
