package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityTHShot;
import thKaguyaMod.entity.spellcard.*;

public class EntitySpellCard extends Entity
{
	//スペルカード

	public EntityLivingBase user;
	public EntityLivingBase tgEntity;
	public int count;
	private int spellCardNumber;
	Vec3 tgVec;
	private int spellCardUsedTime;
	public int level;

    public EntitySpellCard(World world)
    {
        super(world);
        preventEntitySpawning = true;
        setSize(0.4F, 0.4F);//サイズを設定　平面上の横と奥行きサイズ、高さ
        yOffset = 0.0F;//高さを設定
    }
	
    public EntitySpellCard(World world,EntityLivingBase spUser, EntityLivingBase target, int num)
    {
        this(world);

        setPosition(spUser.posX - (double)MathHelper.sin((spUser.rotationYaw + 30F) / 180F * 3.141593F) * (double)MathHelper.cos(spUser.rotationPitch / 180F * 3.141593F),
        			spUser.posY - (double)MathHelper.sin(spUser.rotationPitch / 180F * 3.141593F) + (double)spUser.getEyeHeight() - 0.10000000149011612D ,
        			spUser.posZ + (double)MathHelper.cos((spUser.rotationYaw + 30F) / 180F * 3.141593F) * (double)MathHelper.cos(spUser.rotationPitch / 180F * 3.141593F));//初期位置を設定(x,y,z)
    	rotationYaw = spUser.rotationYaw;
    	rotationPitch = spUser.rotationPitch;
    	setRotation(rotationYaw, rotationPitch);
    	tgVec = spUser.getLookVec();
    	user = spUser;//使用者をuserに保存
    	tgEntity = target;//ターゲットした相手
    	spellCardNumber = num;
    	setSpellCardNumber(num);
    	spellCardUsedTime = 0;
    	count = 0;
    	worldObj.playSoundAtEntity(this, "thKaguyaMod.spellcard", mod_thKaguya.SpellCardVol, 1.0F);
    	
    	level = 2;
    }
    
    public EntitySpellCard(World world,EntityLivingBase spUser, EntityLivingBase target, int num, int spLevel)
    {
        this(world, spUser, target, num);
    	
    	level = spLevel;;
    }

	//
    protected void entityInit()
    {
    	dataWatcher.addObject(18, new Integer(0));
    }

    /**
     * Returns true if this entity should push and be pushed by other entities when colliding.
     */
    public boolean canBePushed()
    {
        return false;
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
    	return false;
    }

	//Entityの消滅処理
	private void finish()
	{
		setDead();
	}
	
	//指定した時間になったらスペルカードを終了する
	private void spellCardEnd(int time)
	{
		if(!worldObj.isRemote && ticksExisted >= time)
		{
			finish();
		}
	}
	
	//Entityが存在する限り毎フレーム呼び出されるメソッド
	@Override
    public void onUpdate()
    {
        super.onUpdate();
    	if(!worldObj.isRemote && (user == null || user.isDead))
    	{
    		setDead();
    	}
    	
    	if(user != null)
    	{
    		if(user instanceof EntityTHFairy)
    		{
    			EntityTHFairyCirno fairy = (EntityTHFairyCirno)user;
    			if(!fairy.isSpellCardMode)
    			{
    				setDead();
    			}
    		}
    	}
    	
    	if(ticksExisted > spellCardUsedTime || spellCardNumber == 8)
    	{
    		/*Class<?> spellCardClass = null;
    		String spellCardClassName = "thKaguyaMod.entity.spellcard.THSpellCard_" + spellCardNumber;
    		try{
    			spellCardClass = Class.forName(spellCardClassName);
    		}
    		catch(ClassNotFoundException ex)
    		{
    			ex.printStackTrace();
    		}
    		
    		if(spellCardClass != null)
    		{
    			//THSpellCard spellCard = (THSpellCard)spellCardClass.newInstance();
    		}*/
    			
	    	switch(spellCardNumber)
	    	{
	    		case 0://霊符「夢想封印」
	    			spellCard_0();
	    			break;
	    		case 1://恋符「マスタースパーク」
	    			spellCard_1();
	    			break;
	    		case 2://死蝶「華胥の永眠」
	    			spellCard_2();
	    			break;
	    		case 3://星符「メテオニックシャワー」
	    			spellCard_3();
	    			break;
	    		case 4://境符「波と粒の境界」
	    			spellCard_4();
	    			break;
	    		case 5://魍魎「二重黒死蝶」
	    			spellCard_5();
	    			break;
	    		case 6://紅符「スカーレットシュート」
	    			spellCard_6();
	    			break;
	    		case 8://メイド秘技「殺人ドール」
	    			spellCard_8();
	    			break;
	    		case 9://凍符「パーフェクトフリーズ」
	    			spellCard_9();
	    			break;
	    		case 10://幻巣「飛行虫ネスト」
	    			spellCard_10();
	    			break;
	    		case 11://水符「河童のポロロッカ」
	    			spellCard_11();
	    			break;
	    		case 12://魔符「スターダストレヴァリエ」
	    			spellCard_12();
	    			break;
	    		case 13://土着神「ケロちゃん風雨に負けず」
	    			spellCard_13();
	    			break;
	    		case 14://奇跡「ミラクルフルーツ」
	    			spellCard_14();
	    			break;
	    		case 15://奇跡「ファフロッキーズの奇跡」
	    			spellCard_15();
	    			break;
	    		case 16://妖怪退治「妖力スポイラー」
	    			spellCard_16();
	    			break;
	    		case 17://開海「モーゼの奇跡」
	    			spellCard_17();
	    			break;
	    		case 18://大奇跡「八坂の神風」
	    			spellCard_18();
	    			break;
	    		case 19://氷符「アイシクルフォール」
	    			spellCard_19();
	    			break;
	    		case 20://禁弾「スターボウブレイク」
	    			spellCard_20();
	    			/*starbow*/break;
	    		case 21://禁弾「カタディオプトリック」
	    			spellCard_21();
	    			break;
	    		case 22://祟符「ミシャグジさま」
	    			spellCard_22();
	    			break;
	    		case 23://「レッドマジック」
	    			spellCard_23();
	    			break;
	    		case 24://奇術「エターナルミーク」
	    			spellCard_24();
	    			break;
	    		case 25://恋符「ノンディレクショナルレーザー」
	    			spellCard_25();
	    			break;
	    		case 26://幻想「花鳥風月、嘯風弄月」
	    			spellCard_26();
	    			break;
	    		case 27:
	    			spellCardEnd(48);
	    			break;
	    		default://
	    			break;
	    	}
    	}
    	
    	if(spellCardUsedTime < ticksExisted)
    	{
    		spellCardUsedTime = ticksExisted;
    	}

		//時間で消滅
		if(ticksExisted >= 200)
		{
			if(!worldObj.isRemote)
			{
				finish();
			}
		}
	}
	
	//霊符「夢想封印」
	private void spellCard_0()
	{
		//THSpellCard
		if(ticksExisted % 2 == 0 && ticksExisted > 15)
		{
			float angle = (float)ticksExisted * 33F;
			double xVec = -(double)MathHelper.sin(angle / 180F * 3.141593F);
			double yVec = 0.0D;
			double zVec = (double)MathHelper.cos(angle / 180F * 3.141593F);
			if(user != null && tgEntity != null)
			{
				EntityMusouFuuin entityMusouFuuin = new EntityMusouFuuin(worldObj, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, xVec, yVec, zVec, 4.0D, 0.0D, -0.1D, 9, rand.nextInt(7), 2.0F, tgEntity);
				if(!worldObj.isRemote)
       			{
        			worldObj.spawnEntityInWorld(entityMusouFuuin);//夢想封印の光弾を出現させる
       			}
			}
		}
		spellCardEnd(49);
	}
	
	//恋符「マスタースパーク」
	private void spellCard_1()
	{
		if(ticksExisted == 1)
		{
			EntityMiniHakkero entityMiniHakkero;
    			
    		entityMiniHakkero = new EntityMiniHakkero(worldObj, user, tgEntity);
       		if(!worldObj.isRemote)
       		{
        			worldObj.spawnEntityInWorld(entityMiniHakkero);//ミニ八卦炉を出す
       		}
		}
		if(ticksExisted > 30)
		{
			EntityTHShot[] entityTHShot = new EntityTHShot[7];
    		double xVector, yVector, zVector, xVectorG, yVectorG, zVectorG, gRate, angleXZ = 0, angleY = 0, X1, Z1, X2, Z2;
			Vec3 lookAt = tgVec;
			lookAt.xCoord = -MathHelper.sin(rotationYaw / 180F * 3.141593F) * MathHelper.cos((rotationPitch + 90F) / 180F * 3.141593F);
    		lookAt.yCoord =	-MathHelper.sin((rotationPitch + 90F) / 180F * 3.141593F);
    		lookAt.zCoord =	 MathHelper.cos(rotationYaw / 180F * 3.141593F) * MathHelper.cos((rotationPitch + 90F) / 180F * 3.141593F);
			lookAt.rotateAroundY((float)Math.PI * 2);
			float angle = (float)ticksExisted * 6F ;
			float angleSpan = 360F / 7F;
			//gRate = (double)(ticksExisted % 9) / 9D + 0.1D;
			gRate = 0.04 + 0.03D * Math.sin(angle / 180F *3.141593F);
			
			xVectorG = -MathHelper.sin(rotationYaw / 180F * 3.141593F) * MathHelper.cos(rotationPitch / 180F * 3.141593F) * gRate;
    		yVectorG = -MathHelper.sin(rotationPitch / 180F * 3.141593F) * gRate;
    		zVectorG =  MathHelper.cos(rotationYaw / 180F * 3.141593F) * MathHelper.cos(rotationPitch / 180F * 3.141593F) * gRate;
			
    		for(int i = 0; i < 7; i++)
    		{
				angleXZ = angle;//横の角度　0=正面　+1ごとに左にずれていき360で正面に戻る
				angleY = 0;//縦の角度　0=正面　+1ごとに上にずれていき360で正面に戻る

				X1 =  Math.sin(angleXZ/ 180.0F * Math.PI) * Math.cos(rotationYaw/ 180.0F * Math.PI);
				Z1 =  Math.sin(angleXZ/ 180.0F * Math.PI) * Math.sin(rotationYaw/ 180.0F * Math.PI);
				X2 =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin(angleY/ 180.0F * Math.PI) * Math.sin((rotationPitch + 90F)/ 180.0F * Math.PI) * Math.sin(rotationYaw/ 180.0F * Math.PI);
				Z2 =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin(angleY/ 180.0F * Math.PI) * Math.sin((rotationPitch + 90F)/ 180.0F * Math.PI) * Math.cos(rotationYaw/ 180.0F * Math.PI);
						
				yVector = -Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin((rotationPitch + 90F - angleY)/ 180.0F * Math.PI);//Y方向　上下
				xVector =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.cos(angleY/ 180.0F * Math.PI) * lookAt.xCoord + X1 - X2;//X方向　水平方向
				zVector =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.cos(angleY/ 180.0F * Math.PI) * lookAt.zCoord + Z1 + Z2;//Z方向　水平方向

    			entityTHShot[i] = new EntityTHShot(worldObj, user, this, xVector, yVector, zVector,
    				0.2D, 0.3D, 0.05D/*0.05D*/, xVectorG, yVectorG, zVectorG, 8, thShotLib.STAR[0] + ticksExisted % 7, 0.8F, 35);
    			angle += angleSpan;
    			if(!worldObj.isRemote)
    			{
    				worldObj.spawnEntityInWorld(entityTHShot[i]);
    			}
    		}
			
			//thShotLib.createCircleShotBaseB(user, this, posX, posY, posZ, rotationYaw + angle, rotationPitch + 90F, 0.2D, 0.3D, 0.05D, xVectorG, yVectorG, zVectorG, 8, thShotLib.STAR[ticksExisted % 7], 0.8F, 35, 0, 7, 0.2D);
		}
		spellCardEnd(99);
	}
	
	//死蝶「華胥の永眠」
	private void spellCard_2()
	{
		if(ticksExisted % 6 == 3)
		{		
			Vec3 look = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch, 1.0D);
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, look.xCoord, look.yCoord, look.zCoord,  2F, 0.1D, 0.2D, 0.01D, 0.0D, 0.0D, 0.0D, 6, thShotLib.BUTTERFLY[thShotLib.YELLOW], thShotLib.SIZE[thShotLib.BUTTERFLY[0] / 8], 70, 3, 0, 16, 0.3D);
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, look.xCoord, look.yCoord, look.zCoord, -2F, 0.1D, 0.2D, 0.01D, 0.0D, 0.0D, 0.0D, 6, thShotLib.BUTTERFLY[thShotLib.PURPLE], thShotLib.SIZE[thShotLib.BUTTERFLY[0] / 8], 70, 3, 0, 16, 0.3D);

		}
		spellCardEnd(90);
	}
	
	//星符「メテオニックシャワー」
	private void spellCard_3()
	{
		if(ticksExisted > 10)
		{
			EntityTHShot entityTHShot;
			double vectorX, vectorY, vectorZ;
			Random rand = new Random();
			int colors[] = {0, 2, 3, 4};
			int color = colors[rand.nextInt(4)] + thShotLib.STAR[0];
			float size = 0.3F + rand.nextFloat() * 0.5F;
			int damage = (int)(size * 10F);
			float yaw = user.rotationYaw + rand.nextFloat() * 20F - 10F;
			float pitch = user.rotationPitch + rand.nextFloat() * 20F - 10F;
			thShotLib.createShot(user, this, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, yaw, pitch, 0F, 0.0D, 1.0D, 0.0D, 0.4D, 1.0D, 0.1D, 0.0D, 0.0D, 0.0D, damage, color, size, 120, 0, 0);
			thShotLib.playShotSound(user);
		}
		spellCardEnd(40);
	}
	
	//境符「波と粒の境界」
	private void spellCard_4()
	{
		if(ticksExisted < 5)
		{
			return;
		}
		rotationYaw += MathHelper.cos((float)ticksExisted / 30F) * 10F;
		rotationPitch = MathHelper.sin(MathHelper.sin(ticksExisted / 10F) * 3.14F) * 10F;
		int color = thShotLib.LIGHT[thShotLib.PURPLE];
		float size = 0.2F;
		int damage = 5;

		thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, rotationYaw, rotationPitch, 0.2D, 0.6D, 0.05D, 0.0D, 0.0D, 0.0D,
										damage, color, size, 100, 2, 0, 7, 1.0D);
		spellCardEnd(160);
	}
	
	//魍魎「二重黒死蝶」
	private void spellCard_5()
	{
		if(ticksExisted % 70 == 10)
		{
			for(int i = 0; i < 30; i++)
			{
				double speed;
				float angleXZ, angleY;
				
				speed = rand.nextDouble() * 2.0 + 0.5D;
				angleXZ = rand.nextFloat() * 360F;
				angleY = rand.nextFloat() * 180F - 90F;
				Vec3 vec3 = thShotLib.getVecFromAngle(angleXZ, angleY, 1.0D);
				
				thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, angleXZ, angleY, speed, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 8.0F, thShotLib.BUTTERFLY[i % 2], thShotLib.SIZE[thShotLib.BUTTERFLY[0] / 8], 120, 1, thShotLib.KOKUSHI01, 8, 0.2D);
			}
			thShotLib.playShotSound(user);
		}
		spellCardEnd(100);
	}
	
	//紅符「スカーレットシュート」
	private void spellCard_6()
	{
		if(!worldObj.isRemote && ticksExisted % 25 == 20 && ticksExisted < 60)
		{
	    	double xVector, yVector, zVector, xVectorG, yVectorG, zVectorG, gRate, angleXZ = 0, angleY = 0, X1, Z1, X2, Z2;
			Vec3 lookAt = user.getLookVec();
			/*Vec3 lookAt = tgVec;
			lookAt.xCoord = -MathHelper.sin(user.rotationYaw / 180F * 3.141593F) * MathHelper.cos(user.rotationPitch / 180F * 3.141593F);
	    	lookAt.yCoord =	-MathHelper.sin(user.rotationPitch / 180F * 3.141593F);
	    	lookAt.zCoord =	 MathHelper.cos(user.rotationYaw / 180F * 3.141593F) * MathHelper.cos(user.rotationPitch / 180F * 3.141593F);*/
			lookAt.rotateAroundY((float)Math.PI * 2);
			float angle = -90F ;
			float angleSpan = 180F / 4F;
			
	    	for(int i = 0; i < 5; i++)
	    	{
				angleXZ = angle;//横の角度　0=正面　+1ごとに左にずれていき360で正面に戻る
				angleY = 0;//縦の角度　0=正面　+1ごとに上にずれていき360で正面に戻る

				X1 =  Math.sin(angleXZ/ 180.0F * Math.PI) * Math.cos(user.rotationYaw/ 180.0F * Math.PI);
				Z1 =  Math.sin(angleXZ/ 180.0F * Math.PI) * Math.sin(user.rotationYaw/ 180.0F * Math.PI);
				X2 =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin(angleY/ 180.0F * Math.PI) * Math.sin(user.rotationPitch/ 180.0F * Math.PI) * Math.sin(user.rotationYaw/ 180.0F * Math.PI);
				Z2 =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin(angleY/ 180.0F * Math.PI) * Math.sin(user.rotationPitch/ 180.0F * Math.PI) * Math.cos(user.rotationYaw/ 180.0F * Math.PI);
						
				yVector = -Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin((user.rotationPitch - angleY)/ 180.0F * Math.PI);//Y方向　上下
				xVector =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.cos(angleY/ 180.0F * Math.PI) * lookAt.xCoord + X1 - X2;//X方向　水平方向
				zVector =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.cos(angleY/ 180.0F * Math.PI) * lookAt.zCoord + Z1 + Z2;//Z方向　水平方向
	    		scarletShot(xVector, yVector, zVector, 1.0D, false);
	    		angle += angleSpan;
	    	}
	    	thShotLib.playShotSound(user);
		}
		else if(ticksExisted == 80)
		{
			double xVector, yVector, zVector, xVectorG, yVectorG, zVectorG, gRate, angleXZ = 0, angleY = 0, X1, Z1, X2, Z2;
			Vec3 lookAt = user.getLookVec();
			/*Vec3 lookAt = tgVec;
			lookAt.xCoord = -MathHelper.sin(user.rotationYaw / 180F * 3.141593F) * MathHelper.cos(user.rotationPitch / 180F * 3.141593F);
	    	lookAt.yCoord =	-MathHelper.sin(user.rotationPitch / 180F * 3.141593F);
	    	lookAt.zCoord =	 MathHelper.cos(user.rotationYaw / 180F * 3.141593F) * MathHelper.cos(user.rotationPitch / 180F * 3.141593F);*/
			lookAt.rotateAroundY((float)Math.PI * 2);
			float angle = -3F ;
			float angleSpan = 6F / 2F;
			
	    	for(int i = 0; i < 3; i++)
	    	{
				angleXZ = angle;//横の角度　0=正面　+1ごとに左にずれていき360で正面に戻る
				angleY = 0;//縦の角度　0=正面　+1ごとに上にずれていき360で正面に戻る

				X1 =  Math.sin(angleXZ/ 180.0F * Math.PI) * Math.cos(user.rotationYaw/ 180.0F * Math.PI);
				Z1 =  Math.sin(angleXZ/ 180.0F * Math.PI) * Math.sin(user.rotationYaw/ 180.0F * Math.PI);
				X2 =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin(angleY/ 180.0F * Math.PI) * Math.sin(user.rotationPitch/ 180.0F * Math.PI) * Math.sin(user.rotationYaw/ 180.0F * Math.PI);
				Z2 =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin(angleY/ 180.0F * Math.PI) * Math.sin(user.rotationPitch/ 180.0F * Math.PI) * Math.cos(user.rotationYaw/ 180.0F * Math.PI);
						
				yVector = -Math.cos(angleXZ/ 180.0F * Math.PI) * Math.sin((user.rotationPitch - angleY)/ 180.0F * Math.PI);//Y方向　上下
				xVector =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.cos(angleY/ 180.0F * Math.PI) * lookAt.xCoord + X1 - X2;//X方向　水平方向
				zVector =  Math.cos(angleXZ/ 180.0F * Math.PI) * Math.cos(angleY/ 180.0F * Math.PI) * lookAt.zCoord + Z1 + Z2;//Z方向　水平方向
	    		scarletShot(xVector, yVector, zVector, 1.0D, false);
	    		angle += angleSpan;
	    	}
	    	thShotLib.playShotSound(user);
		}
		spellCardEnd(90);
	}
	
	//スカーレットシュートのまとまった弾（カタディオプトリックの弾に変更も可）
	private void scarletShot(double vectorX, double vectorY, double vectorZ, double speed, boolean isCatadi)
	{
		int special = 0;
		int color = thShotLib.RED;
		double speed2;
		
		if(isCatadi)
		{
			special = thShotLib.BOUND04;
			color = thShotLib.BLUE;
		}
		thShotLib.createShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, vectorX, vectorY, vectorZ, 0F, 0.0D, 1.0D, 0.0D, speed, speed, 0.0D, 0.0D, 0.0D, 0.0D, 6.0F, thShotLib.BIG[color], thShotLib.SIZE[thShotLib.BIG[0] / 8], 120, 0, special);
		for(int i = 0; i < 11; i++)
		{
			speed2 = (0.5D + rand.nextDouble() * 0.3D) * speed;
			//thShotLib.createShot(user, user, user.posX + (rand.nextDouble() * 2.0D - 1.0D) * 0.2D, thShotLib.getPosYFromEye(user, -0.2D) + (rand.nextDouble() * 2.0D - 1.0D) * 0.2D, user.posZ + (rand.nextDouble() - 0.5D) * 0.2D, vectorX, vectorY, vectorZ, 0F, 0.0D, 1.0D, 0.0D, speed2, speed2, 0.0D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.MEDIUM[color], thShotLib.SIZE[thShotLib.MEDIUM[0] / 8], 120, 0, special);
			thShotLib.createRandomRingShot(user, user.posX, thShotLib.getPosYFromEye(user), user.posZ, vectorX, vectorY, vectorZ, speed2, speed2, 0.0D, 4.0F, thShotLib.MEDIUM[color], thShotLib.SIZE[thShotLib.MEDIUM[0] / 8], 120, 0, special, 1, 0.0D, 30F);
		}
		for(int i = 0; i < 22; i++)
		{
			speed2 = (0.2D + rand.nextDouble() * 0.3D) * speed;
			//thShotLib.createShot(user, user, user.posX + (rand.nextDouble() * 2.0D - 1.0D) * 0.3D, thShotLib.getPosYFromEye(user, -0.2D) + (rand.nextDouble() * 2.0D - 1.0D) * 0.3D, user.posZ + (rand.nextDouble() - 0.5D) * 0.3D, vectorX, vectorY, vectorZ, 0F, 0.0D, 1.0D, 0.0D, speed2, speed2, 0.0D, 0.0D, 0.0D, 0.0D, 2.0F, thShotLib.SMALL[color], thShotLib.SIZE[thShotLib.SMALL[0] / 8], 120, 0, special);
			thShotLib.createRandomRingShot(user, user.posX, thShotLib.getPosYFromEye(user), user.posZ, vectorX, vectorY, vectorZ, speed2, speed2, 0.0D, 2.0F, thShotLib.SMALL[color], thShotLib.SIZE[thShotLib.SMALL[0] / 8], 120, 0, special, 1, 0.0D, 60F);
		}
		
	}
	
	//メイド秘技「殺人ドール」
	private void spellCard_8()
	{
		if(ticksExisted < 5)
		{
			return;
		}
		else if(ticksExisted >= 23)
		{
			ticksExisted ++;
		}
		
		if(ticksExisted < 15 && ticksExisted % 2 == 0)
		{
			int way = 9;
			float angleXZ = user.rotationYaw + (float)ticksExisted * 10F;
			//float angleY = -90;
			float angleY = user.rotationPitch;
			float spanAngleY = 180F / (way-1);
			float spanAngleXZ = 360F / (float)way / 5F;

			double speed = 0.3D;
			rotationPitch = -60F;
			for(int j = 0; j < 5; j++)
			{
				//thShotLib.createCircleShot01(user, angleXZ, rotationPitch, speed, thShotLib.KNIFE[thShotLib.BLUE], way);
				thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, angleXZ, rotationPitch, 
						speed, speed, 0.0D, 0.0D, 0.0D, 0.0D, 12, thShotLib.KNIFE[thShotLib.BLUE], thShotLib.SIZE[thShotLib.KNIFE[0] / 8], 80, 3, 0, way, 1.0D);
				angleXZ+= spanAngleXZ;
				rotationPitch += 30F;
				speed -= 0.01D;
			}
			angleY += spanAngleY;
		}
		if(ticksExisted > 14 && ticksExisted < 24 && ticksExisted % 4 == 0)
		{
			int way = 9;
			float angleXZ = user.rotationYaw;
			float angleY = user.rotationPitch;
			//thShotLib.createCircleShot01(user, angleXZ,      angleY, 0.4D, thShotLib.KNIFE[thShotLib.RED], way);
			//thShotLib.createCircleShot01(user, angleXZ + 5F, angleY, 0.4D, thShotLib.KNIFE[thShotLib.RED], way);
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, angleXZ, angleY, 
					0.4D, 0.4D, 0.0D, 0.0D, 0.0D, 0.0D, 12, thShotLib.KNIFE[thShotLib.RED], thShotLib.SIZE[thShotLib.KNIFE[0] / 8], 80, 3, 0, way, 1.0D);
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, angleXZ + 5F, angleY, 
					0.4D, 0.4D, 0.0D, 0.0D, 0.0D, 0.0D, 12, thShotLib.KNIFE[thShotLib.RED], thShotLib.SIZE[thShotLib.KNIFE[0] / 8], 80, 3, 0, way, 1.0D);
		}
		if(ticksExisted == 50)
		{
			boolean flag = true;
		    List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(20.0D, 20.0D, 20.0D));
    		for(int k = 0; k < list.size(); k++)
    		{
    			Entity entity = (Entity)list.get(k);
    			if(entity instanceof EntityPrivateSquare)
    			{
    				EntityPrivateSquare entityPrivateSquare = (EntityPrivateSquare)entity;
    				if(entityPrivateSquare.userEntity == user)
    				{
						flag = false;
    				}
    			}
    		}
			if(flag)
			{
    			EntityPrivateSquare entityPrivateSquare = new EntityPrivateSquare(worldObj, user, 1);
				if(!worldObj.isRemote)
       			{
         			worldObj.spawnEntityInWorld(entityPrivateSquare);//時間停止空間を生み出す
       			}
			}
		}
		if(ticksExisted > 50 && ticksExisted < 74 && ticksExisted % 8 == 3)
		{
			List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(20.0D, 20.0D, 20.0D));
    		for(int k = 0; k < list.size(); k++)
    		{
    			Entity entity = (Entity)list.get(k);
    			if(entity instanceof EntityTHShot)
    			{
    				EntityTHShot entityTHShot = (EntityTHShot)entity;
    				if( (entityTHShot.color == thShotLib.KNIFE[thShotLib.BLUE] || entityTHShot.color == thShotLib.KNIFE[thShotLib.RED] )&& rand.nextInt(100) < 25)
    				{
    					//thShotLib.createShot03(user, entityTHShot.posX, entityTHShot.posY - ((double)user.getEyeHeight() - 0.25D), entityTHShot.posZ, 
    						//	rand.nextFloat() * 360F, rand.nextFloat() * 360F, 0.01D, 0.28D, 0.05D, thShotLib.KNIFE[thShotLib.GREEN]);
    					thShotLib.createShot(user, user, entityTHShot.posX, entityTHShot.posY - ((double)user.getEyeHeight() - 0.25D), entityTHShot.posZ, 
    							rand.nextFloat() * 360F, rand.nextFloat() * 360F, 0F, 0.0D, 1.0D, 0.0D, 0.2D, 0.58D, 0.02D, 0.0D, 0.0D, 0.0D,
    							12, thShotLib.KNIFE[thShotLib.GREEN], thShotLib.SIZE[thShotLib.KNIFE[0] / 8], 80, 0, 0);
    					entityTHShot.setDead();
    					
    				}
    			}
    		}
		}
		spellCardEnd(70);
	}
	
	//凍符「パーフェクトフリーズ」
	private void spellCard_9()
	{
		if(ticksExisted < 5)
		{
			return;
		}
		
		if(ticksExisted < 58)
		{
			int num = 4 + level;
			if(num > 10)num = 10;
			Vec3 look;
			for(int i = 0; i < num; i++)
			{
				look = thShotLib.getVecFromAngle(rand.nextFloat() * 360F, rand.nextFloat() * 360F);
				thShotLib.createShot(user, user, user.posX + look.xCoord, thShotLib.getPosYFromEye(user, -0.2D) + look.yCoord, user.posZ + look.zCoord, look.xCoord, look.yCoord, look.zCoord, 0F, 0.0D, 1.0D, 0.0D, 0F, level * 0.1D, 0.5D, 0.03D, 0.0D, 0.0D, 0.0D, thShotLib.DAMAGE[thShotLib.CIRCLE[0] / 8], thShotLib.CIRCLE[rand.nextInt(7)], thShotLib.SIZE[thShotLib.CIRCLE[0] / 8], 120, 5, 0);
			}
			thShotLib.playShotSound(user);
		}

		if(ticksExisted == 64)
		{
			List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(20.0D, 20.0D, 20.0D));
    		for(int k = 0; k < list.size(); k++)
    		{
    			Entity entity = (Entity)list.get(k);
    			if(entity instanceof EntityTHShot && entity instanceof EntityTHLaser == false)
    			{
    				if(entity instanceof EntityHomingAmulet == false && entity instanceof EntityMusouFuuin == false)
    				{
    					EntityTHShot entityTHShot = (EntityTHShot)entity;
    					EntityTHShot newEntityTHShot;
    					int color = entityTHShot.color - entityTHShot.color % 8 + 7;
    					newEntityTHShot = thShotLib.createShot(	user, user, entityTHShot.posX, entityTHShot.posY, entityTHShot.posZ, rand.nextFloat() * 360F, rand.nextFloat() * 180F - 90F, 0F, 0.0D, 1.0D, 0.0D, 
    						0.0001D, 0.0001D, 0.0D, 0.0D, 0.0D, 0.0D, entityTHShot.shotDamage, color, entityTHShot.getShotSize(), entityTHShot.deadTime - entityTHShot.ticksExisted + 50, 0, thShotLib.FREEZE01);
    					entityTHShot.setDead();
    				}
    			}
    		}
		}
		spellCardEnd(70);
	}
	
	//幻巣「飛光虫ネスト」
	private void spellCard_10()
	{
		boolean flag = false;
		int count = 0;
		while(!flag && count < 4)
		{
			double length = rand.nextDouble() * 5.0D + 1.0D;
			float angleXZ = (rotationYaw + 90F) / 180F * (float)Math.PI + rand.nextFloat() * (float)Math.PI;
			float angleY  = rand.nextFloat() * (float)Math.PI - (float)Math.PI / 2.0F;
			double xVector = Math.sin(angleXZ) * Math.cos(angleY) * length;
			double yVector = Math.sin(angleY) * length;
			double zVector = Math.cos(angleXZ) * Math.cos(angleY) * length;
			double xPos, yPos, zPos;
		    //始点（現在地）
	    	Vec3 vec3d = worldObj.getWorldVec3Pool().getVecFromPool(user.posX, user.posY, user.posZ);
	    	//終点（現在地に移動量を足した点）
	    	Vec3 vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(user.posX + xVector, user.posY + yVector, user.posZ + zVector);
	        //始点と終点からブロックとの当たりを取得
	    	MovingObjectPosition movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d1, false, true);
	    	vec3d = worldObj.getWorldVec3Pool().getVecFromPool(user.posX, user.posY, user.posZ);
	    	vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(user.posX + xVector, user.posY + yVector, user.posZ + zVector);
	    	//何らかのブロックに当たっているなら
	        if (movingObjectPosition != null)
	        {
	        	//終点を当たった点に変更
	        	/*vec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(movingObjectPosition.hitVec.xCoord, movingObjectPosition.hitVec.yCoord, movingObjectPosition.hitVec.zCoord);
	        	xPos = movingObjectPosition.hitVec.xCoord;
	        	yPos = movingObjectPosition.hitVec.yCoord;
	        	zPos = movingObjectPosition.hitVec.zCoord;*/
	        	count ++;
	        }
			else
			{
				xPos = user.posX + xVector;
				yPos = user.posY + yVector;
				zPos = user.posZ + zVector;
				EntitySukima entitySukima = new EntitySukima(worldObj, user, xPos, yPos, zPos, user.rotationYaw, 17);
				if(!worldObj.isRemote)
				{
					worldObj.spawnEntityInWorld(entitySukima);
				}
				flag = true;
			}
		}

		
		spellCardEnd(140);
	}
	
	//水符「河童のポロロッカ」
	private void spellCard_11()
	{
		if(ticksExisted < 5)return;
		
		if(ticksExisted % 10 == 0)
		{
			thShotLib.createShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, user.rotationYaw + 90F, -60F, 0F, 0.0D, 1.0D, 0.0D, 0.3D, 0.3D, 0.0D, 0.0D, -0.03D, 0.0D, 
									8.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.45F, 60, 2, thShotLib.KAPPA01);
			thShotLib.createShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, user.rotationYaw - 90F, -60F, 0F, 0.0D, 1.0D, 0.0D, 0.3D, 0.3D, 0.0D, 0.0D, -0.03D, 0.0D, 
									8.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.45F, 60, 2, thShotLib.KAPPA01);
		}
		spellCardEnd(140);
	}
	
	//魔符「スターダストレヴァリエ」
	private void spellCard_12()
	{
		if(ticksExisted < 5)return;
		
		if(ticksExisted == 5)
		{
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ,
					rotationYaw, rotationPitch, 0.3D, 0.3D, 0.0D, 0.0D, 0.0D, 0.0D,
					7, 2000 + thShotLib.STAR[rand.nextInt(7)], 1.2F, 120, 2, thShotLib.STARDUST01, 6, 0.2D);
		}
		spellCardEnd(60);
	}
	
	//土着神「ケロちゃん風雨に負けず」
	private void spellCard_13()
	{
		if(ticksExisted < 2)return;
		
		int i;
		
		if(ticksExisted < 140)
		{
			for(i = 0; i < 4; i++)
			{
				double speed = 0.5D;// - j * 0.1D;
					
				thShotLib.createShot(user, user, posX, posY - 0.4D, posZ, rotationYaw + i * 90F +  MathHelper.cos((float)ticksExisted * 4F) * 45F, MathHelper.cos((float)(ticksExisted + i * 45F) * 2F / 180F * 3.141593F)  * 19F - 70F , 0F, 0.0D, 1.0D, 0.0D, speed, speed, 0.0F, 0.0F, -0.01F, 0.0F, 9.0F, thShotLib.LIGHT[thShotLib.BLUE], thShotLib.SIZE[thShotLib.LIGHT[0] / 8], 120, 10, 0);
					
			}
		}
		for(i = 0; i < 2; i++)
		{
			double speed2 = rand.nextDouble() * 0.2D + 0.45D;
			thShotLib.createShot(user, user, posX, posY - 0.4D, posZ, rand.nextFloat() * 360F, rand.nextFloat() * 14F - 75F , 0F, 0.0D, 1.0D, 0.0D, speed2, speed2, 0.0F, 0.0F, -0.018F, 0.0F, 9.0F, thShotLib.RICE[thShotLib.AQUA], 0.15F, 120, 4, 0);
		}
		spellCardEnd(180);
	}
	
	//奇跡「ミラクルフルーツ」
	private void spellCard_14()
	{
		if(ticksExisted == 1)
		{
			user.clearActivePotions();
		}
		if(ticksExisted < 5)
		{
			return;
		}
		
		float angle = rand.nextFloat() * 360F;
		if(ticksExisted % 30 == 6)
		{
			Vec3 look = thShotLib.getRotationVectorFromAngle(user.rotationYaw, user.rotationPitch, 0F, 1.0D);
			thShotLib.playShotSound(user);
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, look.xCoord, look.yCoord, look.zCoord, 2.0D, 0.1D, -0.2D, 0.0D, 0.0D, 0.0D, 7.0F, thShotLib.OVAL[thShotLib.RED], thShotLib.SIZE[thShotLib.OVAL[0] / 8], 20, 3, thShotLib.MIRACLE, 8, 0.2D);
		}
		
		
		spellCardEnd(60);
	}
	
	//奇跡「ファフロッキーズの奇跡」
	private void spellCard_15()
	{
		if(ticksExisted == 1)
		{
			int pattern = rand.nextInt(100);
			for(int i = 0; i < 10; i++)
			{
				thShotLib.createShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, user.rotationYaw + rand.nextFloat() * 50F - 25F, rand.nextFloat() * 20F - 69F, 0F, 0.0D, 1.0D, 0.0D, 1.2D, pattern, 0.0D, 0.0D, -0.03D, 0.0D, 6.0F, thShotLib.CIRCLE[thShotLib.AQUA], 0.4F, 20, i, thShotLib.FAFRO);
			}
			thShotLib.playShotSound(user);
		}
		spellCardEnd(20);
	}
	
	//妖怪退治「妖力スポイラー」
	private void spellCard_16()
	{
		if(ticksExisted < 20)
		{
			if(tgEntity != null)
			{
				worldObj.playSoundAtEntity(user, "portal.portal", 2.0F, 1.9F);//音を出す
				thShotLib.createCircleShot(user, user, tgEntity.posX, thShotLib.getPosYFromEye(tgEntity, -0.2D), tgEntity.posZ, rotationYaw + ticksExisted * 3F, rotationPitch, 2.0D, 0.2D, -0.1D, 0.0D, 0.0D, 0.0D, 3.0F, thShotLib.SCALE[rand.nextInt(7)], 0.3F, 70, 6, thShotLib.SPOILER01, 16, 1.5D);
		
			}
		}
		if(ticksExisted > 40 && ticksExisted < 60)
		{
			if(tgEntity != null)
			{
				worldObj.playSoundAtEntity(user, "portal.portal", 2.0F, 1.9F);//音を出す
				thShotLib.createCircleShot(user, user, tgEntity.posX, thShotLib.getPosYFromEye(tgEntity, -0.2D), tgEntity.posZ, rotationYaw - ticksExisted * 3F, rotationPitch, 2.0D, 0.2D, -0.1D, 0.0D, 0.0D, 0.0D, 3.0F, thShotLib.SCALE[rand.nextInt(7)], 0.3F, 70, 6, thShotLib.SPOILER01, 16, 1.5D);
		
			}
		}
		spellCardEnd(80);
	}
	
	//開海「モーゼの奇跡」
	private void spellCard_17()
	{
		double angle = (double)ticksExisted * 6.0D;
		double distance = (Math.sin(ticksExisted * 17 / 180F * 3.141593F) + 1.2D) * 3.0D;
		double vectorXG = -Math.sin(user.rotationYaw / 180F * 3.141593F) * 0.1D;
		double vectorZG = Math.cos(user.rotationYaw / 180F * 3.141593F) * 0.1D;
		float baseAngle = user.rotationYaw;
		if(tgEntity != null)
		{
			baseAngle = (float)Math.atan2(posX - tgEntity.posX, tgEntity.posZ - posZ) / 3.141593F * 180F;
		}
				//double x = user.posX + Math.sin(angle / 180F * 3.141593F) * 4.0D;
		//double y = user.posY;
		//double z = user.posZ + Math.cos(angle / 180F * 3.141593F) * 4.0D;
		for(int i = -5; i < 6; i++)
		{
			double baseX = posX - Math.sin(angle / 180F * 3.141593F) * Math.cos(baseAngle / 180F * 3.141593F) * 3.0D;
			double baseZ = posZ + Math.cos(angle / 180F * 3.141593F) * Math.sin(baseAngle / 180F * 3.141593F) * 3.0D;
			double sideX = -Math.sin((baseAngle + 90F) / 180F * 3.141593F);
			double sideZ = Math.cos((baseAngle + 90F) / 180F * 3.141593F);
			thShotLib.createShot(user, user,  baseX + sideX * 2.5D, posY + i, baseZ + sideZ * 2.5D, baseAngle, 0F, 0F, 0.0D, 1.0D, 0.0D, 0.8D, 0.8D, 0.0D, 0.0D, 0.0D, 0.0D, 7.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.8F, 60, 0, 0);
			thShotLib.createShot(user, user,  baseX - sideX * 2.5D, posY + i, baseZ - sideZ * 2.5D, baseAngle, 0F, 0F, 0.0D, 1.0D, 0.0D, 0.8D, 0.8D, 0.0D, 0.0D, 0.0D, 0.0D, 7.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.8F, 60, 0, 0);
			//thShotLib.createShotBaseB(user, user, user.posX - Math.sin(angle / 180F * 3.141593F) * Math.cos(user.rotationYaw / 180F * 3.141593F) * 3.0D , user.posY + i, user.posZ + Math.cos(angle / 180F * 3.141593F) * Math.cos(user.rotationYaw / 180F * 3.141593F) * 3.0D - 3.5D, user.rotationYaw, 0F, 0.4D, 0.4D, 0.0D, 0.0D, 0.0D, 0.0D, 7.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.8F, 30, 0, 0);
		}
		//thShotLib.createCircleShotBaseB(user, user, user.posX, user.posY, user.posZ, user.rotationYaw, 90F, 0.4D, 0.1D, -0.05D, vectorXG, 0.0D, vectorZG, 7.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.8F, 80, 0, 0, 16, distance);
		/*if(ticksExisted < 30)
		{
			thShotLib.createShotBaseB(user, user, user.posX, user.posY + 1.0D, user.posZ, rotationYaw, rotationPitch, 1.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 20F, thShotLib.SCALE[thShotLib.AQUA], 0.8F, 60, 2, thShotLib.UMIWARE);
		}*/
		spellCardEnd(180);
	}
	
	//大奇跡「八坂の神風」
	private void spellCard_18()
	{
		if(ticksExisted < 5 || user == null)
		{
			return;
		}
		
		if( ticksExisted % 45 < 25)
		{
			double xVectorG = -Math.sin(user.rotationYaw / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * 0.1D;
			double yVectorG = -Math.sin(user.rotationPitch / 180F * 3.141593F) * 0.1D;
			double zVectorG =  Math.cos(user.rotationYaw / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * 0.1D;
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, ticksExisted * 10F, user.rotationPitch, 4.0D, 0.6D, -0.3D, 0.0D, 0.0D, 0.0D, 18.0F, thShotLib.WIND[thShotLib.GREEN], 0.4F, 40, 5, thShotLib.WIND01, 16, 1.4D);
		}
		else if(ticksExisted % 45 < 45)
		{
			double xVectorG = -Math.sin(user.rotationYaw / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * 0.1D;
			double yVectorG = -Math.sin(user.rotationPitch / 180F * 3.141593F) * 0.1D;
			double zVectorG =  Math.cos(user.rotationYaw / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * 0.1D;
			thShotLib.createCircleShot(user, user, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, -ticksExisted * 10F, user.rotationPitch, 4.0D, 0.6D, -0.3D, 0.0D, 0.0D, 0.0D, 18.0F, thShotLib.WIND[thShotLib.AQUA], 0.4F, 40, 5, thShotLib.WIND01, 16, 1.4D);
		}
		spellCardEnd(180);
	}
	
	//氷符「アイシクルフォール」
	private void spellCard_19()
	{
		if(ticksExisted % 5 == 0)
		{
			float angle = (float)Math.sin(ticksExisted * 13F / 180F * 3.141593F) * (30F + level * 30F) + 90F;
			int num = 4 + level * 2;
			float damage = 6.0F;
			for(int i = 1; i < num; i++)
			{
				thShotLib.createShot(user, this, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, user.rotationYaw + angle, -30F, 0F, 0.0D, 1.0D, 0.0D, i * 1.0D, 0.0D, -i * 0.1D, 0.0D, 0.0D, 0.0D, damage, thShotLib.CRYSTAL[thShotLib.BLUE], 0.5F, num, 0, thShotLib.ICECLEFALL01);
				thShotLib.createShot(user, this, user.posX, thShotLib.getPosYFromEye(user, -0.2D), user.posZ, user.rotationYaw - angle, -30F, 0F, 0.0D, 1.0D, 0.0D, i * 1.0D, 0.0D, -i * 0.1D, 0.0D, 0.0D, 0.0D, damage, thShotLib.CRYSTAL[thShotLib.BLUE], 0.5F, num, 0, thShotLib.ICECLEFALL02);
			}
		}
		spellCardEnd(180);
			
	}
	
	//禁弾「スターボウブレイク」
	private void spellCard_20()
	{
		//worldObj.playSoundAtEntity(user, "portal.portal", 2.0F, 1.9F);//音を出す
		if(ticksExisted % 60 >= 3 && ticksExisted % 60 <= 23 && ticksExisted % 3 == 0)
		{
			//虹色のパターン
			int rainbowPattern[] = {thShotLib.PURPLE, thShotLib.BLUE, thShotLib.AQUA, thShotLib.GREEN, thShotLib.YELLOW, thShotLib.ORANGE, thShotLib.RED};
			
			Vec3 look = user.getLookVec();//使用者が見ている方向のベクトルを取得
			Vec3 side = thShotLib.getVecFromAngle(user.rotationYaw + 90F, 0F, 0.3F);
			int color;
			int num = ticksExisted % 60;
			float span = 360F / num;
			
			Vec3 vec = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch, 0.13F);
			color = thShotLib.LIGHT[rainbowPattern[num / 3 - 1]];
			thShotLib.createCircleShot(user, user, user.posX + vec.xCoord * num, thShotLib.getPosYFromEye(user, -0.2D) + vec.yCoord * num, user.posZ + vec.zCoord * num, user.rotationYaw, user.rotationPitch + 90F,
					0.1D, 4.0D, 0.01D, vec.xCoord, vec.yCoord, vec.zCoord, 8.0F, color, 0.3F, 8, 5, thShotLib.BRAKE01, num * 2, (float)num / 5F);
		}
		spellCardEnd(119);
	}

	//禁弾「カタディオプトリック」
	private void spellCard_21()
	{
		if(ticksExisted % 25 == 1 && ticksExisted < 75)
		{
			float angle;
			float angleSpan = 90F / 4F;
			float angleBase = 180F;
			if(ticksExisted == 26)
			{
				angleBase = 90F;
			}
			else if(ticksExisted == 51)
			{
				angleBase = -90F;
			}
			angle = angleBase - angleSpan * 2;
			
	    	for(int i = 0; i < 5; i++)
	    	{
				Vec3 look = thShotLib.getRotationVectorFromAngle(user.rotationYaw, user.rotationPitch, angle, 1.0D);
				scarletShot(look.xCoord, look.yCoord, look.zCoord, 0.6D, true);
	    		angle += angleSpan;
	    	}
	    	thShotLib.playShotSound(user);
		}
		spellCardEnd(80);
	}
	
	//祟符「ミシャグジさま」
	private void spellCard_22()
	{
		if(ticksExisted % 9 == 3)
		{		
			Vec3 look = thShotLib.getVecFromAngle(user.rotationYaw, 0F, 1.0D);
			//Vec3 look2 = thShotLib.getRotationVectorFromAngle(user.rotationYaw, user.rotationPitch,  + rand.nextFloat() * 360F, 1.0D);
			//Vec3 look2 = thShotLib.getVecFromAngle(user.rotationYaw + rand.nextFloat() * 360F, user.rotationPitch, 1.0D);
			Vec3 rotate = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch + 90F, 1.0D);
			Vec3 rotate2 = thShotLib.getVectorFromRotation(rotate.xCoord, rotate.yCoord, rotate.zCoord, look.xCoord, look.yCoord, look.zCoord, 90F);
			thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord,  1.2F, 1.9D, 0.2D, -0.15D, 0.0D, 0.0D, 0.0D, 3.0F, thShotLib.RICE[thShotLib.GREEN], thShotLib.SIZE[thShotLib.RICE[0] / 8], 120, 3, 0, 32, 0.7D);
			thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord, -1.2F, 1.9D, 0.2D, -0.15D, 0.0D, 0.0D, 0.0D, 3.0F, thShotLib.RICE[thShotLib.GREEN], thShotLib.SIZE[thShotLib.RICE[0] / 8], 120, 3, 0, 32, 0.7D);

		}
		spellCardEnd(90);
	}
	
	//「レッドマジック」
	private void spellCard_23()
	{
		/*if(ticksExisted == 5)
		{
			for(int i = 0; i < 3; i++)
			{
				Vec3 look = thShotLib.getVecFromAngle(user.rotationYaw + i * 30F, 0F, 1.0D);
				Vec3 rotate = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch + 90F, 1.0D);
				Vec3 rotate2 = thShotLib.getVectorFromRotation(rotate.xCoord, rotate.yCoord, rotate.zCoord, look.xCoord, look.yCoord, look.zCoord, 90F);
				thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord,  0F, 0.6D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 6, thShotLib.BIG[thShotLib.BLUE], thShotLib.SIZE[thShotLib.BIG[0] / 8], 40, i * 2 + 2, thShotLib.REDMAGIC1, 4, 0.7D);
			}
		}
		else */if(ticksExisted == 5)
		{
			float angle = 0F;
			for(int i = 0; i < 3; i++)
			{
			Vec3 look = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch + angle, 1.0D);
			thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord, -5F, 0.9D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.BIG[thShotLib.PURPLE], thShotLib.SIZE[thShotLib.BIG[0] / 8], 30, 3, thShotLib.REDMAGIC1, 6, 0.7D);

			
			look = thShotLib.getVecFromAngle(user.rotationYaw + 90F, user.rotationPitch + 90F + angle, 1.0D);
			thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord, -5F, 0.9D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.BIG[thShotLib.PURPLE], thShotLib.SIZE[thShotLib.BIG[0] / 8], 30, 3, thShotLib.REDMAGIC1, 6, 0.7D);
			angle += 60F;
			}
		}
		else if(ticksExisted == 75)
		{
			float angle = 0F;
			for(int i = 0; i < 3; i++)
			{
			Vec3 look = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch + angle, 1.0D);
			thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord,  5F, 0.9D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.BIG[thShotLib.PURPLE], thShotLib.SIZE[thShotLib.BIG[0] / 8], 30, 3, thShotLib.REDMAGIC1, 6, 0.7D);
			
			look = thShotLib.getVecFromAngle(user.rotationYaw + 90F, user.rotationPitch + 90F + angle, 1.0D);
			thShotLib.createCircleShot(user, user, user.posX, user.posY + 0.2D, user.posZ, look.xCoord, look.yCoord, look.zCoord,  5F, 0.9D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.BIG[thShotLib.PURPLE], thShotLib.SIZE[thShotLib.BIG[0] / 8], 30, 3, thShotLib.REDMAGIC1, 6, 0.7D);
			angle += 60F;
			}
		}
		spellCardEnd(190);
	}
	
	//奇術「エターナルミーク」
	private void spellCard_24()
	{
		if(ticksExisted < 40)
		{
			Vec3 look = user.getLookVec();
			thShotLib.createRandomRingShot(user, user, user.posX + look.xCoord, thShotLib.getPosYFromEye(user, -0.2D) + look.yCoord, user.posZ + look.zCoord, look.xCoord, look.yCoord, look.zCoord, 0F, 1.5D, 1.5D, 0.0D, 0.0D, 0.0D, 0.0D, 3F, thShotLib.KNIFE[thShotLib.BLUE], thShotLib.SIZE[thShotLib.KNIFE[0] / 8], 60, 3, 0, 3, 0.2D, 50F);
			thShotLib.playShotSound(user);
			user.swingItem();
		}
		spellCardEnd(50);
	}
	
	//恋符「ノンディレクショナルレーザー」
	private void spellCard_25()
	{
		if(ticksExisted == 3)
		{
			worldObj.playSoundAtEntity(this, "thKaguyaMod.masterspark", mod_thKaguya.MasterSparkVol, 1.0F);
			for(int i = 0; i < 5; i++)
			{
				Vec3 look = user.getLookVec();
				Vec3 rotate = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch - 90F);
				Vec3 move = thShotLib.getVectorFromRotation(rotate.xCoord, rotate.yCoord, rotate.zCoord, look.xCoord, look.yCoord, look.zCoord, i * 72F);
				thShotLib.createLaserB(user, user, 0.0D, thShotLib.getPosYFromEye(user) - user.posY, 0.0D, move.xCoord, move.yCoord, move.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord, -4F, 7.0F, thShotLib.RED + i, 0.7F, 60, 25, 0,  20.8D, user, 1.5D, 1.0F);
			}
		}
		if(ticksExisted == 63)
		{
			worldObj.playSoundAtEntity(this, "thKaguyaMod.masterspark", mod_thKaguya.MasterSparkVol, 1.0F);
			for(int i = 0; i < 5; i++)
			{
				Vec3 look = user.getLookVec();
				Vec3 rotate = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch - 90F);
				Vec3 move = thShotLib.getVectorFromRotation(rotate.xCoord, rotate.yCoord, rotate.zCoord, look.xCoord, look.yCoord, look.zCoord, i * 72F);
				thShotLib.createLaserB(user, user, 0.0D, thShotLib.getPosYFromEye(user) - user.posY, 0.0D, move.xCoord, move.yCoord, move.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord,  4F, 7.0F, thShotLib.RED + i, 0.7F, 60, 25, 0,  20.8D, user, 1.5D, 1.0F);
			}
		}
		spellCardEnd(103);
	}
	
	//幻想「花鳥風月、嘯風弄月」
	private void spellCard_26()
	{
		

		Vec3 look = user.getLookVec();
		Vec3 rotate = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch + 90F);
		Vec3 look2, look3;
		EntityTHShot mother;
		float angle = ticksExisted * 3F, angle2;
		//float rotationYawSpeed = 3F;
		if(ticksExisted > 30)
		{
			angle = -ticksExisted * 3F;
			//rotationYawSpeed = -3F;
		}
		
		if(ticksExisted > 60)
		{
			
		}
		//else if(ticksExisted % 10 == 0)
		{
			rotate = thShotLib.getVecFromAngle(user.rotationYaw, user.rotationPitch + 25F + (float)Math.sin(ticksExisted * 10F / 180F * 3.141593F) * 20F);
			for(int i = 0; i < 5; i++)
			{
				look2 = thShotLib.getVectorFromRotation(look.xCoord, look.yCoord, look.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord, angle);
				look3 = thShotLib.getVectorFromRotation(look.xCoord, look.yCoord, look.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord, -angle);
				if(ticksExisted % 10 == 0)
				{
					mother = thShotLib.createShot(user, user, user.posX + look2.xCoord * 2.0D, thShotLib.getPosYFromEye(user) + look2.yCoord * 2.0D, user.posZ + look2.zCoord * 2.0D, look2.xCoord, look2.yCoord, look2.zCoord, 0F, rotate.xCoord, rotate.yCoord, rotate.zCoord, 0F, 0.4D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.MEDIUM[thShotLib.RED], thShotLib.SIZE[thShotLib.BIG[0] / 8], 120, 3, 0);
					angle2 = 0F;
					Vec3 motherOver = thShotLib.getVecFromAngle(mother.rotationYaw, mother.rotationPitch + 90F);
					for(int j = 0; j < 5; j++)
					{
						Vec3 set = thShotLib.getVectorFromRotation(mother.shotVectorX, mother.shotVectorY, mother.shotVectorZ, motherOver.xCoord, motherOver.yCoord, motherOver.zCoord, angle2);
						//look3 = thShotLib.getVectorFromRotation(rotate.xCoord, rotate.yCoord, rotate.zCoord, look2.xCoord, look2.yCoord, look2.zCoord, angle2);
						thShotLib.createLaserB(user, mother, 0.0D, 0.0D, 0.0D, set.xCoord, set.yCoord, set.zCoord, mother.shotVectorX, mother.shotGravityY, mother.shotVectorZ, 4F, 6.0F, thShotLib.RED, 0.5F, 120, 0, 0, 2.0D, mother, 0.0D, 0.0D);
						angle2 += 72F;
					}
				}
				else if(ticksExisted % 2 == 0)
				{
					thShotLib.createShot(user, user, user.posX + look2.xCoord * 2.0D, thShotLib.getPosYFromEye(user) + look2.yCoord * 2.0D, user.posZ + look2.zCoord * 2.0D, look2.xCoord, look2.yCoord, look2.zCoord, 0F, rotate.xCoord, rotate.yCoord, rotate.zCoord, 0F, 0.4D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.MEDIUM[thShotLib.YELLOW], thShotLib.SIZE[thShotLib.MEDIUM[0] / 8], 120, 3, 0);
					thShotLib.createShot(user, user, user.posX + look3.xCoord * 2.0D, thShotLib.getPosYFromEye(user) + look3.yCoord * 2.0D, user.posZ + look3.zCoord * 2.0D, look3.xCoord, look3.yCoord, look3.zCoord, 0F, rotate.xCoord, rotate.yCoord, rotate.zCoord, 0F, 0.4D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.MEDIUM[thShotLib.YELLOW], thShotLib.SIZE[thShotLib.MEDIUM[0] / 8], 120, 3, 0);
				}
				angle += 72F;
			}
		}
		/*else //if(ticksExisted )
		{
			look2 = thShotLib.getVectorFromRotation(look.xCoord, look.yCoord, look.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord, angle);
			//thShotLib.createRingShot(user, user, user.posX, thShotLib.getPosYFromEye(user), user.posZ, look2.xCoord, look2.yCoord, look2.zCoord, 0F, 0.4D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.MEDIUM[thShotLib.YELLOW], thShotLib.SIZE[thShotLib.BIG[0] / 8], 120, 6, 0, 5, 2.0D,  45F + (float)Math.sin(ticksExisted * 30F / 180F * 3.141593F) * 30F);
			thShotLib.createRingShot(user, user, user.posX, user.posY, user.posZ, look.xCoord, look.yCoord, look.zCoord, 0.0F, 0.4D, 0.2D, 0.0D, 0.0D, 0.0D, 0.0D, 14F, thShotLib.MEDIUM[thShotLib.YELLOW], thShotLib.SIZE[thShotLib.MEDIUM[0] / 8], 120, 6, 0, 5, 2.0D, 45F + (float)Math.sin(ticksExisted * 10F / 180F * 3.141593F) * 30F, angle);
		}*/
		spellCardEnd(80);
	}
	
	
    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
    	nbttagcompound.setShort("count", (short)count);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
    	count = nbttagcompound.getShort("count");
    }
	
	//スペルカードNoを設定する
	public void setSpellCardNumber(int number)
	{
		dataWatcher.updateObject(18, Integer.valueOf(number));
	}
	
	//スペルカードNoを返す
	public int getSpellCardNumber()
	{
		return dataWatcher.getWatchableObjectInt(18);
	}

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float par1)
    {
        return 0.5F;
    }

}
