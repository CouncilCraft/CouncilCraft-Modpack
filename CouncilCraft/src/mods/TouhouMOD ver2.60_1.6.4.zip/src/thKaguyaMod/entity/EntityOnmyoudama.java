package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityFallingSand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;

public class EntityOnmyoudama extends EntityTHShot
{
	//陰陽玉
	
	private boolean shootingFlag;
	private boolean userHit;
	private int hitTimer;
	
	//ワールド読み込み時に呼び出されるコンストラクト
    public EntityOnmyoudama(World world)
    {
        super(world);
    }
    
   
	
	public EntityOnmyoudama(World world, EntityLivingBase entityUser, Entity entity,
		double xPos, double yPos, double zPos,
    	double xVector, double yVector, double zVector,
    	double firstSpeed, double maxSpeed, double addSpeed,
    	double xVectorG, double yVectorG, double zVectorG, float damage, int color, float size, int dead, int delay, int special)
    {
        super(world, entityUser, entity, xPos, yPos, zPos, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D, firstSpeed, maxSpeed, addSpeed,
        		xVectorG, yVectorG, zVectorG, damage, color, size, dead, delay, thShotLib.BOUND04);
        shootingFlag = false;
        userHit = false;
        hitTimer = 0;
    }
	
	//ショットが存在する限り呼び出されるメソッド
	@Override
    public void onUpdate()
    {	
		if(shootingFlag)
		{
			shotAcceleration = 0.0D;
		}
		if(userEntity != null)
		{
			if(userEntity instanceof EntityPlayer)
			{
				EntityPlayer player = (EntityPlayer)userEntity;
				if(player.isUsingItem() && !shootingFlag)
				{
					Vec3 vec3 = thShotLib.getVecFromAngle( -rotationYaw, -rotationPitch, 0.6D);
					/*double xPos = userEntity.posX - (double)(MathHelper.cos(userEntity.rotationYaw / 180.0F * (float)Math.PI) * 0.32F) * getShotSize() * 2.0D;
					double yPos = userEntity.posY - 0.1D;
					double zPos = userEntity.posZ - (double)(MathHelper.sin(userEntity.rotationYaw / 180.0F * (float)Math.PI) * 0.32F) * getShotSize() * 2.0D;*/
					//prevPosX = posX;
		        	//prevPosY = posY;
		        	//prevPosZ = posZ;
		        	
					setPositionAndRotation(userEntity.posX + vec3.xCoord * 2, thShotLib.getPosYFromEye(userEntity, -0.1D) + vec3.yCoord, userEntity.posZ + vec3.zCoord, -userEntity.rotationYaw, -userEntity.rotationPitch);
					
					
					if(getShotSize() < 3.00F)
					{
						setShotSize(getShotSize() + 0.06F);
					}
					if(player.inventory.getCurrentItem() != null)
					{
						if(player.inventory.getCurrentItem().getItem() != mod_thKaguya.oharaibouRItem)
						{
						
							if(!worldObj.isRemote)
							{
								//worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
								setDead();
							}
							return;
						}
					}
					else
					{
						if(!worldObj.isRemote)
						{
							//worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
							setDead();
						}
						return;
					}
					return;
				}
				else if(shootingFlag == false)
				{
					
					if(player.inventory.getCurrentItem() != null)
					{
						if(player.inventory.getCurrentItem().getItem() != mod_thKaguya.oharaibouRItem)
						{
						
							if(!worldObj.isRemote)
							{
								//worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
								setDead();
							}
							return;
						}
					}
					else
					{
						if(!worldObj.isRemote)
						{
							//worldObj.createExplosion(this, this.posX, this.posY, this.posZ, getShotSize(), true);
							setDead();
						}
						return;
					}
					ticksExisted = 1;
					shotSpeed = 0.5D;
					setVector();
					shotAcceleration = 1.0D;
					setSize(shotSize, shotSize);
					shootingFlag = true;
				}
			}

		}
		else
		{
			if(!worldObj.isRemote)
			{
				setDead();
				return;
			}
		}
		
		shotDamage = getShotSize() * 6.0F;

    	super.onUpdate();
    	
		//始点を登録
        Vec3 supVec3d1 = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
    	//終点を登録
    	Vec3 supVec3d2 = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY + getShotSize(), posZ);
        //始点と終点からブロックとの衝突を取得
    	MovingObjectPosition movingObjectPosition = worldObj.rayTraceBlocks_do_do(supVec3d1, supVec3d2, false, true);
    	
    	if(movingObjectPosition != null && movingObjectPosition.entityHit == null)
    	{
    		double diveY = movingObjectPosition.blockY - (posY + getShotSize());
    		posY = movingObjectPosition.blockY + getShotSize() + 0.01D + diveY;
    		setPosition(posX, posY, posZ);
    		rotationPitch *= -1.0D;
    		setVector();
    		motionY *= 0.9D;
    	}
    	
		if(!userHit)
		{
			//始点を登録
	        Vec3 vec3d = worldObj.getWorldVec3Pool().getVecFromPool(posX, posY, posZ);
	    	//終点を登録
	    	Vec3 vec3d2 = worldObj.getWorldVec3Pool().getVecFromPool(posX + motionX, posY + motionY, posZ + motionZ);
	        //始点と終点からブロックとの衝突を取得
	    	movingObjectPosition = worldObj.rayTraceBlocks_do_do(vec3d, vec3d2, false, true);
			if(!hitUserCheck(movingObjectPosition, vec3d, vec3d2))
			{
				hitTimer++;
				if(hitTimer >= 2)
				{
					userHit = true;
				}
			}
		}
    }
	
	public boolean userHitCheck(Entity entity)
	{
		return userHit;
	}
	
	
	//使用者自身にも当たるかどうか
	@Override
	protected boolean isUserHit()
	{
		return true;
	}
	
	
	@Override
	public boolean entityHitSpecialProcess(Entity hitEntity)
	{
		rotationYaw *= -1.0F;
		rotationPitch *= -1.0F;
		setRotation(rotationYaw, rotationPitch);
		setVector();
		motionX *= 0.8F;
		motionY *= 0.8F;
		motionZ *= 0.8F;
		
		return false;
	}
	

	
    //跳ね返せる弾かどうか
    protected boolean isReturnableShot()
    {
    	return true;
    }
	
	
	//当たり判定の追加
	public boolean hitCheckEx(Entity entity)
	{
		return false;
	}
    	
    //弾の強さ
    public int getShotStrength()
    {
    	return 10;
    }
	
}
