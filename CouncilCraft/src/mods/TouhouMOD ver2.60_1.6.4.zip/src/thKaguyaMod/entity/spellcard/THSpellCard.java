package thKaguyaMod.entity.spellcard;

public abstract class THSpellCard {
	
	private int start;
	private int end;
	private int number;
	private int count;
	
	public THSpellCard()
	{
	}
	
	public boolean onUpdate()
	{
		if(count > getStartTime())
		{
			return false;
		}
		return true;
	}
	
	public int getSpellCardNumber()
	{
		return -1;
	}
	
	public int getStartTime()
	{
		return 0;
	}
	
	public int getEndTime()
	{
		return 120;
	}

}
