package thKaguyaMod.entity.spellcard;

public class THSpellCard_0 extends THSpellCard
{
	public THSpellCard_0()
	{
	}
	
	public int getSpellCardNumber()
	{
		return 0;
	}
	
	public int getStartTime()
	{
		return 15;
	}
	
	public int getEndTime()
	{
		return 49;
	}
}
