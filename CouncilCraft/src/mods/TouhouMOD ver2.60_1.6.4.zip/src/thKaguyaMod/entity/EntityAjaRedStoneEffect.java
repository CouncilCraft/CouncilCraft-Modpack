package thKaguyaMod.entity;

import net.minecraft.*;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import thKaguyaMod.thShotLib;

public class EntityAjaRedStoneEffect extends Entity
{
	//エイジャの赤石の光のエフェクト

	public EntityLivingBase user;
	public int lightLevel;//取り込んだ光の量を保存
	private double length = 1.2D;

    public EntityAjaRedStoneEffect(World world)
    {
        super(world);
        setSize(2.0F, 0.0F);//サイズを設定　平面上の横と奥行きサイズ、高さ
        yOffset = 0.0F;//高さを設定
    	lightLevel = 0;
    	setLightPower(0);
    }

    public EntityAjaRedStoneEffect(World world, EntityLivingBase entityLiving)
    {
        this(world);

        setLightPower(0);
    	user = entityLiving;
    	posX = user.posX - Math.sin((user.rotationYaw) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * length;
    	posY = user.posY - Math.sin(user.rotationPitch / 180F * 3.141593F) * length + (double)user.getEyeHeight();
    	posZ = user.posZ + Math.cos((user.rotationYaw) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * length;
    	this.setPositionAndRotation(posX, posY, posZ, user.rotationYaw, user.rotationPitch);
    	//setAngles(user.rotationYaw, user.rotationPitch);
    }
    
	//生成時に呼ばれる
    protected void entityInit()
    {
    	dataWatcher.addObject(19, new Integer(0));
    }

	/**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
	@Override
    protected boolean canTriggerWalking()
    {
        return false;
    }

	//当たり判定の有無　falseだと右クリックの選択ですらできない。trueならsetSize()で設定したボックスの当たり判定が出現する
	@Override
    public boolean canBeCollidedWith()
    {
        return false;
    }

	//Entityが存在する限り毎フレーム呼び出されるメソッド
	@Override
    public void onUpdate()
    {
    	//エイジャの赤石の使用者がいないなら
    	if(!worldObj.isRemote && user == null )
    	{
    		//消滅させる
    		setDead();
    		return;
    	}
    	super.onUpdate();

    	//使用者がいるなら
    	if(user != null)
    	{
    		if(user instanceof EntityPlayer)
    		{
    			EntityPlayer userEntity_p = (EntityPlayer)user;
    			if(!userEntity_p.isUsingItem())
    			{
	    			//レーザーを発射する
	    			float yaw, pitch;
	    			yaw   = user.rotationYaw / 180F * (float)Math.PI;
	    			pitch = user.rotationPitch / 180F * (float)Math.PI;

	   				double xVec = -Math.sin( yaw) * Math.cos( pitch);//X方向　水平方向
	    			double yVec = -Math.sin( pitch);//Y方向　上下
	   				double zVec =  Math.cos( yaw) * Math.cos( pitch);//Z方向　水平方向
	    			double px = posX;// + xVec;
	    			double py = posY;// + yVec;
	    			double pz = posZ;// + zVec;
	    			int damage = (int)((double)lightLevel / 40.0);
	    			if(damage > 30)//最大ダメージはハート15個分。頑張ってもそこまで
	    			{
	    				damage = 30;
	    			}

    				if(damage > 0)//ダメージがあるなら
    				{
    					//レーザーを発射する
    					thShotLib.createLaserA(user, this, posX, posY, posZ, user.rotationYaw, user.rotationPitch, 0.1D, 4.0D, 0.3D, 0.0D, 0.0D, 0.0D, damage, thShotLib.RED, (float)damage * 0.01F, 120, 0, thShotLib.AJA01, (double)damage * 0.3D);
    					if(!worldObj.isRemote)//サーバーなら
    					{
    						setDead();//光のエフェクトを消滅させる
    					}
    				}
    			}
    		}
    		else
    		{
    			if(!worldObj.isRemote)
    			{
    				setDead();
    			}
    		}
    	}

    	//今ある場所の光レベルに合わせて光の量を増やす
    	setLightPower( worldObj.getBlockLightValue((int)posX, (int)posY, (int)posZ));
    	lightLevel += getLightPower();

    	//使用者がいれば目の前に行くようにする
    	if(user != null)
    	{
    		//prevPosX = posX;
    		//prevPosY = posY;
    		//prevPosZ = posZ;
    		
    		posX = user.posX - Math.sin((user.rotationYaw) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * length;
    		posY = user.posY - Math.sin(user.rotationPitch / 180F * 3.141593F) * length + user.getEyeHeight();
    		posZ = user.posZ + Math.cos((user.rotationYaw) / 180F * 3.141593F) * Math.cos(user.rotationPitch / 180F * 3.141593F) * length;
    		//thKaguyaLib.itemEffectFollowUser(this, userEntity, 0.8D, 0F);
    		//rotationYaw = userEntity.rotationYaw;
    		rotationYaw = user.rotationYawHead;
    		rotationPitch = user.rotationPitch;
    		setPosition(posX, posY, posZ);
    	}

    	if(rotationYaw >  180F)rotationYaw -= 360F;
    	if(rotationYaw < -180F)rotationYaw += 360F;
    	if(rotationPitch >  180F)rotationPitch -= 360F;
    	if(rotationPitch < -180F)rotationPitch += 360F;

    	setRotation(rotationYaw, rotationPitch);
    }

	//取り込んでいる光の量を設定
	public void setLightPower(int lightPower)
	{
		dataWatcher.updateObject(19, Integer.valueOf(lightPower));
	}

	//取り込んでいる光の量を返す
	public int getLightPower()
	{
		return dataWatcher.getWatchableObjectInt(19);
	}

	protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
    }

    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
    }
}
