package thKaguyaMod;

// レンダーに関するレジストリ
import cpw.mods.fml.client.registry.RenderingRegistry;

public class CommonProxy
{
	public void registerTextures()
	{
	}

	public void registerRenderers()
	{
		/*
		 サーバー側では何もしない
		 クライアント側でのみ必要な処理はこのように空のメソッドを用意し,
		 CommonProxyを継承したClientProxyで行う
		*/
	}

	public int addArmor(String armor)
	{
		return 0;
	}
	
	public int getNewRenderType()
	{
		return -1;
	}
}