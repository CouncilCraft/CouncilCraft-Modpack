package thKaguyaMod;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thKaguyaMod.entity.EntityHomingAmulet;
import thKaguyaMod.entity.EntityMusouFuuin;
import thKaguyaMod.entity.EntityTHShot;
import thKaguyaMod.entity.EntityTHLaser;
import thKaguyaMod.entity.EntityTHSetLaser;
import thKaguyaMod.entity.EntityTHFairy;

import java.util.List;
import java.util.Random;

public class thShotLib
{
	//弾幕関連の汎用関数群
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		定義	Definition																										*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//弾の色		Shot Colors
	public static final int RED    = 0;
	public static final int BLUE   = 1;
	public static final int GREEN  = 2;
	public static final int YELLOW = 3;
	public static final int PURPLE = 4;
	public static final int AQUA   = 5;
	public static final int ORANGE = 6;
	public static final int WHITE  = 7;
	
	//弾形状		Shot Forms
	public static final int SMALL[]     = {  0,  1,  2,  3,  4,  5,  6,  7};
	public static final int TINY[]      = {  8,  9, 10, 11, 12, 13, 14, 15};
	public static final int MEDIUM[]    = { 16, 17, 18, 19, 20, 21, 22, 23};
	public static final int PEARL[]     = { 24, 25, 26, 27, 28, 29, 30, 31};
	public static final int CIRCLE[]    = { 32, 33, 34, 35, 36, 37, 38, 39};
	public static final int LIGHT[]     = { 40, 41, 42, 43, 44, 45, 46, 47};
	public static final int SCALE[]     = { 48, 49, 50, 51, 52, 53, 54, 55};
	public static final int BUTTERFLY[] = { 56, 57, 58, 59, 60, 61, 62, 63};
	public static final int SMALLSTAR[] = { 64, 65, 66, 67, 68, 69, 70, 71};
	public static final int STAR[]      = { 72, 73, 74, 75, 76, 77, 78, 79};
	public static final int RICE[]		= { 80, 81, 82, 83, 84, 85, 86, 87};
	public static final int CRYSTAL[]   = { 88, 89, 90, 91, 92, 93, 94, 95};
	public static final int HEART[]		= { 96, 97, 98, 99,100,101,102,103};
	public static final int KUNAI[]		= {104,105,106,107,108,109,110,111};
	public static final int TALISMAN[]	= {112,113,114,115,116,117,118,119};
	public static final int BIGLIGHT[]	= {120,121,122,123,124,125,126,127};
	public static final int OVAL[]		= {128,129,130,131,132,133,134,135};
	public static final int KNIFE[]     = {224,225,226,227,228,229,230,231};
	public static final int WIND[]		= {232,233,234,235,236,237,238,239};
	public static final int BIG[]       = {240,241,242,243,244,245,246,247};
	public static final int KISHITU[]   = {248,249,250,251,252,253,254,255};
	
	//弾の色の名前		Shot Color Names(JP)
	public static final String COLOR_NAME_JP[]	={
		"赤", "青", "緑", "黄", "紫", "水色", "橙", "白", "虹色", "ランダム", "暖色", "寒色", "", "", "", ""};
	
	//弾の色の名前		Shot Color Names(EN)
	public static final String COLOR_NAME[]	={
		"Red", "Blue", "Green", "Yellow", "Purple", "Aqua", "Orange", "White", "Rainbow", "Random", "Hot", "Cold", "", "", "", ""};
	
	//弾の名前		Shot Form Names
	public static final String SHOT_NAME_JP[]	={
		  "小弾",  "粒弾",  "中弾","真珠弾",  "輪弾",  "光弾",  "鱗弾",  "蝶弾",
		"小星弾",  "星弾",  "米弾","結晶弾","ハート","クナイ",  "札弾","大光弾",
		"楕円弾","未定義","未定義","未定義","未定義","未定義","未定義","未定義",
		"未定義","未定義","未定義","未定義","ナイフ",  "風弾",  "大弾","気質弾"};
	
	//形状ごとの弾のダメージを定義
	/*public static final int DAMAGE[] = {2, 1, 3, 5, 2, 3, 2, 3,
										2, 3, 0, 0, 0, 0, 0, 0,
										0, 0, 0, 0, 0, 0, 0, 0,
										0, 0, 0, 0, 3, 4, 5, 5};*/
	
	//形状ごとの弾のダメージを定義		Shot Damage by Form
	public static final float DAMAGE[] = {	2.4F, 1.0F, 2.8F, 5.0F, 2.0F, 3.4F, 1.6F, 2.8F,
											1.6F, 3.0F, 1.2F, 1.8F, 3.2F, 2.6F, 1.0F, 6.8F,
											3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
											0.0F, 0.0F, 0.0F, 0.0F, 2.6F, 4.0F, 5.0F, 5.0F};
	
	//形状ごとの弾の大きさを定義		Shot Size by Form
	public static final float SIZE[] = {0.30F, 0.15F, 0.50F, 0.30F, 0.30F, 0.30F, 0.15F, 0.30F, 
										0.25F, 0.50F, 0.15F, 0.15F, 0.50F, 0.15F, 0.15F, 0.60F,
										0.50F, 0.00F, 0.00F, 0.00F, 0.00F, 0.00F, 0.00F, 0.00F,
										0.00F, 0.00F, 0.00F, 0.00F, 0.30F, 1.00F, 0.90F, 0.90F};
	
	//特殊弾の定義		Special Shot Definition
	public static final int FALL01          =  30;
	public static final int BOUND01         =  40;//一回だけ跳ね返るする
	public static final int BOUND02         =  41;//二回だけ跳ね返る
	public static final int BOUND03         =  42;//三回だけ跳ね返る
	public static final int BOUND04         =  43;//無限に跳ね返る
	public static final int BOUNDFALL01     =  50;
	public static final int FIRE			=  60;//やけどするぜ！着火効果付与
	public static final int BRAKE01			= 150;
	public static final int FREEZE01        = 160;
	public static final int KAPPA01         = 170;
	public static final int WIND01          = 180;
	public static final int KISHITU01		= 190;
	public static final int FLOWER01		= 200;
	public static final int STARDUST01      = 210;
	public static final int KOKUSHI01		= 230;
	public static final int AJA01           = 240;
	public static final int SILVERKNIFE     = 250;
	public static final int MIRACLE         = 251;
	public static final int FAFRO           = 252;
	public static final int SPOILER01       = 253;
	public static final int SPOILER02       = 254;
	public static final int ICECLEFALL01    = 260;
	public static final int ICECLEFALL02    = 261;
	public static final int MISHAGUZI		= 270;
	public static final int REDMAGIC1       = 280;
	public static final int REDMAGIC2		= 281;
	public static final int REDMAGIC3		= 282;
	public static final int GUNGNIR			= 285;
	
	//標準の重力値		Default Gravity
	public static final double GRAVITY_DEFAULT = -0.03D;
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		弾生成補助	Assistant Create Shots 																						*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/*弾IDから形状IDを返す
	 * shotID	: 弾の形状と色を含めたID。thShotLib.SMALLSTAR[thShotLib.GREEN]と表される。
	 * 返り値	: 形状ID。色を含まない形状単位のID。形状によるデフォルトのサイズやダメージ量を求めるのに必要。
	 */
	public static final int getFormID(int shotID)
	{
		return (shotID - (shotID % 8)) / 8; 
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		弾生成系	Create Shots																								*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/*すべての弾の基礎となる生成処理	Create Shots Base of All
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * angleZ		: 弾の進行方向を軸とした傾き（180にすると弾が上下ひっくり返る）
	 * rotateVectorX: 弾が角度を変えるときに利用する軸のベクトル（回転軸）
	 * rotateVectorY:
	 * rotateVectorZ:
	 * rotateYawSpeed: 弾が角度を変える速度（毎フレーム指定した角度で向きを変える）
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, float angleZ, 
											double rotateVectorX, double rotateVectorY, double rotateVectorZ, float rotationYawSpeed,
											double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special)
	{
		EntityTHShot entityTHShot;
		entityTHShot = new EntityTHShot(source.worldObj, user, source, xPos, yPos, zPos,
										xVector, yVector, zVector, angleZ, 
										rotateVectorX, rotateVectorY, rotateVectorZ, rotationYawSpeed,
										firstSpeed, limitSpeed, acceleration,
										xVectorG, yVectorG, zVectorG,
										damage, form, size, endTime, delay, special);
		if(!source.worldObj.isRemote)
		{
			source.worldObj.spawnEntityInWorld(entityTHShot);
			return entityTHShot;
		}
		return null;
	}
	
	
	/*すべての弾の基礎となる生成処理
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, float angleZ, double rotateVectorX, double rotateVectorY, double rotateVectorZ, 
											double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special)
	{
		EntityTHShot entityTHShot;
		entityTHShot = new EntityTHShot(source.worldObj, user, source, xPos, yPos, zPos,
										xVector, yVector, zVector, angleZ, rotateVectorX, rotateVectorY, rotateVectorZ,
										firstSpeed, limitSpeed, acceleration,
										xVectorG, yVectorG, zVectorG,
										damage, form, size, endTime, delay, special);
		if(!source.worldObj.isRemote)
		{
			source.worldObj.spawnEntityInWorld(entityTHShot);
			return entityTHShot;
		}
		return null;
	}
	

	/* 発射方向を角度で指定できるすべての弾の基礎となる生成処理 
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初期速度。0.1Dでかなり遅く、1.0Dもあれば速く感じる
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     : Y方向の重力。ここに-0.03Dを入れればおおよそ自然な落下になる
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾の場合は0といれる。例えばthShotLib.BOUND01と入れれば跳ね返り弾となる
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											float angleXZ, float angleY, float angleZ, double rotateVectorX, double rotateVectorY, double rotateVectorZ,
											double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special)
	{
		Vec3 vec3 = getVecFromAngle(angleXZ, angleY, 1.0D);
		
		return createShot(	user, source, xPos, yPos, zPos, vec3.xCoord, vec3.yCoord, vec3.zCoord, angleZ, rotateVectorX, rotateVectorY, rotateVectorZ,
						firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, form, size, endTime, delay, special);
	}

	
	/*最も一般的な弾の生成		Most General Shot Create
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 水平方向の角度をDegree（度数）で指定。0F ～ 360Fみたいな感じで
	 * angleY       : 垂直方向の角度。同上
	 * speed        : 弾の速度。目安として、0.1Dでかなり遅い、1.0Dで速い。
	 * form         : 弾番号を指定。整数でも指定できるが、thShotLib.SMALL[thShotLib.RED] などと指定もできる。この場合、赤い小弾が発射される
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed, int form)
	{
		return createShot(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, form, 0);
	}
	
	
	/*一般的な弾に加速度と遅延が付属したものを生成
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初期速度。0.1Dでかなり遅く、1.0Dもあれば速く感じる
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, int form, int delay)
	{	
		return createShot(user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, limitSpeed, acceleration, 0.0D, 0.0D, 0.0D, form, delay);
	}
	
	
	/*一般的な弾に加速度と遅延と重力を指定できるもの
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初期速度。0.1Dでかなり遅く、1.0Dもあれば速く感じる
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     : Y方向の重力。ここに-0.03Dを入れればおおよそ自然な落下になる
	 * zVectorG     :
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, double xVectorG, double yVectorG, double zVectorG, int form, int delay)
	{
		int formNo = form / 8;//形状は8の倍数で変化する

		return createShot(user, user, xPos, yPos, zPos, angleXZ, angleY, 0F, 0.0D, 1.0D, 0.0D,
						firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, DAMAGE[formNo], form, SIZE[formNo], 120, delay, 0);
	}
	
	
	/*最も一般的な弾を角度をベクトルを使い生成
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * speed        : 弾の速度。目安として、0.1Dでかなり遅い、1.0Dで速い。
	 * form         : 弾番号を指定。整数でも指定できるが、thShotLib.SMALL[thShotLib.RED] などと指定もできる。この場合、赤い小弾が発射される
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, double xVector, double yVector, double zVector, double speed, int form)
	{
		int formNo = form / 8;//形状は8の倍数で変化する
		
		return createShot(user, user, user.posX, user.posY, user.posZ, xVector, yVector, zVector, 0F, 0.0D, 1.0D, 0.0D,
						speed, speed, 0.0D, 0.0D, 0.0D, 0.0D, DAMAGE[formNo], form, SIZE[formNo], 120, 0, 0);
	}

	
	/*最も一般的な弾を生成
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 水平方向の角度をDegree（度数）で指定。0F ～ 360Fみたいな感じで
	 * angleY       : 垂直方向の角度。同上
	 * speed        : 弾の速度。目安として、0.1Dでかなり遅い、1.0Dで速い。
	 * form         : 弾番号を指定。整数でも指定できるが、thShotLib.SMALL[thShotLib.RED] などと指定もできる。この場合、赤い小弾が発射される
	 * special      : 弾の特殊な処理を指定する。普通の弾の場合は0といれる。例えばthShotLib.BOUND01と入れれば跳ね返り弾となる
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed, int form, int special)
	{
		return createShot(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, form, 0, special);
	}
	
	
	/*一般的な弾を生成の特殊弾を指定できるものに加速度と遅延を指定できるもの
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初期速度。0.1Dでかなり遅く、1.0Dもあれば速く感じる
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾の場合は0といれる。例えばthShotLib.BOUND01と入れれば跳ね返り弾となる
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, int form, int delay, int special)
	{
		return createShot(user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, limitSpeed, acceleration, 0.0D, 0.0D, 0.0D, form, delay, special);
	}
	
	
	/*一般的な弾を生成の特殊弾を指定できるものに加速度と遅延と重力を指定できるもの
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初期速度。0.1Dでかなり遅く、1.0Dもあれば速く感じる
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     : Y方向の重力。ここに-0.03Dを入れればおおよそ自然な落下になる
	 * zVectorG     :
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾の場合は0といれる。例えばthShotLib.BOUND01と入れれば跳ね返り弾となる
	 */
	public static final EntityTHShot createShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, double xVectorG, double yVectorG, double zVectorG, int form, int delay, int special)
	{
		int formNo = form / 8;//形状は8の倍数で変化する

		return createShot(user, user, xPos, yPos, zPos, angleXZ, angleY, 0F, 0.0D, 1.0D, 0.0D,
						firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, DAMAGE[formNo], form, SIZE[formNo], 120, delay, special);
	}

	
	/*すべてのn-way弾の根底となる処理	Create Wide Shots Base
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * way          : 弾数
	 * wideAngle    : 扇状の成す角度
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createWideShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, float rotationYawSpeed,
											double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special, int way, float wideAngle, double distance)
	{	
		int colorPattern = form - (form % 1000);
		if(colorPattern == 1000)
		{
			form -= 1000;
		}
		else if(colorPattern == 2000)
		{
			form -= 2000;
			form = form - form % 8;
		}
		Random rand = new Random();
    	int color = form;
		//弾の発射方向に対して上方に９０度回転させたベクトル（回転軸）を取得する
		float yaw = getYawFromVector(xVector, zVector);
		float pitch = getPitchFromVector(xVector, yVector, zVector);
		Vec3 rotateVec = thShotLib.getVecFromAngle(-yaw, - pitch + 90F, 1.0F);
		//扇の成す角度の半分、取得した回転軸を回転させる
		float angle = -wideAngle / 2F;
		float span = wideAngle / (way - 1);
		//扇の角度になるまで回転軸に沿って弾を配置する
		
		EntityTHShot shot;
		for(int i = 0; i < way; i++)
		{
			if(colorPattern == 1000)
			{
				color = form + rand.nextInt(7);
			}
			else if(colorPattern == 2000)
			{
				color = form + i % 7;
			}
			Vec3 vec = getVectorFromRotation(rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord, xVector, yVector, zVector, angle);
			createShot(user, source, xPos + vec.xCoord * distance, yPos + vec.yCoord * distance, zPos + vec.zCoord * distance, vec.xCoord, vec.yCoord, vec.zCoord,
					 -pitch * (float)Math.sin(angle / 180F * 3.141593F), rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord, rotationYawSpeed, firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, color, size, endTime, delay, special);
			angle += span;
		}
	}
	
	/*n-way弾の基礎となる処理
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * way          : 弾数
	 * wideAngle    : 扇状の成す角度
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createWideShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special, int way, float wideAngle, double distance)
	{	
		int colorPattern = form - (form % 1000);
		if(colorPattern == 1000)
		{
			form -= 1000;
		}
		else if(colorPattern == 2000)
		{
			form -= 2000;
			form = form - form % 8;
		}
		Random rand = new Random();
    	int color = form;
		//弾の発射方向に対して上方に９０度回転させたベクトル（回転軸）を取得する
		float yaw = getYawFromVector(xVector, zVector);
		float pitch = getPitchFromVector(xVector, yVector, zVector);
		Vec3 rotateVec = thShotLib.getVecFromAngle(-yaw, - pitch + 90F, 1.0F);
		//扇の成す角度の半分、取得した回転軸を回転させる
		float angle = -wideAngle / 2F;
		float span = wideAngle / (way - 1);
		//扇の角度になるまで回転軸に沿って弾を配置する
		
		EntityTHShot shot;
		for(int i = 0; i < way; i++)
		{
			if(colorPattern == 1000)
			{
				color = form + rand.nextInt(7);
			}
			else if(colorPattern == 2000)
			{
				color = form + i % 7;
			}
			Vec3 vec = getVectorFromRotation(rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord, xVector, yVector, zVector, angle);
			createShot(user, source, xPos + vec.xCoord * distance, yPos + vec.yCoord * distance, zPos + vec.zCoord * distance, vec.xCoord, vec.yCoord, vec.zCoord,
					 pitch * (float)Math.sin(angle / 180F * 3.141593F), rotateVec.xCoord, rotateVec.yCoord, rotateVec.zCoord, firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, color, size, endTime, delay, special);
			angle += span;
		}
	}
	
	/*n-way弾の基礎となる処理の角度指定版
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * way          : 弾数
	 * wideAngle    : 扇状の成す角度
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createWideShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos, float angleXZ, float angleY, 
			double firstSpeed, double maxSpeed, double addSpeed, double xVectorG, double yVectorG, double zVectorG, 
			float damage, int form, float size, int endTime, int delay, int special, int way, float wideAngle, double distance)
	{
		Vec3 vec3 = getVecFromAngle(angleXZ, angleY, 1.0D);
		
		createWideShot(user, source, xPos, yPos, zPos, vec3.xCoord, vec3.yCoord, vec3.zCoord, firstSpeed, maxSpeed, addSpeed, xVectorG, yVectorG, zVectorG,
				damage, form, size, endTime, delay, special, way, wideAngle, distance);
	}
	
	
	/*最も一般的な扇状弾
	 * way          : 弾数
	 * wideAngle    : 扇の広がる角度
	 */
	public static final void createWideShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed, int form, int way, float wideAngle)
	{
		createWideShot(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, form, 0, way, wideAngle);
	}
	
	
	/*最も一般的な扇状弾に加速度と遅延が加わったもの
	 * way          : 弾数
	 * wideAngle    : 扇の広がる角度
	 */
	public static final void createWideShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, int form, int delay, int way, float wideAngle)
	{
		int formNo = form;
		if(formNo >= 1000)
		{
			formNo %= 1000;
		}
		formNo = formNo / 8;//形状は8の倍数で変化する
		createWideShot(user, user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, limitSpeed, acceleration, 0.0D, 0.0D, 0.0D,
				DAMAGE[formNo], form, SIZE[formNo], 120, delay, 0, way, wideAngle, 0.0D);
	}
	
	
	/*すべての全方位弾の根底となる処理		Create Circle Shots Base
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * way          : 全方位の弾数
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createCircleShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, float rotationYawSpeed,
											double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special, int way, double distance)
	{
		createWideShot(user, source, xPos, yPos, zPos,
				-xVector, -yVector, -zVector, rotationYawSpeed,
				firstSpeed, limitSpeed, acceleration,
				xVectorG, yVectorG, zVectorG,
				damage, form, size, endTime, delay, special,  way, 360F - (360F / way), distance);
	}
	
	/*全方位弾の基礎となる処理
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : 弾のX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * way          : 全方位の弾数
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createCircleShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special, int way, double distance)
	{
		createWideShot(user, source, xPos, yPos, zPos,
				xVector, yVector,  zVector, firstSpeed, limitSpeed, acceleration,
				xVectorG, yVectorG, zVectorG,
				damage, form, size, endTime, delay, special, way, 360F - (360F / way), distance);
	}
	
	
	/*すべての全方位弾の基礎となる処理の角度指定版
	 * user         : 弾の持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : 弾の発射元。あまり意味は無い
	 * xPos         : 弾のX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 弾の水平方向の角度
	 * angleY       : 弾の垂直方向の角度
	 * firstSpeed   : 弾の初速度
	 * limitSpeed   : 弾の限界速度。これ以上は速く（遅く）ならない
	 * acceleration : 弾の加速度。毎フレームこの数値分速くなる
	 * xVectorG     : 弾のX軸方向の重力値。0.0Dで重力の影響を受けない
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : 弾のダメージ
	 * form         : 弾の形状。小弾、大弾、星弾、光弾などはこれできまる。また色も決まる。thShotLib.BUTTERFLY[ thShotLib.YELLOW ]というように指定できる
	 * size         : 弾の大きさ。当たり判定、描画サイズに関わる
	 * endTime      : 弾の消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * delay        : 弾の遅延時間。この時間が経過後に実体化して動作を起こす。それまでは光のエフェクトだけで何もしない
	 * special      : 弾の特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * way          : 全方位の弾数
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createCircleShot(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int form, float size, int endTime, int delay, int special, int way, double distance)
	{
		Vec3 vec3 = getVecFromAngle(angleXZ, angleY, 1.0D);
		
		createCircleShot(user, source, xPos, yPos, zPos, vec3.xCoord, vec3.yCoord, vec3.zCoord, firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, form, size, endTime, delay, special, way, distance);
	}
	
	
	/*最も一般的な全方位弾を発射する
	 * way          : 全方位の弾数
	 */
	public static final void createCircleShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed, int form, int way)
	{
		createCircleShot(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, form, 0, way);
	}
	
	
	/*最も一般的な全方位弾を発射するに加速度遅延を指定できるもの
	 * way           : 全方位の弾数
	 */
	public static final void createCircleShot(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, int form, int delay, int way)
	{
		int formNo = form / 8;//形状は8の倍数で変化する
		
		createCircleShot(user, user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, limitSpeed, acceleration, 0.0D, 0.0, 0.0D, DAMAGE[formNo], form, SIZE[formNo], 120, delay, 0, way, (double)SIZE[formNo]);
	}
	
	
	/*最も一般的な全方位弾をベクトル指定で発射する
	 * way           : 全方位の段数
	 */
	public static final void createCircleShot(EntityLivingBase user, double xPos, double yPos, double zPos, double vectorX, double vectorY, double vectorZ, double speed, int form, int way)
	{
		int formNo = form / 8;
		
		createCircleShot(user, user, xPos, yPos, zPos, vectorX, vectorY, vectorZ, speed, speed, 0.0D, 0.0D, 0.0D, 0.0D, DAMAGE[formNo], form, SIZE[formNo], 120, 0, 0, way, (double)SIZE[formNo]);
	}
	
	/*目の前に輪状の弾幕を発射する
	 * 
	 */
	public static final void createRingShot(
		EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
		double xVector, double yVector, double zVector, float rotationYawSpeed,
		double firstSpeed, double limitSpeed, double acceleration,
		double xVectorG, double yVectorG, double zVectorG,
		float damage, int form, float size, int endTime, int delay, int special, int way, double distance, float ringSpan, float ringBaseAngle)
	{
		ringSpan /= 2F;
		float yaw = getYawFromVector(-xVector, zVector);
		float pitch = getPitchFromVector(xVector, yVector, zVector);
		Vec3 baseVec = getVecFromAngle(-yaw, pitch + ringSpan, 1.0D);
		Vec3 overVec = getVecFromAngle(-yaw, pitch + 90F, 1.0D);
		Vec3 extendVec;
		float angle = ringBaseAngle;
		float span = 360F / way;
		
		Vec3 movingVec;
		for(int i = 0; i < way; i++)
		{
			movingVec = getVectorFromRotation(-xVector, -yVector, zVector, baseVec.xCoord, baseVec.yCoord, baseVec.zCoord, angle);
			extendVec = getVectorFromRotation(-xVector, -yVector, zVector, overVec.xCoord, overVec.yCoord, overVec.zCoord, angle);
			createShot(user, source, xPos - extendVec.xCoord * distance, yPos - extendVec.yCoord * distance, zPos + extendVec.zCoord * distance, -movingVec.xCoord, -movingVec.yCoord, movingVec.zCoord,
					angle, xVector, yVector, zVector, rotationYawSpeed, 
					firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG,
					damage, form, size, endTime, delay, special);
			angle += span;
		}
	}
	
	/*目の前の輪状空間にランダムに弾を発射する
	 * num		: 輪状空間にランダムに出す弾の数
	 * distance	: ?
	 * ringSpan	: 輪状空間の幅。中心点からこの幅÷２の角度に弾が飛ぶ
	 */
	public static final void createRandomRingShot(
		EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
		double xVector, double yVector, double zVector, float rotationYawSpeed,
		double firstSpeed, double limitSpeed, double acceleration,
		double xVectorG, double yVectorG, double zVectorG,
		float damage, int form, float size, int endTime, int delay, int special, int num, double distance, float ringSpan)
	{
		float ringMaxSpan = ringSpan / 2F;
		float yaw = getYawFromVector(-xVector, zVector);
		float pitch = getPitchFromVector(xVector, yVector, zVector);
		Vec3 baseVec;
		Vec3 overVec = getVecFromAngle(-yaw, pitch + 90F, 1.0D);
		Vec3 extendVec;
		float angle;
		Random rand = new Random();
		
		Vec3 movingVec;
		for(int i = 0; i < num; i++)
		{
			angle = rand.nextFloat() * 360F;
			baseVec = getVecFromAngle(-yaw, pitch + rand.nextFloat() * ringMaxSpan, 1.0D);
			movingVec = getVectorFromRotation(-xVector, -yVector, zVector, baseVec.xCoord, baseVec.yCoord, baseVec.zCoord, angle);
			extendVec = getVectorFromRotation(-xVector, -yVector, zVector, overVec.xCoord, overVec.yCoord, overVec.zCoord, angle);
			createShot(user, source, xPos - extendVec.xCoord * distance, yPos - extendVec.yCoord * distance, zPos + extendVec.zCoord * distance, -movingVec.xCoord, -movingVec.yCoord, movingVec.zCoord,
					angle, xVector, yVector, zVector, rotationYawSpeed, 
					firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG,
					damage, form, size, endTime, delay, special);
		}
	}
	
	public static final void createRandomRingShot(
			EntityLivingBase user, double posX, double posY, double posZ,
			float yaw, float pitch, double speed, int form, int num, float ringSpan)
	{
		Vec3 look = getVecFromAngle(yaw, pitch);
		int formId = form - (form % 8) / 8;
		createRandomRingShot(user, posX, posY, posZ, look.xCoord, look.yCoord, look.zCoord, 
				speed, speed, 0.0D, DAMAGE[formId], form, SIZE[formId], 120, 0, 0, num, 0.0D, ringSpan);
	}
	
	public static final void createRandomRingShot(
			EntityLivingBase user, double posX, double posY, double posZ,
			double xVector, double yVector, double zVector,
			double firstSpeed, double limitSpeed, double acceleration,
			float damage, int form, float size, int endTime, int delay, int special, int num, double distance, float ringSpan)
	{
		createRandomRingShot(user, user, posX, posY, posZ, xVector, yVector, zVector, 0F, firstSpeed, limitSpeed, acceleration,
				0.0D, 0.0D, 0.0D, damage, form, size, endTime, delay, special, num, distance, ringSpan);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		レーザー生成系	Create Lasers																								*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	/*すべての移動レーザー発射の基礎となる処理		Create Laser Base of Can Move
	 * 基本的に弾発射の基礎処理と同じ
	 * width  : レーザーの太さ。弾のsizeに該当。当たり判定の太さ
	 * length : レーザーの長さ。当たり判定も長さの分だけある
	 */
	public static final EntityTHLaser createLaserA(	EntityLivingBase user, Entity source, double xPos, double yPos, double zPos, double xVector, double yVector, double zVector,
												double firstSpeed, double limitSpeed, double acceleration, double xVectorG, double yVectorG, double zVectorG,
												float damage, int color, float width, int endTime, int delay, int special, double length)
	{
		EntityTHLaser laser = new EntityTHLaser(source.worldObj, user, source, xPos, yPos, zPos, xVector, yVector, zVector, 
												firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG,
												damage, color, width, endTime, delay, special, length);
		if(!source.worldObj.isRemote)
		{
			//レーザーを生成する
			source.worldObj.spawnEntityInWorld(laser);
		}
		return laser;
	}
	
	
	/*すべての移動レーザー発射の基礎となる処理の角度指定版
	 * 基本的に弾発射の基礎処理と同じ
	 * width  : レーザーの太さ。弾のsizeに該当。当たり判定の太さ
	 * length : レーザーの長さ。当たり判定も長さの分だけある
	 */
	public static final EntityTHLaser createLaserA(	EntityLivingBase user, Entity source, double xPos, double yPos, double zPos, float angleXZ, float angleY,
												double firstSpeed, double limitSpeed, double acceleration, double xVectorG, double yVectorG, double zVectorG,
												float damage, int color, float width, int endTime, int delay, int special, double length)
	{
		Vec3 vec3 = getVecFromAngle(angleXZ, angleY, 1.0D);
		
		return createLaserA(	user, source, xPos, yPos, zPos, vec3.xCoord, vec3.yCoord, vec3.zCoord, 
							firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG,
							damage, color, width, endTime, delay, special, length);
	}
	
	
	/*最も一般的な移動レーザーを生成
	 * user : レーザーの使用者
	 * xPos : レーザーの発射地点のX座標
	 * yPos :
	 * zPos :
	 * angleXZ : レーザーの水平方向の角度
	 * angleY  : レーザーの水平方向の角度
	 * speed   : レーザーの速度
	 * damage  : レーザーのダメージ
	 * color   : レーザーの色
	 * width   : レーザーの太さ
	 * length  : レーザーの長さ
	 */
	public static final EntityTHLaser createLaserA(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed, float damage, int color, float width, double length)
	{
		return createLaserA(	user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, damage, color, width, 0, length);
	}
	
	
	/*最も一般的な移動レーザーに加速度と遅延を指定できるもの
	 * user         : レーザーの使用者
	 * xPos         : レーザーの発射地点のX座標
	 * yPos         :
	 * zPos         :
	 * angleXZ      : レーザーの水平方向の角度
	 * angleY       : レーザーの水平方向の角度
	 * firstSpeed   : レーザーの初期速度
	 * limitSpeed   : レーザーの最高速度
	 * acceleration ; レーザーの加速度
	 * damage       : レーザーのダメージ
	 * color        : レーザーの色
	 * width        : レーザーの太さ
	 * length       : レーザーの長さ
	 */
	public static final EntityTHLaser createLaserA(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration, float damage, int color, float width, int delay, double length)
	{
		return createLaserA(	user, user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, limitSpeed, acceleration, 0.0D, 0.0D, 0.0D, damage, color, width, 120, delay, 0, length);
	}

	
	/*すべてのn-wayレーザーの基礎となる処理
	 * user         : レーザーの持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : レーザーの発射元。あまり意味は無い
	 * xPos         : レーザーのX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : レーザーのX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : レーザーの初期速度
	 * limitSpeed   : レーザーの最高速度。これ以上は速くならない
	 * acceleration : レーザーの加速度。毎フレームこの数値分速くなる
	 * xVectorG     : レーザーのX軸方向の重力値。0.0Dで重力の影響を受けない　実質レーザーの重力処理は未実装
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : レーザーのダメージ
	 * color        : レーザーの色　thShotLib.RED という感じで設定
	 * width        : レーザーの太さ。当たり判定、描画サイズに関わる
	 * endTime      : レーザーの消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * special      : レーザーの特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * length       : レーザーの長さ
	 * way          : レーザーの数
	 * wideAngle    : 扇状の成す角度
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createWideLaserA(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int color, float width, int endTime, int delay, int special, double length, int way, float wideAngle, double distance)
	{
		float disXZ = (float)Math.sqrt( xVector * xVector + zVector * zVector );
    	float angleXZ = (float)Math.atan2(-xVector, zVector);
    	float angleY  = (float)Math.atan2(-yVector, disXZ);
		float baseYaw = angleXZ;
		float basePitch = angleY;
		double X1,X2,Z1,Z2,/*angleXZ = 0,angleY = 0,*/ vecX, vecY, vecZ;
		float angleXZ_rad, angleY_rad;
		Vec3 lookAt = Vec3.createVectorHelper(xVector, yVector, zVector);
		lookAt.rotateAroundY((float)Math.PI*2);
    	float f = 20F, angle, spanAngle;
    	angle = -radTrans(wideAngle / 2F);
    	if(way == 1)
    	{
    		angle = 0;
    	}
		spanAngle = radTrans(wideAngle / (float)(way - 1)); //あらゆる弾数でも360度飛ぶように、弾の間隔
		
		boolean randomColor = color - (color % 1000) == 1000;
		if(randomColor)
		{
			color -= 1000;
		}
		Random rand = new Random();
    	//int color = form;
		for(int i = 0; i < way; i++)
    	{	
    		//飛ぶ方向を設定
			angleXZ = angle;//横の角度　0=正面　+1ごとに左にずれていき360で正面に戻る
			angleY = 0;//縦の角度　0=正面　+1ごとに上にずれていき360で正面に戻る
    		angleY_rad = radTrans(angleY);
    		
			X1 =  Math.sin(angleXZ) * Math.cos(baseYaw);
			Z1 =  Math.sin(angleXZ) * Math.sin(baseYaw);
			X2 =  Math.cos(angleXZ) * Math.sin(angleY_rad) * Math.sin(basePitch) * Math.sin(baseYaw);
			Z2 =  Math.cos(angleXZ) * Math.sin(angleY_rad) * Math.sin(basePitch) * Math.cos(baseYaw);
			
			//vecY = -Math.cos(angleXZ_rad) * Math.sin(radTrans(user.rotationPitch - angleY));//Y方向　上下
    		vecY = -Math.cos(angleXZ) * Math.sin(basePitch - angleY_rad);//Y方向　上下
			vecX =  Math.cos(angleXZ) * Math.cos(angleY_rad) * lookAt.xCoord + X1 - X2;//X方向　水平方向
			vecZ =  Math.cos(angleXZ) * Math.cos(angleY_rad) * lookAt.zCoord + Z1 + Z2;//Z方向　水平方向
   			
			/*if(randomColor)
			{
				color = form + rand.nextInt(7);
			}*/
    		createLaserA(user, source, xPos + vecX * distance, yPos + vecY * distance, zPos + vecZ * distance, vecX, vecY, vecZ, firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, color, width, endTime, delay, special, length);
			
    		angle += spanAngle;
    		//basePitch -= pitchSpan * (float)Math.cos(basePitch);
   		}
	}
	
	
	/*すべてのn-wayレーザーの基礎となる処理の角度指定版
	 * user         : レーザーの持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : レーザーの発射元。あまり意味は無い
	 * xPos         : レーザーのX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 水平方向の角度
	 * angleY       : 垂直方向の角度
	 * firstSpeed   : レーザーの初期速度
	 * limitSpeed   : レーザーの最高速度。これ以上は速くならない
	 * acceleration : レーザーの加速度。毎フレームこの数値分速くなる
	 * xVectorG     : レーザーのX軸方向の重力値。0.0Dで重力の影響を受けない　実質レーザーの重力処理は未実装
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : レーザーのダメージ
	 * color        : レーザーの色　thShotLib.RED という感じで設定
	 * width        : レーザーの太さ。当たり判定、描画サイズに関わる
	 * endTime      : レーザーの消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * special      : レーザーの特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * length       : レーザーの長さ
	 * way          : レーザーの数
	 * wideAngle    : 扇状の成す角度
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createWideLaserA(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int color, float width, int endTime, int delay, int special, double length, int way, float wideAngle, double distance)
	{
		Vec3 vec3 = getVecFromAngle(angleXZ, angleY, 1.0D);
		
    	createWideLaserA(user, source, xPos + vec3.xCoord * distance, yPos + vec3.yCoord * distance, zPos + vec3.zCoord * distance, vec3.xCoord, vec3.yCoord, vec3.zCoord, firstSpeed, limitSpeed, acceleration, xVectorG, yVectorG, zVectorG, damage, color, width, endTime, delay, special, length, way, wideAngle, distance);
	}
	
	
	public static final void createWideLaserA(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed,
			float damage, int color, float width, double length, int way, float wideAngle)
	{
		createWideLaserA(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, damage, color, width, 0, length, way, wideAngle);
	}
	
	
	public static final void createWideLaserA(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double maxSpeed, double acceleration,
			float damage, int color, float width, int delay, double length, int way, float wideAngle)
	{
		createWideLaserA(user, user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, maxSpeed, acceleration,
				0.0D, 0.0D, 0.0D, damage, color, width, 120, delay, 0, length, way, wideAngle, 0.0D);
	}
	
	
	/*すべての全方位レーザーの基礎となる処理
	 * user         : レーザーの持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : レーザーの発射元。あまり意味は無い
	 * xPos         : レーザーのX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * xVector      : レーザーのX方向のベクトル値
	 * yVector      :
	 * zVector      :
	 * firstSpeed   : レーザーの初期速度
	 * limitSpeed   : レーザーの最高速度。これ以上は速くならない
	 * acceleration : レーザーの加速度。毎フレームこの数値分速くなる
	 * xVectorG     : レーザーのX軸方向の重力値。0.0Dで重力の影響を受けない　実質レーザーの重力処理は未実装
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : レーザーのダメージ
	 * color        : レーザーの色　thShotLib.RED という感じで設定
	 * width        : レーザーの太さ。当たり判定、描画サイズに関わる
	 * endTime      : レーザーの消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * special      : レーザーの特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * length       : レーザーの長さ
	 * way          : レーザーの数
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createCircleLaserA(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											double xVector, double yVector, double zVector, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int color, float width, int endTime, int delay, int special, double length, int way, double distance)
	{
		createWideLaserA(user, source, xPos, yPos, zPos,
				-xVector, -yVector, -zVector, firstSpeed, limitSpeed, acceleration,
				xVectorG, yVectorG, zVectorG,
				damage, color, width, endTime, delay, special, length, way + 1, 360F, distance);
	}
	
	/*すべての全方位レーザーの基礎となる処理の角度指定版
	 * user         : レーザーの持ち主、当たった場合持ち主が当てたことになる。また、持ち主が死ぬと消滅したり、アイテム化する
	 * source       : レーザーの発射元。あまり意味は無い
	 * xPos         : レーザーのX座標の発射地点
	 * yPos         :
	 * zPos         :
	 * angleXZ      : 水平方向の角度
	 * angleY       : 垂直方向の角度
	 * firstSpeed   : レーザーの初期速度
	 * limitSpeed   : レーザーの最高速度。これ以上は速くならない
	 * acceleration : レーザーの加速度。毎フレームこの数値分速くなる
	 * xVectorG     : レーザーのX軸方向の重力値。0.0Dで重力の影響を受けない　実質レーザーの重力処理は未実装
	 * yVectorG     :
	 * zVectorG     :
	 * damage       : レーザーのダメージ
	 * color        : レーザーの色　thShotLib.RED という感じで設定
	 * width        : レーザーの太さ。当たり判定、描画サイズに関わる
	 * endTime      : レーザーの消滅時間。この時間になったら強制的に消滅する。懐中時計で止められている場合は時間は進まず停滞する
	 * special      : レーザーの特殊な処理を指定する。普通の弾は0。FALL01とすれば落下弾になる
	 * length       : レーザーの長さ
	 * way          : レーザーの数
	 * distance     : 発射地点からこの分だけ離して発射する
	 */
	public static final void createCircleLaserA(EntityLivingBase user, Entity source, double xPos, double yPos, double zPos,
											float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration,
											double xVectorG, double yVectorG, double zVectorG,
											float damage, int color, float width, int endTime, int delay, int special, double length, int way, double distance)
	{
		Vec3 vec3 = getVecFromAngle(angleXZ, angleY, 1.0D);
		
		createCircleLaserA(user, source, xPos, yPos, zPos,
				vec3.xCoord, vec3.yCoord, vec3.zCoord, firstSpeed, limitSpeed, acceleration,
				xVectorG, yVectorG, zVectorG,
				damage, color, width, endTime, delay, special, length, way, distance);
	}
	
	
	public static final void createCircleLaserA(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed,
			float damage, int color, float width, double length, int way)
	{
		createCircleLaserA(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, damage, color, width, 0, length, way);
	}
	
	
	public static final void createCircleLaserA(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double firstSpeed, double limitSpeed, double acceleration,
			float damage, int color, float width, int delay, double length, int way)
	{
		createCircleLaserA(user, user, xPos, yPos, zPos, angleXZ, angleY, firstSpeed, limitSpeed, acceleration,
				0.0D, 0.0D, 0.0D, damage, color, width, 120, delay, 0, length, way, 0.0D);
	}
	
	
	
	public static final EntityTHSetLaser createLaserB(EntityLivingBase user, Entity setting, double posX, double posY, double posZ, 
			double xVector, double yVector, double zVector, double rotateVectorX, double rotateVectorY, double rotateVectorZ, float rotateYawSpeed,
			float damage, int color, float width, int endTime, int delay, int special, double length, Entity set, double setLength, double setYOffset)
	{
		EntityTHSetLaser laser = new EntityTHSetLaser(setting.worldObj, user, setting,
				posX, posY, posZ, xVector, yVector, zVector, rotateVectorX, rotateVectorY, rotateVectorZ, rotateYawSpeed,
		    	damage, color, width, endTime, delay, special, length, set, setLength, setYOffset);
		    	
		if(!setting.worldObj.isRemote)
		{
			//レーザーを生成する
			setting.worldObj.spawnEntityInWorld(laser);
		}
		return laser;   	
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		エフェクト系	Effect																									*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/* ショット発射音を出す
	 * entity : 音を出すEntity
	 */
	public static void playShotSound(Entity entity)
	{
		entity.worldObj.playSoundAtEntity(entity, "random.bow", 2.0F, 1.2F);//音を出す
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		弾幕関連処理系	Danmaku Handle																							*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
    /*周囲から指定の、もしくはすべての弾幕を取り除く
     * centerEntity : 弾消しの中心となるEntity
     * range        : 弾消しの有効距離
     * target       : "ALL"ですべての弾、"Enemy"で敵弾、"Player"でプレイヤーの弾をすべて消す
     * isDropBounus : 弾消しボーナスを出すかどうか。出した場合弾の元に変換され、出さない場合完全に消滅だけする
     * 返り値       : 消した弾の数
     */
    public static int danmakuRemove(Entity centerEntity, double range, String target, boolean isDropBounus)
    {
    	int count = 0;
		List list = centerEntity.worldObj.getEntitiesWithinAABBExcludingEntity(centerEntity, centerEntity.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(range, range, range));
		for(int k = 0; k < list.size(); k++)
		{
			Entity entity = (Entity)list.get(k);
			if(entity instanceof EntityTHShot)
			{
				EntityTHShot entityTHShot = (EntityTHShot)entity;
				if(target.equals("ALL"))
				{
					if(isDropBounus)
					{
						entityTHShot.shotFinishBonus();
					}
					else
					{
						entityTHShot.setDead();
					}
					count++;
				}
				else if(target.equals("Enemy"))
				{
					if(entityTHShot.userEntity instanceof EntityPlayer == false)
					{
						if(isDropBounus)
						{
							entityTHShot.shotFinishBonus();
						}
						else
						{
							entityTHShot.setDead();
						}
						count++;
					}
				}
				else if(target.equals("Player"))
				{
					if(entityTHShot.userEntity instanceof EntityPlayer)
					{
						if(isDropBounus)
						{
							entityTHShot.shotFinishBonus();
						}
						else
						{
							entityTHShot.setDead();
						}
						count++;
					}
				}
			}
		}
		return count;
    }
    
    /*倒れたときに周囲にダメージを与えて消える。距離があるほどダメージが少なくなる
     * deadEntity   : 倒れたEntity
     * range        : 周囲にダメージを与える有効距離
     * maxDamage    : 最も接近していた時のダメージ
     */
    public static void banishExplosion(Entity deadEntity, double range, float maxDamage)
    {
    	int count = 0;
		List list = deadEntity.worldObj.getEntitiesWithinAABBExcludingEntity(deadEntity, deadEntity.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(range, range, range));
		for(int k = 0; k < list.size(); k++)
		{
			Entity entity = (Entity)list.get(k);
			
			if(entity instanceof EntityTHFairy)
			{
				EntityTHFairy fairy = (EntityTHFairy)entity;
				double distance = entity.getDistanceToEntity(deadEntity);
				
				if(distance <= range)
				{
					float damage = maxDamage * (1.0F - (float)(distance / range));
					if(damage < 2.0F)
					{
						damage = 2.0F;
					}
					fairy.attackEntityFrom(DamageSource.causeIndirectMagicDamage(entity, deadEntity), damage);
				}
				
			}
		}
    }
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		計算系	Mathematics																										*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//DegをRadに変換する
	public static final float radTrans(float deg)
	{
		return (float)((double)deg / 180.0D * Math.PI);
	}
	
	//DegをRadに変換する
	public static final float radTrans(double deg)
	{
		return (float)(deg / 180.0D * Math.PI);
	}
	
	/*２つの角度の差を求める。-180°～180°の間で返す。angleAとangleBは-180°～180°で表せられなければならない
	 * angleA : 基準となる角度。これを０°としてangleBとどれだけ差があるかを返す
	 * angleB : 基準の角度angleAと比較する角度。
	 * 返り値：angleAに対するangleBの角度
	 */
	public static final float getAngleAndAngleSpan(float angleA, float angleB)
	{
		if(angleA == 0.0F)
		{
			return angleB;
		}
		//angleAが右よりなら
		else if(angleA > 0.0F)
		{
			if(angleB > angleA - 180F)
			{
				return angleA - angleB;
			}
			else if(angleB > angleA)
			{
				return angleB - angleA;
			}
			else
			{
				return 180F - angleA - (-180F + angleB);
			}
		}
		//angleAが左よりなら
		else
		{
			if(angleB < angleA + 180F)
			{
				return angleB - angleA;
			}
			else if(angleB < angleA)
			{
				return angleB + angleA;
			}
			else
			{
				return -180F - angleA - (180F - angleB);
			}
		}
	}

	
	/*目の高さも含めたY座標を返す
	 * living      : 目の高さを含めたY座標を取得するEntityLivingBase
	 * yAdjustment : 高さの調整
	 * 戻り値：目の高さに調整したY座標
	 */
	public static final double getPosYFromEye(EntityLivingBase living, double yAdjustment)
	{
		return living.posY + living.getEyeHeight() + Math.sin((double)living.rotationPitch / 180.0D * Math.PI) * yAdjustment + yAdjustment;
	}
	
	/*目の高さも含めたY座標を返す。目より少し下から出す標準的な設定
	 * living      : 目の高さを含めたY座標を取得するEntityLivingBase
	 * 戻り値：目の高さに調整したY座標
	 */
	public static final double getPosYFromEye(EntityLivingBase living)
	{
		return living.posY + living.getEyeHeight() + Math.sin((double)living.rotationPitch / 180.0D * Math.PI) * -0.2 - 0.2;
	}
	
	/*角度（度数）と強さからベクトルを取得する
	 * yaw   : 水平方向の角度（度数）
	 * pitch : 垂直方向の角度（度数）
	 * force : ベクトルの強さ
	 * 戻り値：角度と強さから求まった３次元ベクトル
	*/
	public static final Vec3 getVecFromAngle(float yaw, float pitch, double force)
	{
		double yaw_rad = (double)yaw / 180.0D * Math.PI;
		double pitch_rad = (double)pitch / 180.0D * Math.PI;
		double vectorX = -Math.sin(yaw_rad) * Math.cos(pitch_rad) * force;//X方向　水平方向
		double vectorY = -Math.sin(pitch_rad) * force;//Y方向　上下
		double vectorZ =  Math.cos(yaw_rad) * Math.cos(pitch_rad) * force;//Z方向　水平方向
		return Vec3.createVectorHelper(vectorX, vectorY, vectorZ);
	}
	
	/*角度（度数）から単位ベクトルを取得する
	 * yaw   : 水平方向の角度（度数）
	 * pitch : 垂直方向の角度（度数）
	 * 戻り値：角度から求まった３次元の単位ベクトル
	*/
	public static final Vec3 getVecFromAngle(float yaw, float pitch)
	{
		/*pitch = pitch % 180F;//-180～180で固定する
		if(pitch >= 90F)
		{
			yaw += 180F;
			pitch = 180F - pitch;
		}
		else if(pitch <= -90F)
		{
			yaw -= 180F;
			pitch = -180F + pitch;
		}*/
		return getVecFromAngle(yaw, pitch, 1.0D);
	}
	
	/*ベクトルから水平方向の角度を返す
	 * 
	 */
	public static final float getYawFromVector(double xVector, double zVector)
	{
		return  (float)((Math.atan2(xVector, zVector) * 180D) / 3.1415927410125732D);
	}
	
	/*ベクトルから垂直方向の角度を返す
	 * 
	 */
	public static final float getPitchFromVector(double xVector, double yVector, double zVector)
	{
		double f = MathHelper.sqrt_double(xVector * xVector + zVector * zVector);
		return  (float)((Math.atan2(yVector, f) * 180D) / 3.1415927410125732D);
	}
	
	/*特定のベクトルから水平方向に特定の角度ずれたベクトルを取得する
	 * 要はどんな方向を見ていても、左に３０度ずれた弾の進行方向が変わらないようなベクトルを取得するってもの
	 * xVector : 元となるベクトルのX成分
	 * yVector : 
	 * zVector :
	 * angle   : 元のベクトルからどれだけ横に角度をずらすか
	 * force   : ベクトルの強さ
	 */
	public static final Vec3 getRotationVector(double xVector, double yVector, double zVector, float angle, double force)
	{
		float disXZ = (float)Math.sqrt( xVector * xVector + zVector * zVector );
		float angleXZ = (float)Math.atan2(-xVector, zVector);
		float angleY  = (float)Math.atan2(-yVector, disXZ);
		float baseYaw = angleXZ;
		float basePitch = angleY;
		double X1,X2,Z1,Z2, vecX, vecY, vecZ;
		float angleXZ_rad, angleY_rad;
		Vec3 lookAt = Vec3.createVectorHelper(xVector, yVector, zVector);
		lookAt.rotateAroundY((float)Math.PI*2);
		angle = angle / 180.0F * (float)Math.PI;
			
		//飛ぶ方向を設定
		angleXZ = angle;//横の角度　0=正面　+1ごとに左にずれていき360で正面に戻る
		angleY = 0;//縦の角度　0=正面　+1ごとに上にずれていき360で正面に戻る
		angleY_rad = radTrans(angleY);
		
		X1 =  Math.sin(angleXZ) * Math.cos(baseYaw);
		Z1 =  Math.sin(angleXZ) * Math.sin(baseYaw);
		X2 =  Math.cos(angleXZ) * Math.sin(angleY_rad) * Math.sin(basePitch) * Math.sin(baseYaw);
		Z2 =  Math.cos(angleXZ) * Math.sin(angleY_rad) * Math.sin(basePitch) * Math.cos(baseYaw);
		
		vecY = -Math.cos(angleXZ) * Math.sin(basePitch - angleY_rad);//Y方向　上下
		vecX =  Math.cos(angleXZ) * Math.cos(angleY_rad) * lookAt.xCoord + X1 - X2;//X方向　水平方向
		vecZ =  Math.cos(angleXZ) * Math.cos(angleY_rad) * lookAt.zCoord + Z1 + Z2;//Z方向　水平方向
		
		return Vec3.createVectorHelper(vecX * force, vecY * force, vecZ * force);
	}
	
	
	/*特定の角度から水平方向に特定の角度ずれたベクトルを取得する
	 * 要はどんな方向を見ていても、左に３０度ずれた弾の進行方向が変わらないようなベクトルを取得するってもの
	 * yaw   : 水平方向の角度（度数）
	 * pitch : 垂直方向の角度（度数）
	 * angle   : 元のベクトルからどれだけ横に角度をずらすか
	 * force   : ベクトルの強さ
	 */
	public static final Vec3 getRotationVectorFromAngle(float yaw, float pitch, float angle, double force)
	{
		Vec3 vec3 = getVecFromAngle(yaw, pitch, 1.0D);
		return getRotationVector(vec3.xCoord, vec3.yCoord, vec3.zCoord, angle, force);
	}
	
	//任意の回転軸rotateVecに対して、任意のベクトルangleVecがangle度回転したベクトルを返す
	public static Vec3 getVectorFromRotation(double rotateVecX, double rotateVecY, double rotateVecZ, double angleVecX, double angleVecY, double angleVecZ, float angle)
	{
		double angleRad = (double)angle / 180.0D * (double)Math.PI;
		double sinA = Math.sin(angleRad);
		double cosA = Math.cos(angleRad);
		double returnVectorX = (rotateVecX * rotateVecX * (1 - cosA) + cosA)              * angleVecX + (rotateVecX * rotateVecY * (1 - cosA) - rotateVecZ * sinA) * angleVecY + (rotateVecZ * rotateVecX * (1 - cosA) + rotateVecY * sinA) * angleVecZ;
		double returnVectorY = (rotateVecX * rotateVecY * (1 - cosA) + rotateVecZ * sinA) * angleVecX + (rotateVecY * rotateVecY * (1 - cosA) + cosA)              * angleVecY + (rotateVecY * rotateVecZ * (1 - cosA) - rotateVecX * sinA) * angleVecZ;
		double returnVectorZ = (rotateVecZ * rotateVecX * (1 - cosA) - rotateVecY * sinA) * angleVecX + (rotateVecY * rotateVecZ * (1 - cosA) + rotateVecX * sinA) * angleVecY + (rotateVecZ * rotateVecZ * (1 - cosA) + cosA)              * angleVecZ;
		
		return Vec3.createVectorHelper(returnVectorX, returnVectorY, returnVectorZ);
		
		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		互換用の古いメソッド																									*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*最も一般的な扇状弾
	 * way          : 弾数
	 * wideAngle    : 扇の広がる角度
	 */
	public static final void createWideShot01(EntityLivingBase user, double xPos, double yPos, double zPos, float angleXZ, float angleY, double speed, int form, int way, float wideAngle)
	{
		createWideShot(user, xPos, yPos, zPos, angleXZ, angleY, speed, speed, 0.0D, form, 0, way, wideAngle);
	}
	
}