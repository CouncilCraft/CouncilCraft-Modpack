package thKaguyaMod.block;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
//import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
//import net.minecraft.util.Icon;
import net.minecraft.world.World;
import net.minecraft.util.Icon;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.tileentity.TileEntityDivineSpirit;

public class BlockDivineSpirit extends BlockContainer
{
	//小神霊
	public static final String[] texture = {
		"thkaguyamod:divinespirit_red",
		"thkaguyamod:divinespirit_blue",
		"thkaguyamod:divinespirit_green",
		"thkaguyamod:divinespirit_yellow",
		"thkaguyamod:divinespirit_purple",
		"thkaguyamod:divinespirit_aqua",
		"thkaguyamod:divinespirit_orange",
		"thkaguyamod:divinespirit_white"};
	private Icon[] iconArray = new Icon[8];
	//public int field_82521_b = 0;
	
	public BlockDivineSpirit(int blockID, Material material)
	{
		super(blockID, material);
		
		this.setCreativeTab(CreativeTabs.tabDecorations);//クリエイティブタブの選択
		//this.setUnlocalizedName("danmakuCraftingTable");//システム名の設定
		//this.func_111022_d("thkaguyamod:divineSpirit_Blue");//テクスチャの指定
		this.setHardness(0.1F);//硬さ
		this.setResistance(2000.0F);//爆発耐性
		this.setStepSound(Block.soundSnowFootstep);//ブロックの音
		this.setLightValue(8F / 15F);//明るさ　1.0F = 15
		
		//this.blockIndexInTexture = 0;
		
	}
	
    public TileEntity createNewTileEntity(World world)
    {
        return new TileEntityDivineSpirit();
    }
    
    //クリエイティブダブにメタデータの異なるアイテムも出現させる
    public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List par3List)
    {
    	for(int i = 0; i < 8; i++)
    	{
    		par3List.add(new ItemStack(par1, 1, i));
    	}
    }
    
    @SideOnly(Side.CLIENT)

    public Icon getIcon(int side, int metadata)
    {
        return iconArray[metadata];//(par2 & 3) == 1 ? this.iconArray[this.field_94394_cP][1] : ((par2 & 3) == 3 ? this.iconArray[this.field_94394_cP][3] : ((par2 & 3) == 2 ? this.iconArray[this.field_94394_cP][2] : this.iconArray[this.field_94394_cP][0]));
    }
    
    @SideOnly(Side.CLIENT)
    
    public void registerIcons(IconRegister par1IconRegister)
    {
    	String iconName;
    	for(int i = 0; i < 8; i++)
    	{
    		iconName = texture[i];
    		iconArray[i] = par1IconRegister.registerIcon(iconName);
    	}
    }
    
    @SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, 6);
        return this.iconArray[i];
    }
    
    //壊したときにドロップするブロックのダメージ値を返す
    public int damageDropped(int damage)
    {
        return damage;
    }
	
	/*@Override
	public String getTextureFile()
	{
		return "/gui/thKaguyaTerrain.png";
	}*/
    
    
    
	
    /*public int getIconFromDamage(int damage)
    {
        return damage;
    }*/
    
    /*public int getBlockTextureFromSideAndMetadata(int par1, int par2)
    {
    	return 40 + par2;
    }*/
    
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }
    
    public boolean isOpaqueCube()
    {
        return false;
    }
	
	//ブロックが右クリックされたときに呼び出される
	/*@Override
	public boolean onBlockActivated(World world, int x, int y, int z, 
			EntityPlayer player, int size, float disX, float disY, float disZ)
	{
		return false;
	}*/
	

    
    //@SideOnly(Side.CLIENT)

    /**
     * From the specified side and block metadata retrieves the blocks texture. Args: side, metadata
     */
    /*public Icon getIcon(int par1, int par2)
    {
        return iconArray[par2];//(par2 & 3) == 1 ? this.iconArray[this.field_94394_cP][1] : ((par2 & 3) == 3 ? this.iconArray[this.field_94394_cP][3] : ((par2 & 3) == 2 ? this.iconArray[this.field_94394_cP][2] : this.iconArray[this.field_94394_cP][0]));
    }*/
    
    //@SideOnly(Side.CLIENT)

    /**
     * When this method is called, your block should register all the icons it needs with the given IconRegister. This
     * is the only chance you get to register icons.
     */
    /*public void registerIcons(IconRegister par1IconRegister)
    {
    	iconArray[0] = par1IconRegister.registerIcon(texture[0]);
    	iconArray[1] = par1IconRegister.registerIcon(texture[1]);
        /*for (int i = 0; i < texture.length; ++i)
        {
            this.iconArray[i] = new Icon[texture[i].length];

            for (int j = 0; j < texture[i].length; ++j)
            {
                this.iconArray[i][j] = par1IconRegister.registerIcon(field_94396_b[i][j]);
            }
        }*/
    //}
    
    
    
    /**
     * アイテム欄でのアイコンや、実際の描画での大きさを設定
     */
    /*public void setBlockBoundsForItemRender()
    {
        float f = 0.25F;
        float f1 = 0.25F;
        this.setBlockBounds(f, f1, f, 1.0F - f, f1, 1.0F - f);
    }*/
    
    /**
     * 通常と違う形のブロックならfalse
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }
    
    /**
     * From the specified side and block metadata retrieves the blocks texture. Args: side, metadata
     */
    /*public int getBlockTextureFromSideAndMetadata(int par1, int par2)
    {
        if (this.field_82521_b == 3 && par1 == 1)
        {
            int var3 = par2 >> 2;

            switch (var3)
            {
                case 1:
                    return this.blockIndexInTexture + 1;
                case 2:
                    return this.blockIndexInTexture + 16 + 1;
                default:
                    return this.blockIndexInTexture + 16;
            }
        }
        else
        {
            return this.blockIndexInTexture;
        }
    }*/
   
    
    //描画時の描画タイプを返す
    public int getRenderType()
    {
        return mod_thKaguya.blockRenderId;
    }
	
    public boolean isBlockReplaceable(World world, int x, int y, int z)
    {
        return false;
    }
}