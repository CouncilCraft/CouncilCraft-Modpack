package thKaguyaMod.block;

import thKaguyaMod.*;

import java.util.List;
import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.World;

public class BlockDanmakuCraftingTable extends Block
{
	//弾幕を作成する作業台
	public static final String[] texture = {"thkaguyamod:danmaku_crafting_table", "thkaguyamod:danmaku_crafting_table2"};
	private Icon[] iconArray = new Icon[2];
	
	public BlockDanmakuCraftingTable(int blockID, Material material)
	{
		super(blockID, material);
		
		this.setCreativeTab(CreativeTabs.tabDecorations);//クリエイティブタブの選択
		//this.setUnlocalizedName("danmakuCraftingTable");//システム名の設定
		//this.func_111022_d("thkaguyamod:danmaku_crafting_table");//テクスチャの指定
		this.setHardness(1.5F);//硬さ
		this.setResistance(1.0F);//爆発耐性
		this.setStepSound(Block.soundWoodFootstep);//ブロックの音
		this.setLightValue(1.0F);//明るさ　1.0F = 15
		
	}
	
	//ブロックが右クリックされたときに呼び出される
	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, 
			EntityPlayer player, int size, float disX, float disY, float disZ)
	{
		if(world.isRemote)
		{
			return true;
		}
		else
		{
			if(world.getBlockMetadata(x, y, z) == 0)
			{
				player.openGui(mod_thKaguya.instance, mod_thKaguya.instance.guiDanmakuCraftingID, world, x, y, z);
			}
			else
			{
				player.openGui(mod_thKaguya.instance, mod_thKaguya.instance.guiDanmakuCraftingLaserID, world, x, y, z);
			}
			return true;
		}
	}
	
    /**
     * returns a list of blocks with the same ID, but different meta (eg: wood returns 4 blocks)
     */
    public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List par3List)
    {
        par3List.add(new ItemStack(par1, 1, 0));
        par3List.add(new ItemStack(par1, 1, 1));
    }
    
    @SideOnly(Side.CLIENT)

    /**
     * From the specified side and block metadata retrieves the blocks texture. Args: side, metadata
     */
    public Icon getIcon(int side, int metadata)
    {
        return iconArray[metadata];//(par2 & 3) == 1 ? this.iconArray[this.field_94394_cP][1] : ((par2 & 3) == 3 ? this.iconArray[this.field_94394_cP][3] : ((par2 & 3) == 2 ? this.iconArray[this.field_94394_cP][2] : this.iconArray[this.field_94394_cP][0]));
    }
    
    @SideOnly(Side.CLIENT)

    /**
     * When this method is called, your block should register all the icons it needs with the given IconRegister. This
     * is the only chance you get to register icons.
     */
    public void registerIcons(IconRegister par1IconRegister)
    {
    	iconArray[0] = par1IconRegister.registerIcon(texture[0]);
    	iconArray[1] = par1IconRegister.registerIcon(texture[1]);
        /*for (int i = 0; i < texture.length; ++i)
        {
            this.iconArray[i] = new Icon[texture[i].length];

            for (int j = 0; j < texture[i].length; ++j)
            {
                this.iconArray[i][j] = par1IconRegister.registerIcon(field_94396_b[i][j]);
            }
        }*/
    }
    
    //壊したときにドロップするブロックのダメージ値を返す
    public int damageDropped(int damage)
    {
        return damage;
    }
    
    /**
     * アイテム欄でのアイコンや、実際の描画での大きさを設定
     */
    /*public void setBlockBoundsForItemRender()
    {
        float f = 0.25F;
        float f1 = 0.25F;
        this.setBlockBounds(f, f1, f, 1.0F - f, f1, 1.0F - f);
    }*/
    
    /**
     * 通常と違う形のブロックならfalse
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    /*public boolean renderAsNormalBlock()
    {
        return false;
    }*/
	
}
