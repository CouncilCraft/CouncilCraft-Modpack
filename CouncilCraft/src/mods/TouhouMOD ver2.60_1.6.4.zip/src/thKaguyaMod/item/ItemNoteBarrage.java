package thKaguyaMod.item;

import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.StatCollector;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import java.util.Random;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemNoteBarrage extends Item
{
	//弾幕形状を記憶するアイテム
	
	public static final String shotNames[] =
    {
        "Normal Shot", "Small Shot", "Medium Shot", "Big Shot", "Star Shot", "Small Star Shot", "Circle Shot", "Scale Shot", "Butterfly Shot"
    };
	public static final String shotIconName[] =
	{
		"normalShot", "smallShot", "mediumShot", "bigShot", "starShot", "smallStarShot", "circleShot", "scaleShot", "butterflyShot"
	};
	public static final float size[] =
	{
		0.3F, 0.15F, 0.6F, 1.2F, 0.3F, 0.15F, 0.3F, 0.3F, 0.6F
	};
	public static final float speed[] =
	{
		0.6F, 0.6F, 0.5F, 0.3F, 0.6F, 0.6F, 0.6F, 0.65F, 0.3F
	};
	public static final int damage[] =
	{
		2, 1, 3, 5, 3, 2, 2, 2, 3
	};
	public static final int form[] =
	{
		0, 0, 0, 240, 48, 48, 16, 24, 32
	};
	
	@SideOnly(Side.CLIENT)
    private Icon[] icon;

	public ItemNoteBarrage(int itemID)
	{
		super(itemID);
		maxStackSize = 64;
		//setHasSubtypes(true);
		//setMaxDamage(0);
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
	}
	
	/*public String getUnlocalizedName(ItemStack itemStack)
    {
        int i = MathHelper.clamp_int(itemStack.getItemDamage(), 0, 15);
        return super.getUnlocalizedName() + "." + shotNames[i];
    }*/
	
	/*@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, shotNames.length);
        return this.icon[i];
    }*/
	
	/*@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister)
    {
        this.icon = new Icon[shotIconName.length];

        for (int i = 0; i < shotIconName.length; ++i)
        {
            this.icon[i] = par1IconRegister.registerIcon(shotIconName[i]);
        }
    }*/
	
	//右クリックを押したときの処理
	/*public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
	{
		EntityTHShot entityTHShot;
		double vectorX, vectorY, vectorZ;
		Random rand = new Random();
		int type = itemStack.getItemDamage();
		int color = form[type] + rand.nextInt(6);
		int sellectbleColor[] = {7, 0, 2, 0, 1, 4, 5, 7, 7, 4, 2, 3, 5, 4, 6, 7};
		ItemStack colorItem = entityPlayer.inventory.mainInventory[entityPlayer.inventory.currentItem + 1];
		if(entityPlayer.inventory.currentItem < 8 && colorItem != null)
    	{
    		if(colorItem.itemID == Item.dyePowder.itemID)
    		{
    			color = form[type] + sellectbleColor[entityPlayer.inventory.mainInventory[entityPlayer.inventory.currentItem + 1].getItemDamage()];
    		}
    	}
		int deadTime = 40;
		vectorX = -MathHelper.sin(entityPlayer.rotationYaw / 180F * 3.141593F) * MathHelper.cos(entityPlayer.rotationPitch / 180F * 3.141593F);
		vectorY = -MathHelper.sin(entityPlayer.rotationPitch / 180F * 3.141593F);
		vectorZ =  MathHelper.cos(entityPlayer.rotationYaw / 180F * 3.141593F) * MathHelper.cos(entityPlayer.rotationPitch / 180F * 3.141593F);
		entityTHShot = new EntityTHShot( world, entityPlayer, entityPlayer, entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ,
			vectorX, vectorY, vectorZ,
			speed[type], speed[type], 1.0D, 0.0D, 0.0D, 0.0D, 
			damage[type], color, size[type], deadTime);
		if(!world.isRemote)
		{
			world.spawnEntityInWorld(entityTHShot);
			itemStack.stackSize --;
		}
		return itemStack;
	}*/
	
	
    @SideOnly(Side.CLIENT)
    /**
     * allows items to add custom lines of information to the mouseover description
     */
    public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4)
    {
        /*if (par1ItemStack.hasTagCompound())
        {
            NBTTagCompound nbttagcompound = par1ItemStack.getTagCompound().getCompoundTag("Fireworks");

            if (nbttagcompound != null)
            {
                if (nbttagcompound.hasKey("Flight"))
                {
                    par3List.add(StatCollector.translateToLocal("item.fireworks.flight") + " " + nbttagcompound.getByte("Flight"));
                }

                NBTTagList nbttaglist = nbttagcompound.getTagList("Explosions");

                if (nbttaglist != null && nbttaglist.tagCount() > 0)
                {
                    for (int i = 0; i < nbttaglist.tagCount(); ++i)
                    {
                        NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.tagAt(i);
                        ArrayList arraylist = new ArrayList();
                        ItemFireworkCharge.func_92107_a(nbttagcompound1, arraylist);

                        if (arraylist.size() > 0)
                        {
                            for (int j = 1; j < arraylist.size(); ++j)
                            {
                                arraylist.set(j, "  " + (String)arraylist.get(j));
                            }

                            par3List.addAll(arraylist);
                        }
                    }
                }
            }
        }*/
    	if (par1ItemStack.hasTagCompound())
        {
            NBTTagCompound nbttagcompound = par1ItemStack.getTagCompound().getCompoundTag("Fireworks");

            if (nbttagcompound != null)
            {
                if (nbttagcompound.hasKey("Flight"))
                {
                    par3List.add(StatCollector.translateToLocal("item.fireworks.flight") + " " + nbttagcompound.getByte("Flight"));
                }

                NBTTagList nbttaglist = nbttagcompound.getTagList("Explosions");

                if (nbttaglist != null && nbttaglist.tagCount() > 0)
                {
                    for (int i = 0; i < nbttaglist.tagCount(); ++i)
                    {
                        NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.tagAt(i);
                        ArrayList arraylist = new ArrayList();
                        ItemFireworkCharge.func_92107_a(nbttagcompound1, arraylist);

                        if (arraylist.size() > 0)
                        {
                            for (int j = 1; j < arraylist.size(); ++j)
                            {
                                arraylist.set(j, "  " + (String)arraylist.get(j));
                            }

                            par3List.addAll(arraylist);
                        }
                    }
                }
            }
        }
    }

	
	/*@SideOnly(Side.CLIENT)
	//クリエイトモードのアイテム欄に、ダメージ値の違うアイテムも表示できるようにする
    public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List par3List)
    {
        for (int i = 0; i < shotNames.length; i++)
        {
            par3List.add(new ItemStack(par1, 1, i));
        }
    }*/
	
}