package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.IShearable;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.block.Block;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.util.ChatMessageComponent;
import net.minecraft.util.DamageSource;
import net.minecraft.util.StatCollector;
import net.minecraft.util.StringTranslate;
import net.minecraft.world.World;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.entity.EntityHisou;

import java.util.Random;
import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.Multimap;

public class ItemHisou extends ItemSword
{

	//緋想の剣
	//5レベル以上なら「全人類の緋想天」を放てる
	//相手の気質を取得し弱点をつく
		
    public ItemHisou(int itemID, EnumToolMaterial enumToolMaterial)
    {
        super(itemID, enumToolMaterial);
        func_111206_d("thkaguyamod:hisousword");//テクスチャの指定
        setMaxDamage(200);
    }
    
	//Entityに当たったときの処理
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase hitEntityLivingBase, EntityLivingBase useEntityLivingBase)
    {
    	NBTTagCompound nbt = itemStack.getTagCompound();
    	if(nbt != null)
    	{
    		String hitEntityName = "entity." + EntityList.getEntityString(hitEntityLivingBase) + ".name";
    		//if(hitEntityLivingBase.getEntityName() == nbt.getString("EntityName"))
    		if( hitEntityName.equals( nbt.getString("EntityName")))
    		{
    			hitEntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(useEntityLivingBase), 10);
    			if(useEntityLivingBase instanceof EntityPlayer)
    			{
    				EntityPlayer player = (EntityPlayer)useEntityLivingBase;
    				player.onEnchantmentCritical(hitEntityLivingBase);
    			}
    		}
	    }
    	    	
	    if(nbt == null)
	    {
	    	nbt = new NBTTagCompound();
	    	itemStack.setTagCompound(nbt);
	    }
	    //nbt.setString("EntityName", hitEntityLivingBase.getEntityName());
    	nbt.setString("EntityName", "entity." + EntityList.getEntityString(hitEntityLivingBase) + ".name");
	    
        itemStack.damageItem(1, useEntityLivingBase);
        return true;
    }
	
	//ブロックを破壊したときに呼び出される
	@Override
	public boolean onBlockDestroyed(ItemStack itemStack, World world, int blockID, int x, int y, int z, EntityLivingBase EntityLivingBase)
    {
        if (blockID == Block.leaves.blockID )//壊したブロックが葉っぱであり、
        {
        	Random random = new Random();
        	int rand = random.nextInt(25);
        	if( rand == 1 && y > 128)//高さが128m以上の場所なら
        	{
        		EntityItem entityItem = new EntityItem(EntityLivingBase.worldObj, x, y, z, new ItemStack(mod_thKaguya.heavenlyPeachItem));
        		if(!world.isRemote)
        		{
        			EntityLivingBase.worldObj.spawnEntityInWorld(entityItem);
        		}
        	}
            return true;
        }
        else
        {
            return super.onBlockDestroyed(itemStack, world, blockID, x, y, z, EntityLivingBase);
        }
    }
	
	

	//ブロックに対する強さ
	@Override
    public float getStrVsBlock(ItemStack itemStack, Block block)
    {
    	if (block.blockID == Block.leaves.blockID)
        {
            return 15F;
        }

        if (block.blockID == Block.cloth.blockID)
        {
            return 10F;
        }
        else
        {
            return super.getStrVsBlock(itemStack, block);
        }
    }
	
	//アイテムを発光させる。 trueなら発光
	@Override
	public boolean hasEffect(ItemStack itemstack)
	{   
		return true;
    }
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
   	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	//「全人類の緋想天」を使用する
    	if(!world.isRemote && entityPlayer.experienceLevel >= 5)//レベルが５より上なら使用可能
    	{
    		//スペルカード「全人類の緋想天」を宣言
    		if(thKaguyaLib.checkSpellCardDeclaration(world, itemStack, entityPlayer, 7, 2, true) == false)
    		{
    			//宣言に失敗したなら終了する
    			return itemStack;
    		}
    		//entityplayer.removeExperience(5);//経験値を５消費
    		entityPlayer.addExperienceLevel(-5);//レベルを5消費
    		EntityHisou[] entityHisou = new EntityHisou[8];
    		
    		entityHisou[7] = new EntityHisou(world, entityPlayer,null, 7+1, itemStack.getItemDamageForDisplay());
    		if(!world.isRemote)
    		{
         		world.spawnEntityInWorld(entityHisou[7]);//バールのようなものの本体
    			itemStack.stackSize--;//スタックから消滅させる
    		}
    		for(int i = 6; i > 0; i--)
    		{
    			entityHisou[i] = new EntityHisou(world, entityPlayer, entityHisou[7], i+1, 0);
         		if(!world.isRemote)
    			{
    				world.spawnEntityInWorld(entityHisou[i]);//バールのようなものの残像
    			}
    		}
    	}
    		
       	return itemStack;
    }

	//エンチャント
	@Override
    public int getItemEnchantability()
    {
        return 0;//エンチャントできない
    }
    
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
	
    @Override
	public void addInformation(ItemStack itemStack, EntityPlayer entityPlayer, List list, boolean bool)
	{
		super.addInformation(itemStack, entityPlayer, list, bool);
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt == null)
		{
			return;
		}
		String entityName = nbt.getString("EntityName");
		list.add(StatCollector.translateToLocal("thKaguya.item.kishitu") + " : " + StatCollector.translateToLocal(entityName));
	}
	
}
