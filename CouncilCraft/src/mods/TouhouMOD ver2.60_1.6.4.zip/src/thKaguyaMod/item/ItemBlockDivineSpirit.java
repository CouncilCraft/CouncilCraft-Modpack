package thKaguyaMod.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.util.MathHelper;

public class ItemBlockDivineSpirit extends ItemBlock
{
	public static final String[] iconName = {
		"thkaguyamod:divinespirit_red",
		"thkaguyamod:divinespirit_blue",
		"thkaguyamod:divinespirit_green",
		"thkaguyamod:divinespirit_yellow",
		"thkaguyamod:divinespirit_purple",
		"thkaguyamod:divinespirit_aqua",
		"thkaguyamod:divinespirit_orange",
		"thkaguyamod:divinespirit_white"};
	private Icon[] iconArray = new Icon[8];
	
	
	public ItemBlockDivineSpirit(int itemID)
	{
		super(itemID);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
		
	}
	
	@Override
	public int getMetadata(int damage)
	{
		return damage;
	}
	
	@Override
	public String getUnlocalizedName(ItemStack itemStack)
	{
		return super.getUnlocalizedName() + "_" + itemStack.getItemDamage();
	}
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister)
    {
        this.iconArray = new Icon[iconName.length];

        for (int i = 0; i < iconName.length; ++i)
        {
            this.iconArray[i] = par1IconRegister.registerIcon(iconName[i]);
        }
    }
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, 8);
        return this.iconArray[i];
    }
	
    /*public String getItemNameIS(ItemStack itemStack)
    {
    	return "thKaguyaMod.divineSpirit_red";
    }*/
    
    /*public int getIconFromDamage(int damage)
    {
        return damage;
    }*/
    
    /*public boolean onItemUse(ItemStack itemStack, EntityPlayer entityPlayer, World world, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
    {
    	if(!super.onItemUse(itemStack, entityPlayer, world, par4, par5, par6, par7, par8, par9, par10))
    	{
    		int setX = (int)entityPlayer.posX;
    		int setY = (int)(entityPlayer.posY + entityPlayer.getEyeHeight());
    		int setZ = (int)entityPlayer.posZ;
    		if(world.isAirBlock(setX, setY, setZ))
    		{
    			Block var12 = Block.blocksList[getBlockID()];
                int var13 = this.getMetadata(itemStack.getItemDamage());
                int var14 = Block.blocksList[getBlockID()].onBlockPlaced(world, par4, par5, par6, par7, par8, par9, par10, var13);
    			if (placeBlockAt(itemStack, entityPlayer, world, setX, setY, setZ, par7, par8, par9, par10, var14))
                {
                    world.playSoundEffect((double)((float)par4 + 0.5F), (double)((float)par5 + 0.5F), (double)((float)par6 + 0.5F), var12.stepSound.getPlaceSound(), (var12.stepSound.getVolume() + 1.0F) / 2.0F, var12.stepSound.getPitch() * 0.8F);
                    --itemStack.stackSize;
                }

    			return true;
    		}
    	}
    	return false;
    }*/
}
