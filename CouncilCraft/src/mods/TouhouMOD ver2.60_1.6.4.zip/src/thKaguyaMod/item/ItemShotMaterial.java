package thKaguyaMod.item;

import java.util.List;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemShotMaterial extends Item
{
	//弾幕の素　弾幕を作成する為の素材

	public ItemShotMaterial(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:shotMaterial");//テクスチャの指定
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
	}
}