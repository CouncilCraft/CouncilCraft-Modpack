package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

import thKaguyaMod.entity.EntityKinkakuzi;

import java.util.List;
import java.util.Random;

public class ItemKinkakuzi extends Item
{
	//巨大な板を投げつけるアイテム
	
	public ItemKinkakuzi(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:kinkakuzi");//テクスチャの指定
		maxStackSize = 1;
		setCreativeTab(CreativeTabs.tabCombat);//クリエイティブの武器タブに登録
	}
	
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	double pow = 0.7;
    	if(entityPlayer.isSneaking())
    	{
    		pow = 1.0;
    	}
    	EntityKinkakuzi entityKinkakuzi;
    	//飛ばす角度を設定
   		//double angleX = -MathHelper.sin((entityplayer.rotationYaw / 180F) * 3.141593F) * MathHelper.cos(((entityplayer.rotationPitch) / 180F) * 3.141593F);
   		//double angleZ =  MathHelper.cos((entityplayer.rotationYaw / 180F) * 3.141593F) * MathHelper.cos(((entityplayer.rotationPitch) / 180F) * 3.141593F);
    	//使用者の上方向に発射
    	entityKinkakuzi = new EntityKinkakuzi(world, entityPlayer.posX, entityPlayer.posY + entityPlayer.height, entityPlayer.posZ, entityPlayer, pow);
       	world.playSoundAtEntity(entityPlayer, "random.drr", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
       	if(!world.isRemote)
       	{
         	world.spawnEntityInWorld(entityKinkakuzi);//金閣寺の一枚天井を出現させる
       	}
    	itemStack.stackSize--;//スタックから消滅させる
    		
       	return itemStack;
    }
	
	
	//右クリック時の行動を設定
	@Override
    public EnumAction getItemUseAction(ItemStack itemStack)
    {
        return EnumAction.bow;//弓の構えをする
    }
	
	//右クリック時のカウントの最大値を指定
	public int getMaxItemUseDuration(ItemStack itemStack)
    {
        return 72000;
    }
	
	//アイテムを発光させる。 trueなら発光
	@Override
	public boolean hasEffect(ItemStack itemStack)
	{   
		return true;
    }
}