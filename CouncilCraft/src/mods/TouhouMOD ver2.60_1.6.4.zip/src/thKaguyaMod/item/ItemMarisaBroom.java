package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import thKaguyaMod.entity.EntityMarisaBroom;

import java.util.List;
import java.util.Random;

public class ItemMarisaBroom extends Item
{
	//魔理沙の魔法の箒。そのまま武器としても使え、空をとぶこともできる
	
	public ItemMarisaBroom(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:magicBroom");//テクスチャの指定
		maxStackSize = 1;
		setCreativeTab(CreativeTabs.tabCombat);//クリエイティブの武器タブに登録
	}
	
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	EntityMarisaBroom entityMarisaBroom;
    	//飛ばす角度を設定
   		//double angleX = -MathHelper.sin((entityplayer.rotationYaw / 180F) * 3.141593F) * MathHelper.cos(((entityplayer.rotationPitch) / 180F) * 3.141593F);
   		//double angleZ =  MathHelper.cos((entityplayer.rotationYaw / 180F) * 3.141593F) * MathHelper.cos(((entityplayer.rotationPitch) / 180F) * 3.141593F);
    	//使用者の上方向に発射
    	entityMarisaBroom = new EntityMarisaBroom(world, entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ);
       	world.playSoundAtEntity(entityPlayer, "random.drr", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
       	if(!world.isRemote)
       	{
         	world.spawnEntityInWorld(entityMarisaBroom);//魔理沙の箒を出現させる
       		itemStack.stackSize--;//スタックから消滅させる
       	}
    		
       	return itemStack;
    }
	
	//Entityに当たったときの処理
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase hitEntityLivingBase, EntityLivingBase useEntityLivingBase)
    {
    	hitEntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(useEntityLivingBase), 2.0F);
    	return true;
    }
	
	//右クリック時の行動を設定
	@Override
    public EnumAction getItemUseAction(ItemStack itemStack)
    {
        return EnumAction.block;//弓の構えをする
    }
	
	//右クリック時のカウントの最大値を指定
	public int getMaxItemUseDuration(ItemStack itemStack)
    {
        return 72000;
    }
	
    public boolean isFull3D()
    {
        return true;
    }
	
}