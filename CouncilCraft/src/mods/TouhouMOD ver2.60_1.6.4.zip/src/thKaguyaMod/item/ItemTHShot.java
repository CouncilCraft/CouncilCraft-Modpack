package thKaguyaMod.item;

import java.util.List;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityTHShot;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemTHShot extends Item
{
	//単発ショット　弾幕作成の素でもある
	
	//登録した英語名のアイテム名（？）
	public static final String shotNames[] =
    {
        "Small Shot"	, "Tiny Shot"		, "Medium Shot"		, "Big Shot"	,
        "Star Shot"		, "Small Star Shot"	, "Circle Shot"		, "Scale Shot"	,
        "Butterfly Shot", "Light Shot"		, "Knife Shot"		, "Heart Shot"	,
        "Kunai Shot"	, "Talisman Shot"	, "Big Light Shot"	, "Rice Shot"	,
        "Oval Shot"
    };
	//アイコンの名前。smallShot.pngを反映させるなら、"smallShot"で対応する。
	public static final String shotIconName[] =
	{
		"smallShot", "tinyShot", "mediumShot", "bigShot",
		"starShot", "smallStarShot", "circleShot", "scaleShot",
		"butterflyShot", "lightShot", "silverKnife_Red", "heartShot",
		"kunaiShot", "talismanShot", "bigLightShot", "riceShot",
		"ovalShot"
	};
	
	//弾アイテムとEntityで弾の番号が異なるため、その変換用
	public static final int shotTypeTrans[] =
	{
		 0,  1,  2, 30,
		 9,  8,  4,  6,
		 7,  5, 28, 12,
		13, 14, 15, 10,
		16
	};

	//各弾の弾速。
	/*public static final float speed[] =
	{
		0.6F, 0.6F, 0.5F, 0.3F, 0.6F, 0.6F, 0.6F, 0.65F, 0.3F, 0.5F, 0.8F
	};*/
	
	//各弾の弾速。
	public static final float speed[] =
	{
		0.50F, 0.50F, 0.40F, 0.25F,
		0.50F, 0.50F, 0.50F, 0.55F,
		0.30F, 0.50F, 0.65F, 0.40F,
		0.60F, 0.50F, 0.40F, 0.50F,
		0.40F
	};

	//各弾IDの形状
	public static final int form[] =
	{
		thShotLib.SMALL[0]    	, thShotLib.TINY[0]     , thShotLib.MEDIUM[0]	, thShotLib.BIG[0]  , 
		thShotLib.STAR[0]     	, thShotLib.SMALLSTAR[0], thShotLib.CIRCLE[0]	, thShotLib.SCALE[0],
		thShotLib.BUTTERFLY[0]	, thShotLib.LIGHT[0]	, thShotLib.KNIFE[0]	, thShotLib.HEART[0],
		thShotLib.KUNAI[0]		, thShotLib.TALISMAN[0]	, thShotLib.BIGLIGHT[0] , thShotLib.RICE[0],
		thShotLib.OVAL[0]
	};
	
	public static final String danmakuForm[] =
	{
		"Point", "Random", "Sector", "Around", "Sphere", "Ring", "未定義"
	};
	
	/*public static final String danmakuForm_JP[] =
	{
		"一点", "ランダム", "扇状", "全方位", "球状", "未定義"
	};*/
	
	
	public static final int sellectbleColor[] = {7, 0, 2, 0, 1, 4, 5, 7, 7, 4, 2, 3, 5, 4, 6, 7};//１６色の染料を８色に対応させるための配列
	
	@SideOnly(Side.CLIENT)
    private Icon[] icon;

	public ItemTHShot(int itemID)
	{
		super(itemID);
		setHasSubtypes(true);
		setMaxDamage(0);
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
	}
	
	public String getUnlocalizedName(ItemStack itemStack)
    {
        int i = MathHelper.clamp_int(itemStack.getItemDamage(), 0, shotNames.length);
        return super.getUnlocalizedName() + "." + shotNames[i];
    }
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, shotNames.length);
        return this.icon[i];
    }
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister)
    {
        this.icon = new Icon[shotIconName.length];

        for (int i = 0; i < shotIconName.length; ++i)
        {
            this.icon[i] = par1IconRegister.registerIcon("thkaguyamod:" + shotIconName[i]);
        }
    }
	
	//右クリックを押したときの処理
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
	{
		EntityTHShot entityTHShot;
		double vectorX, vectorY, vectorZ;
		Random rand = new Random();
		int type = itemStack.getItemDamage();
		int type2 = form[type] / 8;//IDの互換用
		int color = form[type] + rand.nextInt(7);
		int special = 0;
		//int sellectbleColor[] = {7, 0, 2, 0, 1, 4, 5, 7, 7, 4, 2, 3, 5, 4, 6, 7};//１６色の染料を８色に対応させるための配列
		
		ItemStack colorItem = player.inventory.mainInventory[player.inventory.currentItem + 1];//右横に持っている相手っ無を取得
		
		if(player.inventory.currentItem < 8)//常時選択可能な１～９のアイテムなら
		{
			if(colorItem != null)//右横にアイテムがあるなら
	    	{
	    		if(colorItem.itemID == Item.dyePowder.itemID)//そのアイテムが染料なら
	    		{
	    			//染料のダメージ値を取得
	    			color = form[type] + sellectbleColor[player.inventory.mainInventory[player.inventory.currentItem + 1].getItemDamage()];
	    		}
	    		/*else if(colorItem.itemID == mod_thKaguya.powerItem.itemID)
	    		{
	    			//弾数を一つ追加
	    			NBTTagCompound nbt = itemStack.getTagCompound();
	    		    if(nbt == null)
	    		    {
	    		    	nbt = new NBTTagCompound();
	    		    	itemStack.setTagCompound(nbt);
	    		    	nbt.setShort("shotNum", (short)2);
	    		    	nbt.setByte("danmakuForm", (byte)(nbt.getByte("danmakuForm")));
	    		    }
	    		    else
	    		    {
	    		    	nbt.setShort("shotNum", (short)(nbt.getShort("shotNum") + 1));
	    		    	nbt.setByte("danmakuForm", (byte)(nbt.getByte("danmakuForm")));
	    		    }
	    		}
	    		else if(colorItem.itemID == mod_thKaguya.pointItem.itemID)
	    		{
	    			//形状を変化
	    			NBTTagCompound nbt = itemStack.getTagCompound();
	    		    if(nbt == null)
	    		    {
	    		    	nbt = new NBTTagCompound();
	    		    	itemStack.setTagCompound(nbt);
	    		    	nbt.setShort("shotNum", (short)1);
	    		    	nbt.setByte("danmakuForm", (byte)1);
	    		    	nbt.setByte("shotSpeed", (byte)0);
	    		    }
	    		    else
	    		    {
	    		    	nbt.setShort("shotNum", (short)(nbt.getShort("shotNum")));
	    		    	nbt.setByte("danmakuForm", (byte)(nbt.getByte("danmakuForm") + 1));
	    		    	nbt.setByte("shotSpeed", (byte)(nbt.getByte("shotSpeed")));
	    		    }
	    		}*/
	    	}
		}
		
		int way = 1;
		double shotSpeed = speed[type];
		int danmakuForm = 0;
		int deadTime = 60;
		double gravity = 0.0D;
		int i;
		
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt != null)
		{
			way = nbt.getShort("shotNum");
			danmakuForm = nbt.getByte("danmakuForm");
			shotSpeed = speed[type] * (1.0D + (double)nbt.getByte("shotSpeed") * 0.03D);
			special = nbt.getByte("special");
			gravity = (double)nbt.getByte("gravity") * -0.003D;
			
			int setColor = (int)nbt.getByte("shotColor");
			if(setColor != 9)
			{
				color = form[type] + (int)nbt.getByte("shotColor");
			}
			//special = (int)nbt.getByte("Special");
    	}
		
		//configで設定した最高弾数より多いなら、最高弾数にする
		if(way > mod_thKaguya.shotMaxNumber)
		{
			way = mod_thKaguya.shotMaxNumber;
		}
		
		float angleXZ, angleY;
		
		Vec3 look = player.getLookVec();
		
		switch(danmakuForm)
		{
			case 0:
				//color = thShotLib.CRYSTAL[ color % 8];
				double shotSpeedMin = shotSpeed / (double)way;
				double speedRate = 1.0D;
				double shotSpeed2 = shotSpeed;
			
				for(i = 1; i <= way; i++)
				{
					thShotLib.createShot(player, player, player.posX + look.xCoord * 0.2D, thShotLib.getPosYFromEye(player) + look.yCoord * 0.2D, player.posZ + look.zCoord * 0.2D, player.rotationYaw, player.rotationPitch, 0F, 0.0D, 1.0D, 0.0D, shotSpeed2, shotSpeed2, 0.0D, 0.0D, gravity, 0.0D,
							thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special);
					shotSpeed2 = shotSpeed / (double)way * (double)i;
				}
				break;
			case 1:
				thShotLib.createRandomRingShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D),player.posZ, 
						look.xCoord, look.yCoord, look.zCoord, 0F, shotSpeed, shotSpeed, 0.0D, 0.0D, gravity, 0.0D, thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special, way, 0.0D, 120F);
				break;
			case 2:
				//thShotLib.createWideShot01(player, player.rotationYaw, player.rotationPitch, shotSpeed, color, way, way * 3F);
				thShotLib.createWideShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch, shotSpeed, shotSpeed, 0.0D, 0.0D, gravity, 0.0D,
						thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special, way, way * 3F, 0.1D);
				break;
			case 3:
				thShotLib.createCircleShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch, shotSpeed, shotSpeed, 0.0D, 0.0D, gravity, 0.0D,
						thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special, way, 0.1D);
				break;
			case 4:
				int way2 = (int)Math.sqrt(way);
				//int rest = way - way2 * way2;
				way2= way;
				/*float angleXZ = player.rotationYaw;
				float angleYSpan = 180F / (float)(way2 + 1);
				float angleY = player.rotationPitch + angleYSpan - 90F;
				for(i = 0; i < way2; i++)
				{
					thShotLib.createCircleShot01(player, angleXZ, angleY, shotSpeed, color, way2);
					//angleXZ += 17F;
					angleY += angleYSpan;
				}
				if(rest >= 2)
				{
					thShotLib.createShot01(player, player.rotationYaw, -90F, shotSpeed, color);
					thShotLib.createShot01(player, player.rotationYaw,  90F, shotSpeed, color);
				}*/	
				angleXZ = itemRand.nextFloat() * 360F;
				float angleXZSpan = 0F;
				angleY = -90F;
				float angleYSpan = 180F / (way2 * 2 - 4);
				int n = 1;
				while(n <= way2 )
				{
					if(n != 2)
					{
					angleXZSpan = 360F / n;
					angleXZ = itemRand.nextFloat() * 360F;
					for(int n2 = 1; n2 <= n; n2++)
					{
						//thShotLib.createShot41(player, angleXZ, angleY, shotSpeed, color, special);
						thShotLib.createShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, angleXZ, angleY, 0F, 0.0D, 1.0D, 0.0D, shotSpeed, shotSpeed, 0.0D, 0.0D, gravity, 0.0D,
								thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special);
						angleXZ += angleXZSpan;
					}
					angleY += angleYSpan;
					}
					n++;
				}
				n--;
				while(n >= 1 )
				{
					if(n != 2)
					{
					angleXZSpan = 360F / n;
					angleXZ = itemRand.nextFloat() * 360F;
					for(int n2 = 1; n2 <= n; n2++)
					{
						thShotLib.createShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, angleXZ, angleY, 0F, 0.0D, 1.0D, 0.0D, shotSpeed, shotSpeed, 0.0D, 0.0D, gravity, 0.0D,
								thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special);
						angleXZ += angleXZSpan;
					}
					angleY += angleYSpan;
					}
					n--;
				}
				break;
			case 5:
				
				thShotLib.createRingShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D),player.posZ, 
						look.xCoord, look.yCoord, look.zCoord, 0F, shotSpeed, shotSpeed, 0.0D, 0.0D, gravity, 0.0D, thShotLib.DAMAGE[type2], color, thShotLib.SIZE[type2], 120, 0, special, way, 0.0D, 15F, rand.nextFloat() * 360F);
			default:
				break;
		}
		
		if(!world.isRemote)
		{
			itemStack.stackSize--;
		}
		
		return itemStack;
	}

	
	@SideOnly(Side.CLIENT)
	//クリエイトモードのアイテム欄に、ダメージ値の違うアイテムも表示できるようにする
    public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List par3List)
    {
        for (int i = 0; i < shotNames.length; i++)
        {
            par3List.add(new ItemStack(par1, 1, i));
        }
    }
	
    @Override
	public void addInformation(ItemStack itemStack, EntityPlayer entityPlayer, List list, boolean bool)
	{
		super.addInformation(itemStack, entityPlayer, list, bool);
		int type = itemStack.getItemDamage();
		short shotNum = 1;
		byte form = 0;
		float shotSpeed = (float)speed[type];
		int color = 8;
		double gravity = 0.0D;
		byte bound = 0;
		
		
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt != null)
		{
			shotNum = nbt.getShort("shotNum");
			form = nbt.getByte("danmakuForm");
			shotSpeed = (float)speed[type] * (1.0F + (float)nbt.getByte("shotSpeed") * 0.03F);
			color = nbt.getByte("shotColor");
			gravity = (double)nbt.getByte("gravity") * 0.003D;
			bound = (byte)(nbt.getByte("special") - thShotLib.BOUND01 + 1);
		}
		
		if(form >= danmakuForm.length)
		{
			form = (byte)(danmakuForm.length - 1);
		}
		
		String number = "" + shotNum;
		if(form == (byte)4)
		{
			number = number + " ✕ " + shotNum;
		}
		
		/*String special = "G Free";
		if((int)nbt.getByte("special") == thShotLib.FALL01)
		{
			special = "Fall";
		}*/
		
		//shotSpeed
		
		list.add(StatCollector.translateToLocal("danmakuCrafting.damage") + " : " + ((float)thShotLib.DAMAGE[shotTypeTrans[type]] / 2F));
		list.add(StatCollector.translateToLocal("danmakuCrafting.number") + " : " + number);
		list.add(StatCollector.translateToLocal("danmakuCrafting.form") + " : " + StatCollector.translateToLocal("thKaguya.danmakuForm." + form));
		list.add(StatCollector.translateToLocal("danmakuCrafting.speed") + " : " + shotSpeed);
		if(gravity != 0.0D)
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.gravity") + " : " + gravity);
		}
		else
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.gravity") + " : GFree");
		}
		list.add(StatCollector.translateToLocal("danmakuCrafting.color") + " : " + StatCollector.translateToLocal("thKaguya.color." + color));
		if(bound >= 1 && bound <= 3)
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.bound") + " : " + bound);
		}
		else if(bound == 4)
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.bound") + " : Infinity");
		}
		else
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.bound") + " : 0");
		}
		//list.add("Special: " + special);
	}
	
}