package thKaguyaMod.item;

import java.util.List;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;

import thKaguyaMod.thShotLib;

import java.util.Random;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemTenguFan extends Item
{
	//風を起こす団扇

	public ItemTenguFan(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:tenguFan");//テクスチャの指定
		setMaxDamage(40);
		maxStackSize = 1;
		setCreativeTab(CreativeTabs.tabCombat);//クリエイティブの素材タブに登録
	}
	
	//右クリックを押したときの処理
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
	{
		thShotLib.createShot(player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch, 2.0D, thShotLib.WIND[thShotLib.AQUA], thShotLib.WIND01);
		player.swingItem();//投げる動作をさせる
		world.playSoundAtEntity(player, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
		itemStack.damageItem(1, player);
		return itemStack;
	}

    public boolean isFull3D()
    {
        return true;
    }
}