package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.*;
import net.minecraft.potion.PotionEffect;
import net.minecraft.creativetab.CreativeTabs;

import thKaguyaMod.entity.EntityMazinkyoukan;


public class ItemMazinKyoukan extends Item
{
	
	//超人になれる巻物
	
	public ItemMazinKyoukan(int i)
	{
		super(i);
		func_111206_d("thkaguyamod:mazinKyoukan");//テクスチャの指定
		maxStackSize = 1;//一つしか持てない
		setCreativeTab(CreativeTabs.tabMisc);//クリエイティブのその他タブに登録
	}
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	/*ArrowNockEvent event = new ArrowNockEvent(entityPlayer, itemStack);
        MinecraftForge.EVENT_BUS.post(event);
        if (event.isCanceled())
        {
            return event.result;
        }*/
    	entityPlayer.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));//アイテムの使用継続時間を記憶させる？
    	EntityMazinkyoukan entityMazinkyoukan = new EntityMazinkyoukan(world, entityPlayer);
    	if(!world.isRemote)
    	{
    		world.spawnEntityInWorld(entityMazinkyoukan);
    	}
    	return itemStack;
    }
	
		//右クリックを終了したときに呼び出されるメソッド
	@Override
	//@SideOnly(Side.CLIENT)
	public void onPlayerStoppedUsing(ItemStack itemstack, World world, EntityPlayer entityPlayer, int usedTime)
    {

   	}
	
	//右クリックを終了したときに呼び出されるメソッド
	//@SideOnly(Side.CLIENT)
	/*@Override
	public void onPlayerStoppedUsing(ItemStack itemstack, World world, EntityPlayer entityPlayer, int usedTime)
    {
    	int time = this.getMaxItemUseDuration(itemstack) - usedTime;
        
        ArrowLooseEvent event = new ArrowLooseEvent(entityPlayer, itemstack, time);
        MinecraftForge.EVENT_BUS.post(event);
        if (event.isCanceled())
        {
            return;
        }
        time = event.charge;

    	if(time > 114)
    	{
    		time = 114;
    	}
    	time /= 3;
    	time *= 20;
    	if(time < 20)
    	{
    		time = 20;
    	}
    	//レッドストーンを消費する
    	if (entityPlayer.inventory.hasItem(Item.redstone.shiftedIndex))
        {
        	//	PotionEffect(ポーションのタイプ,持続時間（秒）*20（20は定数？）,レベル（0がレベル１、1がレベル２）)
        	if(!world.isRemote)
        	{
        		entityPlayer.addPotionEffect(new PotionEffect( 1, time, 1));//スピードアップ
        		entityPlayer.addPotionEffect(new PotionEffect( 5, time, 1));//攻撃力アップ
        		entityPlayer.addPotionEffect(new PotionEffect( 8, time, 1));//跳躍力アップ
        		entityPlayer.addPotionEffect(new PotionEffect(11, time, 1));//防御力アップ
        		//entityPlayer.addPotionEffect(new PotionEffect(12, 15 * 20, 1));//炎耐性
        		world.playSoundAtEntity(entityPlayer, "random.spellcard", mod_thKaguya.SpellCardVol, 1.0F);
        		
        	}
        	entityPlayer.inventory.consumeInventoryItem(Item.redstone.shiftedIndex);//レッドストーン消費
        }
    }*/
	
	/*@Override
    public ItemStack onFoodEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
        return par1ItemStack;
    }*/
	
    public ItemStack onEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
        return par1ItemStack;
    }
    
    public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
        return 72000;
    }
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack par1ItemStack)
    {
        return EnumAction.block;//右クリック時は剣のガードアクション
    }
	
	//アイテムを発光させる。 trueなら発光
	@Override
	@SideOnly(Side.CLIENT)
	public boolean hasEffect(ItemStack itemstack)
    {   
		return true;
    }
}