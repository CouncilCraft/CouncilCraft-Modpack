package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;

import thKaguyaMod.thShotLib;

import java.util.List;
import java.util.Random;

public class ItemKappaWaterPistol extends Item{
	//河童の水鉄砲
	//水を補充して水の弾幕を発射できる
	
	public ItemKappaWaterPistol(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:kappaWaterPistol");//テクスチャの指定
		setMaxDamage(39);
		this.maxStackSize = 1;
		setNoRepair();//修理不可
		this.setCreativeTab(CreativeTabs.tabCombat);
	}
	
	//右クリックを押したときの処理
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {
		//水を補充する処理
    	int blockX = 0, blockY = 0, blockZ = 0;
    	
        MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(world, player, true);
        
        if (movingobjectposition != null)
        {
        	blockX = movingobjectposition.blockX;
			blockY = movingobjectposition.blockY;
        	blockZ = movingobjectposition.blockZ;
        	if (world.getBlockMaterial(blockX, blockY, blockZ) == Material.water && world.getBlockMetadata(blockX, blockY, blockZ) == 0)
	        {
	        	//world.setBlockToAir(blockX, blockY, blockZ);
	        	itemStack.setItemDamage(itemStack.getItemDamage() - 2);
	        	player.swingItem();//投げる動作をさせる
	        	return itemStack;//補充ができたら弾幕は出さずに終了
	        }
		}
        
        if(itemStack.getItemDamage() == itemStack.getMaxDamage() - 1)
        {
        	return itemStack;
        }
        
        //水弾幕を出す処理
		double speed = 0.3D;
		Vec3 vec3 = thShotLib.getVecFromAngle(player.rotationYaw + 30F, player.rotationPitch, 0.2D);
		double xPos = player.posX + vec3.xCoord;
		double yPos = thShotLib.getPosYFromEye(player, -0.1D) + vec3.yCoord;
		double zPos = player.posZ + vec3.zCoord;
		//for(int i = 0; i < 8; i++)
		{
			thShotLib.createShot(player, player, xPos, yPos, zPos, player.rotationYaw, player.rotationPitch - 7F, 0F, 0.0D, 1.0D, 0.0D,
	        		1.0D - speed, 0.0D, 0.4D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.2F, 120, 0, thShotLib.FALL01);
	        thShotLib.createShot(player, player, xPos, yPos, zPos, player.rotationYaw, player.rotationPitch, 0F, 0.0D, 1.0D, 0.0D,
	        		1.1D - speed, 0.0D, 0.4D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.2F, 120, 0, thShotLib.FALL01);
	        thShotLib.createShot(player, player, xPos, yPos, zPos, player.rotationYaw, player.rotationPitch + 7F, 0F, 0.0D, 1.0D, 0.0D,
	        		1.2D - speed, 0.0D, 0.4D, 0.0D, 0.0D, 0.0D, 4.0F, thShotLib.LIGHT[thShotLib.BLUE], 0.2F, 120, 0, thShotLib.FALL01);
	        speed += 0.07D;
		}
        world.playSoundAtEntity(player, "liquid.splash", 0.5F, 4.0F);//音を出す
		itemStack.damageItem(1, player);//

        return itemStack;
    }
    
    /*public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
        return 72000;
    }*/
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack itemStack)
    {
        return EnumAction.bow;//右クリック時は剣のガードアクション
    }
	/*
	//アイテムを発光させる。 trueなら発光
	@Override
	public boolean hasEffect(ItemStack itemStack)
	{   
		return true;
    }*/
	
	//アイテムを大きく表示する
	@Override
	public boolean isFull3D()
    {
        return true;
    }
    
    //エンチャント不可
    @Override
    public int getItemEnchantability()
    {
        return 0;
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
}
