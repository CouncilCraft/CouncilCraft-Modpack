package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityHisou;
import thKaguyaMod.entity.EntityTHLaser;

import java.util.List;
import java.util.Random;

public class ItemSpearTheGungnir extends Item{
	//スピア・ザ・グングニル
	
	public ItemSpearTheGungnir(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:Gungnir");//テクスチャの指定
		setMaxDamage(95);
		this.maxStackSize = 1;
		setNoRepair();//修理不可
		this.setCreativeTab(CreativeTabs.tabCombat);
	}
	
	//右クリックを押したときの処理
	/*@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {
		Vec3 look = player.getLookVec();
		thShotLib.createLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, + 0.6D), player.posZ, -look.xCoord, look.yCoord, -look.zCoord, 0.0D, 2.0D, 0.0D, 0.0D, 0.0D, 0.0D,
				14F, thShotLib.RED + 8, 1.0F, 120, 0, thShotLib.GUNGNIR, 10.0D);
		
		player.motionX -= look.xCoord;
		player.motionZ -= look.zCoord;
		
        world.playSoundAtEntity(player, "mob.zombie.remedy", 0.5F, 2.7F);//音を出す
        world.playSoundAtEntity(player, "mob.wither.spawn", 0.2F, 10.0F);//音を出す
        //world.playSoundAtEntity(player, "random.orb", 2.0F, 1.0F);//音を出す
		itemStack.damageItem(1, player);//

        return itemStack;
    }*/
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
   	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {
    	//神槍「スピア・ザ・グングニル」を使用する
    	if(player.experienceLevel >= 3)//レベルが3より上なら使用可能
    	{
    		boolean spellCard = thKaguyaLib.checkSpellCardDeclaration(world, itemStack, player, 27, 2, true);
    		//スペルカード神槍「スピア・ザ・グングニル」を宣言
    		if(!world.isRemote && spellCard == false)
    		{
    			//宣言に失敗したなら終了する
    			return itemStack;
    		}
    		if(spellCard)
    		{
    			if(!world.isRemote){
    				
    				//entityplayer.removeExperience(5);//経験値を５消費
    			
    				player.addExperienceLevel(-3);//レベルを5消費
    			}
	    		Vec3 look = player.getLookVec();
	    		thShotLib.createLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, + 0.6D), player.posZ, -look.xCoord, look.yCoord, -look.zCoord, 0.0D, 2.0D, 0.0D, 0.0D, 0.0D, 0.0D,
	    				14F, thShotLib.RED + 8, 1.0F, 120, 0, thShotLib.GUNGNIR, 10.0D);
	    		
	    		/*if(world.isRemote)
	    		{
	    			player.motionX -= look.xCoord;
	    			player.motionZ -= look.zCoord;
	    		}*/
	            world.playSoundAtEntity(player, "mob.zombie.remedy", 0.5F, 2.7F);//音を出す
	            world.playSoundAtEntity(player, "mob.wither.spawn", 0.2F, 10.0F);//音を出す
	            //world.playSoundAtEntity(player, "random.orb", 2.0F, 1.0F);//音を出す
	    		itemStack.damageItem(1, player);//
    		}

    	}
    		
       	return itemStack;
    }
    
    /*public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
        return 72000;
    }*/
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack itemStack)
    {
        return EnumAction.bow;//右クリック時は剣のガードアクション
    }
	/*
	//アイテムを発光させる。 trueなら発光
	@Override
	public boolean hasEffect(ItemStack itemStack)
	{   
		return true;
    }*/
	
	//アイテムを大きく表示する
	@Override
	public boolean isFull3D()
    {
        return true;
    }
    
    //エンチャント不可
    @Override
    public int getItemEnchantability()
    {
        return 0;
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
}