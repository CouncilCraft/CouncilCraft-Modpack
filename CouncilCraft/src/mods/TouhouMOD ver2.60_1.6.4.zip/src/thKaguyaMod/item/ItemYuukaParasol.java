package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.client.gui.FontRenderer;
//import net.minecraft.client.renderer.RenderEngine;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.creativetab.CreativeTabs;
//import net.minecraft.client.texturepacks.TexturePackList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Icon;
import net.minecraft.util.MathHelper;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;

import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityYuukaParasol;
import thKaguyaMod.entity.EntityTHShot;

import java.util.List;
import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemYuukaParasol extends Item
{
	//幽香の傘
	
	public static final int PARASOL_MAX_DAMAGE = 60;//耐久値
	
	public ItemYuukaParasol(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:yuukaParasol");//テクスチャの指定
		setMaxDamage(PARASOL_MAX_DAMAGE);
		this.maxStackSize = 1;
		this.setCreativeTab(CreativeTabs.tabCombat);
	}
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	entityPlayer.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));//アイテムの使用継続時間を記憶させる
    	if(entityPlayer.isSneaking())
    	{
    		boolean flag = true;
    		//周囲のEntityを取得
    		List list = world.getEntitiesWithinAABBExcludingEntity(entityPlayer, entityPlayer.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(20.0D, 20.0D, 20.0D));
    		for(int k = 0; k < list.size(); k++)
    		{
    			Entity entity = (Entity)list.get(k);
    			if(entity instanceof EntityYuukaParasol)//幽香の日傘があるなら
    			{
    				EntityYuukaParasol entityYuukaParasol = (EntityYuukaParasol)entity;
    				if(entityYuukaParasol.user == entityPlayer)//その日傘の持ち主がこの日傘の持ち主と同じなら
    				{
						return itemStack;//日傘は出せない
    				}
    			}
    		}
    		EntityYuukaParasol entityYuukaParasol = new EntityYuukaParasol(world, entityPlayer, itemStack.getItemDamageForDisplay());
    		if(!world.isRemote)
    		{
    			world.spawnEntityInWorld(entityYuukaParasol);
    			itemStack.stackSize--;
    		}
    	}
    	return itemStack;
    }
	
	//右クリックを離したときに呼び出される
	@Override
	public void onPlayerStoppedUsing(ItemStack itemStack, World world, EntityPlayer entityPlayer, int usedTime)
	{
		int shotPower = 10 + getMaxItemUseDuration(itemStack)-usedTime;
		double shotPower2 = (float)shotPower / 10.0D;
		if(shotPower2 > 4.0D)
		{
			shotPower2 = 5.0D;
		}
    	float transDegree = 3.141593F / 180F;
    	double ax,ay,az;
    	EntityTHShot entityTHShot;
		Random random = new Random();
    	float angle = (float)random.nextInt(36000)/100F;
    	float angle2 = 0.0F;
    	int shotNum = 45;
    	float angleSpan = (360F / (float)shotNum) * transDegree;
    	float angle2Span = angleSpan * 20F;
		int color = thShotLib.SCALE[thShotLib.RED] + random.nextInt(2);
		if(color == thShotLib.SCALE[thShotLib.RED] + 1)
		{
			color = thShotLib.SCALE[thShotLib.YELLOW];
		}
		
    	for(int i = 0; i < shotNum; i++)
    	{
    		ax = -(double)MathHelper.sin(angle);//X方向　水平方向
    		az =  (double)MathHelper.cos(angle);//Z方向　水平方向
    		double speed = 0.23D - (double)MathHelper.sin(angle2) * 0.02D;
    		entityTHShot = new EntityTHShot(world, (EntityLivingBase)entityPlayer, entityPlayer, 
    			entityPlayer.posX, thShotLib.getPosYFromEye(entityPlayer, 0.2D), entityPlayer.posZ, 
    			ax * shotPower2, 1.4F, az * shotPower2, 0F, 0.0D, 1.0D, 0.0D, 
    			speed, speed, 0.0D, 0.0D, -0.02D, 0.0D, 7, color, 0.3F, 120, 3, thShotLib.FLOWER01);
    		if(!world.isRemote)
       		{
          		world.spawnEntityInWorld(entityTHShot);//鱗弾を出現させる
       		}
    		angle += angleSpan;
    		angle2 += angle2Span;
    	}
    	
    	shotNum = (int)((float)shotNum * 0.25F);
    	angleSpan  = (360F / (float)shotNum) * transDegree;
		shotPower2 *= 0.66D;
    	for(int i = 0 ;i < shotNum; i++)
    	{
    		ax = -(double)MathHelper.sin(angle);//X方向　水平方向
    		az =  (double)MathHelper.cos(angle);//Z方向　水平方向
       		entityTHShot = new EntityTHShot(world, (EntityLivingBase)entityPlayer, entityPlayer, 
       			entityPlayer.posX, thShotLib.getPosYFromEye(entityPlayer, 0.2D), entityPlayer.posZ, 
       			ax * shotPower2, 1.1F, az * shotPower2, 0F, 0.0D, 1.0D, 0.0D,
    			0.23D, 0.23D, 0.0D, 0.0D, -0.02D, 0.0D, 7, color, 0.3F, 120, 3, thShotLib.FLOWER01);
    		if(!world.isRemote)
       		{
          		world.spawnEntityInWorld(entityTHShot);//鱗弾を出現させる
       		}
    		angle += angleSpan;
    	}
    	world.playSoundAtEntity(entityPlayer, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
		itemStack.damageItem(1, entityPlayer);
    }
	
	//Entityに当たった時に呼び出される
	@Override
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase hitEntityLivingBase, EntityLivingBase useEntityLivingBase)
    {
    	//Entityを吹っ飛ばす
    	double disX = hitEntityLivingBase.posX - useEntityLivingBase.posX;
    	double disY = hitEntityLivingBase.posY - useEntityLivingBase.posY;
    	double disZ = hitEntityLivingBase.posZ - useEntityLivingBase.posZ;
    	float toEntityYaw = (float)Math.atan2(disX, disZ);
    	float toEntityPitch = (float)Math.atan2(disY, Math.sqrt(disX * disX + disZ * disZ));
    	double power = 3.0D;

    	hitEntityLivingBase.motionX = MathHelper.sin(toEntityYaw) * MathHelper.cos(toEntityPitch) * power;
    	hitEntityLivingBase.motionY = MathHelper.sin(toEntityPitch) * power + 1.0D;
    	hitEntityLivingBase.motionZ = MathHelper.cos(toEntityYaw) * MathHelper.cos(toEntityPitch) * power;

    	hitEntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(useEntityLivingBase), 7);
    	
    	itemStack.damageItem(1, useEntityLivingBase);
    	
        return true;
    }
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack par1ItemStack)
    {
        return EnumAction.block;//右クリック時は剣のガードアクション
    }
	
	//Entityへのダメージ
	/*@Override
    public int getDamageVsEntity(Entity par1Entity)
    {
        return 7;
    }*/
	
	//Forgeの追加メソッド
	//武器のダメージを返す
	@Override
    @Deprecated
    public float getDamageVsEntity(Entity hitEntity, ItemStack itemStack)
    {
        return 7.0F;
    }
	
    public ItemStack onEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
        return par1ItemStack;
    }
    
    public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
        return 72000;
    }
	
	//エンチャント
	@Override
    public int getItemEnchantability()
    {
        return 0;//エンチャントできない
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
	
	//Forgeの追加メソッド
	/*@Override
    public Icon getIcon(ItemStack stack, int pass)
    {
    	return getIconFromDamageForRenderPass(stack.getItemDamage(), 2);
    }*/
	
    /*@SideOnly(Side.CLIENT)
    public FontRenderer getFontRenderer(ItemStack stack)
    {
    	GameSettings gameSettings = new GameSettings();
    	String str = "";
    	TexturePackList texturePackList = new TexturePackList();
    	RenderEngine renderEngine = new RenderEngine(texturePackList, gameSettings);
    	FontRenderer fontRenderer = new FontRenderer(gameSettings, str, renderEngine, boolean par4);
        return null;
    }*/

}