package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import net.minecraft.util.Vec3;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityOnmyoudama;

import java.util.List;
import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemOnmyoudama extends Item
{
       
	//陰陽玉

	public ItemOnmyoudama(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:Onmyoudama");//テクスチャの指定
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
		this.maxStackSize = 1;//最大スタック数
	}
}
