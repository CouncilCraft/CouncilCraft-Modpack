package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityPrivateSquare;
import thKaguyaMod.entity.EntityTHLaser;
import thKaguyaMod.entity.EntityTHSetLaser;

import java.util.List;
import java.util.Random;

public class ItemLaevateinn extends ItemSword{
	//レーヴァテイン
	
	public ItemLaevateinn(int itemID, EnumToolMaterial material)
	{
		super(itemID, material);
		func_111206_d("thkaguyamod:Laevateinn");//テクスチャの指定
		//setMaxDamage(39);
		//this.maxStackSize = 1;
		setNoRepair();//修理不可
		//this.setCreativeTab(CreativeTabs.tabCombat);
	}
	
	//左クリックでEntityに当たった場合に呼び出されるメソッド
	@Override
	public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase)
    {
        //par1ItemStack.damageItem(0, par3EntityLivingBase);//耐久値を０減らす　（いらない？）
    	par2EntityLivingBase.setFire(itemRand.nextInt(3) + 3);//当たったEntityに着火　数値が大きいほど長くなるのかな？
        return true;
    }
	
	//右クリックを押したときの処理
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {		
		boolean flag = true;
		//周囲のEntityを取得
		List list = world.getEntitiesWithinAABBExcludingEntity(player, player.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(20.0D, 20.0D, 20.0D));
		for(int k = 0; k < list.size(); k++)
		{
			Entity entity = (Entity)list.get(k);
			if(entity instanceof EntityTHSetLaser)//設置レーザーがあるなら
			{
				EntityTHSetLaser laser = (EntityTHSetLaser)entity;
				if(laser.shootingEntity == player)//その設置レーザーの持ち主がレーヴァテインの持ち主と同じなら
				{
					return itemStack;//レーヴァテインは出せない
				}
			}
		}
		
		float angle = 0;
		Vec3 rotate;
		Vec3 move;// = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch + 155F, 0F, 1.0D);
		
		if(player.isSneaking())
		{	
			rotate = thShotLib.getVecFromAngle(player.rotationYaw + 90F,0F);
			move = thShotLib.getVecFromAngle(player.rotationYaw, player.rotationPitch - 90F);
			thShotLib.createLaserB(player, player, 0.0D, thShotLib.getPosYFromEye(player) - player.posY, 0.0D, move.xCoord, move.yCoord, move.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord, -6F, 7.0F, thShotLib.RED + 16, 0.6F, 30, 0, thShotLib.FIRE, 20.8D, player, 1.5D, 1.0F).setAngleZ(90F);
		}
		else
		{
			Vec3 look = player.getLookVec();
			rotate = thShotLib.getVecFromAngle(player.rotationYaw, player.rotationPitch - 90F);
			//move = thShotLib.getVecFromAngle(player.rotationYaw - 90F, player.rotationPitch);
			move = thShotLib.getVectorFromRotation(rotate.xCoord, rotate.yCoord, rotate.zCoord, look.xCoord, look.yCoord, look.zCoord, 90F);
			thShotLib.createLaserB(player, player, 0.0D, thShotLib.getPosYFromEye(player) - player.posY, 0.0D, move.xCoord, move.yCoord, move.zCoord, rotate.xCoord, rotate.yCoord, rotate.zCoord, -6F, 7.0F, thShotLib.RED + 16, 0.6F, 30, 0, thShotLib.FIRE, 20.8D, player, 1.5D, 1.0F);
		}
        world.playSoundAtEntity(player, "mob.ghast.fireball", 0.5F, 1.0F);//音を出す
		itemStack.damageItem(1, player);//

        return itemStack;
    }

	/*
	//アイテムを発光させる。 trueなら発光
	@Override
	public boolean hasEffect(ItemStack itemStack)
	{   
		return true;
    }*/
	
    
    //エンチャント不可
    @Override
    public int getItemEnchantability()
    {
        return 0;
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
}
