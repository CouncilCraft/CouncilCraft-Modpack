package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

import thKaguyaMod.entity.EntityAjaRedStoneEffect;

import java.util.List;
import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemAjaRedStone extends Item
{
	
	//エイジャの赤石
	//光を貯めてアンデッド特効のレーザーを発射する
	
	public ItemAjaRedStone(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:ajaRedStone");//テクスチャの指定
		setMaxDamage(3000);//耐久値だが、ここではチャージの具合を表すものとして使用している。
		this.maxStackSize = 1;
		this.setCreativeTab(CreativeTabs.tabCombat);
	}

	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {
    	player.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));//アイテムの使用継続時間を記憶させる
    	
    	double sx = player.posX - Math.sin(player.rotationYaw / 180F * (float)Math.PI) * Math.cos(player.rotationPitch / 180F * (float)Math.PI) * 1.2D;
    	double sy = player.posY - Math.sin(player.rotationPitch / 180F * (float)Math.PI) * 1.2D + (double)player.getEyeHeight();
    	double sz = player.posZ + Math.cos(player.rotationYaw / 180F * (float)Math.PI) * Math.cos(player.rotationPitch / 180F * (float)Math.PI) * 1.2D;
    	
    	EntityAjaRedStoneEffect entityAjaRedStoneEffect = new EntityAjaRedStoneEffect( world, player);
    	if(!world.isRemote)
    	{
    		world.spawnEntityInWorld(entityAjaRedStoneEffect);
    	}

    	
    	return itemStack;
    }
	
	//インベントリにある限り常時呼び出されるメソッド
	/*@Override
	public void onUpdate(ItemStack itemStack, World world, Entity entity, int i, boolean flag)
	{
		if(!(entity instanceof EntityPlayer))
		{
			return;
		}
		
		EntityPlayer player = (EntityPlayer)entity;
		
		if(player.isUsingItem() &&  itemStack.isItemEqual(player.inventory.getCurrentItem()))
		{
	    	double sx = player.posX - Math.sin(player.rotationYaw / 180F * (float)Math.PI) * Math.cos(player.rotationPitch / 180F * (float)Math.PI) * 1.2D;
	    	double sy = player.posY - Math.sin(player.rotationPitch / 180F * (float)Math.PI) * 1.2D + (double)player.getEyeHeight();
	    	double sz = player.posZ + Math.cos(player.rotationYaw / 180F * (float)Math.PI) * Math.cos(player.rotationPitch / 180F * (float)Math.PI) * 1.2D;
	    	
	    	EntityAjaRedStoneEffect entityAjaRedStoneEffect = new EntityAjaRedStoneEffect( world, player, sx, sy, sz, player.rotationYaw, player.rotationPitch);
	    	if(!world.isRemote)
	    	{
	    		world.spawnEntityInWorld(entityAjaRedStoneEffect);
	    	}
	    	
			if(!world.isRemote)
			{
	    		NBTTagCompound nbt = itemStack.getTagCompound();
				if(nbt == null)
	    		{
	    			nbt = new NBTTagCompound();
	    			itemStack.setTagCompound(nbt);
	    		}
	    		nbt.setShort("Charge", (short)(nbt.getShort("Charge") + world.getBlockLightValue((int)player.posX, (int)player.posY, (int)player.posZ)));
			}
	    	
	    	//itemStack.damageItem(world.getBlockLightValue((int)player.posX, (int)player.posY, (int)player.posZ), player);
	    	//player.setItemInUse(itemStack, player.getItemInUseCount() + world.getBlockLightValue((int)player.posX, (int)player.posY, (int)player.posZ) * 15);
		}
		
	}*/
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public void onPlayerStoppedUsing(ItemStack itemStack, World world, EntityPlayer player, int usedTime)
    {
		//float damage = (this.getMaxItemUseDuration(itemStack) - usedTime) / 40F;
		//float damage = (this.getMaxItemUseDuration(itemStack) - player.getItemInUseCount())  / 40F;
		
		//float damage = itemStack.getItemDamage();
		float damage = 0F;
		/*if(!world.isRemote)
		{
    		NBTTagCompound nbt = itemStack.getTagCompound();
			if(nbt == null)
    		{
    			nbt = new NBTTagCompound();
    			itemStack.setTagCompound(nbt);
    		}
    		damage = (float)nbt.getShort("Charge");
		}
		
		damage = damage / 40F;
		
		if(damage > 30F)
		{
			damage = 30F;
		}
		
		if(damage > 0F)
		{
			thShotLib.createLaserABaseB(player, player, player.posX, player.posY, player.posZ, player.rotationYaw, player.rotationPitch, 0.1D, 4.0D, 0.3D, 0.0D, 0.0D, 0.0D, damage, thShotLib.RED, (float)damage * 0.01F, 120, thShotLib.AJA01, (double)damage * 0.3D);
		}*/
    }
	
    /*public ItemStack onEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
        return par1ItemStack;
    }*/
    
    public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
        return 72000;
    }
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack par1ItemStack)
    {
        return EnumAction.block;//右クリック時は剣のガードアクション
    }
	
	//アイテムを発光させるか
	@Override
    @SideOnly(Side.CLIENT)
	public boolean hasEffect(ItemStack itemstack)
	{   
		return true;
    }
	
	//エンチャント可能か
    @Override
	public int getItemEnchantability()
    {
        return 0;//エンチャント適正0
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;//許可しない
    }
	
	//弓や剣のように大きな描画をするか
	@Override
    public boolean isFull3D()
    {
        return false;//しない
    }
}