package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import thKaguyaMod.mod_thKaguya;

import java.util.List;

public class ItemIcicleSword extends ItemSword
{

	//アイシクルソード
	//攻撃した相手を凍りづけにする
	
    public ItemIcicleSword(int itemID, EnumToolMaterial enumToolMaterial)
    {
        super(itemID, enumToolMaterial);
        func_111206_d("thkaguyamod:IcicleSword");//テクスチャの指定
    }

	//Entityに当たった時に呼び出される
	@Override
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase entityLivingBase_hit, EntityLivingBase entityLivingBase_user)
    {
		int x = (int)(entityLivingBase_hit.posX - 0.5D) - 1;
		int y = (int)(entityLivingBase_hit.posY + 0.5D) - 1;
		int z = (int)(entityLivingBase_hit.posZ - 0.5D) - 1;
		int yLoop = 3 + (int)entityLivingBase_hit.height;
		
		entityLivingBase_hit.setPosition(x + 1 + 0.5D, y + 1 + 0.5D, z + 1 + 0.5D);
		entityLivingBase_hit.motionX = 0.0D;
		entityLivingBase_hit.motionY = 0.0D;
		entityLivingBase_hit.motionZ = 0.0D;
		
		for(int i = 0; i < 3; i++)
		{
			for(int j = 0; j < yLoop; j ++)
			{
				for(int k = 0; k < 3; k++)
				{
					if(entityLivingBase_hit.worldObj.isAirBlock(x, y, z) || entityLivingBase_hit.worldObj.getBlockMaterial(x, y, z) == Material.water
							|| entityLivingBase_hit.worldObj.getBlockId(x, y, z) == 6
							|| entityLivingBase_hit.worldObj.getBlockId(x, y, z) == 31
							|| entityLivingBase_hit.worldObj.getBlockId(x, y, z) == 51
							|| entityLivingBase_hit.worldObj.getBlockId(x, y, z) == 78)
					{
						entityLivingBase_hit.worldObj.setBlock(x, y, z, 79);
					}
					z++;
				}
				z -= 3;
				y++;
			}
			y -= yLoop;
			x++;
		}
    	
        return super.hitEntity(itemStack, entityLivingBase_hit, entityLivingBase_user);
    }
		
	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	entityPlayer.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));//アイテムの使用継続時間を記憶させる
        return itemStack;
    }

	//エンチャント可能か？
	@Override
    public int getItemEnchantability()
    {
        return 0;//エンチャント不可
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
	
}
