package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import net.minecraft.util.Vec3;// 変更１

import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;

import java.util.List;
import java.util.Random;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemHouraiEda extends ItemBow
{
       
	//主に弓を元に改造。　360度飛ぶ弾幕を発射するアイテム
	
	public static final String houraiEdaIconName[] =
	{
		"houraiEda", "houraiEda_4","houraiEda_3", "houraiEda_2", "houraiEda_1", "houraiEda_0"
	};
	
	@SideOnly(Side.CLIENT)
    private Icon[] icon;

	public ItemHouraiEda(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:houraiEda");//テクスチャの指定
		setMaxDamage(301);//耐久値だが、ここではチャージの具合を表すものとして使用している。
		setHasSubtypes(true);
		setNoRepair();//修理不可
	}
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
    	int i = 5;
    	if(damage == 0)
    	{
    		i = 0;
    	}
    	else if(damage <= 100)
    	{
    		i = 1;
    	}
    	else if(damage <= 150)
    	{
    		i = 2;
    	}
    	else if(damage <= 200)
    	{
    		i = 3;
    	}
    	else if(damage <= 250)
    	{
    		i = 4;
    	}
        return this.icon[i];
    }
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister iconRegister)
    {
        this.icon = new Icon[houraiEdaIconName.length];

        for (int i = 0; i < houraiEdaIconName.length; ++i)
        {
            this.icon[i] = iconRegister.registerIcon("thkaguyamod:" + houraiEdaIconName[i]);
        }
    }
	

	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
	{
		entityPlayer.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));
		
		return itemStack;
	}
       
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public void onPlayerStoppedUsing(ItemStack itemStack, World world, EntityPlayer entityPlayer, int usedTime)
	{
		int i,j,rand,shotNum;
		shotNum = 32 + getMaxItemUseDuration(itemStack)-usedTime;//発射される弾数を代入。　最低32発。　getMaxItemUseDuration(itemstack)-usedTimeは右クリック継続時間で変化うする部分

		/*ArrowLooseEvent event = new ArrowLooseEvent(entityPlayer, itemStack, shotNum);
		MinecraftForge.EVENT_BUS.post(event);
		if (event.isCanceled())
		{
			return;
		}*/

		if(shotNum > 72)
		{
			shotNum = 72;//最大でも72発まで
		}
		shotNum /= 3;
		float f = 20F, angle = 0F, spanAngle;

		// 変更2
		double X1,X2,Z1,Z2,angleXZ = 0,angleY = 0,ay,ax,az;
		Vec3 lookAt = entityPlayer.getLookVec();
		lookAt.rotateAroundY((float)Math.PI*2);

		spanAngle = 360F/(float)shotNum; //あらゆる弾数でも360度飛ぶように、弾の間隔を代入
		Random random = new Random();
		float degTrans = 3.141593F / 180F;
		float pitchDis = entityPlayer.rotationPitch / ((float)shotNum / 4.0F);
		float rotationPitch = entityPlayer.rotationPitch;


		
		if(itemStack.getItemDamageForDisplay() <= 250)//受けているダメージが249より小さいなら使用可能　つまり耐久値が50/300より大きいなら使用できる
    	{
			if(entityPlayer.isSneaking())//スニーク状態なら
			{
				//弾幕を発射。　単純な全方位ではなく、弾速の違う３つをセットに全方位に放つ
				for(i = 0; i < shotNum; i+=3)
				{
					rand = thShotLib.PEARL[0] + random.nextInt(7);//弾の色をランダムで決める
					thShotLib.createCircleShot(entityPlayer, entityPlayer, entityPlayer.posX, thShotLib.getPosYFromEye(entityPlayer, -0.2), entityPlayer.posZ, 
							entityPlayer.rotationYaw + (float)i * 3F, entityPlayer.rotationPitch, 0.3D + (double)i * 0.2D, 2.0D, 0.03D, 0.0D, 0.0D, 0.0D, 
							5, rand, 0.3F, 80, 1, 0, shotNum, 0.2D);
				}

			}
			else//スニーク状態でないなら
			{
				rand = thShotLib.PEARL[0] + random.nextInt(7);
				thShotLib.createWideShot(entityPlayer, entityPlayer, entityPlayer.posX,  thShotLib.getPosYFromEye(entityPlayer, -0.2), entityPlayer.posZ, 
						entityPlayer.rotationYaw, entityPlayer.rotationPitch, 0.3D, 2.0D, 0.03D, 0.0D, 0.0D, 0.0D, 
						5, 1000 + thShotLib.PEARL[0], 0.3F, 80, 1, 0, shotNum, 30F, 0.2D);
			}
			
			world.playSoundAtEntity(entityPlayer, "random.orb", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
			
			itemStack.damageItem(50, entityPlayer);//耐久を50/300減らす　連射は6回までということになる
			
			/*if(!world.isRemote)
    		{
	    		NBTTagCompound nbt = itemStack.getTagCompound();
    			if(nbt == null)
	    		{
	    			nbt = new NBTTagCompound();
	    			itemStack.setTagCompound(nbt);
	    		}
	    		nbt.setInteger("Charge", (entityPlayer.ticksExisted - 1) % 50);
    		}*/
		}
	}
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack itemStack)
	{
		return EnumAction.block;//右クリック時は剣のガードアクション
		//return EnumAction.bow;//右クリック時は剣のガードアクション
	}

	//インベントリにある限り常時呼び出されるメソッド
	@Override
	public void onUpdate(ItemStack itemStack, World world, Entity entity, int i, boolean flag)
	{
		//耐久が減っていたら徐々に回復
		//if(  /*itemStack.isItemDamaged() == true &&*/ entity.ticksExisted % 5 == 0)
		/*{
			if(entity instanceof EntityPlayer)
			{
				EntityPlayer entityPlayer = (EntityPlayer)entity;
				if(!world.isRemote && itemStack.getItemDamage() > 300)
				{
					itemStack.setItemDamage(300);
				}
			}
		}*/
		
		/*if(!world.isRemote)
    	{
	    	NBTTagCompound nbt = itemStack.getTagCompound();
    		if(nbt == null)
	    	{
	    		nbt = new NBTTagCompound();
	    		itemStack.setTagCompound(nbt);
	    		nbt.setInteger("Charge", 0);
	    		if(entity.ticksExisted % 50 == 0)
	    		{
	    			itemStack.setItemDamage(itemStack.getItemDamage() -50);
	    		}
	    	}
    		else if(entity.ticksExisted % 50 == nbt.getInteger("Charge"))
    		{
    			//nbt.setInteger("Charge", nbt.getInteger("Charge") - 50);
    			itemStack.setItemDamage(itemStack.getItemDamage() - 50);
    		}
    	}*/
		if(itemStack.isItemDamaged() && entity.ticksExisted % 20 == 0)
		{
			if(entity instanceof EntityPlayer)
			{
				EntityPlayer player = (EntityPlayer)entity;
				itemStack.damageItem(-20, player);
			}
			
			//itemStack.setItemDamage(itemStack.getItemDamage() - 20);
		}
	}

	//アイテムを発光させる。 trueなら発光
	@Override
	@SideOnly(Side.CLIENT)
	public boolean hasEffect(ItemStack itemStack)
	{   
		return true;
	}
	
	//エンチャント不可
	@Override
	public int getItemEnchantability()
	{
		return 0;
	}
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
	
}