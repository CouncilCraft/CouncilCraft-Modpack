package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.block.material.Material;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;

public class ItemIbukihyou extends ItemFood
{
	
	//飲むと一時的に攻撃力が上昇するが、
	
	public ItemIbukihyou(int itemID, int foodLevel, boolean flag)
	{
		super(itemID, foodLevel, flag);
		func_111206_d("thkaguyamod:ibukihyou");//テクスチャの指定
		setMaxDamage(10);
		maxStackSize = 1;//スタック不可
		setAlwaysEdible();//いつでも飲める
		setNoRepair();//修理不可
	}
	
	//食べたときの処理
	@Override
	protected void onFoodEaten(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
        if (!world.isRemote)
    	{
    		//	 				PotionEffect(ポーションのタイプ,持続時間（秒）*20（20は定数？）,レベル（0がレベル１、1がレベル２）)
        	entityPlayer.addPotionEffect(new PotionEffect( 5, 10 * 20, 2));//攻撃力アップ
    		entityPlayer.addPotionEffect(new PotionEffect( 9, 10 * 20, 2));//ゆらゆら
    	}
    }
	
	//食べ物を食べたときに呼び出されるメソッド
	@Override
	public ItemStack onEaten(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	if(itemStack.getItemDamageForDisplay() < 9)
    	{
    		itemStack.damageItem(1, entityPlayer);
        	entityPlayer.getFoodStats().addStats(this);
        	world.playSoundAtEntity(entityPlayer, "random.burp", 0.5F, world.rand.nextFloat() * 0.1F + 0.9F);
        	this.onFoodEaten(itemStack, world, entityPlayer);
    	}
        return itemStack;
    }
	
	//右クリックを押したときに呼び出される
	@Override
    public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {	
    	super.onItemRightClick(itemStack, world, entityPlayer);

    	int blockX = 0, blockY = 0, blockZ = 0;
    	
        MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(world, entityPlayer, true);
        
        if (movingobjectposition != null)
        {
        	blockX = movingobjectposition.blockX;
			blockY = movingobjectposition.blockY;
        	blockZ = movingobjectposition.blockZ;
        	if (world.getBlockMaterial(blockX, blockY, blockZ) == Material.water && world.getBlockMetadata(blockX, blockY, blockZ) == 0)
	        {
	        	world.setBlockToAir(blockX, blockY, blockZ);
	        	itemStack.setItemDamage(0);
	        }
		}
		return itemStack;
    }
	
	//飲み干すまでにかかる時間
	@Override
    public int getMaxItemUseDuration(ItemStack itemStack)
    {
        return 16;
    }
	
	//右クリックしている間の動作
	@Override
    public EnumAction getItemUseAction(ItemStack itemStack)
    {
    	if(itemStack.getItemDamageForDisplay() >= 9)
    	{
    		return EnumAction.none;
    	}
        return EnumAction.drink;
    }
	
}