package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;

import thKaguyaMod.mod_thKaguya;

import java.util.List;

public class ItemRoukanken extends ItemSword
{

	//楼観剣　アンデッドに特攻　ガードはできない
	//基本鉄の剣と同じ
	
    public ItemRoukanken(int itemID, EnumToolMaterial enumToolMaterial)
    {
        super(itemID, enumToolMaterial);
        func_111206_d("thkaguyamod:roukanSword");//テクスチャの指定
    }
	
	//ブロックに対する強さ
	@Override
    public float getStrVsBlock(ItemStack itemStack, Block block)
    {
    	//蜘蛛の巣か、葉っぱブロックなら
    	if (block.blockID == Block.web.blockID || block.blockID == Block.leaves.blockID)
        {
            return 30F;//かなりの速度で壊せる
        }

        if (block.blockID == Block.cloth.blockID)//羊毛ブロックなら
        {
            return 20F;//それなりの速度で壊せる（これでも早い）
        }
        else
        {
        	//それ以外なら、通常処理の３倍で壊す
            return super.getStrVsBlock(itemStack, block) * 3F;
        }
    }

	//Entityに当たった時に呼び出される
	@Override
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase entityLivingBase_hit, EntityLivingBase entityLivingBase_user)
    {
    	//当たったEntityがアンデットなら
    	if(entityLivingBase_hit.getCreatureAttribute() == EnumCreatureAttribute.UNDEAD)
    	{
    		//ハート１０個分のダメージ
    		entityLivingBase_hit.attackEntityFrom(DamageSource.causeMobDamage(entityLivingBase_user), 16.0F);
    		if(entityLivingBase_user instanceof EntityPlayer)
    		{
    			EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase_user;
    			entityPlayer.onEnchantmentCritical(entityLivingBase_hit);
    		}
    	}
        itemStack.damageItem(1, entityLivingBase_user);//耐久を１減らす
    	
        return true;
    }
	
	//Forgeの追加メソッド
	//武器のダメージを返す
	@Override
    @Deprecated
    public float getDamageVsEntity(Entity hitEntity, ItemStack itemStack)
    {
        return 8.0F;
    }
		
	//右クリックを押したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	entityPlayer.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));//アイテムの使用継続時間を記憶させる
        return itemStack;
    }
	
	//右クリックを押し終わったときに呼び出されるメソッド
	@Override
	public void onPlayerStoppedUsing(ItemStack itemStack, World world, EntityPlayer entityPlayer, int usedTime)
    {	
    	if(entityPlayer.onGround)//プレイヤーが地面に接しているなら
    	{
    		//右クリック時間でダッシュするパワーを決める
	    	double パワー = (double)getMaxItemUseDuration(itemStack) - usedTime;
	    	//Javaって日本語名の変数使えるのね・・・
	    	
    		//ダッシュするパワーは20が限界
    		if(パワー > 20.0)
	    	{
	    		パワー = 20.0;
	    	}
	    	
    		パワー *= 0.3;
    		
    		//プレイヤーをダッシュするパワーの分だけ前進させる
	    	entityPlayer.motionX = -Math.sin(Math.toRadians(entityPlayer.rotationYaw)) * パワー;
	    	entityPlayer.motionZ =  Math.cos(Math.toRadians(entityPlayer.rotationYaw)) * パワー;
	    	
			if(!entityPlayer.capabilities.isCreativeMode)//クリエイティブでないなら
			{
				entityPlayer.addExhaustion(1.5F);//使うたびに少し腹が減る
			}
       		
    		itemStack.damageItem(1, entityPlayer);
    	}
   	}
	
	//所持している限り常に呼ばれるメソッド
	@Override
	public void onUpdate(ItemStack itemStack, World world, Entity entity, int i, boolean flag)
	{
		//プレイヤーでなければ失敗する
		if(entity instanceof EntityPlayer)
		{
			EntityPlayer entityPlayer = (EntityPlayer)entity;
			
			//手に何か持っているなら
			if(entityPlayer.inventory.getCurrentItem() != null)
			{
				//プレイヤーが手にしているものが楼観剣なら
				if(entityPlayer.inventory.getCurrentItem().getItem() == mod_thKaguya.roukankenItem)
				{
					double xx, zz;
					xx = entity.motionX;
					zz = entity.motionZ;
					if( Math.sqrt(xx*xx + zz*zz) > 3.0)//移動量が3.0を越しているなら
					{
						//指定範囲内のEntityのリストを取得
						List list = world.getEntitiesWithinAABBExcludingEntity(entity, entity.boundingBox.addCoord(entity.motionX, entity.motionY, entity.motionZ).expand(1.0D, 1.0D, 1.0D));
        				double d = 0.0D;
        				for (int j = 0; j < list.size(); j++)
        				{
							 Entity entity1 = (Entity)list.get(j);
            				if (!entity1.canBeCollidedWith())
            				{
                				continue;
            				}
        					MovingObjectPosition movingobjectposition = new MovingObjectPosition(entity1);
    						if(movingobjectposition.entityHit instanceof EntityLivingBase)
    						{
    							EntityLivingBase entityLivingBase = (EntityLivingBase)movingobjectposition.entityHit;
    							if(entityPlayer.canEntityBeSeen(entityLivingBase))
    							{
    								if(entityLivingBase.getCreatureAttribute() == EnumCreatureAttribute.UNDEAD)//アンデッドに当たったなら
    								{
    									entityLivingBase.attackEntityFrom(DamageSource.causeMobDamage((EntityLivingBase)entity), 16.0F);//20ダメージを追加する
    									entityPlayer.onEnchantmentCritical(entityLivingBase);
    								}
    								else
    								{
    									entityLivingBase.attackEntityFrom(DamageSource.causeMobDamage((EntityLivingBase)entity), getDamageVsEntity(entity, itemStack));//それ以外なら8ダメージ
    								}
    								world.playSoundAtEntity(entity, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
    							}
    						}
        					itemStack.damageItem(1, (EntityLivingBase)entity);//アイテムの耐久を1減らす
        					entityPlayer.swingItem();//投げる動作をさせる
        					if(itemStack.getItemDamageForDisplay() == getMaxDamage())//アイテムの耐久が限界なら
        					{
        						itemStack.stackSize--;//消滅させる
        						break;//これ以上の処理を終了させる
        					}
        				}
					}
				}
			}
		}
	}
	
	//右クリックを長押しした祭の動作を指定
	@Override
	public EnumAction getItemUseAction(ItemStack itemStack)
    {
        return EnumAction.bow;//弓の構えをする
    }

	@Override
    public boolean canHarvestBlock(Block block)
    {
    	return true;//なんでも取得可能　切れぬものはあんm（ry
    }

	//エンチャント可能か？
	@Override
    public int getItemEnchantability()
    {
        return 0;//エンチャント不可
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
	
}
