package thKaguyaMod.item;

import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class ItemBlockDanmakuCraftingTable extends ItemBlock
{
	public ItemBlockDanmakuCraftingTable(int itemID)
	{
		super(itemID);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
		
	}
	
	@Override
	public int getMetadata(int damage)
	{
		return damage;
	}
	
	@Override
	public String getUnlocalizedName(ItemStack itemStack)
	{
		return super.getUnlocalizedName() + "_" + itemStack.getItemDamage();
	}

}
