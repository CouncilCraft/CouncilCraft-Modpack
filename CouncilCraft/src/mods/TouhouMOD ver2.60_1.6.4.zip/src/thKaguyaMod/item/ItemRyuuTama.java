package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityRyuuLightningBolt;

import java.util.List;
import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemRyuuTama extends Item
{
	
	//龍の玉を投げつけて、落下地点に雷を落とす
	
	public ItemRyuuTama(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:ryuuTama");//テクスチャの指定
		setMaxDamage(300);//最大耐久値だが、ここではチャージ値として扱う
		maxStackSize = 1;
		setCreativeTab(CreativeTabs.tabCombat);//クリエイティブの武器タブに登録
		setNoRepair();//修理不可
	}

	//右クリック時に呼び出されるメソッド
	@Override
   	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player)
    {
    	float f = 20F;
    	double px, py, pz;
    	double xVector, yVector, zVector;
    	float[] r = {1.0F, 0.1F, 0.1F, 1.0F, 1.0F};
    	float[] g = {0.1F, 1.0F, 0.1F, 1.0F, 0.1F};
    	float[] b = {0.1F, 0.1F, 1.0F, 0.1F, 1.0F};
    	Vec3 vec3;
    	EntityRyuuLightningBolt ryuutama;
    	
    	if(!player.isSneaking() && itemstack.getItemDamageForDisplay() < 229)//受けているダメージが229よりちいさいなら　つまり耐久値が70/300より大きいなら
    	{
    		vec3 = thShotLib.getVecFromAngle(player.rotationYaw, player.rotationPitch, 1.0D);
    		Random random = new Random();
    		int rand = random.nextInt(5);
    		ryuutama = new EntityRyuuLightningBolt(world, player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, vec3.xCoord, vec3.yCoord, vec3.zCoord, r[rand], g[rand], b[rand]);
       		world.playSoundAtEntity(player, "random.orb", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
       		if(!world.isRemote)
       		{
           		world.spawnEntityInWorld(ryuutama);//龍の頸の玉を発射
       		}
       		
       		itemstack.damageItem(70, player);//耐久を70減らす
    	}
    	else if(player.isSneaking() && itemstack.getItemDamageForDisplay() < 1)//スニーク時は５つ同時発射　5色の雷を落とす
    	{
    		float angle = -40F;
    		for(int i = 0; i < 5; i++)
    		{
    			vec3 = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch, angle, 1.0D);
    			ryuutama = new EntityRyuuLightningBolt(world, player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2),player.posZ, vec3.xCoord, vec3.yCoord, vec3.zCoord, r[i], g[i], b[i]);
    			if(!world.isRemote)
    			{
    				world.spawnEntityInWorld(ryuutama);//龍の頸の玉を発射
    			}
    			angle += 20F;
    		}
       		world.playSoundAtEntity(player, "random.orb", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
       		
       		itemstack.damageItem(299, player);//耐久を最大まで減らす
    	}
    		
       	return itemstack;
    }
	
	//インベントリにあるかぎり呼び出されるメソッド
	//@SideOnly(Side.CLIENT)
	@Override
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
    {
    	//耐久が減っていたら徐々に回復
    	if(entity.ticksExisted % 20 == 0 && itemstack.isItemDamaged() == true)//ダメージを受けているなら
    	{
    		//if(world.isRemote)
    		{
    			itemstack.damageItem(-20, (EntityLivingBase)entity);//毎フレーム耐久を1回復
    			//itemstack.setItemDamage(itemstack.getItemDamage() - 5);
    		}
    	}  
    }
	
	//アイテムを発光させる。 trueなら発光
	@SideOnly(Side.CLIENT)
	@Override
	public boolean hasEffect(ItemStack itemstack)
	{   
		return true;
    }
}