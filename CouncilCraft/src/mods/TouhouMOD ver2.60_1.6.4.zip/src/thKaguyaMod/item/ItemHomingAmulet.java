package thKaguyaMod.item;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.Icon;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityHomingAmulet;

public class ItemHomingAmulet extends Item
{
	//霊夢のホーミングアミュレット
	public static final String amuletTypeNames[] =
	    {
	        "Homing Amulet", "Diffusion Amulet"
	    };
	public static final String amuletIconName[] =
		{
			"thkaguyamod:homingAmulet", "thkaguyamod:diffusionAmulet"
		};
	
	@SideOnly(Side.CLIENT)
    private Icon[] icon;
	
	public ItemHomingAmulet(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:homingAmulet");//テクスチャの指定
		setHasSubtypes(true);
		setMaxDamage(0);
		setCreativeTab(CreativeTabs.tabCombat);//クリエイティブの武器タブに登録
	}
	
	public String getUnlocalizedName(ItemStack itemStack)
    {
        int i = MathHelper.clamp_int(itemStack.getItemDamage(), 0, 15);
        return super.getUnlocalizedName() + "." + amuletTypeNames[i];
    }
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, 2);
        return this.icon[i];
    }
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister iconRegister)
    {
        this.icon = new Icon[amuletIconName.length];

        for (int i = 0; i < amuletIconName.length; ++i)
        {
            this.icon[i] = iconRegister.registerIcon(amuletIconName[i]);
        }
    }
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {
    	double vectorX, vectorY, vectorZ;
    	EntityHomingAmulet entityHomingAmulet;
    	Vec3 vec3;

    	if(itemStack.getItemDamage() == 0)
    	{
    		if(player.isSneaking())//低速モード
    		{
	    		float angle = -10F;
	    		for(int i = 0; i < 2; i++)
	    		{
	    			vec3 = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch, angle, 1.0D);
	    			thKaguyaLib.createHomingAmulet(world, player, player, player.posX + vec3.xCoord, thShotLib.getPosYFromEye(player, -0.2D) + vec3.yCoord, player.posZ + vec3.zCoord, vec3.xCoord, vec3.yCoord, vec3.zCoord, 
							0.7D, 0.7D, 0.0D, 0.0D, 0.0D, 0.0D, 
							5.0F, 1, 2.0F, 60, 0);
	    			angle += 20F;
	    		}
	    	}
	    	else//高速モード
	    	{
	    		float angle = -50F;
	    		for(int i = 0; i < 5; i++)
	    		{
	    			vec3 = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch, angle, 1.0D);
		    		thKaguyaLib.createHomingAmulet(world, player, player, player.posX + vec3.xCoord, thShotLib.getPosYFromEye(player, -0.2D) + vec3.yCoord, player.posZ + vec3.zCoord, vec3.xCoord, vec3.yCoord, vec3.zCoord, 
							0.7D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 
							2.5F, 0, 0.4F, 60, 0);
	    			angle += 25F;
	    		}
	    	}
    	}
    	else
    	{
    		float angle = -30F;
    		for(int i = 0; i < 2; i++)
    		{
    			vec3 = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch, angle, 1.0D);	
	    		thKaguyaLib.createHomingAmulet(world, player, player, player.posX + vec3.xCoord, thShotLib.getPosYFromEye(player, -0.2D) + vec3.yCoord, player.posZ + vec3.zCoord, vec3.xCoord, vec3.yCoord, vec3.zCoord, 
						0.5D, 0.0D, -0.03D, 0.0D, 0.0D, 0.0D, 
						8.0F, 3, 2.0F, 60, 0);
	    		angle += 60F;
    		}
    	}
    	world.playSoundAtEntity(player, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
    	if(!world.isRemote)
    	{
    		itemStack.stackSize--;//一つ消費
    	}
    	
        return itemStack;
    }
	
	@SideOnly(Side.CLIENT)
	//クリエイトモードのアイテム欄に、ダメージ値の違うアイテムも表示できるようにする
    public void getSubItems(int damage, CreativeTabs creativeTabs, List list)
    {
        for (int i = 0; i < 2; i++)
        {
            list.add(new ItemStack(damage, 1, i));
        }
    }
}