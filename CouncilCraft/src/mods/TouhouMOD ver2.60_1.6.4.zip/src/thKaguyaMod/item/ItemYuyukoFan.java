package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.ArrowNockEvent;

import thKaguyaMod.thShotLib;

import java.util.List;
import java.util.Random;

public class ItemYuyukoFan extends Item
{
	
	//幽々子の扇
	//死に誘う扇
	//蝶の弾幕をいくらでも出せるが、どんどん腹が減る
	//
	
	public ItemYuyukoFan(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:yuyukoOugi");//テクスチャの指定
		setMaxDamage(444);
		this.maxStackSize = 1;
		this.setCreativeTab(CreativeTabs.tabCombat);
	}
	
	//右クリックを押したときの処理
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
        /*ArrowNockEvent event = new ArrowNockEvent(entityPlayer, itemStack);
        MinecraftForge.EVENT_BUS.post(event);
        if (event.isCanceled())
        {
            return event.result;
        }*/
        
        entityPlayer.setItemInUse(itemStack, this.getMaxItemUseDuration(itemStack));

        return itemStack;
    }
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public void onPlayerStoppedUsing(ItemStack itemStack, World world, EntityPlayer player, int usedTime)
    {
    	int color,shotNum,shotNum3;
    	shotNum = 32 + getMaxItemUseDuration(itemStack) - usedTime;//発射される弾数を代入。　最低32発。　getMaxItemUseDuration(itemStack)-usedTimeは右クリック継続時間で変化する部分
    	if(shotNum > 72)
    	{
    		shotNum = 72;//最大でも72発まで
    	}
    	else if(shotNum % 3 != 0)
    	{
    		shotNum = (int)(shotNum / 3) * 3;
    	}
    	shotNum3 = shotNum / 3;
    	
    	if(player.isSneaking())//スニーク状態なら
    	{
    		//弾幕を発射。　単純な全方位ではなく、弾速の違う３つをセットに全方位に放つ
    		for(int i = 0 ; i < 3; i++)
    		{
    			color = thShotLib.BUTTERFLY[thShotLib.BLUE] + itemRand.nextInt(4);//弾の色をランダムで決める
    			double speed = 0.1D + (double)(i * 0.1D);
    			//Vec3 vec3 = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch, 30, 1.0D);
    			thShotLib.createCircleShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch,
    					speed, speed, 0.0D, 0.0D, 0.0D, 0.0D, 4, color, 0.6F, 120, 1, 0, shotNum3, 0.2D);
    		}
    	}
    	else//スニーク状態でないなら
    	{
    		color = thShotLib.BUTTERFLY[thShotLib.BLUE] + itemRand.nextInt(4);//弾の色をランダムで決める
			thShotLib.createWideShot(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch,
					0.15D, 0.15D, 0.0D, 0.0D, 0.0D, 0.0D, 4, color, 0.6F, 120, 1, 0, shotNum3 + 1, 60F, 0.2D);
    	}
		
		if(!player.capabilities.isCreativeMode)//クリエイティブでないなら
		{
			player.addExhaustion(1.5F);//使うたびに少し腹が減る
		}
		world.playSoundAtEntity(player, "random.orb", 0.5F, 1.0F);//音を出す
		itemStack.damageItem(1, player);//
   	}
	
	@Override
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase hitEntityLivingBase, EntityLivingBase userEntityLivingBase)
    {
		if(hitEntityLivingBase.func_110143_aJ()/*getHealth()*/ > 0 && hitEntityLivingBase.func_110143_aJ()/*getHealth()*/ < 20 && hitEntityLivingBase.hurtTime > 0)
		{
			if(itemRand.nextInt(100) < 5)
			{
				userEntityLivingBase.heal(hitEntityLivingBase.func_110143_aJ()/*getHealth()*/);
				hitEntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(userEntityLivingBase), 4444);
				userEntityLivingBase.worldObj.playSoundAtEntity(userEntityLivingBase, "mob.zombie.unfect", 1.0F, 40.0F);
			}
		}
		itemStack.setItemDamage(itemStack.getItemDamage() + 1);
		//itemStack.damageIteme(1, userEntityLiving);
		return true;
    }
	
    public ItemStack onEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
        return par1ItemStack;
    }
    
    public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
        return 72000;
    }
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack itemStack)
    {
		//return EnumAction.bow;
        return EnumAction.block;//右クリック時は剣のガードアクション
    }
	
	//アイテムを発光させる。 trueなら発光
	@Override
	public boolean hasEffect(ItemStack itemStack)
	{   
		return true;
    }
	
	//アイテムを大きく表示する
	@Override
	public boolean isFull3D()
    {
        return true;
    }
    
    //エンチャント不可
    @Override
    public int getItemEnchantability()
    {
        return 0;
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
}