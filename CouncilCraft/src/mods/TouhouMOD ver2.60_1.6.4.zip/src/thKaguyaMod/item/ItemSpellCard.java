package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import net.minecraft.util.StringTranslate;
import net.minecraft.client.renderer.texture.IconRegister;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thKaguyaLib;
import thKaguyaMod.entity.EntitySpellCard;

import java.util.List;
import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemSpellCard extends Item
{
	
	//スペルカード
	
	@SideOnly(Side.CLIENT)
    private Icon[] icon;
	
	public ItemSpellCard(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:spellCard/0");//テクスチャの指定
		setHasSubtypes(true);
		setMaxDamage(0);
		maxStackSize = 3;
		setCreativeTab(mod_thKaguya.tabSpellCard);//クリエイティブのスペルカードタブに登録
	}
	
	public String getUnlocalizedName(ItemStack itemStack)
    {
        int i = MathHelper.clamp_int(itemStack.getItemDamage(), 0, mod_thKaguya.scEnName.length);
    	return super.getUnlocalizedName() + "." + mod_thKaguya.scEnName[i];
    }
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, mod_thKaguya.scEnName.length);
        return this.icon[i];
    }
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister)
    {
        this.icon = new Icon[mod_thKaguya.scEnName.length];

        for (int i = 0; i < mod_thKaguya.scEnName.length; ++i)
        {
            this.icon[i] = par1IconRegister.registerIcon("thkaguyamod:spellCard/" + i);
        }
    }
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {	
    	if(thKaguyaLib.checkSpellCardDeclaration(world, itemStack, entityPlayer, itemStack.getItemDamage(), 2, true))
    	{
    		if(!world.isRemote)
    		{
    			itemStack.stackSize--;
    		}
    	}
    	
    	return itemStack;
   	}
	
	private boolean itemPossessionCheck(World world, EntityPlayer entityPlayer, int nomber)
	{
		/*switch(nomber)
		{
			case 1:*/
		return true;		
	}
	
	//インベントリにある限り常時呼び出されるメソッド
	@Override
	public void onUpdate(ItemStack itemStack, World world, Entity entity, int i, boolean flag)
	{
		int miracleTime = 0;
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt != null)
		{
			miracleTime = nbt.getInteger("Charge");
			if(miracleTime > 1)
			{
				nbt.setInteger("Charge", miracleTime - 1);
			}
			else
			{
				nbt.removeTag("Charge");
			}
		}
	}
	
	/*public String getItemDisplayName(ItemStack itemStack)
	{
		return spellCardName[itemStack.getItemDamage()];
	}*/
	
	//アイテムの表示情報付加
    @Override
	public void addInformation(ItemStack itemStack, EntityPlayer entityPlayer, List list, boolean bool)
	{
		super.addInformation(itemStack, entityPlayer, list, bool);
		
		int miracleTime = 0;
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt != null)
		{
			miracleTime = nbt.getInteger("Charge");
		}
		if(itemStack.getItemDamage() >= 14 && itemStack.getItemDamage() <= 18)
		{
			int level = 20 - ((14 - itemStack.getItemDamage()) * 5) ;
			list.add(StatCollector.translateToLocal("thKaguya.sneSc1") + level + StatCollector.translateToLocal("thKaguya.sneSc2")+ (itemStack.getItemDamage() - 13) + StatCollector.translateToLocal("thKaguya.sneSc3"));
			list.add(StatCollector.translateToLocal("thKaguya.sneSc4") + miracleTime / 10 + "%");
		}

	}
    
	//アイテムを発光させる。 trueなら発光
	@Override
	@SideOnly(Side.CLIENT)
	public boolean hasEffect(ItemStack itemStack)
	{   
		if(itemStack.getItemDamage() >= 14 && itemStack.getItemDamage() <= 18)
		{
			NBTTagCompound nbt = itemStack.getTagCompound();
			if(nbt != null)
			{
				if(nbt.getInteger("Charge") > 0)
				{
					return true;
				}
			}
		}
		return false;
	}
	
	@SideOnly(Side.CLIENT)
	//クリエイトモードのアイテム欄に、ダメージ値の違うアイテムも表示できるようにする
    public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List par3List)
    {
        for (int i = 0; i < mod_thKaguya.scEnName.length; i++)
        {
            par3List.add(new ItemStack(par1, 1, i));
        }
    }
	

}