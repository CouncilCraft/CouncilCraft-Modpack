package thKaguyaMod.item;

import java.util.List;

import thKaguyaMod.entity.EntityPrivateSquare;
import net.minecraftforge.common.MinecraftForge;
//import net.minecraftforge.common.IArmorTextureProvider;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.inventory.IInventory;

public class ItemMarisaHat extends ItemArmor// implements IArmorTextureProvider//ItemArmorを継承。これを継承しないと簡単に鎧を着ることができない。
{	
	
	//魔理沙の帽子
	//かぶると通常よりアイテムとの当たり判定が大きくなる
	
    public ItemMarisaHat(int i, EnumArmorMaterial enumarmormaterial, int j, int k)
    {
    	super(i,enumarmormaterial,j,k);//鎧の素材を、独自のものにしたいなら、EnumArmorMaterialを独自のものに変更すればいいはず
    	func_111206_d("thkaguyamod:MarisaHat");//テクスチャの指定
    	setMaxDamage(40);//アイテムの耐久設定
    }
    
	//アーマーのテクスチャを指定
	@Override
	public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type)
	{

		return "thkaguyamod:textures/armor/marisa_1.png";
	}
	
	//エンチャントの可否
	@Override
	public int getItemEnchantability()
    {
        return 0;//エンチャント不可
    }
	
	//Forgeの追加メソッド　エンチャントブックの使用を許可するか
	@Override
	public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
    {
        return false;
    }
	
	@SideOnly(Side.CLIENT)
    public boolean requiresMultipleRenderPasses()
    {
        return false;
    }
	
	/*
	 * IArmorTextureProviderで防具のテクスチャファイルを適当させているだけです。
	 * 頭、胴、足は"/armor/hogearmor_1.png"から
	 * 脚は"/armor/hogearmor_2.png"を参照させています。
	 */
	@SideOnly(Side.CLIENT)
	public String getArmorTextureFile(ItemStack itemstack)
	{
		return "/armor/hinezumi_1.png";
	}
	
	//アーマースロットに入っているときに呼び出される（Forge追加）
	public void onArmorTickUpdate(World world, EntityPlayer player, ItemStack itemStack)
    {	
   		//周囲のEntityを取得
		List list = world.getEntitiesWithinAABBExcludingEntity(player, player.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(5.0D, 5.0D, 5.0D));
		for(int k = 0; k < list.size(); k++)
		{
			Entity entity = (Entity)list.get(k);
			if(entity instanceof EntityItem)//アイテムがあるなら
			{
				EntityItem item = (EntityItem)entity;
				item.onCollideWithPlayer(player);
			}
		}
    }

	
	//アイテムを大きく表示する
	@Override
	public boolean isFull3D()
    {
        return true;
    }
}