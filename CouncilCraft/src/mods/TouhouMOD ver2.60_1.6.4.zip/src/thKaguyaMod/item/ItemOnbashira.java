package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;

import thKaguyaMod.mod_thKaguya;

import java.util.List;
import java.util.Random;

public class ItemOnbashira extends ItemSword
{

	/*
	御柱
	とてつもなく強力な武器
	しかし重くて、所持しているだけで動作に支障をきたす
	投げつけることもできる
	*/
    public ItemOnbashira(int itemID, EnumToolMaterial enumToolMaterial)
    {
        super(itemID, enumToolMaterial);
        func_111206_d("thkaguyamod:onbashira");//テクスチャの指定
    }
	

	//ブロックに対する強さ
	@Override
    public float getStrVsBlock(ItemStack itemStack, Block block)
    {
    	return 3F;
    }
	
	//Entityに当たったときの処理
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase hitEntityLivingBase, EntityLivingBase useEntityLivingBase)
    {
    	hitEntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(useEntityLivingBase), 5 + itemRand.nextInt(18));
    	itemStack.damageItem(1, useEntityLivingBase);
    	return true;
    }

	//Entityへのダメージ
	/*@Override
    public int getDamageVsEntity(Entity entity)
    {
        return 22;//ハート11個分のダメージ
    }*/
	
	//Forgeの追加メソッド
	//武器のダメージを返す
	@Override
    @Deprecated
    public float getDamageVsEntity(Entity hitEntity, ItemStack itemStack)
    {
        return 22.0F;
    }
	
	//所持している限り常時呼び出されるメソッド
	@Override
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
	{
		//移動速度が0.9倍になる。持てば持つほど移動速度が落ちる
		entity.motionX *= 0.9;
		entity.motionZ *= 0.9;
		if(entity.motionY > 0.0)
		{
			entity.motionY *= 0.9;
		}
		
		//entityがプレイヤーなら
		if(entity instanceof EntityPlayer)
		{
			EntityPlayer entityPlayer = (EntityPlayer)entity;
			//手に何か持っているなら
			if(entityPlayer.inventory.getCurrentItem() != null)
			{
				//プレイヤーが手にしているものが御柱なら
				if(entityPlayer.inventory.getCurrentItem().getItem() == mod_thKaguya.onbashiraItem)
				{
					if (!world.isRemote)
    				{
    					//	 				PotionEffect(ポーションのタイプ,持続時間（秒）*20（20は定数？）,レベル（0がレベル１、1がレベル２）)
        				entityPlayer.addPotionEffect(new PotionEffect( 4, 1 * 10, 0));//攻撃力アップ
    				}
				}
			}
    	}
	}

	@Override
    public boolean canHarvestBlock(Block block)
    {
    	return false;//特にブロックを取得はできない
    }
	
}
