package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;

public class ItemHeavenlyPeach extends ItemFood
{
	
	//天界の桃　食べると一時的に硬くなる
	
	public ItemHeavenlyPeach(int itemID, int foodLevel, boolean flag)
	{
		super(itemID, foodLevel, flag);
		func_111206_d("thkaguyamod:heavenlyPeach");//テクスチャの指定
		maxStackSize = 10;//10個まで持てる
		setAlwaysEdible();//いつでも食べられる
	}
	
	//食べたときの処理
	@Override
	protected void onFoodEaten(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
        if (!world.isRemote)
    	{
    		//	 				PotionEffect(ポーションのタイプ,持続時間（秒）*20（20は定数？）,レベル（0がレベル１、1がレベル２）)
        	entityPlayer.addPotionEffect(new PotionEffect(11, 20 * 20, 2));//防御力アップ
    	}
    }
	
}