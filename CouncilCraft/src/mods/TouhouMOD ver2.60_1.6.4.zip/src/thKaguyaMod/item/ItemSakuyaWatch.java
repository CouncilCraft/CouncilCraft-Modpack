package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import thKaguyaMod.entity.EntityPrivateSquare;

import java.util.List;
import java.util.Random;

public class ItemSakuyaWatch extends Item
{

	//周囲の時間を止めるアイテム　止まるのは基本移動のみ
	
	public ItemSakuyaWatch(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:sakuyaWatch");//テクスチャの指定
		maxStackSize = 1;
		setCreativeTab(CreativeTabs.tabMisc);//クリエイティブのその他タブに登録
	}
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
   	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
    {
		player.setItemInUse(itemStack, getMaxItemUseDuration(itemStack));
		
    	if(player.getFoodStats().getFoodLevel() > 0)//空腹ゲージ２以上で使用可能
    	{
    		int mode = 0;
    		if(player.isSneaking())//スニークなら低速モード　　通常は停止モード
    		{
    			mode = 2;
    		}
    		
    		boolean flag = true;
    		//周囲のEntityを取得
    		List list = world.getEntitiesWithinAABBExcludingEntity(player, player.boundingBox.addCoord(0.0D, 0.0D, 0.0D).expand(20.0D, 20.0D, 20.0D));
    		for(int k = 0; k < list.size(); k++)
    		{
    			Entity entity = (Entity)list.get(k);
    			if(entity instanceof EntityPrivateSquare)//懐中時計があるなら
    			{
    				EntityPrivateSquare entityPrivateSquare = (EntityPrivateSquare)entity;
    				if(entityPrivateSquare.userEntity == player)//その懐中時計の持ち主がこの時計の持ち主と同じなら
    				{
						return itemStack;//時計は出せない
    				}
    			}
    		}
    		/*if(!player.capabilities.isCreativeMode)//クリエイティブでないなら
    		{
    			if(mode == 0)
    			{
    				mode = 3;
    			}
    			else if(mode == 2)
    			{
    				mode = 4;
    			}
    			//world.playSoundAtEntity(player, "portal.travel", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));
    		}*/
    		//else
    		{
    			world.playSoundAtEntity(player, "random.click", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));
    		}
    		EntityPrivateSquare entityPrivateSquare = new EntityPrivateSquare(world, player, mode);
       		if(!world.isRemote)
       		{
         		world.spawnEntityInWorld(entityPrivateSquare);//時間停止空間を生み出す
         		itemStack.stackSize--;//スタックから消滅させる
       			
       		}
       		
    	}
    		
       	return itemStack;
    }
	
	//右クリックを終了したときに呼び出されるメソッド
	/*@Override
	public void onPlayerStoppedUsing(ItemStack itemStack, World world, EntityPlayer player, int usedTime)
	{

	}*/
	
    /*public ItemStack onEaten(ItemStack itemStack, World world, EntityPlayer player)
    {
        return itemStack;
    }
    
    public int getMaxItemUseDuration(ItemStack itemStack)
    {
        return 72000;
    }
	
	//アイテムを使ったときのアクションを指定
	@Override
	public EnumAction getItemUseAction(ItemStack itemStack)
	{
		return EnumAction.bow;
	}*/
}