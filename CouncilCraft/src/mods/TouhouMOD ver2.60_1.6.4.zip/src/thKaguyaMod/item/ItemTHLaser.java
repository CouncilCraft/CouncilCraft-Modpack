package thKaguyaMod.item;

import java.util.List;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import thKaguyaMod.mod_thKaguya;
import thKaguyaMod.thShotLib;
import thKaguyaMod.entity.EntityTHLaser;

import java.util.Random;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemTHLaser extends Item
{
	//単発レーザー
	
	//登録した英語名のアイテム名（？）
	public static final String laserNames[] =
    {
        "Laser", "Short Laser", "Long Laser"
    };
	//アイコンの名前。smallShot.pngを反映させるなら、"smallShot"で対応する。
	public static final String laserIconName[] =
	{
		"Laser1", "Laser2", "Laser3"
	};

	//各弾の弾速。
	public static final float speed[] =
	{
		0.6F, 0.6F, 0.5F, 0.3F, 0.6F, 0.6F, 0.6F, 0.65F, 0.3F, 0.5F,
	};

	//各弾IDの形状
	public static final int form[] =
	{
		thShotLib.SMALL[0]    , thShotLib.TINY[0]     , thShotLib.MEDIUM[0], thShotLib.BIG[0]  , 
		thShotLib.STAR[0]     , thShotLib.SMALLSTAR[0], thShotLib.CIRCLE[0], thShotLib.SCALE[0],
		thShotLib.BUTTERFLY[0], thShotLib.LIGHT[0]
	};
	
	public static final String danmakuForm[] =
	{
		"Point", "Random", "Sector", "Around", "Sphere", "未定義"
	};
	
	@SideOnly(Side.CLIENT)
    private Icon[] icon;

	public ItemTHLaser(int itemID)
	{
		super(itemID);
		setHasSubtypes(true);
		setMaxDamage(0);
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
	}
	
	public String getUnlocalizedName(ItemStack itemStack)
    {
        int i = MathHelper.clamp_int(itemStack.getItemDamage(), 0, 15);
        return super.getUnlocalizedName() + "." + laserNames[i];
    }
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, laserNames.length);
        return this.icon[i];
    }
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister)
    {
        this.icon = new Icon[laserIconName.length];

        for (int i = 0; i < laserIconName.length; ++i)
        {
            this.icon[i] = par1IconRegister.registerIcon("thkaguyamod:" + laserIconName[i]);
        }
    }
	
	//右クリックを押したときの処理
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player)
	{
		int type = itemStack.getItemDamage();
		int type2 = form[type] / 8;//IDの互換用
		int color = /*form[type] + */itemRand.nextInt(7);
		int sellectbleColor[] = {7, 0, 2, 0, 1, 4, 5, 7, 7, 4, 2, 3, 5, 4, 6, 7};//１６色の染料を８色に対応させるための配列
		ItemStack colorItem = player.inventory.mainInventory[player.inventory.currentItem + 1];//右横に持っている相手っ無を取得
		if(player.inventory.currentItem < 8 && colorItem != null)//右横にアイテムがあるなら
    	{
    		if(colorItem.itemID == Item.dyePowder.itemID)//そのアイテムが染料なら
    		{
    			//染料のダメージ値を取得
    			color = /*form[type] +*/ sellectbleColor[player.inventory.mainInventory[player.inventory.currentItem + 1].getItemDamage()];
    		}
    	}
		double length = 5.0D;
		if(type == 1)
		{
			length = 2.0D;
		}
		else if(type == 2)
		{
			length = 8.0D;
			//length = 20D;
		}
		
		int way = 1;
		double shotSpeed = speed[type];
		int danmakuForm = 0;
		int deadTime = 60;
		float damage = 5.0F;
		//double gravity = 0.0D;
		int i;
		
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt != null)
		{
			way = nbt.getShort("shotNum");
			danmakuForm = nbt.getByte("danmakuForm");
			shotSpeed = speed[type] * (1.0D + (double)nbt.getByte("shotSpeed") * 0.03D);
			//special = nbt.getByte("special");
			//gravity = (double)nbt.getByte("gravity") * -0.003D;
			
			int setColor = (int)nbt.getByte("shotColor");
			if(setColor != 9)
			{
				color = /*form[type] +*/ (int)nbt.getByte("shotColor");
			}
			//special = (int)nbt.getByte("Special");
    	}
		
		//configで設定した最高弾数より多いなら、最高弾数にする
		if(way > mod_thKaguya.laserMaxNumber)
		{
			way = mod_thKaguya.laserMaxNumber;
		}
		
		float angleXZ, angleY;
		
		switch(danmakuForm)
		{
			case 0:
				//color = thShotLib.CRYSTAL[ color % 8];
				double shotSpeedMin = shotSpeed / (double)way;
				double speedRate = 1.0D;
				double shotSpeed2 = shotSpeed;
				EntityTHLaser mother;
				Vec3 look = player.getLookVec();
			
				for(i = 1; i <= way; i++)
				{
					//thShotLib.createShot41(player, player.rotationYaw, player.rotationPitch, shotSpeed2, color, special);
					mother = thShotLib.createLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch, shotSpeed2, shotSpeed2, 0.0D, 0.0D, 0.0D, 0.0D,
							damage, color, 0.1F, 120, 0, 0, length);
					shotSpeed2 = shotSpeed / (double)way * (double)i;
					
					/*float angle = 0;
					Vec3 move = thShotLib.getRotationVectorFromAngle(player.rotationYaw, player.rotationPitch + 135F, 0F, 1.0D);
					
					for(int j = 0; j < 12; j++)
					{
						Vec3 rotate = thShotLib.getVectorFromRotation(look.xCoord, look.yCoord, look.zCoord, move.xCoord, move.yCoord, move.zCoord, angle);
						thShotLib.createLaserB(player, mother, mother.posX, mother.posY, mother.posZ, rotate.xCoord, rotate.yCoord, rotate.zCoord, look.xCoord, look.yCoord, look.zCoord, 10F, 5.0F, color, 0.2F, 120, 0, 0, 3.4D, mother, 0.0D, 0.0D);
						angle += 30F;
					}*/
				}
				break;
			case 1:
				float angleFl, angleSp;
				double xVec, yVec, zVec;
				double speed;
				for(i = 0; i < way; i++)
				{
					angleFl = itemRand.nextFloat() * (float)Math.PI * 2.0F;
					angleSp = (itemRand.nextFloat() * 30F - 15F) / 180F * (float)Math.PI;
					angleXZ = player.rotationYaw / 180F * (float)Math.PI + angleSp * (float)Math.sin(angleFl);
					angleY = player.rotationPitch / 180F * (float)Math.PI + angleSp * (float)Math.cos(angleFl);
					xVec = -MathHelper.sin(angleXZ) * MathHelper.cos(angleY);
					yVec = -MathHelper.sin(angleY);
					zVec =  MathHelper.cos(angleXZ) * MathHelper.cos(angleY);
					
					speed = shotSpeed * (itemRand.nextFloat() * 0.5F + 0.5F);
					thShotLib.createLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ,
							xVec, yVec, zVec, speed, speed, 0.0D, 
							0.0D, 0.0D, 0.0D, damage, color, 0.1F, 120, 0, 0, length);
				}
				break;
			case 2:
				//thShotLib.createWideShot01(player, player.rotationYaw, player.rotationPitch, shotSpeed, color, way, way * 3F);
				thShotLib.createWideLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch, shotSpeed, shotSpeed, 0.0D, 0.0D, 0.0D, 0.0D,
						damage, color, 0.1F, 120, 0, 0, length, way, way * 3F, 0.1D);
				break;
			case 3:
				thShotLib.createCircleLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, player.rotationYaw, player.rotationPitch, shotSpeed, shotSpeed, 0.0D, 0.0D, 0.0D, 0.0D,
						damage, color, 0.1F, 120, 0, 0, length, way, 0.1D);
				break;
			case 4:
				int way2 = (int)Math.sqrt(way);
				//int rest = way - way2 * way2;
				way2= way;
				/*float angleXZ = player.rotationYaw;
				float angleYSpan = 180F / (float)(way2 + 1);
				float angleY = player.rotationPitch + angleYSpan - 90F;
				for(i = 0; i < way2; i++)
				{
					thShotLib.createCircleShot01(player, angleXZ, angleY, shotSpeed, color, way2);
					//angleXZ += 17F;
					angleY += angleYSpan;
				}
				if(rest >= 2)
				{
					thShotLib.createShot01(player, player.rotationYaw, -90F, shotSpeed, color);
					thShotLib.createShot01(player, player.rotationYaw,  90F, shotSpeed, color);
				}*/	
				angleXZ = itemRand.nextFloat() * 360F;
				float angleXZSpan = 0F;
				angleY = -90F;
				float angleYSpan = 180F / (way2 * 2 - 4);
				int n = 1;
				while(n <= way2 )
				{
					if(n != 2)
					{
					angleXZSpan = 360F / n;
					angleXZ = itemRand.nextFloat() * 360F;
					for(int n2 = 1; n2 <= n; n2++)
					{
						//thShotLib.createShot41(player, angleXZ, angleY, shotSpeed, color, special);
						thShotLib.createLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, angleXZ, angleY, shotSpeed, shotSpeed, 0.0D, 0.0D, 0.0D, 0.0D,
								damage, color, 0.1F, 120, 0, 0, length);
						angleXZ += angleXZSpan;
					}
					angleY += angleYSpan;
					}
					n++;
				}
				n--;
				while(n >= 1 )
				{
					if(n != 2)
					{
					angleXZSpan = 360F / n;
					angleXZ = itemRand.nextFloat() * 360F;
					for(int n2 = 1; n2 <= n; n2++)
					{
						thShotLib.createLaserA(player, player, player.posX, thShotLib.getPosYFromEye(player, -0.2D), player.posZ, angleXZ, angleY, shotSpeed, shotSpeed, 0.0D, 0.0D, 0.0D, 0.0D,
								damage, color, 0.1F, 120, 0, 0, length);
						angleXZ += angleXZSpan;
					}
					angleY += angleYSpan;
					}
					n--;
				}
				break;
			default:
				break;
		}

		//thShotLib.createLaserABaseB(entityPlayer, entityPlayer, entityPlayer.posX, thShotLib.getPosYFromEye(entityPlayer, -0.2D), entityPlayer.posZ, entityPlayer.rotationYaw, entityPlayer.rotationPitch,
		//							0.1D, 0.4D, 0.05D, 0.0D, 0.0D, 0.0D, 6, color, 0.1F, 120, 0, 0, length);
		if(!world.isRemote)
		{
			itemStack.stackSize --;
		}
		
		return itemStack;
	}

	
	@SideOnly(Side.CLIENT)
	//クリエイトモードのアイテム欄に、ダメージ値の違うアイテムも表示できるようにする
    public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List par3List)
    {
        for (int i = 0; i < laserNames.length; i++)
        {
            par3List.add(new ItemStack(par1, 1, i));
        }
    }
	
    @Override
	public void addInformation(ItemStack itemStack, EntityPlayer entityPlayer, List list, boolean bool)
	{
		super.addInformation(itemStack, entityPlayer, list, bool);
		int type = itemStack.getItemDamage();
		short shotNum = 1;
		byte form = 0;
		float shotSpeed = (float)speed[type];
		int color = 8;
		//double gravity = 0.0D;
		//byte bound = 0;
		
		
		NBTTagCompound nbt = itemStack.getTagCompound();
		if(nbt != null)
		{
			shotNum = nbt.getShort("shotNum");
			form = nbt.getByte("danmakuForm");
			shotSpeed = (float)speed[type] * (1.0F + (float)nbt.getByte("shotSpeed") * 0.03F);
			color = nbt.getByte("shotColor");
			//gravity = (double)nbt.getByte("gravity") * 0.003D;
			//bound = (byte)(nbt.getByte("special") - thShotLib.BOUND01 + 1);
		}
		
		if(form >= danmakuForm.length)
		{
			form = (byte)(danmakuForm.length - 1);
		}
		
		String number = "" + shotNum;
		if(form == (byte)4)
		{
			number = number + " ✕ " + shotNum;
		}
		
		/*String special = "G Free";
		if((int)nbt.getByte("special") == thShotLib.FALL01)
		{
			special = "Fall";
		}*/
		
		//shotSpeed
		
		list.add(StatCollector.translateToLocal("danmakuCrafting.damage") + " : 2.5");
		list.add(StatCollector.translateToLocal("danmakuCrafting.number") + " : " + number);
		list.add(StatCollector.translateToLocal("danmakuCrafting.form") + " : " + StatCollector.translateToLocal("thKaguya.danmakuForm." + form));
		list.add(StatCollector.translateToLocal("danmakuCrafting.speed") + " : " + shotSpeed);
		/*if(gravity != 0.0D)
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.gravity") + " : " + gravity);
		}
		else
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.gravity") + " : GFree");
		}*/
		list.add(StatCollector.translateToLocal("danmakuCrafting.color") + " : " + StatCollector.translateToLocal("thKaguya.color." + color));
		/*if(bound >= 1 && bound <= 3)
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.bound") + " : " + bound);
		}
		else if(bound == 4)
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.bound") + " : Infinity");
		}
		else
		{
			list.add(StatCollector.translateToLocal("danmakuCrafting.bound") + " : 0");
		}
		//list.add("Special: " + special);*/
	}
	
}