package thKaguyaMod.item;

import java.util.List;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Icon;

import thKaguyaMod.entity.EntitySilverKnife;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemSilverKnife extends Item
{
	//咲夜の銀のナイフ　　投げてよし、切ってよし
	
	public static final String knifeColorNames[] =
    {
        "Silver Knife blue", "Silver Knife red", "Silver Knife green", "Silveer Knife white"
    };
	public static final String knifeIconName[] =
	{
		"silverKnife_Blue", "silverKnife_Red", "silverKnife_Green", "silverKnife_White"
	};
	
    @SideOnly(Side.CLIENT)
    private Icon[] icon;
	
	public ItemSilverKnife(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:silverKnife_Blue");//テクスチャの指定
		setHasSubtypes(true);
		setMaxDamage(0);
		setCreativeTab(CreativeTabs.tabCombat);//クリエイティブの武器タブに登録
	}
	
	public String getUnlocalizedName(ItemStack itemStack)
    {
        int i = MathHelper.clamp_int(itemStack.getItemDamage(), 0, 15);
        return super.getUnlocalizedName() + "." + knifeColorNames[i];
    }
	
	@SideOnly(Side.CLIENT)
	//ダメージ値によってアイテムアイコンを変える
    public Icon getIconFromDamage(int damage)
    {
        int i = MathHelper.clamp_int(damage, 0, 3);
        return this.icon[i];
    }
	
	@SideOnly(Side.CLIENT)
    public void registerIcons(IconRegister iconRegister)
    {
        this.icon = new Icon[knifeIconName.length];

        for (int i = 0; i < knifeIconName.length; ++i)
        {
            this.icon[i] = iconRegister.registerIcon("thkaguyamod:" + knifeIconName[i]);
        }
    }
	
	//Entityに当たったときの処理
    public boolean hitEntity(ItemStack itemStack, EntityLivingBase hitEntityLivingBase, EntityLivingBase useEntityLivingBase)
    {
    	hitEntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(useEntityLivingBase), 3.0F);
    	if(itemStack.getItemDamage() == 3)
    	{
    		itemStack.stackSize--;
    	}
    	return true;
    }
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	double xVec,yVec,zVec;
    	double speed = 1.0D;
    	EntitySilverKnife entitySilverKnife;

    	xVec = -Math.sin(entityPlayer.rotationYaw / 180F * 3.141593F) * Math.cos(entityPlayer.rotationPitch / 180F * 3.141593F) * speed;//X方向　水平方向
    	yVec = -Math.sin(entityPlayer.rotationPitch / 180F * 3.141593F) * speed;//Y方向　上下
    	zVec =  Math.cos(entityPlayer.rotationYaw / 180F * 3.141593F) * Math.cos(entityPlayer.rotationPitch / 180F * 3.141593F) * speed;//Z方向　水平方向
    	entitySilverKnife = new EntitySilverKnife(world, entityPlayer, entityPlayer.posX + xVec, entityPlayer.posY + yVec + (double)entityPlayer.getEyeHeight() - 0.10000000149011612D, entityPlayer.posZ + zVec,
   			xVec, yVec, zVec, 0.28D, itemStack.getItemDamage());
       	
    	world.playSoundAtEntity(entityPlayer, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 4F + 0.8F));//音を出す
       	
    	if(!world.isRemote)
       	{
			world.spawnEntityInWorld(entitySilverKnife);//銀のナイフを出現させる
			itemStack.stackSize--;//一つ消費
       	}
    	
    	entityPlayer.swingItem();//投げる動作をさせる
        
    	return itemStack;
    }
	
	@SideOnly(Side.CLIENT)
	//クリエイトモードのアイテム欄に、ダメージ値の違うアイテムも表示できるようにする
    public void getSubItems(int damage, CreativeTabs creativeTabs, List list)
    {
        for (int i = 0; i < 3; i++)
        {
            list.add(new ItemStack(damage, 1, i));
        }
    }
}