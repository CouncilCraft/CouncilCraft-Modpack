package thKaguyaMod.item;

import net.minecraft.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.block.Block;

import java.util.List;

public class ItemDeathScythe extends ItemSword
{

	//死神の大鎌
	//周囲の動物やモンスターを引き寄せたり、離したりできる
	
    public ItemDeathScythe(int itemID, EnumToolMaterial enumToolMaterial)
    {
        super(itemID, enumToolMaterial);
        func_111206_d("thkaguyamod:deathScythe");//テクスチャの指定
        setMaxDamage(444);
    }
	
	//右クリックを押したときに呼び出されるメソッド
	@Override
   	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	//プレイヤーの当たり判定を取得して、周囲のEntityとの接触を調べる
    	Entity entity = null;
    	List list = world.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.boundingBox.expand(10.0D, 10.0D,10.0D));//プレイヤーを中心に10ブロックの立方体内の当たりを取得
    	double ax, ay, az, dx, dy, dz, power;
		float angleXZ, angleY;
    	float epYaw = (360F-entityplayer.rotationYaw) % 360F;
    	if(epYaw < 0F)
    	{
    		epYaw -= 360F;
    	}
    	boolean check;
    	power = 0.4D;//引力、斥力の力

        if (list != null && list.size() > 0)
        {
            for (int j1 = 0; j1 < list.size(); j1++)
            {
                entity = (Entity)list.get(j1);
                if ( (entity.canBePushed() || entity instanceof EntityPlayer) && entity instanceof EntityLivingBase)//押すことができて、生物なら
            	{
            		EntityLivingBase EntityLivingBase = (EntityLivingBase)entity;
            		if(entityplayer.canEntityBeSeen(EntityLivingBase))//間に壁があれば無効
            		{
						dx = EntityLivingBase.posX - entityplayer.posX;//Entityと使用者の各要素の距離を保存
						dy = EntityLivingBase.posY - entityplayer.posY;
						dz = EntityLivingBase.posZ - entityplayer.posZ;
			
						angleY  = (float)Math.atan2(dx, dz);//平面上の角度を求める
						angleXZ = (float)Math.atan2( dy, Math.sqrt( dx*dx + dz*dz));//上下方向の角度を求める
	            		check = false;
	            		
	            		float angleYDeg = angleY / 3.141593F * 180F;
	            		//水平方向の判定　見ている方向の-20～+20の角度をカバー
	            		if(angleYDeg < 0F)
	            		{
	            			angleYDeg += 360F;
	            		}
	            		
            			//見ている角度epYawとEntityまでの角度angleYDegを0～360に固定して判定
            			//20～340のときはそのまま判定
	            		if(epYaw > 20F && epYaw < 340F)
	            		{
	            			if(epYaw-20F < angleYDeg && epYaw+20F > angleYDeg)
	            			{
	            				check = true;
	            			}
	            		}
            			//20以下のときは少し特殊な判定を与えないとできない
	            		else if(epYaw <= 20F)
	            		{
	            			if( (0F <= angleYDeg && epYaw+20F >= angleYDeg ) || 
	            				(360F-epYaw < angleYDeg && 360F > angleYDeg))
	            			{
	            				check = true;
	            			}
	            		}
            			//340以上　同上
	            		else
	            		{
	            			if( (20F-(360F-epYaw) >= angleYDeg && 0F <= angleYDeg ) || 
	            				(epYaw-20F < angleYDeg && 360F > angleYDeg))
	            			{
	            				check = true;
	            			}
	            		}
	            		if(check)
	            		{
	                		if(entityplayer.isSneaking())//スニークなら斥力
	                		{
	                			EntityLivingBase.motionX += Math.sin(angleY) * Math.cos(angleXZ) * power;//powerの分だけ斥力を働かせる
	                			EntityLivingBase.motionY += Math.sin(angleXZ) * power;
	                			EntityLivingBase.motionZ += Math.cos(angleY) * Math.cos(angleXZ) * power;
		                	}
		                	else//スニークじゃないなら引力
		                	{
		                		EntityLivingBase.motionX -= Math.sin(angleY) * Math.cos(angleXZ) * power;//powerの分だけ引力を働かせる
		                		EntityLivingBase.motionY -= Math.sin(angleXZ) * power;
		                		EntityLivingBase.motionZ -= Math.cos(angleY) * Math.cos(angleXZ) * power;
		                	}
	            			itemstack.damageItem(1, entityplayer);//距離を操った生物の数だけ耐久が減る
	            		}
            		}
                }
            }
        }
       	return itemstack;
    }
	
	//武器のダメージを返す
	/*@Override
	public int getDamageVsEntity(Entity entity)
    {
        return 6;
    }*/
	
	//Forgeの追加メソッド
	//武器のダメージを返す
	@Override
    @Deprecated
    public float getDamageVsEntity(Entity hitEntity, ItemStack itemStack)
    {
        return 6.0F; //getDamageVsEntity(par1Entity);
    }

	@Override
    public boolean canHarvestBlock(Block block)
    {
    	return false;//特にブロックを壊せるわけではない
    }

	//エンチャン適性値
	@Override
    public int getItemEnchantability()
    {
        return 7;
    }
	

	
}
