package thKaguyaMod.item;

import net.minecraftforge.common.MinecraftForge;
import net.minecraft.item.*;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import thKaguyaMod.entity.EntityPendulum;

import java.util.List;
import java.util.Random;

public class ItemPendulum extends Item
{
	
	//ナズーリンペンデュラム
	//ナズーリンの持つペンデュラム
	//使用時の横に持っていたアイテム（ブロックのみ）が周囲にあるか探索する
	//ダイヤの探索などに使える。といっても、この仕様ではダイヤ鉱石もっていないと・・・
	//Shiftで使用すると高感度モードになる
	
	public ItemPendulum(int itemID)
	{
		super(itemID);
		func_111206_d("thkaguyamod:pendulum");//テクスチャの指定
		maxStackSize = 1;
		setCreativeTab(CreativeTabs.tabMisc);//クリエイティブのその他タブに登録
	}
	
	//右クリックを終了したときに呼び出されるメソッド
	@Override
	public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer entityPlayer)
    {
    	int blockID = -1;
    	Item item = null;
    	ItemStack searchItem = entityPlayer.inventory.mainInventory[entityPlayer.inventory.currentItem + 1];
    	if(entityPlayer.inventory.currentItem < 8 && searchItem != null)
    	{
    		blockID = searchItem.itemID;
    		item = searchItem.getItem();
    	}
    	else
    	{
    		return itemStack;
    	}
    	if(searchItem.itemID > 4095)//ブロック以外のアイテムはサーチできなくする
    	{
    		return itemStack;
    	}
    	/*if(!searchItem.canEditBlocks())
    	{
    		return itemStack;
    	}*/
    	
    	int mode = 0;
    	if(entityPlayer.isSneaking())//スニークなら高感度ナズーリンペンデュラムになる
    	{
    		mode = 1;
    	}
    	
    	EntityPendulum entityPendulum;
    	entityPendulum = new EntityPendulum(world, entityPlayer, mode, blockID);
    	world.playSoundAtEntity(entityPlayer, "random.orb", 0.5F, 0.9F);
       	if(!world.isRemote)
       	{
        	world.spawnEntityInWorld(entityPendulum);//ペンデュラムを出現させる
       		itemStack.stackSize--;//スタックから消滅させる
       	}
    	
    	//使用時のメッセージを表示
    	String str;
    	if(mode == 0)
    	{
    		//StatCollector.translateToLocal("thKaguya.item.kishitu")
    		str = StatCollector.translateToLocal("thKaguya.pendulum1") + item.getItemDisplayName(searchItem) + StatCollector.translateToLocal("thKaguya.pendulum2");
    	}
    	else
    	{
    		str = StatCollector.translateToLocal("thKaguya.pendulum1") + item.getItemDisplayName(searchItem) + StatCollector.translateToLocal("thKaguya.pendulum3");
    	}
    	if(!world.isRemote)
    	{
    		entityPlayer.addChatMessage( str );
    	}
    	
    	return itemStack;
   	}
	
	//Forgeの追加メソッド
	/*@Override
	public boolean onItemUseFirst(ItemStack itemStack, EntityPlayer entityPlayer, World world, int x, int y, int z, int surface, float hitX, float hiyY, float hitZ) 
	{
		int blockID = world.getBlockId(x, y, z);
		String name = getBlock(x, y, z).getUnlocalizedName();
		spawnPendulum(world, itemStack, entityPlayer, blockID, name);
		return true;
	}
	
	private ItemStack spawnPendulum(World world, ItemStack itemStack, EntityPlayer entityPlayer, int blockID, String name)
	{
		int mode = 0;
    	if(entityPlayer.isSneaking())//スニークなら高感度ナズーリンペンデュラムになる
    	{
    		mode = 1;
    	}
		
		EntityPendulum entityPendulum;
    	entityPendulum = new EntityPendulum(world, entityPlayer, mode, blockID);
    	world.playSoundAtEntity(entityPlayer, "random.orb", 0.5F, 0.9F);
       	if(!world.isRemote)
       	{
        	world.spawnEntityInWorld(entityPendulum);//ペンデュラムを出現させる
       		itemStack.stackSize--;//スタックから消滅させる
       	}
    	
    	//使用時のメッセージを表示
    	String str;
    	if(mode == 0)
    	{
    		str = "Pendulum started searching for " + name;
    	}
    	else
    	{
    		str = "Pendulum started searching for " + name + " by High sensitivity mode!";
    	}
    	if(!world.isRemote)
    	{
    		entityPlayer.addChatMessage( str );
    	}
		
		return itemStack;
	}*/

}